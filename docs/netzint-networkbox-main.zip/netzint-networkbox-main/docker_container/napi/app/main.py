import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.routers import health, wake, scan, tcpdump, nmap, analyze, snmp

# Configure logging
logging.basicConfig(
    level=logging.DEBUG if settings.debug else logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    logger.info(f"Starting {settings.app_name} v{settings.app_version}")
    yield
    logger.info("Shutting down NAPI")


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Internal Network API for NetworkBox - provides WOL and network scanning capabilities",
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None,
    lifespan=lifespan
)

# Include routers
app.include_router(health.router)
app.include_router(wake.router)
app.include_router(scan.router)
app.include_router(tcpdump.router)
app.include_router(nmap.router)
app.include_router(analyze.router)
app.include_router(snmp.router)


@app.get("/")
async def root():
    """Root endpoint - redirects to health check."""
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "status": "running"
    }
