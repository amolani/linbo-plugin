from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "NetworkBox NAPI"
    app_version: str = "2.0.0"
    debug: bool = False

    # Scanner settings
    ping_timeout: float = 1.0
    ping_workers: int = 50
    arp_timeout: float = 2.0
    dns_timeout: float = 0.5

    class Config:
        env_prefix = "NAPI_"


settings = Settings()
