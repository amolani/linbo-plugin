import logging
import asyncio
from typing import Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# Standard OIDs
OIDS = {
    # System
    "sysDescr": "1.3.6.1.2.1.1.1.0",
    "sysName": "1.3.6.1.2.1.1.5.0",
    # IF-MIB
    "ifDescr": "1.3.6.1.2.1.2.2.1.2",
    "ifName": "1.3.6.1.2.1.31.1.1.1.1",
    "ifAlias": "1.3.6.1.2.1.31.1.1.1.18",
    "ifInOctets": "1.3.6.1.2.1.2.2.1.10",
    "ifOutOctets": "1.3.6.1.2.1.2.2.1.16",
    "ifInDiscards": "1.3.6.1.2.1.2.2.1.13",
    "ifOutDiscards": "1.3.6.1.2.1.2.2.1.19",
    "ifInErrors": "1.3.6.1.2.1.2.2.1.14",
    "ifOutErrors": "1.3.6.1.2.1.2.2.1.20",
    "ifOperStatus": "1.3.6.1.2.1.2.2.1.8",
    "ifAdminStatus": "1.3.6.1.2.1.2.2.1.7",
    "ifSpeed": "1.3.6.1.2.1.2.2.1.5",
    # BRIDGE-MIB (STP)
    "dot1dStpTopChanges": "1.3.6.1.2.1.17.2.4.0",
    "dot1dStpTimeSinceTopologyChange": "1.3.6.1.2.1.17.2.3.0",
    "dot1dStpPortState": "1.3.6.1.2.1.17.2.15.1.3",
    "dot1dBasePortIfIndex": "1.3.6.1.2.1.17.1.4.1.2",
    # Q-BRIDGE-MIB (MAC Table with VLAN)
    "dot1qTpFdbPort": "1.3.6.1.2.1.17.7.1.2.2.1.2",
    # BRIDGE-MIB (MAC Table without VLAN - fallback)
    "dot1dTpFdbAddress": "1.3.6.1.2.1.17.4.3.1.1",
    "dot1dTpFdbPort": "1.3.6.1.2.1.17.4.3.1.2",
    # EtherLike-MIB
    "dot3StatsFCSErrors": "1.3.6.1.2.1.10.7.2.1.3",
}

# STP Port States
STP_PORT_STATES = {
    1: "disabled",
    2: "blocking",
    3: "listening",
    4: "learning",
    5: "forwarding",
    6: "broken"
}


@dataclass
class SNMPTarget:
    ip_address: str
    version: str = "v2c"
    community: str = "public"
    username: str = ""
    auth_protocol: str = ""
    auth_password: str = ""
    priv_protocol: str = ""
    priv_password: str = ""
    port: int = 161
    timeout: float = 2.0
    retries: int = 2


class SNMPPoller:
    """SNMP polling service for switch data collection using pysnmp."""

    def __init__(self):
        self._engine = None

    def _create_auth_data(self, target: SNMPTarget):
        """Create authentication data for SNMP request."""
        try:
            from pysnmp.hlapi.v3arch.asyncio import CommunityData, UsmUserData

            if target.version == "v2c":
                return CommunityData(target.community, mpModel=1)
            elif target.version == "v3":
                # Map protocol names to pysnmp constants
                from pysnmp.hlapi.v3arch.asyncio import (
                    usmHMACMD5AuthProtocol,
                    usmHMACSHAAuthProtocol,
                    usmHMAC128SHA224AuthProtocol,
                    usmHMAC192SHA256AuthProtocol,
                    usmDESPrivProtocol,
                    usmAesCfb128Protocol,
                    usmAesCfb256Protocol,
                    usmNoAuthProtocol,
                    usmNoPrivProtocol
                )

                auth_protocols = {
                    "MD5": usmHMACMD5AuthProtocol,
                    "SHA": usmHMACSHAAuthProtocol,
                    "SHA224": usmHMAC128SHA224AuthProtocol,
                    "SHA256": usmHMAC192SHA256AuthProtocol,
                    "": usmNoAuthProtocol
                }

                priv_protocols = {
                    "DES": usmDESPrivProtocol,
                    "AES": usmAesCfb128Protocol,
                    "AES128": usmAesCfb128Protocol,
                    "AES256": usmAesCfb256Protocol,
                    "": usmNoPrivProtocol
                }

                auth_proto = auth_protocols.get(target.auth_protocol.upper(), usmNoAuthProtocol)
                priv_proto = priv_protocols.get(target.priv_protocol.upper(), usmNoPrivProtocol)

                return UsmUserData(
                    target.username,
                    authKey=target.auth_password or None,
                    privKey=target.priv_password or None,
                    authProtocol=auth_proto,
                    privProtocol=priv_proto
                )
            else:
                # Default to v2c
                return CommunityData(target.community, mpModel=1)
        except ImportError:
            logger.error("pysnmp not installed")
            raise ImportError("pysnmp is required for SNMP operations")

    async def _get_single_oid(self, target: SNMPTarget, oid: str) -> Optional[str]:
        """Get a single OID value."""
        try:
            from pysnmp.hlapi.v3arch.asyncio import (
                get_cmd, SnmpEngine, UdpTransportTarget, ContextData, ObjectType, ObjectIdentity
            )

            engine = SnmpEngine()
            auth_data = self._create_auth_data(target)
            transport = await UdpTransportTarget.create(
                (target.ip_address, target.port),
                timeout=target.timeout,
                retries=target.retries
            )

            error_indication, error_status, error_index, var_binds = await get_cmd(
                engine,
                auth_data,
                transport,
                ContextData(),
                ObjectType(ObjectIdentity(oid))
            )

            if error_indication:
                logger.error(f"SNMP error: {error_indication}")
                return None
            if error_status:
                logger.error(f"SNMP error status: {error_status.prettyPrint()}")
                return None

            for var_bind in var_binds:
                return str(var_bind[1])

            return None
        except Exception as e:
            logger.error(f"SNMP get failed: {e}")
            return None

    async def _walk_oid(self, target: SNMPTarget, oid: str) -> dict:
        """Walk an OID tree and return results as dict."""
        try:
            from pysnmp.hlapi.v3arch.asyncio import (
                bulk_walk_cmd, SnmpEngine, UdpTransportTarget, ContextData,
                ObjectType, ObjectIdentity
            )

            results = {}
            engine = SnmpEngine()
            auth_data = self._create_auth_data(target)
            transport = await UdpTransportTarget.create(
                (target.ip_address, target.port),
                timeout=target.timeout,
                retries=target.retries
            )

            async for error_indication, error_status, error_index, var_binds in bulk_walk_cmd(
                engine,
                auth_data,
                transport,
                ContextData(),
                0, 25,  # non-repeaters, max-repetitions
                ObjectType(ObjectIdentity(oid)),
                lexicographicMode=False
            ):
                if error_indication:
                    logger.error(f"SNMP walk error: {error_indication}")
                    break
                if error_status:
                    logger.error(f"SNMP walk status error: {error_status.prettyPrint()}")
                    break

                for var_bind in var_binds:
                    oid_str = str(var_bind[0])
                    value = var_bind[1]
                    # Extract index from OID (last part after base OID)
                    if oid_str.startswith(oid):
                        index = oid_str[len(oid):].lstrip(".")
                        results[index] = value

            return results
        except Exception as e:
            logger.error(f"SNMP walk failed for {oid}: {e}")
            return {}

    async def test_connection(self, target: SNMPTarget) -> dict:
        """Test SNMP connection by getting system name."""
        try:
            sys_name = await self._get_single_oid(target, OIDS["sysName"])
            sys_descr = await self._get_single_oid(target, OIDS["sysDescr"])

            if sys_name is not None:
                return {
                    "success": True,
                    "system_name": sys_name,
                    "system_description": sys_descr or ""
                }
            return {
                "success": False,
                "error": "No response from device"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }

    async def get_mac_table(self, target: SNMPTarget) -> list[dict]:
        """
        Get MAC address table from switch.
        Tries Q-BRIDGE-MIB first (VLAN-aware), falls back to BRIDGE-MIB.
        """
        mac_table = []

        # Try Q-BRIDGE-MIB first (dot1qTpFdbPort)
        try:
            qbridge_results = await self._walk_oid(target, OIDS["dot1qTpFdbPort"])

            if qbridge_results:
                for index, port_value in qbridge_results.items():
                    # Index format: vlan_id.mac_bytes (e.g., "100.0.37.69.1.2.3")
                    parts = index.split(".")
                    if len(parts) >= 7:
                        vlan_id = int(parts[0])
                        mac_bytes = parts[1:7]
                        mac_addr = ":".join(f"{int(b):02x}" for b in mac_bytes)
                        port = int(port_value)

                        mac_table.append({
                            "mac": mac_addr,
                            "port": port,
                            "vlan": vlan_id
                        })

                logger.debug(f"Got {len(mac_table)} MAC entries from Q-BRIDGE-MIB")
                return mac_table
        except Exception as e:
            logger.debug(f"Q-BRIDGE-MIB not available: {e}")

        # Fallback to BRIDGE-MIB (dot1dTpFdbTable)
        try:
            bridge_results = await self._walk_oid(target, OIDS["dot1dTpFdbPort"])

            for index, port_value in bridge_results.items():
                # Index format: mac_bytes (e.g., "0.37.69.1.2.3")
                parts = index.split(".")
                if len(parts) >= 6:
                    mac_bytes = parts[:6]
                    mac_addr = ":".join(f"{int(b):02x}" for b in mac_bytes)
                    port = int(port_value)

                    mac_table.append({
                        "mac": mac_addr,
                        "port": port,
                        "vlan": 0  # No VLAN info in BRIDGE-MIB
                    })

            logger.debug(f"Got {len(mac_table)} MAC entries from BRIDGE-MIB")
        except Exception as e:
            logger.error(f"BRIDGE-MIB also failed: {e}")

        return mac_table

    async def get_stp_status(self, target: SNMPTarget) -> dict:
        """Get STP status including topology changes."""
        result = {
            "topology_changes": 0,
            "time_since_tc": 0,
            "port_states": {}
        }

        # Get topology change count
        tc_count = await self._get_single_oid(target, OIDS["dot1dStpTopChanges"])
        if tc_count:
            try:
                result["topology_changes"] = int(tc_count)
            except ValueError:
                pass

        # Get time since last topology change (in centiseconds)
        time_since = await self._get_single_oid(target, OIDS["dot1dStpTimeSinceTopologyChange"])
        if time_since:
            try:
                result["time_since_tc"] = int(time_since) // 100  # Convert to seconds
            except ValueError:
                pass

        # Get port states
        try:
            port_states = await self._walk_oid(target, OIDS["dot1dStpPortState"])
            for port_index, state_value in port_states.items():
                try:
                    port_num = int(port_index)
                    state_num = int(state_value)
                    result["port_states"][port_num] = STP_PORT_STATES.get(state_num, "unknown")
                except ValueError:
                    pass
        except Exception as e:
            logger.debug(f"Could not get STP port states: {e}")

        return result

    async def get_interface_counters(self, target: SNMPTarget) -> list[dict]:
        """Get interface counters (octets, errors, discards)."""
        interfaces = []

        # Get interface names
        if_names = await self._walk_oid(target, OIDS["ifName"])
        if not if_names:
            if_names = await self._walk_oid(target, OIDS["ifDescr"])

        # Get counters
        in_octets = await self._walk_oid(target, OIDS["ifInOctets"])
        out_octets = await self._walk_oid(target, OIDS["ifOutOctets"])
        in_discards = await self._walk_oid(target, OIDS["ifInDiscards"])
        out_discards = await self._walk_oid(target, OIDS["ifOutDiscards"])
        in_errors = await self._walk_oid(target, OIDS["ifInErrors"])
        out_errors = await self._walk_oid(target, OIDS["ifOutErrors"])
        oper_status = await self._walk_oid(target, OIDS["ifOperStatus"])
        if_speed = await self._walk_oid(target, OIDS["ifSpeed"])

        for if_index, name in if_names.items():
            try:
                idx = str(if_index)
                interface = {
                    "if_index": int(if_index),
                    "name": str(name),
                    "in_octets": int(in_octets.get(idx, 0)),
                    "out_octets": int(out_octets.get(idx, 0)),
                    "in_discards": int(in_discards.get(idx, 0)),
                    "out_discards": int(out_discards.get(idx, 0)),
                    "in_errors": int(in_errors.get(idx, 0)),
                    "out_errors": int(out_errors.get(idx, 0)),
                    "oper_status": "up" if int(oper_status.get(idx, 2)) == 1 else "down",
                    "speed_mbps": int(if_speed.get(idx, 0)) // 1000000
                }
                interfaces.append(interface)
            except (ValueError, TypeError) as e:
                logger.debug(f"Error parsing interface {if_index}: {e}")
                continue

        return interfaces

    async def poll_all(self, target: SNMPTarget) -> dict:
        """Poll all relevant data from a switch."""
        # Run all polls concurrently
        mac_table_task = asyncio.create_task(self.get_mac_table(target))
        stp_task = asyncio.create_task(self.get_stp_status(target))
        counters_task = asyncio.create_task(self.get_interface_counters(target))

        mac_table = await mac_table_task
        stp_status = await stp_task
        counters = await counters_task

        return {
            "mac_table": mac_table,
            "stp_status": stp_status,
            "interface_counters": counters,
            "timestamp": asyncio.get_event_loop().time()
        }


# Singleton instance
snmp_poller = SNMPPoller()
