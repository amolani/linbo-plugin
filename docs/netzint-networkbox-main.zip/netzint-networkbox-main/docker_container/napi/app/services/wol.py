import socket
import struct
import logging

logger = logging.getLogger(__name__)


def create_magic_packet(mac: str) -> bytes:
    """Create a Wake-on-LAN magic packet for the given MAC address."""
    # Remove delimiters and convert to bytes
    mac_bytes = bytes.fromhex(mac.replace(":", ""))

    # Magic packet: 6 bytes of 0xFF followed by MAC repeated 16 times
    return b"\xff" * 6 + mac_bytes * 16


def send_wol(mac: str, ip: str = "255.255.255.255", port: int = 9) -> None:
    """
    Send a Wake-on-LAN magic packet.

    Args:
        mac: MAC address in format XX:XX:XX:XX:XX:XX
        ip: Broadcast IP address
        port: UDP port (default: 9)

    Raises:
        OSError: If sending fails
    """
    packet = create_magic_packet(mac)

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.sendto(packet, (ip, port))

    logger.info(f"WOL packet sent to {mac} via {ip}:{port}")
