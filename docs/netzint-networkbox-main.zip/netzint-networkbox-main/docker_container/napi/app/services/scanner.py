import asyncio
import ipaddress
import socket
import subprocess
import re
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Optional, AsyncGenerator

from icmplib import ping as icmp_ping, ICMPLibError

from app.config import settings
from app.models import DeviceInfo

logger = logging.getLogger(__name__)


def find_interface_for_subnet(subnet: str) -> Optional[str]:
    """
    Find the network interface that can reach a given subnet.

    Uses 'ip addr' command to find interfaces, which works better with
    dynamically added macvlan interfaces than Scapy.

    Args:
        subnet: Subnet in CIDR notation (e.g., 192.168.1.0/24)

    Returns:
        Interface name if found, None otherwise
    """
    target_network = ipaddress.ip_network(subnet, strict=False)

    try:
        result = subprocess.run(
            ["ip", "-o", "addr", "show"],
            capture_output=True,
            text=True,
            timeout=5
        )

        for line in result.stdout.strip().split("\n"):
            if not line:
                continue

            # Parse: "index: name    inet IP/mask ..."
            match = re.match(r'\d+:\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)', line)
            if match:
                iface_name = match.group(1)
                iface_ip = match.group(2)

                if iface_name == "lo":
                    continue

                try:
                    iface_addr = ipaddress.ip_address(iface_ip)
                    if iface_addr in target_network:
                        logger.debug(f"Found interface {iface_name} ({iface_ip}) for subnet {subnet}")
                        return iface_name
                except Exception:
                    continue

    except Exception as e:
        logger.error(f"Error finding interface for subnet {subnet}: {e}")

    return None


def ping_host(ip: str, timeout: float = None) -> Optional[str]:
    """
    Ping a single host and return its IP if reachable.

    Args:
        ip: IP address to ping
        timeout: Timeout in seconds

    Returns:
        IP address if reachable, None otherwise
    """
    timeout = timeout or settings.ping_timeout

    try:
        result = icmp_ping(ip, count=1, timeout=timeout, privileged=True)
        if result.is_alive:
            return ip
    except ICMPLibError as e:
        logger.debug(f"Ping failed for {ip}: {e}")
    except Exception as e:
        logger.warning(f"Unexpected error pinging {ip}: {e}")

    return None


def ping_scan(subnet: str) -> list[str]:
    """
    Perform a ping scan on a subnet.

    Args:
        subnet: Subnet in CIDR notation (e.g., 192.168.1.0/24)

    Returns:
        List of reachable IP addresses
    """
    network = ipaddress.ip_network(subnet, strict=False)
    hosts = list(network.hosts())
    reachable = []

    logger.info(f"Starting ping scan of {subnet} ({len(hosts)} hosts)")

    with ThreadPoolExecutor(max_workers=settings.ping_workers) as executor:
        futures = {executor.submit(ping_host, str(ip)): ip for ip in hosts}

        for future in as_completed(futures):
            result = future.result()
            if result:
                reachable.append(result)

    logger.info(f"Ping scan complete: {len(reachable)}/{len(hosts)} hosts reachable")
    return sorted(reachable, key=lambda x: ipaddress.ip_address(x))


def resolve_hostname(ip: str, timeout: float = None) -> Optional[str]:
    """
    Resolve hostname for an IP address with timeout.

    Args:
        ip: IP address to resolve
        timeout: Timeout in seconds

    Returns:
        Hostname if resolved, None otherwise
    """
    timeout = timeout or settings.dns_timeout

    # Set socket timeout for DNS resolution
    original_timeout = socket.getdefaulttimeout()
    socket.setdefaulttimeout(timeout)

    try:
        hostname = socket.gethostbyaddr(ip)[0]
        return hostname
    except (socket.herror, socket.timeout, socket.gaierror):
        return None
    finally:
        socket.setdefaulttimeout(original_timeout)


async def arp_scan_stream(subnet: str) -> AsyncGenerator[dict, None]:
    """
    Perform an ARP scan on a subnet using arp-scan command, streaming results.

    Yields devices as they are discovered, allowing for real-time updates.

    Args:
        subnet: Subnet in CIDR notation (e.g., 192.168.1.0/24)

    Yields:
        Dict with type ('status', 'device', 'complete', 'error') and data
    """
    logger.info(f"Starting streaming ARP scan of {subnet}")

    # Find the correct interface for this subnet
    iface = find_interface_for_subnet(subnet)
    if iface:
        logger.info(f"Using interface {iface} for ARP scan")
        yield {"type": "status", "message": f"Using interface {iface}"}
    else:
        logger.warning(f"No interface found for subnet {subnet}, scan may fail")
        iface = "eth0"
        yield {"type": "status", "message": f"No interface found for subnet, using {iface}"}

    # Run arp-scan command with streaming output
    cmd = ["arp-scan", f"--interface={iface}", subnet]
    logger.debug(f"Running: {' '.join(cmd)}")

    yield {"type": "status", "message": f"Starting scan: {' '.join(cmd)}"}

    try:
        # Start process with line-buffered output
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        device_count = 0

        # Read output line by line as it comes
        while True:
            try:
                line = await asyncio.wait_for(
                    process.stdout.readline(),
                    timeout=30.0  # Generous timeout for slow networks
                )

                if not line:
                    break

                line = line.decode("utf-8", errors="replace").strip()

                # Skip header and footer lines
                if not line or line.startswith("Interface:") or line.startswith("Starting"):
                    continue
                if "packets received" in line or "Ending" in line:
                    continue

                # Parse device line: "192.168.1.1\t00:11:22:33:44:55\tVendor Name"
                parts = line.split("\t")
                if len(parts) >= 2:
                    ip = parts[0].strip()
                    mac = parts[1].strip().upper()

                    # Validate IP format
                    try:
                        ipaddress.ip_address(ip)
                    except ValueError:
                        continue

                    # Vendor from arp-scan output (if available)
                    vendor = parts[2].strip() if len(parts) >= 3 else None
                    if vendor == "(Unknown)" or vendor == "(Unknown: locally administered)":
                        vendor = None

                    # Resolve hostname in background (non-blocking)
                    hostname = await asyncio.get_event_loop().run_in_executor(
                        None, resolve_hostname, ip
                    )

                    device_count += 1
                    device = DeviceInfo(
                        ip=ip,
                        mac=mac,
                        hostname=hostname,
                        vendor=vendor
                    )

                    yield {
                        "type": "device",
                        "device": device.model_dump(),
                        "count": device_count
                    }

            except asyncio.TimeoutError:
                # Check if process is still running
                if process.returncode is not None:
                    break
                continue

        # Wait for process to complete
        await process.wait()

        # Check for errors
        if process.returncode != 0:
            stderr = await process.stderr.read()
            error_msg = stderr.decode("utf-8", errors="replace").strip()
            logger.error(f"arp-scan failed: {error_msg}")
            yield {"type": "error", "message": f"arp-scan failed: {error_msg}"}
        else:
            yield {
                "type": "complete",
                "message": f"Scan complete: {device_count} devices found",
                "count": device_count
            }

    except asyncio.CancelledError:
        logger.info("ARP scan cancelled")
        if process and process.returncode is None:
            process.terminate()
        raise
    except Exception as e:
        logger.error(f"ARP scan error: {e}")
        yield {"type": "error", "message": str(e)}


def arp_scan(subnet: str) -> list[DeviceInfo]:
    """
    Perform an ARP scan on a subnet using arp-scan command.

    Uses the arp-scan tool which works better with macvlan interfaces
    than Scapy's ARP implementation.

    Args:
        subnet: Subnet in CIDR notation (e.g., 192.168.1.0/24)

    Returns:
        List of discovered devices with IP, MAC, hostname, and vendor
    """
    logger.info(f"Starting ARP scan of {subnet}")

    # Find the correct interface for this subnet
    iface = find_interface_for_subnet(subnet)
    if iface:
        logger.info(f"Using interface {iface} for ARP scan")
    else:
        logger.warning(f"No interface found for subnet {subnet}, scan may fail")
        iface = "eth0"  # Fallback

    # Run arp-scan command
    cmd = ["arp-scan", f"--interface={iface}", subnet]
    logger.debug(f"Running: {' '.join(cmd)}")

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=settings.arp_timeout + 10  # Give some extra time
        )

        if result.returncode != 0:
            logger.error(f"arp-scan failed: {result.stderr}")
            return []

    except subprocess.TimeoutExpired:
        logger.error(f"arp-scan timed out for {subnet}")
        return []
    except Exception as e:
        logger.error(f"arp-scan error: {e}")
        return []

    # Parse arp-scan output
    # Format: "192.168.1.1\t00:11:22:33:44:55\tVendor Name"
    devices = []
    for line in result.stdout.strip().split("\n"):
        # Skip header and footer lines
        if not line or line.startswith("Interface:") or line.startswith("Starting"):
            continue
        if "packets received" in line or "Ending" in line:
            continue

        # Parse device line
        parts = line.split("\t")
        if len(parts) >= 2:
            ip = parts[0].strip()
            mac = parts[1].strip().upper()

            # Validate IP format
            try:
                ipaddress.ip_address(ip)
            except ValueError:
                continue

            # Vendor from arp-scan output (if available)
            vendor = parts[2].strip() if len(parts) >= 3 else None
            if vendor == "(Unknown)" or vendor == "(Unknown: locally administered)":
                vendor = None

            # Resolve hostname
            hostname = resolve_hostname(ip)

            devices.append(DeviceInfo(
                ip=ip,
                mac=mac,
                hostname=hostname,
                vendor=vendor
            ))

    # Sort by IP address
    devices.sort(key=lambda d: ipaddress.ip_address(d.ip))

    logger.info(f"ARP scan complete: {len(devices)} devices found")
    return devices
