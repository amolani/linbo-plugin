import asyncio
import logging
import re
import xml.etree.ElementTree as ET
from typing import Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/nmap", tags=["nmap"])


class PortInfo(BaseModel):
    """Port information."""
    port: int
    protocol: str
    state: str
    service: str
    product: Optional[str] = None
    version: Optional[str] = None
    extrainfo: Optional[str] = None


class ScriptResult(BaseModel):
    """Script scan result."""
    id: str
    output: str


class HostInfo(BaseModel):
    """Host information from nmap scan."""
    ip: str
    hostnames: list[str] = []
    status: str
    os_matches: list[dict] = []
    ports: list[PortInfo] = []
    scripts: list[ScriptResult] = []
    uptime: Optional[str] = None
    distance: Optional[int] = None
    mac_address: Optional[str] = None
    mac_vendor: Optional[str] = None


def parse_nmap_xml(xml_content: str) -> dict:
    """Parse nmap XML output into structured data."""
    result = {
        "scan_info": {},
        "hosts": [],
        "run_stats": {}
    }

    try:
        root = ET.fromstring(xml_content)

        # Parse scan info
        result["scan_info"] = {
            "scanner": root.get("scanner", "nmap"),
            "args": root.get("args", ""),
            "start": root.get("start", ""),
            "startstr": root.get("startstr", ""),
            "version": root.get("version", ""),
        }

        # Parse scaninfo elements
        for scaninfo in root.findall("scaninfo"):
            result["scan_info"]["type"] = scaninfo.get("type", "")
            result["scan_info"]["protocol"] = scaninfo.get("protocol", "")
            result["scan_info"]["services"] = scaninfo.get("services", "")

        # Parse hosts
        for host in root.findall("host"):
            host_info = {
                "ip": "",
                "hostnames": [],
                "status": "",
                "os_matches": [],
                "ports": [],
                "scripts": [],
                "uptime": None,
                "distance": None,
                "mac_address": None,
                "mac_vendor": None,
            }

            # Status
            status = host.find("status")
            if status is not None:
                host_info["status"] = status.get("state", "unknown")

            # Address
            for addr in host.findall("address"):
                if addr.get("addrtype") == "ipv4":
                    host_info["ip"] = addr.get("addr", "")
                elif addr.get("addrtype") == "mac":
                    host_info["mac_address"] = addr.get("addr", "")
                    host_info["mac_vendor"] = addr.get("vendor", "")

            # Hostnames
            hostnames = host.find("hostnames")
            if hostnames is not None:
                for hostname in hostnames.findall("hostname"):
                    name = hostname.get("name", "")
                    if name:
                        host_info["hostnames"].append(name)

            # Ports
            ports = host.find("ports")
            if ports is not None:
                for port in ports.findall("port"):
                    port_info = {
                        "port": int(port.get("portid", 0)),
                        "protocol": port.get("protocol", ""),
                        "state": "",
                        "service": "",
                        "product": None,
                        "version": None,
                        "extrainfo": None,
                    }

                    state = port.find("state")
                    if state is not None:
                        port_info["state"] = state.get("state", "")

                    service = port.find("service")
                    if service is not None:
                        port_info["service"] = service.get("name", "")
                        port_info["product"] = service.get("product")
                        port_info["version"] = service.get("version")
                        port_info["extrainfo"] = service.get("extrainfo")

                    # Port scripts
                    for script in port.findall("script"):
                        script_result = {
                            "id": script.get("id", ""),
                            "output": script.get("output", ""),
                        }
                        host_info["scripts"].append(script_result)

                    host_info["ports"].append(port_info)

            # OS detection
            os_elem = host.find("os")
            if os_elem is not None:
                for osmatch in os_elem.findall("osmatch"):
                    os_match = {
                        "name": osmatch.get("name", ""),
                        "accuracy": osmatch.get("accuracy", ""),
                        "osclass": []
                    }
                    for osclass in osmatch.findall("osclass"):
                        os_match["osclass"].append({
                            "type": osclass.get("type", ""),
                            "vendor": osclass.get("vendor", ""),
                            "osfamily": osclass.get("osfamily", ""),
                            "osgen": osclass.get("osgen", ""),
                            "accuracy": osclass.get("accuracy", ""),
                        })
                    host_info["os_matches"].append(os_match)

            # Uptime
            uptime = host.find("uptime")
            if uptime is not None:
                host_info["uptime"] = uptime.get("lastboot")

            # Distance (hop count)
            distance = host.find("distance")
            if distance is not None:
                host_info["distance"] = int(distance.get("value", 0))

            # Host scripts
            hostscript = host.find("hostscript")
            if hostscript is not None:
                for script in hostscript.findall("script"):
                    script_result = {
                        "id": script.get("id", ""),
                        "output": script.get("output", ""),
                    }
                    host_info["scripts"].append(script_result)

            result["hosts"].append(host_info)

        # Parse run stats
        runstats = root.find("runstats")
        if runstats is not None:
            finished = runstats.find("finished")
            if finished is not None:
                result["run_stats"]["time"] = finished.get("time", "")
                result["run_stats"]["timestr"] = finished.get("timestr", "")
                result["run_stats"]["elapsed"] = finished.get("elapsed", "")
                result["run_stats"]["summary"] = finished.get("summary", "")
                result["run_stats"]["exit"] = finished.get("exit", "")

            hosts_stat = runstats.find("hosts")
            if hosts_stat is not None:
                result["run_stats"]["hosts_up"] = hosts_stat.get("up", "0")
                result["run_stats"]["hosts_down"] = hosts_stat.get("down", "0")
                result["run_stats"]["hosts_total"] = hosts_stat.get("total", "0")

    except ET.ParseError as e:
        logger.error(f"Failed to parse nmap XML: {e}")
        raise

    return result


@router.websocket("/scan")
async def nmap_scan_live(
    websocket: WebSocket,
    host: str = Query(..., description="Host IP address to scan"),
):
    """
    Perform an nmap -A scan on a host via WebSocket.

    Uses XML output for reliable parsing.

    Query parameters:
        host: IP address to scan

    Messages sent to client:
        - {"type": "status", "message": "..."} - Status updates
        - {"type": "progress", "percent": N} - Scan progress (if available)
        - {"type": "result", "data": {...}} - Parsed scan result
        - {"type": "complete", "message": "...", "summary": {...}} - Scan complete
        - {"type": "error", "message": "..."} - Error occurred
    """
    await websocket.accept()
    logger.info(f"Nmap scan WebSocket connected for host: {host}")

    # Validate IP address format
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$'
    if not re.match(ip_pattern, host):
        await websocket.send_json({
            "type": "error",
            "message": f"Invalid IP address format: {host}"
        })
        await websocket.close()
        return

    process = None
    try:
        # Build nmap command with XML output
        # -A: Aggressive scan (OS detection, version detection, script scanning, traceroute)
        # -T4: Faster timing template
        # --open: Only show open ports
        # -oX -: Output XML to stdout
        # --stats-every 2s: Progress updates every 2 seconds
        cmd = [
            "nmap",
            "-A",
            "-T4",
            "--open",
            "-oX", "-",
            "--stats-every", "2s",
            host
        ]

        logger.info(f"Running: {' '.join(cmd)}")

        await websocket.send_json({
            "type": "status",
            "message": f"Starting nmap scan on {host}...",
            "command": " ".join(cmd)
        })

        # Start nmap process
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        xml_output = []
        last_progress = 0

        # Read output
        while True:
            try:
                line = await asyncio.wait_for(
                    process.stdout.readline(),
                    timeout=120.0
                )

                if not line:
                    break

                decoded = line.decode("utf-8", errors="replace")
                xml_output.append(decoded)

                # Check for progress in stderr (nmap writes progress to stderr)
                # We'll check stderr at the end

            except asyncio.TimeoutError:
                if process.returncode is not None:
                    break
                try:
                    await websocket.send_json({"type": "ping"})
                except Exception:
                    break

        # Read remaining stdout
        remaining_stdout = await process.stdout.read()
        if remaining_stdout:
            xml_output.append(remaining_stdout.decode("utf-8", errors="replace"))

        # Wait for process
        await process.wait()

        # Read stderr for progress info
        stderr = await process.stderr.read()
        if stderr:
            stderr_text = stderr.decode("utf-8", errors="replace").strip()
            if stderr_text and "error" in stderr_text.lower():
                logger.warning(f"Nmap stderr: {stderr_text}")

        # Parse XML output
        xml_content = "".join(xml_output)

        try:
            result = parse_nmap_xml(xml_content)

            # Send parsed result
            await websocket.send_json({
                "type": "result",
                "data": result
            })

            # Build summary
            host_count = len(result.get("hosts", []))
            total_ports = sum(len(h.get("ports", [])) for h in result.get("hosts", []))

            summary = {
                "hosts_scanned": host_count,
                "ports_found": total_ports,
                "elapsed": result.get("run_stats", {}).get("elapsed", ""),
                "summary": result.get("run_stats", {}).get("summary", ""),
            }

            await websocket.send_json({
                "type": "complete",
                "message": f"Scan complete: {total_ports} open ports found",
                "summary": summary
            })

        except ET.ParseError as e:
            # If XML parsing fails, send raw output
            logger.error(f"XML parse error: {e}")
            await websocket.send_json({
                "type": "error",
                "message": f"Failed to parse scan results: {str(e)}",
                "raw_output": xml_content[:10000]  # Limit size
            })

    except WebSocketDisconnect:
        logger.info("Nmap scan WebSocket disconnected by client")
    except Exception as e:
        logger.error(f"Nmap scan WebSocket error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        if process and process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=5.0)
            except asyncio.TimeoutError:
                process.kill()
            logger.info("Nmap process terminated")
        try:
            await websocket.close()
        except Exception:
            pass
