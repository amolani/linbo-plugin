import logging
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from app.services.snmp_poller import snmp_poller, SNMPTarget

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/snmp", tags=["SNMP"])


class SNMPTargetRequest(BaseModel):
    """SNMP target configuration for requests."""
    ip_address: str
    version: str = "v2c"
    community: str = "public"
    # SNMPv3 options
    username: str = ""
    auth_protocol: str = ""
    auth_password: str = ""
    priv_protocol: str = ""
    priv_password: str = ""
    port: int = 161
    timeout: float = 2.0
    retries: int = 2

    def to_target(self) -> SNMPTarget:
        return SNMPTarget(
            ip_address=self.ip_address,
            version=self.version,
            community=self.community,
            username=self.username,
            auth_protocol=self.auth_protocol,
            auth_password=self.auth_password,
            priv_protocol=self.priv_protocol,
            priv_password=self.priv_password,
            port=self.port,
            timeout=self.timeout,
            retries=self.retries
        )


class SNMPPollRequest(BaseModel):
    """Request for polling specific OIDs."""
    target: SNMPTargetRequest
    oids: list[str] = []  # Empty = poll all standard OIDs


@router.post("/test")
async def test_snmp_connection(target: SNMPTargetRequest):
    """
    Test SNMP connection to a switch.
    Returns system name and description if successful.
    """
    try:
        result = await snmp_poller.test_connection(target.to_target())
        return result
    except Exception as e:
        logger.exception(f"SNMP test failed for {target.ip_address}")
        return {
            "success": False,
            "error": str(e)
        }


@router.post("/mac-table")
async def get_mac_table(target: SNMPTargetRequest):
    """
    Get MAC address table from switch.
    Returns list of MAC entries with port and VLAN information.
    """
    try:
        mac_table = await snmp_poller.get_mac_table(target.to_target())
        return {
            "success": True,
            "mac_table": mac_table,
            "count": len(mac_table)
        }
    except Exception as e:
        logger.exception(f"MAC table fetch failed for {target.ip_address}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stp-status")
async def get_stp_status(target: SNMPTargetRequest):
    """
    Get STP status and topology change information from switch.
    """
    try:
        status = await snmp_poller.get_stp_status(target.to_target())
        return {
            "success": True,
            **status
        }
    except Exception as e:
        logger.exception(f"STP status fetch failed for {target.ip_address}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/interface-counters")
async def get_interface_counters(target: SNMPTargetRequest):
    """
    Get interface counters (octets, errors, discards) from switch.
    """
    try:
        counters = await snmp_poller.get_interface_counters(target.to_target())
        return {
            "success": True,
            "interfaces": counters,
            "count": len(counters)
        }
    except Exception as e:
        logger.exception(f"Interface counters fetch failed for {target.ip_address}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/poll")
async def poll_switch(target: SNMPTargetRequest):
    """
    Poll all relevant data from a switch (MAC table, STP, counters).
    This is a convenience endpoint that combines all other polls.
    """
    try:
        data = await snmp_poller.poll_all(target.to_target())
        return {
            "success": True,
            **data
        }
    except Exception as e:
        logger.exception(f"Full poll failed for {target.ip_address}")
        raise HTTPException(status_code=500, detail=str(e))
