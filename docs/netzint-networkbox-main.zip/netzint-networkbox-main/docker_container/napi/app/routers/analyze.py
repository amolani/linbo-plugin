import asyncio
import json
import logging
import tempfile
import os
from typing import Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/analyze", tags=["analyze"])


class AnalysisResult(BaseModel):
    """Result of pcap analysis."""
    total_packets: int = 0
    duration_seconds: float = 0.0
    protocols: dict[str, int] = {}
    conversations: list[dict] = []
    issues: list[dict] = []
    statistics: dict = {}


async def run_tshark_command(cmd: list[str], timeout: float = 60.0) -> tuple[str, str]:
    """Run a tshark command and return stdout/stderr."""
    process = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(
            process.communicate(),
            timeout=timeout
        )
        return stdout.decode("utf-8", errors="replace"), stderr.decode("utf-8", errors="replace")
    except asyncio.TimeoutError:
        process.kill()
        raise


def parse_io_stat(output: str) -> dict:
    """Parse tshark IO statistics output."""
    stats = {"intervals": [], "total_frames": 0, "total_bytes": 0}
    lines = output.strip().split("\n")

    for line in lines:
        if "|" in line and "<>" in line:
            # Parse interval line like "| 0 <> 1 | 123 | 45678 |"
            parts = [p.strip() for p in line.split("|") if p.strip()]
            if len(parts) >= 3:
                try:
                    frames = int(parts[1]) if parts[1].isdigit() else 0
                    bytes_val = int(parts[2]) if parts[2].isdigit() else 0
                    stats["total_frames"] += frames
                    stats["total_bytes"] += bytes_val
                except (ValueError, IndexError):
                    pass

    return stats


def parse_conversations(output: str) -> list[dict]:
    """Parse tshark conversations output."""
    conversations = []
    lines = output.strip().split("\n")

    for line in lines:
        # Skip header lines, empty lines, and formatting
        if not line.strip():
            continue
        if line.startswith("=") or line.startswith("|") or line.startswith("-"):
            continue
        if "Address" in line or "Packets" in line or "Frames" in line:
            continue
        if "Relative" in line or "Filter" in line:
            continue

        # Must contain <-> for a valid conversation
        if "<->" not in line:
            continue

        parts = line.split()
        if len(parts) >= 6:
            try:
                # Find the <-> separator index
                arrow_idx = None
                for i, p in enumerate(parts):
                    if p == "<->":
                        arrow_idx = i
                        break

                if arrow_idx and arrow_idx > 0 and arrow_idx < len(parts) - 1:
                    conv = {
                        "endpoint_a": parts[arrow_idx - 1],
                        "endpoint_b": parts[arrow_idx + 1],
                        "packets": parts[-4] if len(parts) > 6 else "0",
                        "bytes": parts[-3] if len(parts) > 6 else "0",
                    }
                    # Validate IP addresses (basic check)
                    if "." in conv["endpoint_a"] and "." in conv["endpoint_b"]:
                        conversations.append(conv)
            except (ValueError, IndexError):
                pass

    return conversations[:20]  # Limit to top 20


def parse_expert_info(output: str) -> list[dict]:
    """Parse tshark expert info output for issues."""
    issues = []
    lines = output.strip().split("\n")

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # Parse lines like: "Warning  TCP  12345  TCP Retransmission"
        severity = None
        if line.startswith("Error"):
            severity = "error"
        elif line.startswith("Warning"):
            severity = "warning"
        elif line.startswith("Note"):
            severity = "note"
        elif line.startswith("Chat"):
            severity = "info"

        if severity:
            parts = line.split(None, 3)
            if len(parts) >= 4:
                issues.append({
                    "severity": severity,
                    "protocol": parts[1] if len(parts) > 1 else "",
                    "count": parts[2] if len(parts) > 2 else "1",
                    "message": parts[3] if len(parts) > 3 else line,
                })

    return issues


def parse_protocol_hierarchy(output: str) -> dict[str, int]:
    """Parse tshark protocol hierarchy output."""
    protocols = {}
    lines = output.strip().split("\n")

    for line in lines:
        # Parse lines like "  eth:ip:tcp  frames:1234 bytes:567890"
        if "frames:" in line:
            parts = line.strip().split()
            if len(parts) >= 2:
                proto = parts[0].split(":")[-1]  # Get last protocol in chain
                for part in parts:
                    if part.startswith("frames:"):
                        try:
                            count = int(part.split(":")[1])
                            if proto in protocols:
                                protocols[proto] = max(protocols[proto], count)
                            else:
                                protocols[proto] = count
                        except (ValueError, IndexError):
                            pass

    return protocols


def parse_http_requests(output: str) -> list[dict]:
    """Parse HTTP request details from tshark output."""
    requests = []
    lines = output.strip().split("\n")

    for line in lines:
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 4:
            requests.append({
                "method": parts[0] if parts[0] else "?",
                "host": parts[1] if len(parts) > 1 else "",
                "uri": parts[2] if len(parts) > 2 else "",
                "user_agent": parts[3] if len(parts) > 3 else "",
            })

    return requests[:50]  # Limit to 50


def parse_http_responses(output: str) -> list[dict]:
    """Parse HTTP response details from tshark output."""
    responses = []
    lines = output.strip().split("\n")

    for line in lines:
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 3:
            responses.append({
                "status_code": parts[0] if parts[0] else "?",
                "content_type": parts[1] if len(parts) > 1 else "",
                "content_length": parts[2] if len(parts) > 2 else "",
            })

    return responses[:50]


def parse_dns_queries(output: str) -> list[dict]:
    """Parse DNS query details from tshark output."""
    queries = []
    seen = set()
    lines = output.strip().split("\n")

    for line in lines:
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            name = parts[0]
            qtype = parts[1] if len(parts) > 1 else "A"
            key = f"{name}:{qtype}"
            if key not in seen:
                seen.add(key)
                queries.append({
                    "name": name,
                    "type": qtype,
                })

    return queries[:100]  # Limit to 100 unique queries


def parse_tls_info(output: str) -> list[dict]:
    """Parse TLS/SSL handshake information."""
    tls_info = []
    seen = set()
    lines = output.strip().split("\n")

    for line in lines:
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 1:
            sni = parts[0]
            if sni and sni not in seen:
                seen.add(sni)
                version = parts[1] if len(parts) > 1 else ""
                cipher = parts[2] if len(parts) > 2 else ""
                tls_info.append({
                    "server_name": sni,
                    "version": version,
                    "cipher": cipher,
                })

    return tls_info[:50]


def parse_credentials(output: str) -> list[dict]:
    """Parse potential credentials from traffic (for security analysis)."""
    credentials = []
    lines = output.strip().split("\n")

    for line in lines:
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            credentials.append({
                "protocol": parts[0] if parts[0] else "unknown",
                "info": parts[1] if len(parts) > 1 else "",
            })

    return credentials[:20]


def parse_file_objects(output: str) -> list[dict]:
    """Parse file transfer information."""
    files = []
    lines = output.strip().split("\n")

    for line in lines:
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 2:
            files.append({
                "filename": parts[0] if parts[0] else "unknown",
                "content_type": parts[1] if len(parts) > 1 else "",
                "size": parts[2] if len(parts) > 2 else "",
            })

    return files[:30]


@router.websocket("/pcap")
async def analyze_pcap(websocket: WebSocket):
    """
    Analyze a pcap file via WebSocket.

    Client sends:
        - {"type": "start", "filename": "capture.pcap"} - Start analysis
        - Binary data chunks of the pcap file
        - {"type": "end"} - All data sent, start analysis

    Server sends:
        - {"type": "status", "message": "..."} - Status updates
        - {"type": "progress", "step": "...", "percent": N} - Progress
        - {"type": "result", "data": {...}} - Analysis results
        - {"type": "error", "message": "..."} - Error occurred
    """
    await websocket.accept()
    logger.info("Pcap analysis WebSocket connected")

    temp_file = None
    try:
        # Wait for start message
        start_msg = await websocket.receive_json()
        if start_msg.get("type") != "start":
            await websocket.send_json({
                "type": "error",
                "message": "Expected start message"
            })
            return

        filename = start_msg.get("filename", "capture.pcap")
        await websocket.send_json({
            "type": "status",
            "message": f"Ready to receive {filename}"
        })

        # Create temp file for pcap data
        temp_file = tempfile.NamedTemporaryFile(
            delete=False,
            suffix=".pcap",
            prefix="analyze_"
        )

        # Receive pcap data
        total_bytes = 0
        while True:
            msg = await websocket.receive()

            if "text" in msg:
                # Handle JSON message - parse the text directly
                try:
                    json_data = json.loads(msg["text"])
                    if json_data.get("type") == "end":
                        break
                except json.JSONDecodeError:
                    pass
            elif "bytes" in msg:
                # Binary pcap data
                temp_file.write(msg["bytes"])
                total_bytes += len(msg["bytes"])

                if total_bytes % 100000 < 10000:  # Send progress every ~100KB
                    await websocket.send_json({
                        "type": "status",
                        "message": f"Received {total_bytes / 1024:.1f} KB"
                    })

        temp_file.close()
        pcap_path = temp_file.name

        await websocket.send_json({
            "type": "status",
            "message": f"Received {total_bytes / 1024:.1f} KB, starting analysis..."
        })

        # Initialize result
        result = {
            "total_packets": 0,
            "duration_seconds": 0.0,
            "protocols": {},
            "conversations": [],
            "issues": [],
            "statistics": {},
            "filename": filename,
            "file_size": total_bytes,
            # New detailed content fields
            "http_requests": [],
            "http_responses": [],
            "dns_queries": [],
            "tls_connections": [],
            "credentials": [],
            "files": [],
        }

        # Step 1: Get basic capture info
        await websocket.send_json({
            "type": "progress",
            "step": "capture_info",
            "percent": 5,
            "message": "Getting capture information..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-q", "-z", "io,stat,0"
            ])
            stats = parse_io_stat(stdout)
            result["total_packets"] = stats.get("total_frames", 0)
            result["statistics"]["total_bytes"] = stats.get("total_bytes", 0)
        except Exception as e:
            logger.warning(f"Failed to get IO stats: {e}")

        # Step 2: Get protocol hierarchy
        await websocket.send_json({
            "type": "progress",
            "step": "protocols",
            "percent": 12,
            "message": "Analyzing protocols..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-q", "-z", "io,phs"
            ])
            result["protocols"] = parse_protocol_hierarchy(stdout)
        except Exception as e:
            logger.warning(f"Failed to get protocol hierarchy: {e}")

        # Step 3: Get conversations
        await websocket.send_json({
            "type": "progress",
            "step": "conversations",
            "percent": 19,
            "message": "Analyzing conversations..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-q", "-z", "conv,ip"
            ])
            result["conversations"] = parse_conversations(stdout)
        except Exception as e:
            logger.warning(f"Failed to get conversations: {e}")

        # Step 4: Get expert info (issues/problems)
        await websocket.send_json({
            "type": "progress",
            "step": "expert_info",
            "percent": 26,
            "message": "Checking for network issues..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-q", "-z", "expert,error"
            ])
            result["issues"].extend(parse_expert_info(stdout))
        except Exception as e:
            logger.warning(f"Failed to get expert error info: {e}")

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-q", "-z", "expert,warn"
            ])
            result["issues"].extend(parse_expert_info(stdout))
        except Exception as e:
            logger.warning(f"Failed to get expert warning info: {e}")

        # Step 5: TCP analysis
        await websocket.send_json({
            "type": "progress",
            "step": "tcp_analysis",
            "percent": 33,
            "message": "Analyzing TCP issues..."
        })

        tcp_issues = []

        # Check for retransmissions
        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-Y", "tcp.analysis.retransmission",
                "-T", "fields", "-e", "frame.number"
            ])
            retrans_count = len([l for l in stdout.strip().split("\n") if l.strip()])
            if retrans_count > 0:
                tcp_issues.append({
                    "severity": "warning",
                    "protocol": "TCP",
                    "count": str(retrans_count),
                    "message": "TCP Retransmissions detected",
                    "description": "Packets had to be resent, indicating packet loss"
                })
        except Exception as e:
            logger.warning(f"Failed to check retransmissions: {e}")

        # Check for RST packets
        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-Y", "tcp.flags.reset==1",
                "-T", "fields", "-e", "frame.number"
            ])
            rst_count = len([l for l in stdout.strip().split("\n") if l.strip()])
            if rst_count > 0:
                tcp_issues.append({
                    "severity": "note",
                    "protocol": "TCP",
                    "count": str(rst_count),
                    "message": "TCP RST packets detected",
                    "description": "Connection resets, may indicate refused connections"
                })
        except Exception as e:
            logger.warning(f"Failed to check RST packets: {e}")

        # Check for duplicate ACKs
        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-Y", "tcp.analysis.duplicate_ack",
                "-T", "fields", "-e", "frame.number"
            ])
            dup_ack_count = len([l for l in stdout.strip().split("\n") if l.strip()])
            if dup_ack_count > 0:
                tcp_issues.append({
                    "severity": "warning",
                    "protocol": "TCP",
                    "count": str(dup_ack_count),
                    "message": "Duplicate ACKs detected",
                    "description": "May indicate packet loss or network congestion"
                })
        except Exception as e:
            logger.warning(f"Failed to check duplicate ACKs: {e}")

        # Check for zero window
        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-Y", "tcp.analysis.zero_window",
                "-T", "fields", "-e", "frame.number"
            ])
            zw_count = len([l for l in stdout.strip().split("\n") if l.strip()])
            if zw_count > 0:
                tcp_issues.append({
                    "severity": "warning",
                    "protocol": "TCP",
                    "count": str(zw_count),
                    "message": "Zero Window conditions detected",
                    "description": "Receiver buffer full, flow control engaged"
                })
        except Exception as e:
            logger.warning(f"Failed to check zero window: {e}")

        result["issues"].extend(tcp_issues)

        # Step 6: DNS analysis
        await websocket.send_json({
            "type": "progress",
            "step": "dns_analysis",
            "percent": 40,
            "message": "Analyzing DNS..."
        })

        try:
            # Count DNS queries and responses
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-Y", "dns",
                "-T", "fields", "-e", "dns.flags.response"
            ])
            dns_lines = [l for l in stdout.strip().split("\n") if l.strip()]
            dns_queries = sum(1 for l in dns_lines if l == "0")
            dns_responses = sum(1 for l in dns_lines if l == "1")

            if dns_queries > 0:
                result["statistics"]["dns_queries"] = dns_queries
                result["statistics"]["dns_responses"] = dns_responses

                # Check for unanswered queries
                if dns_queries > dns_responses + 5:
                    result["issues"].append({
                        "severity": "warning",
                        "protocol": "DNS",
                        "count": str(dns_queries - dns_responses),
                        "message": "Unanswered DNS queries",
                        "description": "Some DNS queries may not have received responses"
                    })
        except Exception as e:
            logger.warning(f"Failed to analyze DNS: {e}")

        # Step 7: Extract DNS query details
        await websocket.send_json({
            "type": "progress",
            "step": "dns_details",
            "percent": 47,
            "message": "Extracting DNS queries..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path,
                "-Y", "dns.flags.response == 0",
                "-T", "fields",
                "-e", "dns.qry.name",
                "-e", "dns.qry.type",
                "-E", "separator=\t"
            ])
            result["dns_queries"] = parse_dns_queries(stdout)
        except Exception as e:
            logger.warning(f"Failed to extract DNS queries: {e}")

        # Step 8: HTTP Request Analysis
        await websocket.send_json({
            "type": "progress",
            "step": "http_requests",
            "percent": 54,
            "message": "Analyzing HTTP requests..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path,
                "-Y", "http.request",
                "-T", "fields",
                "-e", "http.request.method",
                "-e", "http.host",
                "-e", "http.request.uri",
                "-e", "http.user_agent",
                "-E", "separator=\t"
            ])
            result["http_requests"] = parse_http_requests(stdout)
        except Exception as e:
            logger.warning(f"Failed to analyze HTTP requests: {e}")

        # Step 9: HTTP Response Analysis
        await websocket.send_json({
            "type": "progress",
            "step": "http_responses",
            "percent": 61,
            "message": "Analyzing HTTP responses..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path,
                "-Y", "http.response",
                "-T", "fields",
                "-e", "http.response.code",
                "-e", "http.content_type",
                "-e", "http.content_length",
                "-E", "separator=\t"
            ])
            result["http_responses"] = parse_http_responses(stdout)
        except Exception as e:
            logger.warning(f"Failed to analyze HTTP responses: {e}")

        # Step 10: TLS/SSL Analysis
        await websocket.send_json({
            "type": "progress",
            "step": "tls_analysis",
            "percent": 68,
            "message": "Analyzing TLS/SSL connections..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path,
                "-Y", "tls.handshake.extensions_server_name",
                "-T", "fields",
                "-e", "tls.handshake.extensions_server_name",
                "-e", "tls.handshake.version",
                "-e", "tls.handshake.ciphersuite",
                "-E", "separator=\t"
            ])
            result["tls_connections"] = parse_tls_info(stdout)
        except Exception as e:
            logger.warning(f"Failed to analyze TLS: {e}")

        # Step 11: Credential Detection (FTP, HTTP Basic Auth, SMTP, etc.)
        await websocket.send_json({
            "type": "progress",
            "step": "credentials",
            "percent": 75,
            "message": "Checking for credentials in clear text..."
        })

        try:
            # FTP credentials
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path,
                "-Y", "ftp.request.command == USER || ftp.request.command == PASS",
                "-T", "fields",
                "-e", "ftp.request.command",
                "-e", "ftp.request.arg",
                "-E", "separator=\t"
            ])
            ftp_creds = []
            for line in stdout.strip().split("\n"):
                if line.strip():
                    parts = line.split("\t")
                    if len(parts) >= 2:
                        ftp_creds.append({
                            "protocol": f"FTP {parts[0]}",
                            "info": parts[1] if len(parts) > 1 else "",
                        })
            result["credentials"].extend(ftp_creds[:10])
        except Exception as e:
            logger.warning(f"Failed to check FTP credentials: {e}")

        try:
            # HTTP Basic Auth
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path,
                "-Y", "http.authorization",
                "-T", "fields",
                "-e", "http.host",
                "-e", "http.authorization",
                "-E", "separator=\t"
            ])
            for line in stdout.strip().split("\n"):
                if line.strip():
                    parts = line.split("\t")
                    if len(parts) >= 2:
                        result["credentials"].append({
                            "protocol": "HTTP Basic Auth",
                            "info": f"Host: {parts[0]}",
                        })
        except Exception as e:
            logger.warning(f"Failed to check HTTP auth: {e}")

        # Add warning if credentials found
        if result["credentials"]:
            result["issues"].append({
                "severity": "error",
                "protocol": "Security",
                "count": str(len(result["credentials"])),
                "message": "Clear text credentials detected!",
                "description": "Passwords or authentication data transmitted without encryption"
            })

        # Step 12: File Transfer Detection
        await websocket.send_json({
            "type": "progress",
            "step": "files",
            "percent": 82,
            "message": "Detecting file transfers..."
        })

        try:
            # HTTP file downloads
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path,
                "-Y", "http.content_disposition || (http.content_type && http.content_length)",
                "-T", "fields",
                "-e", "http.content_disposition",
                "-e", "http.content_type",
                "-e", "http.content_length",
                "-E", "separator=\t"
            ])
            result["files"] = parse_file_objects(stdout)
        except Exception as e:
            logger.warning(f"Failed to detect files: {e}")

        # Step 13: Top Talkers (endpoints with most traffic)
        await websocket.send_json({
            "type": "progress",
            "step": "top_talkers",
            "percent": 90,
            "message": "Identifying top talkers..."
        })

        try:
            stdout, _ = await run_tshark_command([
                "tshark", "-r", pcap_path, "-q", "-z", "endpoints,ip"
            ])
            # Parse top talkers
            top_talkers = []
            for line in stdout.strip().split("\n"):
                # Skip empty, header, and formatting lines
                if not line.strip():
                    continue
                if "=" in line or line.startswith("|") or line.startswith("-"):
                    continue
                if "Address" in line or "Packets" in line or "Frames" in line:
                    continue
                if "Filter" in line or "Relative" in line:
                    continue

                parts = line.split()
                if len(parts) >= 3:
                    # First part should be an IP address
                    ip = parts[0]
                    if "." not in ip:  # Basic IP validation
                        continue
                    try:
                        top_talkers.append({
                            "ip": ip,
                            "packets": parts[1],
                            "bytes": parts[2],
                        })
                    except (ValueError, IndexError):
                        pass
            result["statistics"]["top_talkers"] = top_talkers[:10]
        except Exception as e:
            logger.warning(f"Failed to get top talkers: {e}")

        # Send final result
        await websocket.send_json({
            "type": "progress",
            "step": "complete",
            "percent": 100,
            "message": "Analysis complete"
        })

        await websocket.send_json({
            "type": "result",
            "data": result
        })

        logger.info(f"Pcap analysis complete: {result['total_packets']} packets, {len(result['issues'])} issues")

    except WebSocketDisconnect:
        logger.info("Pcap analysis WebSocket disconnected by client")
    except Exception as e:
        logger.error(f"Pcap analysis error: {e}")
        try:
            await websocket.send_json({
                "type": "error",
                "message": str(e)
            })
        except Exception:
            pass
    finally:
        # Clean up temp file
        if temp_file and os.path.exists(temp_file.name):
            try:
                os.unlink(temp_file.name)
            except Exception:
                pass
        try:
            await websocket.close()
        except Exception:
            pass
