from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, Query
import logging
import ipaddress

from app.models import ScanRequest, PingScanResponse, ArpScanResponse
from app.services.scanner import ping_scan, arp_scan, arp_scan_stream

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/scan", tags=["network-scan"])


@router.post("/ping", response_model=PingScanResponse)
async def scan_ping(request: ScanRequest):
    """
    Perform a ping scan on a subnet to discover reachable hosts.

    - **subnet**: Subnet in CIDR notation (e.g., 192.168.1.0/24)

    Returns list of IP addresses that responded to ICMP echo requests.
    Maximum subnet size: /22 (1024 hosts)
    """
    try:
        network = ipaddress.ip_network(request.subnet, strict=False)
        total_hosts = network.num_addresses - 2  # Exclude network and broadcast

        reachable = ping_scan(request.subnet)

        return PingScanResponse(
            subnet=str(network),
            total_hosts=total_hosts,
            reachable_count=len(reachable),
            reachable=reachable
        )
    except Exception as e:
        logger.error(f"Ping scan failed: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Ping scan failed: {str(e)}"
        )


@router.post("/arp", response_model=ArpScanResponse)
async def scan_arp(request: ScanRequest):
    """
    Perform an ARP scan on a subnet to discover devices.

    - **subnet**: Subnet in CIDR notation (e.g., 192.168.1.0/24)

    Returns list of devices with IP, MAC address, hostname (if resolvable),
    and vendor information.
    Maximum subnet size: /22 (1024 hosts)
    """
    try:
        devices = arp_scan(request.subnet)

        network = ipaddress.ip_network(request.subnet, strict=False)

        return ArpScanResponse(
            subnet=str(network),
            device_count=len(devices),
            devices=devices
        )
    except Exception as e:
        logger.error(f"ARP scan failed: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"ARP scan failed: {str(e)}"
        )


@router.websocket("/arp/live")
async def scan_arp_live(
    websocket: WebSocket,
    subnet: str = Query(..., description="Subnet to scan (e.g., 192.168.1.0/24)")
):
    """
    Perform a streaming ARP scan via WebSocket.

    Devices are sent as they are discovered, allowing real-time updates.

    Query parameters:
        subnet: Subnet in CIDR notation (e.g., 192.168.1.0/24)

    Messages sent to client:
        - {"type": "status", "message": "..."} - Status updates
        - {"type": "device", "device": {...}, "count": N} - Discovered device
        - {"type": "complete", "message": "...", "count": N} - Scan complete
        - {"type": "error", "message": "..."} - Error occurred
    """
    await websocket.accept()
    logger.info(f"ARP scan WebSocket connected for subnet: {subnet}")

    try:
        # Validate subnet
        try:
            network = ipaddress.ip_network(subnet, strict=False)
            if network.num_addresses > 1024:
                await websocket.send_json({
                    "type": "error",
                    "message": f"Subnet too large ({network.num_addresses} hosts). Maximum: /22 (1024 hosts)"
                })
                return
        except ValueError as e:
            await websocket.send_json({
                "type": "error",
                "message": f"Invalid subnet: {e}"
            })
            return

        # Stream scan results
        async for result in arp_scan_stream(subnet):
            await websocket.send_json(result)

    except WebSocketDisconnect:
        logger.info("ARP scan WebSocket disconnected by client")
    except Exception as e:
        logger.error(f"ARP scan WebSocket error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass
