# NAPI Routers
