from fastapi import APIRouter, HTTPException
import logging

from app.models import WakeRequest, WakeResponse
from app.services.wol import send_wol

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/wake", tags=["wake-on-lan"])


@router.post("", response_model=WakeResponse)
async def wake_on_lan(request: WakeRequest):
    """
    Send a Wake-on-LAN magic packet to wake up a device.

    - **mac**: MAC address of the target device (required)
    - **ip**: Broadcast IP address (default: 255.255.255.255)
    - **port**: UDP port (default: 9)
    """
    try:
        send_wol(mac=request.mac, ip=request.ip, port=request.port)

        return WakeResponse(
            success=True,
            message=f"Wake-on-LAN packet sent successfully",
            mac=request.mac,
            ip=request.ip,
            port=request.port
        )
    except OSError as e:
        logger.error(f"Failed to send WOL packet: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to send Wake-on-LAN packet: {str(e)}"
        )
