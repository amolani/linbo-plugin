import asyncio
import logging
import subprocess
import re
import tempfile
import os
import base64
from typing import Optional

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query
from fastapi.responses import Response
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/tcpdump", tags=["tcpdump"])

# Store for active pcap captures
active_pcap_captures: dict[str, dict] = {}


class InterfaceInfo(BaseModel):
    name: str
    ip_address: Optional[str] = None


def get_interfaces_from_ip_addr() -> list[InterfaceInfo]:
    """Get network interfaces using ip addr command."""
    interfaces = []
    try:
        result = subprocess.run(
            ["ip", "-o", "addr", "show"],
            capture_output=True,
            text=True,
            timeout=5
        )

        # Parse output like: "2: eth0    inet 192.168.1.100/24 ..."
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue

            # Extract interface name and IP
            # Format: "index: name    inet IP/mask ..."
            match = re.match(r'\d+:\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)', line)
            if match:
                iface_name = match.group(1)
                ip_addr = match.group(2)

                # Skip loopback
                if iface_name == "lo":
                    continue

                # Check if already added (avoid duplicates from multiple IPs)
                existing = next((i for i in interfaces if i.name == iface_name), None)
                if not existing:
                    interfaces.append(InterfaceInfo(name=iface_name, ip_address=ip_addr))

        # Also get interfaces without IP using ip link
        link_result = subprocess.run(
            ["ip", "-o", "link", "show"],
            capture_output=True,
            text=True,
            timeout=5
        )

        for line in link_result.stdout.strip().split("\n"):
            if not line:
                continue

            # Format: "index: name: <FLAGS> ..."
            match = re.match(r'\d+:\s+([^:@]+)', line)
            if match:
                iface_name = match.group(1).strip()

                # Skip loopback
                if iface_name == "lo":
                    continue

                # Add if not already in list
                existing = next((i for i in interfaces if i.name == iface_name), None)
                if not existing:
                    interfaces.append(InterfaceInfo(name=iface_name, ip_address=None))

    except Exception as e:
        logger.error(f"Failed to get interfaces: {e}")

    return interfaces


@router.get("/interfaces", response_model=list[InterfaceInfo])
async def get_interfaces():
    """Get list of available network interfaces."""
    return get_interfaces_from_ip_addr()


@router.websocket("/live")
async def tcpdump_live(
    websocket: WebSocket,
    interface: str = Query(default="any"),
    filter: str = Query(default=""),
):
    """
    Live tcpdump capture via WebSocket.

    Captures packets until the client disconnects.

    Args:
        interface: Network interface to capture on (default: any)
        filter: BPF filter expression (e.g., "arp", "icmp", "port 80")
    """
    await websocket.accept()
    logger.info(f"TCPDump WebSocket connected: interface={interface}, filter={filter}")

    process = None
    try:
        # Build tcpdump command - no count limit, runs until disconnected
        cmd = [
            "tcpdump",
            "-i", interface,
            "-l",  # Line buffered output
            "-n",  # Don't resolve hostnames
            "-tttt",  # Human readable timestamps
        ]

        if filter:
            cmd.extend(filter.split())

        logger.info(f"Running: {' '.join(cmd)}")

        # Start tcpdump process
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        # Send initial status
        await websocket.send_json({
            "type": "status",
            "message": f"Started capture on {interface}",
            "command": " ".join(cmd)
        })

        packet_count = 0

        async def read_stderr():
            """Read stderr and send as status messages."""
            while True:
                try:
                    line = await process.stderr.readline()
                    if not line:
                        break
                    decoded = line.decode("utf-8", errors="replace").strip()
                    if decoded:
                        logger.info(f"tcpdump stderr: {decoded}")
                        await websocket.send_json({
                            "type": "status",
                            "message": decoded
                        })
                except Exception:
                    break

        # Start reading stderr in background
        stderr_task = asyncio.create_task(read_stderr())

        # Stream stdout to websocket
        while True:
            try:
                line = await asyncio.wait_for(
                    process.stdout.readline(),
                    timeout=0.5
                )

                if not line:
                    # Process ended
                    break

                decoded = line.decode("utf-8", errors="replace").strip()
                if decoded:
                    packet_count += 1
                    await websocket.send_json({
                        "type": "packet",
                        "data": decoded,
                        "count": packet_count
                    })

            except asyncio.TimeoutError:
                # Check if process is still running
                if process.returncode is not None:
                    break
                # Check if client still connected by sending ping
                try:
                    await websocket.send_json({"type": "ping"})
                except Exception:
                    break

        # Wait for stderr task to complete
        stderr_task.cancel()
        try:
            await stderr_task
        except asyncio.CancelledError:
            pass

        # Send completion message
        await websocket.send_json({
            "type": "complete",
            "message": f"Capture complete: {packet_count} packets",
            "count": packet_count
        })

    except WebSocketDisconnect:
        logger.info("TCPDump WebSocket disconnected by client")
    except Exception as e:
        logger.error(f"TCPDump WebSocket error: {e}")
        try:
            await websocket.send_json({
                "type": "error",
                "message": str(e)
            })
        except Exception:
            pass
    finally:
        if process and process.returncode is None:
            process.terminate()
            try:
                await asyncio.wait_for(process.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                process.kill()
            logger.info("TCPDump process terminated")


@router.post("/capture")
async def capture_packets(
    interface: str = Query(default="any"),
    filter: str = Query(default=""),
    count: int = Query(default=10, ge=1, le=100),
    timeout: int = Query(default=5, ge=1, le=30),
):
    """
    Capture packets and return them (non-streaming).

    Args:
        interface: Network interface to capture on
        filter: BPF filter expression
        count: Number of packets to capture
        timeout: Timeout in seconds
    """
    cmd = [
        "tcpdump",
        "-i", interface,
        "-n",
        "-c", str(count),
        "-tttt",
    ]

    if filter:
        cmd.extend(filter.split())

    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        stdout, stderr = await asyncio.wait_for(
            process.communicate(),
            timeout=timeout
        )

        packets = [
            line.strip()
            for line in stdout.decode("utf-8", errors="replace").split("\n")
            if line.strip()
        ]

        return {
            "interface": interface,
            "filter": filter,
            "packet_count": len(packets),
            "packets": packets
        }

    except asyncio.TimeoutError:
        if process.returncode is None:
            process.kill()
        return {
            "interface": interface,
            "filter": filter,
            "packet_count": 0,
            "packets": [],
            "error": "Capture timed out"
        }
    except Exception as e:
        return {
            "interface": interface,
            "filter": filter,
            "packet_count": 0,
            "packets": [],
            "error": str(e)
        }


@router.websocket("/live-pcap")
async def tcpdump_live_pcap(
    websocket: WebSocket,
    interface: str = Query(default="any"),
    filter: str = Query(default=""),
):
    """
    Live tcpdump capture via WebSocket with PCAP file generation.

    Captures packets until the client disconnects or sends a stop command.
    Uses two tcpdump processes: one for PCAP file, one for live display.

    Client can send:
        - {"type": "stop"} - Stop capture and get pcap data
        - {"type": "get_pcap"} - Get pcap data without stopping

    Messages sent to client:
        - {"type": "status", "message": "..."} - Status updates
        - {"type": "packet", "data": "...", "count": N} - Packet info
        - {"type": "pcap", "data": "base64...", "filename": "...", "size": N} - PCAP file
        - {"type": "complete", ...} - Capture complete
        - {"type": "error", "message": "..."} - Error
    """
    await websocket.accept()
    logger.info(f"TCPDump PCAP WebSocket connected: interface={interface}, filter={filter}")

    pcap_process = None
    display_process = None
    pcap_path = None

    try:
        # Create temp file for pcap
        pcap_file = tempfile.NamedTemporaryFile(
            delete=False,
            suffix=".pcap",
            prefix="capture_"
        )
        pcap_path = pcap_file.name
        pcap_file.close()

        # Build filter args
        filter_args = filter.split() if filter else []

        # Process 1: Write to PCAP file (silent)
        pcap_cmd = [
            "tcpdump",
            "-i", interface,
            "-n",
            "-U",  # Packet-buffered output
            "-w", pcap_path,
        ] + filter_args

        # Process 2: Live display output
        display_cmd = [
            "tcpdump",
            "-i", interface,
            "-l",  # Line buffered output
            "-n",  # Don't resolve hostnames
            "-tttt",  # Human readable timestamps
        ] + filter_args

        logger.info(f"Running PCAP: {' '.join(pcap_cmd)}")
        logger.info(f"Running Display: {' '.join(display_cmd)}")

        # Start both tcpdump processes
        pcap_process = await asyncio.create_subprocess_exec(
            *pcap_cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )

        display_process = await asyncio.create_subprocess_exec(
            *display_cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        # Send initial status
        await websocket.send_json({
            "type": "status",
            "message": f"Started capture on {interface}",
            "command": " ".join(display_cmd),
            "pcap_file": os.path.basename(pcap_path)
        })

        packet_count = 0
        stop_requested = False

        async def read_display_stdout():
            """Read stdout from display process for packet output."""
            nonlocal packet_count
            while True:
                try:
                    line = await display_process.stdout.readline()
                    if not line:
                        break
                    decoded = line.decode("utf-8", errors="replace").strip()
                    if decoded:
                        packet_count += 1
                        await websocket.send_json({
                            "type": "packet",
                            "data": decoded,
                            "count": packet_count
                        })
                except Exception:
                    break

        async def read_display_stderr():
            """Read stderr from display process for status messages."""
            while True:
                try:
                    line = await display_process.stderr.readline()
                    if not line:
                        break
                    decoded = line.decode("utf-8", errors="replace").strip()
                    if decoded:
                        # Log tcpdump status messages
                        if "packets captured" in decoded or "packets received" in decoded:
                            logger.info(f"tcpdump: {decoded}")
                except Exception:
                    break

        # Start reading tasks
        stdout_task = asyncio.create_task(read_display_stdout())
        stderr_task = asyncio.create_task(read_display_stderr())

        # Listen for client messages and monitor process
        while not stop_requested:
            try:
                # Check for client message with short timeout
                try:
                    msg = await asyncio.wait_for(
                        websocket.receive_json(),
                        timeout=1.0
                    )
                    if msg.get("type") == "stop":
                        stop_requested = True
                        break
                    elif msg.get("type") == "get_pcap":
                        # Send current pcap without stopping
                        if os.path.exists(pcap_path):
                            with open(pcap_path, "rb") as f:
                                pcap_data = base64.b64encode(f.read()).decode("utf-8")
                            await websocket.send_json({
                                "type": "pcap",
                                "data": pcap_data,
                                "filename": f"capture_{interface}.pcap",
                                "size": os.path.getsize(pcap_path)
                            })
                except asyncio.TimeoutError:
                    pass

                # Check if processes are still running
                if pcap_process.returncode is not None or display_process.returncode is not None:
                    break

                # Send periodic status with file size
                if os.path.exists(pcap_path):
                    file_size = os.path.getsize(pcap_path)
                    await websocket.send_json({
                        "type": "status",
                        "message": f"Capturing... ({file_size} bytes)",
                        "file_size": file_size
                    })

            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error(f"Error in capture loop: {e}")
                break

        # Stop both processes
        for proc in [pcap_process, display_process]:
            if proc and proc.returncode is None:
                proc.terminate()
                try:
                    await asyncio.wait_for(proc.wait(), timeout=2.0)
                except asyncio.TimeoutError:
                    proc.kill()

        # Cancel read tasks
        for task in [stdout_task, stderr_task]:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

        # Send final pcap data
        if os.path.exists(pcap_path) and os.path.getsize(pcap_path) > 0:
            with open(pcap_path, "rb") as f:
                pcap_data = base64.b64encode(f.read()).decode("utf-8")

            await websocket.send_json({
                "type": "pcap",
                "data": pcap_data,
                "filename": f"capture_{interface}.pcap",
                "size": os.path.getsize(pcap_path)
            })

            await websocket.send_json({
                "type": "complete",
                "message": f"Capture complete: {os.path.getsize(pcap_path)} bytes",
                "packet_count": packet_count,
                "file_size": os.path.getsize(pcap_path)
            })
        else:
            await websocket.send_json({
                "type": "complete",
                "message": "Capture complete: no packets captured",
                "packet_count": 0,
                "file_size": 0
            })

    except WebSocketDisconnect:
        logger.info("TCPDump PCAP WebSocket disconnected by client")
    except Exception as e:
        logger.error(f"TCPDump PCAP WebSocket error: {e}")
        try:
            await websocket.send_json({
                "type": "error",
                "message": str(e)
            })
        except Exception:
            pass
    finally:
        # Cleanup processes
        for proc in [pcap_process, display_process]:
            if proc and proc.returncode is None:
                proc.terminate()
                try:
                    await asyncio.wait_for(proc.wait(), timeout=2.0)
                except asyncio.TimeoutError:
                    proc.kill()
        logger.info("TCPDump processes terminated")

        # Remove temp file
        if pcap_path and os.path.exists(pcap_path):
            try:
                os.unlink(pcap_path)
            except Exception:
                pass

        try:
            await websocket.close()
        except Exception:
            pass
