from pydantic import BaseModel, Field, field_validator
import re
from typing import Optional


class HealthResponse(BaseModel):
    status: str = "ok"
    version: str


class WakeRequest(BaseModel):
    mac: str = Field(..., description="MAC address (e.g., DE:AD:BE:EF:00:01)")
    ip: str = Field(default="255.255.255.255", description="Broadcast IP address")
    port: int = Field(default=9, ge=1, le=65535, description="UDP port")

    @field_validator("mac")
    @classmethod
    def validate_mac(cls, v: str) -> str:
        # Normalize MAC format
        mac = v.upper().replace("-", ":").replace(".", ":")

        # Validate MAC pattern
        pattern = r"^([0-9A-F]{2}:){5}[0-9A-F]{2}$"
        if not re.match(pattern, mac):
            raise ValueError(
                "Invalid MAC address format. Expected format: XX:XX:XX:XX:XX:XX"
            )
        return mac

    @field_validator("ip")
    @classmethod
    def validate_ip(cls, v: str) -> str:
        import ipaddress
        try:
            ipaddress.ip_address(v)
        except ValueError:
            raise ValueError(f"Invalid IP address: {v}")
        return v


class WakeResponse(BaseModel):
    success: bool
    message: str
    mac: str
    ip: str
    port: int


class ScanRequest(BaseModel):
    subnet: str = Field(..., description="Subnet to scan (e.g., 192.168.1.0/24)")

    @field_validator("subnet")
    @classmethod
    def validate_subnet(cls, v: str) -> str:
        import ipaddress
        try:
            network = ipaddress.ip_network(v, strict=False)
            # Limit scan size to prevent abuse
            if network.num_addresses > 1024:
                raise ValueError(
                    f"Subnet too large ({network.num_addresses} hosts). Maximum: /22 (1024 hosts)"
                )
        except ValueError as e:
            if "too large" in str(e):
                raise
            raise ValueError(f"Invalid subnet format: {v}")
        return v


class PingScanResponse(BaseModel):
    subnet: str
    total_hosts: int
    reachable_count: int
    reachable: list[str]


class DeviceInfo(BaseModel):
    ip: str
    mac: str
    hostname: Optional[str] = None
    vendor: Optional[str] = None


class ArpScanResponse(BaseModel):
    subnet: str
    device_count: int
    devices: list[DeviceInfo]


class ErrorResponse(BaseModel):
    detail: str
