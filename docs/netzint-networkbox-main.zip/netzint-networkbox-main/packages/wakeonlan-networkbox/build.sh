#!/bin/bash
# Build script for wakeonlan-networkbox Debian package

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PACKAGE_NAME="wakeonlan-networkbox"
VERSION=$(grep "^Version:" "$SCRIPT_DIR/DEBIAN/control" | cut -d' ' -f2)

echo "Building $PACKAGE_NAME version $VERSION..."

# Set correct permissions
chmod 755 "$SCRIPT_DIR/usr/bin/wakeonlan"
chmod 755 "$SCRIPT_DIR/DEBIAN/postinst"
chmod 644 "$SCRIPT_DIR/DEBIAN/control"
chmod 644 "$SCRIPT_DIR/DEBIAN/conffiles"
chmod 644 "$SCRIPT_DIR/usr/share/man/man1/wakeonlan.1"

# Compress man page
gzip -9 -f "$SCRIPT_DIR/usr/share/man/man1/wakeonlan.1" 2>/dev/null || true

# Build package
cd "$SCRIPT_DIR/.."
dpkg-deb --build "$PACKAGE_NAME" "${PACKAGE_NAME}_${VERSION}_all.deb"

echo ""
echo "Package built successfully: ${PACKAGE_NAME}_${VERSION}_all.deb"
echo ""
echo "To install:"
echo "  sudo dpkg -i ${PACKAGE_NAME}_${VERSION}_all.deb"
echo ""
echo "To configure, edit /etc/networkbox/wakeonlan.conf and set NETWORKBOX_HOST"
