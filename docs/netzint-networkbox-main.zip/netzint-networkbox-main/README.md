# Netzint-NetworkBOX

## Features

* **NAPI** - Network API Service
  * Network scanning (ARP, Ping)
  * Wake-on-LAN from multiple VLANs
  * Live packet capture (tcpdump)
  * PCAP analysis with traffic insights
* WakeOnLAN-Server
* mDNS-Repeater
* Radius-Server (for Linuxmuster- / LDAP-Backend)
* Reverse Proxy (HTTP, LDAP, SMTP, IMAP, POP3, ...)
* Certificate-Manager
* KMS-Server with GUI
* Proxy-Server for Internet blocking

## Installation

1. Create base path for networkbox on the server
```bash
mkdir -p /srv/docker/netzint-networkbox && cd /srv/docker/netzint-networkbox
```

2. Paste the docker-compose.yml in the directory
```bash
cat <<'EOF' > /srv/docker/netzint-networkbox/docker-compose.yml
services:
  networkbox-api:
    image: ghcr.io/netzint/networkbox-api:latest
    container_name: networkbox-api
    restart: always
    cap_add:
      - NET_ADMIN
    network_mode: host
    volumes:
      - /var/run/docker.sock:/var/run/docker.sock
      - ./data/api:/data/api
    environment:
      MONGO_URI: mongodb://${NETWORKBOX_DB_USERNAME:-admin}:${NETWORKBOX_DB_PASSWORD:-supersecret}@localhost:27017
    extra_hosts:
      - "networkbox-napi:172.30.0.10"

  networkbox-napi:
    image: ghcr.io/netzint/networkbox-napi:latest
    container_name: networkbox-napi
    restart: always
    cap_add:
      - NET_ADMIN
      - NET_RAW
    networks:
      networkbox-internal:
        ipv4_address: 172.30.0.10
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  networkbox-ui:
    image: ghcr.io/netzint/networkbox-ui:latest
    container_name: networkbox-ui
    restart: always
    network_mode: host
    volumes:
      - ./data/ui:/data/ui

  networkbox-db:
    image: mongo:7
    container_name: networkbox-db
    restart: always
    ports:
      - 27017:27017
    volumes:
      - ./data/db:/data/db
    environment:
      MONGO_INITDB_ROOT_USERNAME: ${NETWORKBOX_DB_USERNAME:-admin}
      MONGO_INITDB_ROOT_PASSWORD: ${NETWORKBOX_DB_PASSWORD:-supersecret}
      MONGO_INITDB_DATABASE: ${NETWORKBOX_DB_DATABASE:-networkbox}

networks:
  networkbox-internal:
    driver: bridge
    ipam:
      config:
        - subnet: 172.30.0.0/24
EOF
```

3. Create environment file .env. Don't forgot to enter the password!
```bash
cat <<EOF > /srv/docker/netzint-networkbox/.env
NETWORKBOX_JWT_SECRET=$(openssl rand -hex 40)

NETWORKBOX_DB_USERNAME=admin
NETWORKBOX_DB_PASSWORD=$(openssl rand -hex 25)
NETWORKBOX_DB_DATABASE=networkbox

# you can change username and password here
NETWORKBOX_USERNAME=admin
NETWORKBOX_PASSWORD=$(read -p "Passwort: " | sha256sum | cut -d' ' -f1)
EOF
```

4. Start the networkbox
```bash
docker compose up -d
```

## Configuration

### Change password for user

1. Generate new password hash
```bash
read -p "Passwort: " | sha256sum | cut -d' ' -f1
```

2. Paste the hash to the ".env"-File to `NETWORKBOX_PASSWORD=`