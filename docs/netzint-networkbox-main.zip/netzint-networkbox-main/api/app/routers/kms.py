import logging
from fastapi import APIRouter, Depends, HTTPException

from app.dependencies import verify_token, verify_token_from_query
from app.database import db
from app.config import settings
from app.models import KMSConfig, KMSConfigUpdate, NetworkboxResponse
from app.services.docker_service import docker_service
from app.services.action_logger import create_sse_response

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/kms",
    tags=["KMS Server"],
    dependencies=[Depends(verify_token)]
)

# Separate router for SSE streams (no global auth dependency)
stream_router = APIRouter(
    prefix="/api/v1/kms",
    tags=["KMS Server Streams"]
)


@router.get("/config", response_model=KMSConfig | None)
async def get_kms_config():
    """Get KMS configuration."""
    return db.find_one("kms_config", {})


@router.post("/config", response_model=NetworkboxResponse)
async def create_kms_config(config: KMSConfig):
    """Create or update KMS configuration."""
    db.delete("kms_config", {})
    db.insert("kms_config", config.model_dump())
    return NetworkboxResponse(status=True, message="KMS configuration saved")


@router.patch("/config", response_model=NetworkboxResponse)
async def update_kms_config(update: KMSConfigUpdate):
    """Update KMS configuration."""
    existing = db.find_one("kms_config", {})
    if not existing:
        raise HTTPException(status_code=404, detail="KMS configuration not found")

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        db.update("kms_config", {}, update_data)

    return NetworkboxResponse(status=True, message="KMS configuration updated")


@router.get("/status", response_model=NetworkboxResponse)
async def get_kms_status():
    """Get KMS server status."""
    if docker_service.container_is_running("NETWORKBOX_KMS"):
        return NetworkboxResponse(status=True, message="KMS server is running")
    else:
        return NetworkboxResponse(status=False, message="KMS server is not running")


@router.post("/start", response_model=NetworkboxResponse)
async def start_kms_server():
    """Start KMS server."""
    config_data = db.find_one("kms_config", {})
    if not config_data:
        config_data = {
            "listen_address": "0.0.0.0",
            "listen_port": 1688,
            "allowed_networks": []
        }

    config = KMSConfig(**config_data)

    try:
        # Stop existing
        docker_service.stop_container("NETWORKBOX_KMS")

        # Pull image
        docker_service.pull_image(settings.image_kms)

        # Create container
        container = docker_service.create_container(
            image=settings.image_kms,
            name="NETWORKBOX_KMS",
            ports={f"{config.listen_port}/tcp": config.listen_port},
            environment={
                "IP": config.listen_address,
                "PORT": str(config.listen_port),
                "LOGLEVEL": "INFO"
            }
        )

        # Connect to networks if specified
        if config.allowed_networks:
            for vlan_id in config.allowed_networks:
                network = db.find_one("networks", {"vlan_id": vlan_id})
                if network:
                    try:
                        docker_service.connect_container_to_network(
                            container,
                            f"NETWORKBOX_{network['name']}"
                        )
                    except Exception as e:
                        logger.warning(f"Failed to connect to network: {e}")

        return NetworkboxResponse(status=True, message="KMS server started")

    except Exception as e:
        logger.exception(e)
        # Cleanup: stop and remove the container on failure
        docker_service.stop_container("NETWORKBOX_KMS")
        return NetworkboxResponse(status=False, message=f"Failed to start: {str(e)}")


@router.post("/stop", response_model=NetworkboxResponse)
async def stop_kms_server():
    """Stop KMS server."""
    if docker_service.stop_container("NETWORKBOX_KMS"):
        return NetworkboxResponse(status=True, message="KMS server stopped")
    else:
        return NetworkboxResponse(status=False, message="Failed to stop KMS server")


@stream_router.get("/start/stream")
async def start_kms_stream(_: dict = Depends(verify_token_from_query)):
    """Start KMS server with live progress stream."""
    config_data = db.find_one("kms_config", {})
    if not config_data:
        config_data = {
            "listen_address": "0.0.0.0",
            "listen_port": 1688,
            "allowed_networks": []
        }

    config = KMSConfig(**config_data)

    def action(action_logger):
        try:
            action_logger.info("Starting KMS server...")

            # Stop existing
            action_logger.info("Stopping existing KMS container...")
            docker_service.stop_container("NETWORKBOX_KMS", log_callback=action_logger.info)

            # Pull image
            docker_service.pull_image(settings.image_kms, log_callback=action_logger.info)

            # Create container
            action_logger.info("Creating KMS container...")
            container = docker_service.create_container(
                image=settings.image_kms,
                name="NETWORKBOX_KMS",
                ports={f"{config.listen_port}/tcp": config.listen_port},
                environment={
                    "IP": config.listen_address,
                    "PORT": str(config.listen_port),
                    "LOGLEVEL": "INFO"
                },
                log_callback=action_logger.info
            )

            # Connect to networks if specified
            if config.allowed_networks:
                for vlan_id in config.allowed_networks:
                    network = db.find_one("networks", {"vlan_id": vlan_id})
                    if network:
                        try:
                            action_logger.info(f"Connecting to network {network['name']}...")
                            docker_service.connect_container_to_network(
                                container,
                                f"NETWORKBOX_{network['name']}"
                            )
                        except Exception as e:
                            action_logger.warning(f"Failed to connect to network: {e}")

            action_logger.success("KMS server is now running")
            return True

        except Exception as e:
            logger.exception(e)
            action_logger.error(f"Failed to start: {str(e)}")
            # Cleanup: stop and remove the container on failure
            action_logger.info("Cleaning up failed container...")
            docker_service.stop_container("NETWORKBOX_KMS", log_callback=action_logger.info)
            return False

    return create_sse_response(action)


@stream_router.get("/stop/stream")
async def stop_kms_stream(_: dict = Depends(verify_token_from_query)):
    """Stop KMS server with live progress stream."""

    def action(action_logger):
        action_logger.info("Stopping KMS server...")
        success = docker_service.stop_container("NETWORKBOX_KMS", log_callback=action_logger.info)

        if success:
            action_logger.success("KMS server stopped")
        else:
            action_logger.error("Failed to stop KMS server")

        return success

    return create_sse_response(action)
