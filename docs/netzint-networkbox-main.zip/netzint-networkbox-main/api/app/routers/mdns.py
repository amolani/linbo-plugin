import logging
from fastapi import APIRouter, Depends, HTTPException

from app.dependencies import verify_token, verify_token_from_query
from app.database import db
from app.config import settings
from app.models import (
    MDNSRepeater, MDNSRepeaterUpdate, MDNSRepeaterCluster,
    Network, NetworkboxResponse
)
from app.services.docker_service import docker_service
from app.services.action_logger import create_sse_response

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/mdns",
    tags=["MDNS Repeater"],
    dependencies=[Depends(verify_token)]
)

# Separate router for SSE streams (no global auth dependency)
stream_router = APIRouter(
    prefix="/api/v1/mdns",
    tags=["MDNS Repeater Streams"]
)


def start_mdns_container_internal(
    mdns: MDNSRepeater,
    network1: dict,
    network2: dict,
    log_callback=None
) -> bool:
    """Start an MDNS repeater container."""
    container_name = f"NETWORKBOX_MDNS_{mdns.name.upper()}"
    try:
        if log_callback:
            log_callback(f"Starting MDNS repeater '{mdns.name}'...")

        # Pull image
        docker_service.pull_image(settings.image_mdns, log_callback=log_callback)

        # Create container
        if log_callback:
            log_callback(f"Creating container {container_name}...")

        container = docker_service.create_container(
            image=settings.image_mdns,
            name=container_name,
            environment={"REFLECTOR_ENABLE_REFLECTOR": "yes"},
            network=None,
            log_callback=log_callback
        )

        # Connect to networks
        docker_service.connect_container_to_network(
            container,
            f"NETWORKBOX_{network1['name']}",
            ipv4_address=mdns.network1.address,
            log_callback=log_callback
        )
        docker_service.connect_container_to_network(
            container,
            f"NETWORKBOX_{network2['name']}",
            ipv4_address=mdns.network2.address,
            log_callback=log_callback
        )

        if log_callback:
            log_callback(f"MDNS repeater '{mdns.name}' started successfully")

        return True
    except Exception as e:
        logger.error(f"Failed to start MDNS container: {e}")
        if log_callback:
            log_callback(f"Failed to start MDNS container: {e}")
        # Cleanup: stop and remove the container on failure
        if log_callback:
            log_callback(f"Cleaning up failed container...")
        docker_service.stop_container(container_name, log_callback=log_callback)
        return False


def stop_mdns_container_internal(mdns: MDNSRepeater, log_callback=None) -> bool:
    """Stop an MDNS repeater container."""
    container_name = f"NETWORKBOX_MDNS_{mdns.name.upper()}"
    if log_callback:
        log_callback(f"Stopping MDNS repeater '{mdns.name}'...")
    result = docker_service.stop_container(container_name, log_callback=log_callback)
    if log_callback and result:
        log_callback(f"MDNS repeater '{mdns.name}' stopped successfully")
    return result


@router.get("", response_model=list[MDNSRepeater])
async def get_all_mdns_repeaters():
    """Get all MDNS repeaters."""
    result = db.find("mdns_repeater", {})
    return list(result) if result else []


@router.post("", response_model=NetworkboxResponse)
async def create_mdns_repeater(mdns: MDNSRepeater):
    """Create a new MDNS repeater."""
    # Verify networks exist
    network1 = db.find_one("networks", {"vlan_id": mdns.network1.vlan_id})
    network2 = db.find_one("networks", {"vlan_id": mdns.network2.vlan_id})

    if not network1 or not network2:
        raise HTTPException(status_code=400, detail="One or both networks not found")

    existing = db.find_one("mdns_repeater", {"name": mdns.name})
    if existing:
        raise HTTPException(status_code=400, detail="MDNS repeater with this name already exists")

    db.insert("mdns_repeater", mdns.model_dump())
    return NetworkboxResponse(status=True, message="MDNS repeater created")


@router.get("/cluster", response_model=MDNSRepeaterCluster)
async def get_mdns_cluster():
    """Get MDNS repeater cluster visualization data."""
    repeaters = db.find("mdns_repeater", {})

    nodes = []
    links = []
    node_ids = set()

    for mdns_data in repeaters:
        mdns = MDNSRepeater(**mdns_data)
        network1 = db.find_one("networks", {"vlan_id": mdns.network1.vlan_id})
        network2 = db.find_one("networks", {"vlan_id": mdns.network2.vlan_id})

        if not network1 or not network2:
            continue

        # Add nodes
        if network1["name"] not in node_ids:
            node_ids.add(network1["name"])
            nodes.append({"id": network1["name"], "label": network1["name"]})

        if network2["name"] not in node_ids:
            node_ids.add(network2["name"])
            nodes.append({"id": network2["name"], "label": network2["name"]})

        # Add link
        links.append({
            "source": network1["name"],
            "target": network2["name"],
            "id": mdns.name,
            "label": mdns.name
        })

    return MDNSRepeaterCluster(nodes=nodes, links=links)


@router.get("/{name}", response_model=MDNSRepeater | None)
async def get_mdns_repeater(name: str):
    """Get an MDNS repeater by name."""
    return db.find_one("mdns_repeater", {"name": name})


@router.patch("/{name}", response_model=NetworkboxResponse)
async def update_mdns_repeater(name: str, update: MDNSRepeaterUpdate):
    """Update an MDNS repeater."""
    mdns_data = db.find_one("mdns_repeater", {"name": name})
    if not mdns_data:
        raise HTTPException(status_code=404, detail="MDNS repeater not found")

    mdns = MDNSRepeater(**mdns_data)

    if update.network1_address:
        mdns.network1.address = update.network1_address
    if update.network2_address:
        mdns.network2.address = update.network2_address

    db.update("mdns_repeater", {"name": name}, mdns.model_dump())
    return NetworkboxResponse(status=True, message="MDNS repeater updated")


@router.delete("/{name}", response_model=NetworkboxResponse)
async def delete_mdns_repeater(name: str):
    """Delete an MDNS repeater."""
    mdns_data = db.find_one("mdns_repeater", {"name": name})
    if not mdns_data:
        raise HTTPException(status_code=404, detail="MDNS repeater not found")

    mdns = MDNSRepeater(**mdns_data)
    stop_mdns_container_internal(mdns)

    db.delete("mdns_repeater", {"name": name})
    return NetworkboxResponse(status=True, message="MDNS repeater deleted")


@router.post("/{name}/start", response_model=NetworkboxResponse)
async def start_mdns_repeater(name: str):
    """Start an MDNS repeater."""
    mdns_data = db.find_one("mdns_repeater", {"name": name})
    if not mdns_data:
        raise HTTPException(status_code=404, detail="MDNS repeater not found")

    mdns = MDNSRepeater(**mdns_data)

    network1 = db.find_one("networks", {"vlan_id": mdns.network1.vlan_id})
    network2 = db.find_one("networks", {"vlan_id": mdns.network2.vlan_id})

    if not network1 or not network2:
        raise HTTPException(status_code=400, detail="One or both networks not found")

    # Stop if already running
    stop_mdns_container_internal(mdns)

    if start_mdns_container_internal(mdns, network1, network2):
        db.update("mdns_repeater", {"name": name}, {"status": True})
        return NetworkboxResponse(status=True, message="MDNS repeater started")
    else:
        return NetworkboxResponse(status=False, message="Failed to start MDNS repeater")


@router.post("/{name}/stop", response_model=NetworkboxResponse)
async def stop_mdns_repeater(name: str):
    """Stop an MDNS repeater."""
    mdns_data = db.find_one("mdns_repeater", {"name": name})
    if not mdns_data:
        raise HTTPException(status_code=404, detail="MDNS repeater not found")

    mdns = MDNSRepeater(**mdns_data)

    if stop_mdns_container_internal(mdns):
        db.update("mdns_repeater", {"name": name}, {"status": False})
        return NetworkboxResponse(status=True, message="MDNS repeater stopped")
    else:
        return NetworkboxResponse(status=False, message="Failed to stop MDNS repeater")


@stream_router.get("/{name}/start/stream")
async def start_mdns_stream(
    name: str,
    _: dict = Depends(verify_token_from_query)
):
    """Start an MDNS repeater with live progress stream."""
    mdns_data = db.find_one("mdns_repeater", {"name": name})
    if not mdns_data:
        raise HTTPException(status_code=404, detail="MDNS repeater not found")

    mdns = MDNSRepeater(**mdns_data)

    network1 = db.find_one("networks", {"vlan_id": mdns.network1.vlan_id})
    network2 = db.find_one("networks", {"vlan_id": mdns.network2.vlan_id})

    if not network1 or not network2:
        raise HTTPException(status_code=400, detail="One or both networks not found")

    def action(action_logger):
        # Stop if already running
        stop_mdns_container_internal(mdns, log_callback=action_logger.info)

        success = start_mdns_container_internal(
            mdns, network1, network2,
            log_callback=action_logger.info
        )

        if success:
            db.update("mdns_repeater", {"name": name}, {"status": True})
            action_logger.success("MDNS repeater is now running")
        else:
            action_logger.error("Failed to start MDNS repeater")

        return success

    return create_sse_response(action)


@stream_router.get("/{name}/stop/stream")
async def stop_mdns_stream(
    name: str,
    _: dict = Depends(verify_token_from_query)
):
    """Stop an MDNS repeater with live progress stream."""
    mdns_data = db.find_one("mdns_repeater", {"name": name})
    if not mdns_data:
        raise HTTPException(status_code=404, detail="MDNS repeater not found")

    mdns = MDNSRepeater(**mdns_data)

    def action(action_logger):
        success = stop_mdns_container_internal(mdns, log_callback=action_logger.info)

        if success:
            db.update("mdns_repeater", {"name": name}, {"status": False})
            action_logger.success("MDNS repeater stopped")
        else:
            action_logger.error("Failed to stop MDNS repeater")

        return success

    return create_sse_response(action)
