import logging
import io
import tarfile
from fastapi import APIRouter, Depends, HTTPException

from app.dependencies import verify_token
from app.database import db
from app.config import settings
from app.models import ReverseProxy, ReverseProxyUpdate, NetworkboxResponse
from app.services.docker_service import docker_service

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/reverseproxy",
    tags=["Reverse Proxy"],
    dependencies=[Depends(verify_token)]
)


def generate_haproxy_config(proxy: ReverseProxy, cert_path: str = None) -> str:
    """Generate HAProxy configuration."""
    config = f"""
global
    daemon
    maxconn 256

defaults
    mode tcp
    timeout connect 5s
    timeout client 30s
    timeout server 30s

frontend {proxy.name}_frontend
    bind *:{proxy.listen_port}"""

    if cert_path and proxy.protocol in ["https", "ldaps", "smtps", "imaps", "pop3s"]:
        config += f" ssl crt {cert_path}"

    config += f"""
    default_backend {proxy.name}_backend

backend {proxy.name}_backend
    balance {proxy.load_balancing.replace('-', '')}
"""

    for i, target in enumerate(proxy.targets):
        config += f"    server server{i} {target.address}:{target.port} weight {target.weight}\n"

    return config


@router.get("", response_model=list[ReverseProxy])
async def get_all_reverse_proxies():
    """Get all reverse proxies."""
    result = db.find("reverse_proxies", {})
    return list(result) if result else []


@router.post("", response_model=NetworkboxResponse)
async def create_reverse_proxy(proxy: ReverseProxy):
    """Create a new reverse proxy."""
    existing = db.find_one("reverse_proxies", {"name": proxy.name})
    if existing:
        raise HTTPException(status_code=400, detail="Reverse proxy with this name already exists")

    db.insert("reverse_proxies", proxy.model_dump())
    return NetworkboxResponse(status=True, message="Reverse proxy created")


@router.get("/{name}", response_model=ReverseProxy)
async def get_reverse_proxy(name: str):
    """Get a reverse proxy by name."""
    result = db.find_one("reverse_proxies", {"name": name})
    if not result:
        raise HTTPException(status_code=404, detail="Reverse proxy not found")
    return result


@router.patch("/{name}", response_model=NetworkboxResponse)
async def update_reverse_proxy(name: str, update: ReverseProxyUpdate):
    """Update a reverse proxy."""
    existing = db.find_one("reverse_proxies", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Reverse proxy not found")

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        db.update("reverse_proxies", {"name": name}, update_data)

    return NetworkboxResponse(status=True, message="Reverse proxy updated")


@router.delete("/{name}", response_model=NetworkboxResponse)
async def delete_reverse_proxy(name: str):
    """Delete a reverse proxy."""
    existing = db.find_one("reverse_proxies", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Reverse proxy not found")

    docker_service.stop_container(f"NETWORKBOX_REVERSEPROXY_{name}")
    db.delete("reverse_proxies", {"name": name})

    return NetworkboxResponse(status=True, message="Reverse proxy deleted")


@router.post("/{name}/start", response_model=NetworkboxResponse)
async def start_reverse_proxy(name: str):
    """Start a reverse proxy."""
    proxy_data = db.find_one("reverse_proxies", {"name": name})
    if not proxy_data:
        raise HTTPException(status_code=404, detail="Reverse proxy not found")

    proxy = ReverseProxy(**proxy_data)

    try:
        # Stop existing
        docker_service.stop_container(f"NETWORKBOX_REVERSEPROXY_{name}")

        # Pull image
        docker_service.pull_image(settings.image_haproxy)

        # Get certificate
        cert_content = None
        if proxy.certificate:
            cert = db.find_one("certificates", {"name": proxy.certificate})
            if cert:
                cert_content = cert["cert_pem"] + "\n" + cert["key_pem"]

        # Generate config
        cert_path = "/etc/haproxy/cert.pem" if cert_content else None
        config = generate_haproxy_config(proxy, cert_path)

        # Create container
        container = docker_service.create_container(
            image=settings.image_haproxy,
            name=f"NETWORKBOX_REVERSEPROXY_{name}",
            ports={f"{proxy.listen_port}/tcp": proxy.listen_port},
            command=["haproxy", "-f", "/usr/local/etc/haproxy/haproxy.cfg"]
        )

        # Write config to /usr/local/etc/haproxy/
        config_stream = io.BytesIO()
        with tarfile.open(fileobj=config_stream, mode='w') as tar:
            config_bytes = config.encode('utf-8')
            tarinfo = tarfile.TarInfo(name='haproxy.cfg')
            tarinfo.size = len(config_bytes)
            tar.addfile(tarinfo, io.BytesIO(config_bytes))
        config_stream.seek(0)
        container.put_archive('/usr/local/etc/haproxy/', config_stream)

        # Write certificate to /etc/haproxy/ (where config expects it)
        if cert_content:
            cert_stream = io.BytesIO()
            with tarfile.open(fileobj=cert_stream, mode='w') as tar:
                # Create the directory entry in the tar archive
                dirinfo = tarfile.TarInfo(name='haproxy')
                dirinfo.type = tarfile.DIRTYPE
                dirinfo.mode = 0o755
                tar.addfile(dirinfo)
                # Add the certificate file
                cert_bytes = cert_content.encode('utf-8')
                certinfo = tarfile.TarInfo(name='haproxy/cert.pem')
                certinfo.size = len(cert_bytes)
                certinfo.mode = 0o644
                tar.addfile(certinfo, io.BytesIO(cert_bytes))
            cert_stream.seek(0)
            # Extract to /etc/ - this will create /etc/haproxy/cert.pem
            container.put_archive('/etc/', cert_stream)
        container.start()

        db.update("reverse_proxies", {"name": name}, {"status": True})
        return NetworkboxResponse(status=True, message="Reverse proxy started")

    except Exception as e:
        logger.exception(e)
        # Cleanup: stop and remove the container on failure
        docker_service.stop_container(f"NETWORKBOX_REVERSEPROXY_{name}")
        return NetworkboxResponse(status=False, message=f"Failed to start: {str(e)}")


@router.post("/{name}/stop", response_model=NetworkboxResponse)
async def stop_reverse_proxy(name: str):
    """Stop a reverse proxy."""
    if docker_service.stop_container(f"NETWORKBOX_REVERSEPROXY_{name}"):
        db.update("reverse_proxies", {"name": name}, {"status": False})
        return NetworkboxResponse(status=True, message="Reverse proxy stopped")
    else:
        return NetworkboxResponse(status=False, message="Failed to stop reverse proxy")
