from fastapi import APIRouter, Depends, HTTPException

from app.dependencies import verify_token
from app.database import db
from app.models import Authentication, AuthenticationUpdate, AuthenticationTest, NetworkboxResponse
from app.services.ldap_service import ldap_service

router = APIRouter(
    prefix="/api/v1/authentications",
    tags=["Authentication Providers"],
    dependencies=[Depends(verify_token)]
)


@router.get("", response_model=list[Authentication])
async def get_all_authentications():
    """Get all authentication providers."""
    result = db.find("authentications", {})
    return list(result) if result else []


@router.post("", response_model=NetworkboxResponse)
async def create_authentication(auth: Authentication):
    """Create a new authentication provider."""
    existing = db.find_one("authentications", {"name": auth.name})
    if existing:
        raise HTTPException(status_code=400, detail="Authentication provider with this name already exists")

    db.insert("authentications", auth.model_dump())
    return NetworkboxResponse(status=True, message="Authentication provider created")


@router.get("/{name}", response_model=Authentication | None)
async def get_authentication(name: str):
    """Get an authentication provider by name."""
    result = db.find_one("authentications", {"name": name})
    return result


@router.patch("/{name}", response_model=NetworkboxResponse)
async def update_authentication(name: str, update: AuthenticationUpdate):
    """Update an authentication provider."""
    existing = db.find_one("authentications", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Authentication provider not found")

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        db.update("authentications", {"name": name}, update_data)

    return NetworkboxResponse(status=True, message="Authentication provider updated")


@router.delete("/{name}", response_model=NetworkboxResponse)
async def delete_authentication(name: str):
    """Delete an authentication provider."""
    existing = db.find_one("authentications", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Authentication provider not found")

    db.delete("authentications", {"name": name})
    return NetworkboxResponse(status=True, message="Authentication provider deleted")


@router.post("/test", response_model=NetworkboxResponse)
async def test_authentication_inline(auth_test: AuthenticationTest):
    """Test an authentication provider connection with inline data (without saving).

    If password is empty and name is provided, the stored password will be used.
    """
    password = auth_test.password

    # If no password provided but name exists, fetch stored password
    if not password and auth_test.name:
        existing = db.find_one("authentications", {"name": auth_test.name})
        if existing:
            password = existing.get("password")

    if not password:
        return NetworkboxResponse(status=False, message="Password is required")

    # Build Authentication object for test
    auth = Authentication(
        name=auth_test.name or "test",
        server=auth_test.server,
        port=auth_test.port,
        use_ssl=auth_test.use_ssl,
        validate_cert=auth_test.validate_cert,
        binduser=auth_test.binduser,
        password=password,
        basedn=auth_test.basedn,
        userfilter=auth_test.userfilter,
    )

    success, message, entries = ldap_service.test_connection(auth)

    return NetworkboxResponse(
        status=success,
        message=message,
        data={"entries": entries} if entries else None
    )


@router.post("/{name}/test", response_model=NetworkboxResponse)
async def test_authentication(name: str):
    """Test an authentication provider connection."""
    auth_data = db.find_one("authentications", {"name": name})
    if not auth_data:
        raise HTTPException(status_code=404, detail="Authentication provider not found")

    auth = Authentication(**auth_data)
    success, message, entries = ldap_service.test_connection(auth)

    return NetworkboxResponse(
        status=success,
        message=message,
        data={"entries": entries} if entries else None
    )


@router.get("/{name}/groups", response_model=list[str])
async def get_authentication_groups(name: str):
    """Get groups from an authentication provider."""
    auth_data = db.find_one("authentications", {"name": name})
    if not auth_data:
        raise HTTPException(status_code=404, detail="Authentication provider not found")

    auth = Authentication(**auth_data)
    return ldap_service.get_groups(auth)
