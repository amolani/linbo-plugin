from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

from app.dependencies import verify_token, verify_token_from_query
from app.services.docker_service import docker_service
from app.models import Container

router = APIRouter(
    prefix="/api/v1/containers",
    tags=["Containers"],
)


@router.get("", response_model=list[Container], dependencies=[Depends(verify_token)])
async def get_containers():
    """Get all NetworkBox containers."""
    return docker_service.list_networkbox_containers()


@router.get("/{container_id}/logs")
async def get_container_logs(
    container_id: str,
    tail: int = 50,
    _: dict = Depends(verify_token_from_query)
):
    """Stream container logs via Server-Sent Events."""
    container = docker_service.get_container(container_id)
    if not container:
        raise HTTPException(status_code=404, detail="Container not found")

    def sse_generator():
        yield "retry: 2000\n\n"
        for line in docker_service.get_container_logs(container_id, tail):
            yield f"data: {line}\n\n"

    return StreamingResponse(
        sse_generator(),
        media_type="text/event-stream"
    )
