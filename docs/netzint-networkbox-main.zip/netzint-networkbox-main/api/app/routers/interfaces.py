from fastapi import APIRouter, Depends

from app.dependencies import verify_token
from app.services.network_service import network_service

router = APIRouter(
    prefix="/api/v1/interfaces",
    tags=["Interfaces"],
    dependencies=[Depends(verify_token)]
)


@router.get("", response_model=list[str])
async def get_interfaces():
    """Get list of available physical network interfaces."""
    return network_service.get_host_interfaces()
