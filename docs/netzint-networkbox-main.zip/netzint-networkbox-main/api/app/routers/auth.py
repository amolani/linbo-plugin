import hashlib

from fastapi import APIRouter, Depends, HTTPException, Response, Cookie

from app.models import Login, TokenResponse, PasswordChange
from app.dependencies import (
    verify_password,
    verify_token,
    create_access_token,
    create_refresh_token,
    settings
)
from app.database import db
from jose import JWTError, jwt

router = APIRouter(prefix="/api/v1", tags=["Authentication"])


@router.post("/login", response_model=TokenResponse)
async def login(data: Login, response: Response):
    """Authenticate user and return access token."""
    if not verify_password(data.username, data.password):
        raise HTTPException(status_code=400, detail="Invalid credentials")

    access_token = create_access_token(data.username)
    refresh_token = create_refresh_token(data.username)

    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        httponly=True,
        secure=True,
        samesite="strict",
        max_age=60 * 60 * 24 * settings.refresh_token_lifetime_days
    )

    return TokenResponse(access_token=access_token)


@router.post("/change-password", dependencies=[Depends(verify_token)])
async def change_password(data: PasswordChange):
    """Change admin password."""
    if not verify_password(settings.admin_username, data.current_password):
        raise HTTPException(status_code=400, detail="Aktuelles Passwort ist falsch")

    new_hash = hashlib.sha256(data.new_password.encode()).hexdigest()
    db.upsert("settings", {"key": "admin_password_hash"}, {"key": "admin_password_hash", "value": new_hash})
    return {"message": "Passwort erfolgreich geändert"}


@router.post("/refresh", response_model=TokenResponse)
async def refresh(refresh_token: str = Cookie(None)):
    """Refresh access token using refresh token cookie."""
    if not refresh_token:
        raise HTTPException(status_code=401, detail="No refresh token provided")

    try:
        payload = jwt.decode(
            refresh_token,
            settings.jwt_secret,
            algorithms=[settings.jwt_algorithm]
        )
        username = payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid refresh token")

    access_token = create_access_token(username)
    return TokenResponse(access_token=access_token)
