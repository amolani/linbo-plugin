import logging
import ipaddress
import asyncio
from urllib.parse import urlencode

from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect, Query
import websockets

from app.dependencies import verify_token
from app.database import db
from app.config import settings
from app.models import (
    NetworkboxResponse, WOLRequest, WOLClientRequest, ScanRequest,
    PingScanResponse, ArpScanResponse,
    NAPIConfig, NAPIConfigUpdate, NAPIStatus
)
from app.services.napi_client import napi_client
from app.services.docker_service import docker_service

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/napi",
    tags=["NAPI"],
    dependencies=[Depends(verify_token)]
)

# Separate router for WebSocket endpoints (no auth dependency)
ws_router = APIRouter(
    prefix="/api/v1/napi",
    tags=["NAPI WebSocket"]
)


# ============ NAPI Configuration ============

@router.get("/config", response_model=NAPIConfig)
async def get_napi_config():
    """Get NAPI configuration."""
    config = db.find_one("napi_config", {})
    if not config:
        # Return default config
        return NAPIConfig()
    return NAPIConfig(**config)


@router.post("/config", response_model=NetworkboxResponse)
async def save_napi_config(config: NAPIConfig):
    """Save NAPI configuration."""
    db.delete("napi_config", {})
    db.insert("napi_config", config.model_dump())
    return NetworkboxResponse(status=True, message="NAPI configuration saved")


@router.patch("/config", response_model=NetworkboxResponse)
async def update_napi_config(update: NAPIConfigUpdate):
    """Update NAPI configuration."""
    existing = db.find_one("napi_config", {})
    if not existing:
        existing = NAPIConfig().model_dump()

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        existing.update(update_data)
        db.delete("napi_config", {})
        db.insert("napi_config", existing)

    return NetworkboxResponse(status=True, message="NAPI configuration updated")


# ============ NAPI Status & Control ============

@router.get("/status", response_model=NAPIStatus)
async def get_napi_status():
    """Get detailed NAPI service status."""
    is_healthy = await napi_client.health_check()

    # Get connected networks
    connected_networks = []
    try:
        container = docker_service.get_container("networkbox-napi")
        if container:
            networks = container.attrs.get("NetworkSettings", {}).get("Networks", {})
            connected_networks = list(networks.keys())
    except Exception:
        pass

    return NAPIStatus(
        running=is_healthy,
        version=settings.app_version if is_healthy else None,
        connected_networks=connected_networks
    )


@router.post("/restart", response_model=NetworkboxResponse)
async def restart_napi():
    """Restart the NAPI container and reconnect to configured networks."""
    from app.services.network_service import network_service

    try:
        container = docker_service.get_container("networkbox-napi")
        if not container:
            return NetworkboxResponse(status=False, message="NAPI container not found")

        # Get NAPI config to know which networks are needed
        napi_config = db.find_one("napi_config", {})
        required_networks = {}  # network_name -> network_data

        if napi_config and napi_config.get("networks"):
            for net_config in napi_config["networks"]:
                vlan_id = net_config.get("vlan_id")
                if vlan_id is not None:
                    network_data = db.find_one("networks", {"vlan_id": vlan_id})
                    if network_data:
                        network_name = f"NETWORKBOX_{network_data['name']}"
                        required_networks[network_name] = network_data

        # Disconnect from all custom networks before restart
        # This prevents "network not found" errors if a network was deleted
        container.reload()
        current_networks = container.attrs.get("NetworkSettings", {}).get("Networks", {})
        client = docker_service.client

        for network_name in list(current_networks.keys()):
            # Skip default networks that should remain connected
            if network_name in ["bridge", "host", "none", "networkbox_default"]:
                continue
            try:
                network = client.networks.get(network_name)
                network.disconnect(container, force=True)
                logger.info(f"Disconnected NAPI from network: {network_name}")
            except Exception as e:
                # Network might not exist anymore, that's fine
                logger.debug(f"Could not disconnect from {network_name}: {e}")

        # Recreate missing networks that are required
        recreated_networks = []
        for network_name, network_data in required_networks.items():
            try:
                client.networks.get(network_name)
                # Network exists, nothing to do
            except Exception:
                # Network doesn't exist, recreate it
                logger.info(f"Recreating missing network: {network_name}")
                try:
                    # Create VLAN interface if needed
                    if network_data.get("vlan_id", 0) > 0:
                        network_service.create_vlan_interface(
                            network_data["parent"],
                            network_data["vlan_id"]
                        )

                    # Create the macvlan network
                    success = network_service.create_macvlan_network(
                        name=network_data["name"],
                        parent=network_data["parent"],
                        vlan_id=network_data.get("vlan_id", 0),
                        address=network_data["address"],
                        mask=network_data["mask"]
                    )
                    if success:
                        recreated_networks.append(network_name)
                        logger.info(f"Successfully recreated network: {network_name}")
                    else:
                        logger.error(f"Failed to recreate network: {network_name}")
                except Exception as e:
                    logger.error(f"Error recreating network {network_name}: {e}")

        # Now restart the container safely
        container.restart()

        # Wait a moment for container to be ready
        import time
        time.sleep(2)

        # Reconnect to all configured networks
        reconnect_result = await reconnect_napi_networks()

        recreated_msg = f" (recreated {len(recreated_networks)} network(s))" if recreated_networks else ""

        if reconnect_result.status:
            return NetworkboxResponse(
                status=True,
                message=f"NAPI restarted and reconnected to networks{recreated_msg}"
            )
        else:
            return NetworkboxResponse(
                status=True,
                message=f"NAPI restarted but network reconnection failed: {reconnect_result.message}"
            )
    except Exception as e:
        logger.error(f"Failed to restart NAPI: {e}")
        return NetworkboxResponse(status=False, message=f"Failed to restart: {str(e)}")


@router.post("/reconnect-networks", response_model=NetworkboxResponse)
async def reconnect_napi_networks():
    """Reconnect NAPI to all configured networks based on NAPI config."""
    try:
        container = docker_service.get_container("networkbox-napi")
        if not container:
            return NetworkboxResponse(status=False, message="NAPI container not found")

        # Get NAPI config
        config = db.find_one("napi_config", {})
        if not config or not config.get("networks"):
            return NetworkboxResponse(status=True, message="No networks configured in NAPI config")

        connected = []
        errors = []

        for net_config in config["networks"]:
            vlan_id = net_config["vlan_id"]
            ip_address = net_config.get("ip_address")

            if not ip_address:
                continue

            # Get network info
            network = db.find_one("networks", {"vlan_id": vlan_id})
            if not network:
                errors.append(f"Network VLAN {vlan_id} not found")
                continue

            network_name = f"NETWORKBOX_{network['name']}"

            try:
                # Check if already connected
                container.reload()
                current_networks = container.attrs.get("NetworkSettings", {}).get("Networks", {})
                if network_name in current_networks:
                    connected.append(network['name'])
                    continue

                # Connect to network
                docker_service.connect_container_to_network(
                    container,
                    network_name,
                    ipv4_address=ip_address
                )
                connected.append(network['name'])
            except Exception as e:
                errors.append(f"{network['name']}: {str(e)}")

        if errors:
            return NetworkboxResponse(
                status=False,
                message=f"Connected to {len(connected)} networks, {len(errors)} errors: {', '.join(errors)}"
            )

        return NetworkboxResponse(
            status=True,
            message=f"Connected to {len(connected)} networks: {', '.join(connected) if connected else 'none'}"
        )
    except Exception as e:
        logger.error(f"Failed to reconnect NAPI to networks: {e}")
        return NetworkboxResponse(status=False, message=f"Failed to reconnect: {str(e)}")


@router.post("/connect-network/{vlan_id}", response_model=NetworkboxResponse)
async def connect_napi_to_network(vlan_id: int):
    """Connect NAPI to a network."""
    network = db.find_one("networks", {"vlan_id": vlan_id})
    if not network:
        raise HTTPException(status_code=404, detail="Network not found")

    # Get NAPI config for IP address
    config = db.find_one("napi_config", {})
    ip_address = None
    if config and config.get("networks"):
        for net_config in config["networks"]:
            if net_config["vlan_id"] == vlan_id:
                ip_address = net_config["ip_address"]
                break

    if not ip_address:
        raise HTTPException(
            status_code=400,
            detail="No IP address configured for this network in NAPI config"
        )

    try:
        container = docker_service.get_container("networkbox-napi")
        if not container:
            return NetworkboxResponse(status=False, message="NAPI container not found")

        docker_service.connect_container_to_network(
            container,
            f"NETWORKBOX_{network['name']}",
            ipv4_address=ip_address
        )
        return NetworkboxResponse(
            status=True,
            message=f"NAPI connected to {network['name']} with IP {ip_address}"
        )
    except Exception as e:
        logger.error(f"Failed to connect NAPI to network: {e}")
        return NetworkboxResponse(status=False, message=f"Failed to connect: {str(e)}")


@router.post("/disconnect-network/{vlan_id}", response_model=NetworkboxResponse)
async def disconnect_napi_from_network(vlan_id: int):
    """Disconnect NAPI from a network."""
    network = db.find_one("networks", {"vlan_id": vlan_id})
    if not network:
        raise HTTPException(status_code=404, detail="Network not found")

    try:
        container = docker_service.get_container("networkbox-napi")
        if not container:
            return NetworkboxResponse(status=False, message="NAPI container not found")

        docker_network = docker_service.get_network(f"NETWORKBOX_{network['name']}")
        if docker_network:
            docker_network.disconnect(container)

        return NetworkboxResponse(
            status=True,
            message=f"NAPI disconnected from {network['name']}"
        )
    except Exception as e:
        logger.error(f"Failed to disconnect NAPI from network: {e}")
        return NetworkboxResponse(status=False, message=f"Failed to disconnect: {str(e)}")


@router.post("/wake", response_model=NetworkboxResponse)
async def send_wake_on_lan(request: WOLRequest):
    """Send a Wake-on-LAN packet via NAPI."""
    try:
        result = await napi_client.wake_on_lan(
            mac=request.mac,
            ip=request.ip,
            port=request.port
        )
        return NetworkboxResponse(
            status=True,
            message=f"WOL packet sent to {request.mac}",
            data=result
        )
    except Exception as e:
        logger.error(f"WOL request failed: {e}")
        return NetworkboxResponse(
            status=False,
            message="Failed to send WOL packet",
            error=str(e)
        )


@router.post("/ping-scan", response_model=PingScanResponse)
async def ping_scan(request: ScanRequest):
    """Perform a ping scan on a network via NAPI."""
    # Get network config
    network = db.find_one("networks", {"vlan_id": request.vlan_id})
    if not network:
        raise HTTPException(status_code=404, detail="Network not found")

    # Calculate subnet
    net = ipaddress.IPv4Network(
        f"{network['address']}/{network['mask']}",
        strict=False
    )
    subnet = str(net)

    try:
        result = await napi_client.ping_scan(subnet)
        return PingScanResponse(**result)
    except Exception as e:
        logger.error(f"Ping scan failed: {e}")
        raise HTTPException(status_code=500, detail=f"Ping scan failed: {str(e)}")


@router.post("/arp-scan", response_model=ArpScanResponse)
async def arp_scan(request: ScanRequest):
    """Perform an ARP scan on a network via NAPI (non-streaming)."""
    # Get network config
    network = db.find_one("networks", {"vlan_id": request.vlan_id})
    if not network:
        raise HTTPException(status_code=404, detail="Network not found")

    # Calculate subnet
    net = ipaddress.IPv4Network(
        f"{network['address']}/{network['mask']}",
        strict=False
    )
    subnet = str(net)

    try:
        result = await napi_client.arp_scan(subnet)
        return ArpScanResponse(**result)
    except Exception as e:
        logger.error(f"ARP scan failed: {e}")
        raise HTTPException(status_code=500, detail=f"ARP scan failed: {str(e)}")


@ws_router.post("/wol", response_model=NetworkboxResponse)
async def send_wol_client(request: WOLClientRequest):
    """
    Send a Wake-on-LAN packet via NAPI.

    This endpoint is designed for the wakeonlan-networkbox client package
    and does not require authentication.

    Sends the magic packet to the directed broadcast address of every
    configured network so it reaches the correct VLAN.
    """
    try:
        networks = list(db.find("networks", {}))
        sent_to = []
        errors = []

        for network in networks:
            try:
                net = ipaddress.IPv4Network(
                    f"{network['address']}/{network['mask']}",
                    strict=False
                )
                broadcast_ip = str(net.broadcast_address)
                await napi_client.wake_on_lan(
                    mac=request.mac_address,
                    ip=broadcast_ip,
                    port=request.port
                )
                sent_to.append(f"{network.get('name', 'unknown')} ({broadcast_ip})")
            except Exception as e:
                errors.append(f"{network.get('name', 'unknown')}: {e}")

        if not networks:
            # Fallback: no networks configured, try global broadcast
            await napi_client.wake_on_lan(
                mac=request.mac_address,
                ip="255.255.255.255",
                port=request.port
            )
            sent_to.append("global broadcast (255.255.255.255)")

        msg = f"WOL packet sent to {request.mac_address} on: {', '.join(sent_to)}"
        if errors:
            msg += f" (errors: {', '.join(errors)})"

        return NetworkboxResponse(
            status=True,
            message=msg
        )
    except Exception as e:
        logger.error(f"WOL client request failed: {e}")
        return NetworkboxResponse(
            status=False,
            message="Failed to send WOL packet",
            error=str(e)
        )


@ws_router.websocket("/arp-scan/live")
async def arp_scan_live_proxy(
    websocket: WebSocket,
    vlan_id: int = Query(..., description="VLAN ID of network to scan"),
):
    """
    Proxy WebSocket connection to NAPI ARP scan live endpoint.

    Devices are streamed as they are discovered.
    """
    # Get network config before accepting WebSocket
    network = db.find_one("networks", {"vlan_id": vlan_id})
    if not network:
        # Can't send HTTP error from WebSocket, so accept and send error message
        await websocket.accept()
        await websocket.send_json({"type": "error", "message": f"Network with VLAN {vlan_id} not found"})
        await websocket.close()
        return

    # Calculate subnet
    net = ipaddress.IPv4Network(
        f"{network['address']}/{network['mask']}",
        strict=False
    )
    subnet = str(net)

    await websocket.accept()
    logger.info(f"ARP scan WebSocket proxy: vlan_id={vlan_id}, subnet={subnet}")

    # Build NAPI WebSocket URL
    napi_ws_url = settings.napi_url.replace("http://", "ws://").replace("https://", "wss://")
    params = urlencode({"subnet": subnet})
    napi_ws_full_url = f"{napi_ws_url}/scan/arp/live?{params}"

    try:
        async with websockets.connect(napi_ws_full_url) as napi_ws:
            # Forward messages from NAPI to client
            async def forward_to_client():
                try:
                    async for message in napi_ws:
                        await websocket.send_text(message)
                except websockets.ConnectionClosed:
                    pass

            async def forward_to_napi():
                try:
                    while True:
                        data = await websocket.receive_text()
                        await napi_ws.send(data)
                except WebSocketDisconnect:
                    pass

            # Run both directions concurrently
            done, pending = await asyncio.wait(
                [
                    asyncio.create_task(forward_to_client()),
                    asyncio.create_task(forward_to_napi()),
                ],
                return_when=asyncio.FIRST_COMPLETED,
            )

            # Cancel pending tasks
            for task in pending:
                task.cancel()

    except websockets.ConnectionClosed:
        logger.info("NAPI ARP scan WebSocket connection closed")
    except Exception as e:
        logger.error(f"ARP scan WebSocket proxy error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


@ws_router.websocket("/arp-scan/all")
async def arp_scan_all_networks(websocket: WebSocket):
    """
    Scan all configured networks and stream results.

    Sends updates as:
    - {"type": "networks", "networks": [...]} - List of networks to scan
    - {"type": "scanning", "vlan_id": int, "name": str} - Currently scanning network
    - {"type": "device", "vlan_id": int, "device": {...}} - Device found
    - {"type": "network_complete", "vlan_id": int, "device_count": int} - Network scan complete
    - {"type": "complete", "total_devices": int} - All scans complete
    - {"type": "error", "message": str} - Error occurred
    """
    await websocket.accept()
    logger.info("Starting ARP scan for all networks")

    try:
        # Get all networks
        networks = list(db.find("networks", {}))
        if not networks:
            await websocket.send_json({"type": "error", "message": "No networks configured"})
            await websocket.close()
            return

        # Send network list
        network_list = [
            {"vlan_id": n["vlan_id"], "name": n["name"], "address": n["address"], "mask": n["mask"]}
            for n in networks
        ]
        await websocket.send_json({"type": "networks", "networks": network_list})

        total_devices = 0

        # Scan each network
        for network in networks:
            vlan_id = network["vlan_id"]
            name = network.get("name", f"VLAN {vlan_id}")

            # Notify scanning start
            await websocket.send_json({"type": "scanning", "vlan_id": vlan_id, "name": name})

            # Calculate subnet
            try:
                net = ipaddress.IPv4Network(
                    f"{network['address']}/{network['mask']}",
                    strict=False
                )
                subnet = str(net)
            except Exception as e:
                logger.error(f"Invalid network config for VLAN {vlan_id}: {e}")
                await websocket.send_json({
                    "type": "network_complete",
                    "vlan_id": vlan_id,
                    "device_count": 0,
                    "error": str(e)
                })
                continue

            # Connect to NAPI and scan
            napi_ws_url = settings.napi_url.replace("http://", "ws://").replace("https://", "wss://")
            params = urlencode({"subnet": subnet})
            napi_ws_full_url = f"{napi_ws_url}/scan/arp/live?{params}"

            network_device_count = 0
            try:
                async with websockets.connect(napi_ws_full_url) as napi_ws:
                    async for message in napi_ws:
                        try:
                            import json
                            data = json.loads(message)

                            if data.get("type") == "device":
                                # Forward device with vlan_id
                                device_data = data.get("device", data)
                                await websocket.send_json({
                                    "type": "device",
                                    "vlan_id": vlan_id,
                                    "device": device_data
                                })
                                network_device_count += 1
                            elif data.get("type") == "complete":
                                # Network scan complete
                                break
                        except json.JSONDecodeError:
                            pass

            except Exception as e:
                logger.error(f"Error scanning VLAN {vlan_id}: {e}")
                await websocket.send_json({
                    "type": "network_complete",
                    "vlan_id": vlan_id,
                    "device_count": network_device_count,
                    "error": str(e)
                })
                continue

            total_devices += network_device_count
            await websocket.send_json({
                "type": "network_complete",
                "vlan_id": vlan_id,
                "device_count": network_device_count
            })

        # All done
        await websocket.send_json({"type": "complete", "total_devices": total_devices})

    except WebSocketDisconnect:
        logger.info("Client disconnected from all-networks scan")
    except Exception as e:
        logger.error(f"All-networks scan error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


# ============ TCPDump ============

@router.get("/tcpdump/interfaces")
async def get_tcpdump_interfaces():
    """Get available network interfaces from NAPI for tcpdump."""
    try:
        return await napi_client.get_interfaces()
    except Exception as e:
        logger.error(f"Failed to get interfaces: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get interfaces: {str(e)}")


@router.post("/tcpdump/capture")
async def tcpdump_capture(
    interface: str = Query(default="any"),
    filter: str = Query(default=""),
    count: int = Query(default=10, ge=1, le=100),
    timeout: int = Query(default=5, ge=1, le=30),
):
    """Capture packets via NAPI tcpdump (non-streaming)."""
    try:
        return await napi_client.tcpdump_capture(
            interface=interface,
            filter=filter,
            count=count,
            timeout=timeout
        )
    except Exception as e:
        logger.error(f"TCPDump capture failed: {e}")
        raise HTTPException(status_code=500, detail=f"TCPDump capture failed: {str(e)}")


@ws_router.websocket("/tcpdump/live")
async def tcpdump_live_proxy(
    websocket: WebSocket,
    interface: str = Query(default="any"),
    filter: str = Query(default=""),
):
    """Proxy WebSocket connection to NAPI tcpdump live endpoint."""
    await websocket.accept()
    logger.info(f"TCPDump WebSocket proxy: interface={interface}, filter={filter}")

    # Build NAPI WebSocket URL
    napi_ws_url = settings.napi_url.replace("http://", "ws://").replace("https://", "wss://")
    params = urlencode({"interface": interface, "filter": filter})
    napi_ws_full_url = f"{napi_ws_url}/tcpdump/live?{params}"

    try:
        async with websockets.connect(napi_ws_full_url) as napi_ws:
            # Forward messages between client and NAPI
            async def forward_to_client():
                try:
                    async for message in napi_ws:
                        await websocket.send_text(message)
                except websockets.ConnectionClosed:
                    pass

            async def forward_to_napi():
                try:
                    while True:
                        data = await websocket.receive_text()
                        await napi_ws.send(data)
                except WebSocketDisconnect:
                    pass

            # Run both directions concurrently
            done, pending = await asyncio.wait(
                [
                    asyncio.create_task(forward_to_client()),
                    asyncio.create_task(forward_to_napi()),
                ],
                return_when=asyncio.FIRST_COMPLETED,
            )

            # Cancel pending tasks
            for task in pending:
                task.cancel()

    except websockets.ConnectionClosed:
        logger.info("NAPI WebSocket connection closed")
    except Exception as e:
        logger.error(f"TCPDump WebSocket proxy error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


@ws_router.websocket("/tcpdump/live-pcap")
async def tcpdump_live_pcap_proxy(
    websocket: WebSocket,
    interface: str = Query(default="any"),
    filter: str = Query(default=""),
):
    """
    Proxy WebSocket connection to NAPI tcpdump live-pcap endpoint.

    Captures packets and generates a pcap file that can be downloaded/analyzed.
    """
    await websocket.accept()
    logger.info(f"TCPDump PCAP WebSocket proxy: interface={interface}, filter={filter}")

    # Build NAPI WebSocket URL
    napi_ws_url = settings.napi_url.replace("http://", "ws://").replace("https://", "wss://")
    params = urlencode({"interface": interface, "filter": filter})
    napi_ws_full_url = f"{napi_ws_url}/tcpdump/live-pcap?{params}"

    try:
        async with websockets.connect(napi_ws_full_url) as napi_ws:
            # Forward messages between client and NAPI
            async def forward_to_client():
                try:
                    async for message in napi_ws:
                        await websocket.send_text(message)
                except websockets.ConnectionClosed:
                    pass

            async def forward_to_napi():
                try:
                    while True:
                        data = await websocket.receive_text()
                        await napi_ws.send(data)
                except WebSocketDisconnect:
                    pass

            # Run both directions concurrently
            done, pending = await asyncio.wait(
                [
                    asyncio.create_task(forward_to_client()),
                    asyncio.create_task(forward_to_napi()),
                ],
                return_when=asyncio.FIRST_COMPLETED,
            )

            # Cancel pending tasks
            for task in pending:
                task.cancel()

    except websockets.ConnectionClosed:
        logger.info("NAPI PCAP WebSocket connection closed")
    except Exception as e:
        logger.error(f"TCPDump PCAP WebSocket proxy error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


# ============ Nmap Scan ============

@ws_router.websocket("/nmap/scan")
async def nmap_scan_proxy(
    websocket: WebSocket,
    host: str = Query(..., description="Host IP address to scan"),
):
    """
    Proxy WebSocket connection to NAPI nmap scan endpoint.

    Performs an nmap -A scan and streams results in real-time.
    """
    await websocket.accept()
    logger.info(f"Nmap scan WebSocket proxy: host={host}")

    # Build NAPI WebSocket URL
    napi_ws_url = settings.napi_url.replace("http://", "ws://").replace("https://", "wss://")
    params = urlencode({"host": host})
    napi_ws_full_url = f"{napi_ws_url}/nmap/scan?{params}"

    try:
        async with websockets.connect(napi_ws_full_url) as napi_ws:
            # Forward messages from NAPI to client
            async def forward_to_client():
                try:
                    async for message in napi_ws:
                        await websocket.send_text(message)
                except websockets.ConnectionClosed:
                    pass

            async def forward_to_napi():
                try:
                    while True:
                        data = await websocket.receive_text()
                        await napi_ws.send(data)
                except WebSocketDisconnect:
                    pass

            # Run both directions concurrently
            done, pending = await asyncio.wait(
                [
                    asyncio.create_task(forward_to_client()),
                    asyncio.create_task(forward_to_napi()),
                ],
                return_when=asyncio.FIRST_COMPLETED,
            )

            # Cancel pending tasks
            for task in pending:
                task.cancel()

    except websockets.ConnectionClosed:
        logger.info("NAPI Nmap WebSocket connection closed")
    except Exception as e:
        logger.error(f"Nmap scan WebSocket proxy error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


# ============ Pcap Analysis ============

@ws_router.websocket("/analyze/pcap")
async def analyze_pcap_proxy(websocket: WebSocket):
    """
    Proxy WebSocket connection to NAPI pcap analysis endpoint.

    Accepts pcap file uploads and returns analysis results including:
    - Protocol breakdown
    - Network issues (retransmissions, resets, etc.)
    - Conversation statistics
    """
    await websocket.accept()
    logger.info("Pcap analysis WebSocket proxy connected")

    # Build NAPI WebSocket URL
    napi_ws_url = settings.napi_url.replace("http://", "ws://").replace("https://", "wss://")
    napi_ws_full_url = f"{napi_ws_url}/analyze/pcap"

    try:
        async with websockets.connect(napi_ws_full_url) as napi_ws:
            # Forward messages between client and NAPI
            # This includes both JSON messages and binary pcap data
            async def forward_to_client():
                try:
                    async for message in napi_ws:
                        if isinstance(message, bytes):
                            await websocket.send_bytes(message)
                        else:
                            await websocket.send_text(message)
                except websockets.ConnectionClosed:
                    pass

            async def forward_to_napi():
                try:
                    while True:
                        msg = await websocket.receive()
                        if "text" in msg:
                            await napi_ws.send(msg["text"])
                        elif "bytes" in msg:
                            await napi_ws.send(msg["bytes"])
                except WebSocketDisconnect:
                    pass

            # Run both directions concurrently
            done, pending = await asyncio.wait(
                [
                    asyncio.create_task(forward_to_client()),
                    asyncio.create_task(forward_to_napi()),
                ],
                return_when=asyncio.FIRST_COMPLETED,
            )

            # Cancel pending tasks
            for task in pending:
                task.cancel()

    except websockets.ConnectionClosed:
        logger.info("NAPI Pcap analysis WebSocket connection closed")
    except Exception as e:
        logger.error(f"Pcap analysis WebSocket proxy error: {e}")
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
    finally:
        try:
            await websocket.close()
        except Exception:
            pass
