import logging
import io
import tarfile
import ipaddress
import secrets
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Request, Header, Query
from fastapi.responses import Response, StreamingResponse

from app.dependencies import verify_token, verify_token_from_query
from app.database import db
from app.config import settings
from app.models import (
    ProxyConfig, ProxyConfigUpdate, ProxyBlockPageConfig, KerberosConfig, ParentProxyConfig,
    IPAllowConfig, AllowedIP, WebhookIPRequest, WebhookIPStatus, NetworkboxResponse
)
from app.services.docker_service import docker_service
from app.services.action_logger import create_sse_response

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/proxy",
    tags=["Proxy Server"],
    dependencies=[Depends(verify_token)]
)

# Separate router for SSE streams (no global auth dependency)
stream_router = APIRouter(
    prefix="/api/v1/proxy",
    tags=["Proxy Server Streams"]
)

# Public router for WPAD/PAC files (no authentication required)
public_router = APIRouter(
    tags=["Proxy Auto-Configuration"]
)

# Webhook router for IP-based access control (API key authentication)
webhook_router = APIRouter(
    prefix="/api/v1/proxy/webhook",
    tags=["Proxy Webhooks"]
)


def is_ip_or_cidr(entry: str) -> bool:
    """Check if an entry is an IP address, CIDR notation, or IP range."""
    entry = entry.strip()
    # IP range: 192.168.1.100-192.168.1.200
    if '-' in entry and not entry.startswith('-'):
        parts = entry.split('-')
        if len(parts) == 2:
            try:
                ipaddress.ip_address(parts[0].strip())
                ipaddress.ip_address(parts[1].strip())
                return True
            except ValueError:
                pass
    # Single IP or CIDR
    try:
        ipaddress.ip_network(entry, strict=False)
        return True
    except ValueError:
        pass
    try:
        ipaddress.ip_address(entry)
        return True
    except ValueError:
        pass
    return False


def separate_domains_and_ips(entries: list[str]) -> tuple[list[str], list[str]]:
    """Separate a list of entries into domains and IPs/CIDRs/ranges."""
    domains = []
    ips = []
    for entry in entries:
        entry = entry.strip()
        if not entry:
            continue
        if is_ip_or_cidr(entry):
            ips.append(entry)
        else:
            domains.append(entry)
    return domains, ips


def generate_parent_proxy_config(parent: ParentProxyConfig) -> str:
    """Generate Squid parent proxy configuration."""
    if not parent or not parent.enabled:
        return ""

    config_lines = []
    config_lines.append(f"\n# Parent Proxy Configuration")

    # Define the cache peer (parent proxy)
    # login=PASS forwards client credentials to parent
    # login=*:password uses fixed credentials
    # no-query disables ICP queries
    if parent.forward_auth == "basic" and parent.username and parent.password:
        # Use fixed credentials for parent proxy authentication
        config_lines.append(
            f'cache_peer {parent.host} parent {parent.port} 0 no-query default login={parent.username}:{parent.password}'
        )
    elif parent.forward_auth == "basic":
        # Forward client's basic auth credentials to parent
        config_lines.append(
            f'cache_peer {parent.host} parent {parent.port} 0 no-query default login=PASS'
        )
    else:
        # No authentication forwarding
        config_lines.append(
            f'cache_peer {parent.host} parent {parent.port} 0 no-query default'
        )

    # Never go direct - always use parent
    config_lines.append("never_direct allow all")

    # Forward authenticated user via header (for Sophos etc.)
    if parent.forward_auth == "header":
        header_name = parent.auth_header_name or "X-Authenticated-User"
        config_lines.append(f'request_header_add {header_name} %ul')

    config_lines.append("")
    return "\n".join(config_lines)


def extract_group_cn(group_dn: str) -> str:
    """Extract CN from a group DN, or return as-is if not a DN."""
    # If it looks like a DN (contains CN= or cn=), extract the CN value
    if group_dn.upper().startswith("CN="):
        # Extract CN value (everything before the first comma)
        cn_part = group_dn.split(",")[0]
        return cn_part[3:]  # Remove "CN=" prefix
    return group_dn


def generate_squid_config(config: ProxyConfig, auth: dict) -> str:
    """Generate Squid configuration with LDAP auth, whitelist/blacklist."""
    ldap_url = f"{'ldaps' if auth['use_ssl'] else 'ldap'}://{auth['server']}:{auth['port']}"

    # Generate group ACLs for allowed groups
    # Extract just the CN from the group DN for the ACL
    # Multiple groups must be on the same line, space-separated
    allowed_group_acls = ""
    if config.allowed_groups:
        group_cns = [extract_group_cn(group) for group in config.allowed_groups]
        allowed_group_acls = "acl allowed_group external ldap_group " + " ".join(group_cns) + "\n"

    # Generate group ACLs for bypass groups (can bypass blacklist)
    # Multiple groups must be on the same line, space-separated
    bypass_group_acls = ""
    if config.bypass_groups:
        group_cns = [extract_group_cn(group) for group in config.bypass_groups]
        bypass_group_acls = "acl bypass_group external ldap_group " + " ".join(group_cns) + "\n"

    # Whitelist/Blacklist configuration - separate domains and IPs
    whitelist_config = ""
    blacklist_config = ""

    whitelist_domains, whitelist_ips = separate_domains_and_ips(config.whitelist_domains)
    blacklist_domains, blacklist_ips = separate_domains_and_ips(config.blacklist_domains)

    if whitelist_domains:
        whitelist_config += "acl whitelist_domains dstdomain \"/etc/squid/whitelist_domains.txt\"\n"
    if whitelist_ips:
        whitelist_config += "acl whitelist_ips dst \"/etc/squid/whitelist_ips.txt\"\n"

    if blacklist_domains:
        blacklist_config += "acl blacklist_domains dstdomain \"/etc/squid/blacklist_domains.txt\"\n"
    if blacklist_ips:
        blacklist_config += "acl blacklist_ips dst \"/etc/squid/blacklist_ips.txt\"\n"

    # Build access rules with proper order:
    # 1. Whitelist - always allow (before auth)
    # 2. Require authentication
    # 3. Allow bypass groups to access blacklisted domains
    # 4. Deny blacklist for everyone else
    # 5. Allow authenticated users in allowed groups
    # 6. Deny all others
    access_rules = ""

    # Whitelist - allow without authentication (both domains and IPs)
    if whitelist_domains:
        access_rules += "http_access allow whitelist_domains\n"
    if whitelist_ips:
        access_rules += "http_access allow whitelist_ips\n"

    # Blacklist handling - bypass groups can access, others cannot
    if blacklist_domains or blacklist_ips:
        if config.bypass_groups:
            if blacklist_domains:
                access_rules += "http_access allow authenticated bypass_group blacklist_domains\n"
            if blacklist_ips:
                access_rules += "http_access allow authenticated bypass_group blacklist_ips\n"
        if blacklist_domains:
            access_rules += "http_access deny blacklist_domains\n"
        if blacklist_ips:
            access_rules += "http_access deny blacklist_ips\n"

    # Standard access: authenticated users in allowed groups
    access_rules += "http_access allow authenticated allowed_group\n"
    access_rules += "http_access deny all\n"

    # Generate parent proxy config if enabled
    parent_proxy_config = generate_parent_proxy_config(config.parent_proxy)

    return f"""# Squid Proxy Configuration - Generated by NetworkBOX
http_port {config.listen_port}

# File descriptor limit (prevents "running out of filedescriptors" warnings)
max_filedescriptors 65536

# Logging configuration
# Custom log format with username, URL, and status
# Format: timestamp user client_ip method url status size
logformat networkbox %tl %un %>a %rm %ru %Hs %<st
access_log /var/log/squid/access.log networkbox
cache_log /var/log/squid/cache.log

# LDAP Authentication
# -d enables debug mode, -R disables referral chasing (fixes AD "Operations error")
auth_param basic program /usr/lib/squid/basic_ldap_auth -d -R -v 3 -b "{auth['basedn']}" -D "{auth['binduser']}" -w "{auth['password']}" -f "{auth['userfilter']}" -H {ldap_url}
auth_param basic children 5
auth_param basic realm NetworkBOX Proxy
auth_param basic credentialsttl 2 hours

# LDAP Group Check for AD
# -R disables referral chasing (fixes AD "Operations error")
# -K strips Kerberos realm (@DOMAIN), -d strips NT domain (DOMAIN\\) from username
# -F: first lookup user DN by sAMAccountName, then %u becomes the full DN
# -f: check if group has this user DN as member
# ttl=10: cache results for 10 seconds only (groups can change frequently)
external_acl_type ldap_group ttl=10 %LOGIN /usr/lib/squid/ext_ldap_group_acl -R -K -d -v 3 -b "{auth['basedn']}" -D "{auth['binduser']}" -w "{auth['password']}" -F "(sAMAccountName=%s)" -f "(&(objectClass=group)(cn=%g)(member=%u))" -H {ldap_url}

# ACLs - Authentication
acl authenticated proxy_auth REQUIRED
{allowed_group_acls}
{bypass_group_acls}
# ACLs - Domain Lists
{whitelist_config}{blacklist_config}
# Access Rules
{access_rules}
# Custom Error Pages
error_directory /etc/squid/errors
deny_info ERR_ACCESS_DENIED all
deny_info ERR_BLACKLIST_DENIED blacklist
{parent_proxy_config}"""


def generate_krb5_conf(kerberos: KerberosConfig) -> str:
    """Generate krb5.conf for Kerberos authentication."""
    realm = kerberos.realm.upper()
    domain = kerberos.realm.lower()
    # Use configurable ticket lifetimes with defaults
    ticket_lifetime = kerberos.ticket_lifetime or "24h"
    renew_lifetime = kerberos.renew_lifetime or "7d"

    return f"""[libdefaults]
    default_realm = {realm}
    dns_lookup_realm = false
    dns_lookup_kdc = false
    ticket_lifetime = {ticket_lifetime}
    renew_lifetime = {renew_lifetime}
    forwardable = true

[realms]
    {realm} = {{
        kdc = {kerberos.kdc}
        admin_server = {kerberos.kdc}
    }}

[domain_realm]
    .{domain} = {realm}
    {domain} = {realm}
"""


def generate_kerberos_startup_script(kerberos: KerberosConfig) -> str:
    """Generate startup script that installs Kerberos packages, joins domain, and starts Squid."""
    realm = kerberos.realm.upper()
    spn = f"HTTP/{kerberos.proxy_hostname}"

    return f"""#!/bin/bash

echo "=========================================="
echo "[NetworkBOX] Kerberos SSO Setup Starting"
echo "=========================================="

# Set timezone
export TZ=Europe/Berlin
ln -snf /usr/share/zoneinfo/$TZ /etc/localtime
echo $TZ > /etc/timezone

# Fix /etc/hosts for proper FQDN resolution
# The FQDN must come first, then the short hostname
HOSTNAME=$(hostname)
FQDN="{kerberos.proxy_hostname}"
IP=$(hostname -I | awk '{{print $1}}')
echo "[NetworkBOX] Fixing /etc/hosts for FQDN: $FQDN"
# Remove existing hostname entries and add correct one
sed -i "/$HOSTNAME/d" /etc/hosts
echo "$IP $FQDN $HOSTNAME" >> /etc/hosts
cat /etc/hosts

echo "[NetworkBOX] Installing Kerberos packages..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y krb5-user libsasl2-modules-gssapi-mit samba-common-bin samba-dsdb-modules samba-vfs-modules winbind dnsutils netcat-openbsd
if [ $? -eq 0 ]; then
    echo "[NetworkBOX] Packages installed successfully"
else
    echo "[NetworkBOX] ERROR: Package installation failed!"
    exit 1
fi

echo "[NetworkBOX] Configuring Kerberos..."
cp /etc/squid/krb5.conf /etc/krb5.conf
cat /etc/krb5.conf

echo "[NetworkBOX] Configuring Samba..."
cat > /etc/samba/smb.conf << SMBEOF
[global]
    workgroup = {realm.split('.')[0].upper()}
    realm = {realm}
    security = ADS
    kerberos method = secrets and keytab
    client signing = yes
    log level = 1

    # CRITICAL: Disable automatic machine password change
    # This prevents KVNO mismatch issues when container restarts
    machine password timeout = 0

    # Winbind configuration for NTLM auth
    winbind use default domain = yes
    winbind offline logon = no
    winbind enum users = yes
    winbind enum groups = yes
    idmap config * : backend = tdb
    idmap config * : range = 10000-20000
    idmap config {realm.split('.')[0].upper()} : backend = rid
    idmap config {realm.split('.')[0].upper()} : range = 20001-30000
SMBEOF
cat /etc/samba/smb.conf

echo "[NetworkBOX] DNS Configuration:"
cat /etc/resolv.conf

echo "[NetworkBOX] Testing DNS resolution..."
host {kerberos.kdc} || echo "DNS lookup for KDC IP failed"
host _ldap._tcp.{kerberos.realm.lower()} || echo "SRV lookup failed (this is OK if direct IP is used)"

echo "[NetworkBOX] Testing connectivity to DC..."
nc -zv {kerberos.kdc} 88 2>&1 || echo "Cannot reach Kerberos port 88"
nc -zv {kerberos.kdc} 389 2>&1 || echo "Cannot reach LDAP port 389"

echo "[NetworkBOX] Kerberos configured"

echo "=========================================="
echo "[NetworkBOX] Checking Kerberos keytab..."
echo "=========================================="

# Keytab locations
KEYTAB_PATH="/etc/squid/HTTP.keytab"
SAMBA_PRIVATE="/var/lib/samba/private"
SAMBA_KEYTAB="$SAMBA_PRIVATE/secrets.keytab"
NEED_SETUP=true

# Ensure Samba private directory exists
mkdir -p "$SAMBA_PRIVATE"

# FIRST: Check if we have a valid keytab with HTTP SPN (from persistent volume)
# If yes, use it directly without touching AD - this prevents KVNO changes
if [ -f "$SAMBA_KEYTAB" ]; then
    echo "[NetworkBOX] Found keytab in persistent storage"
    if klist -k "$SAMBA_KEYTAB" 2>/dev/null | grep -qi "HTTP/"; then
        echo "[NetworkBOX] Keytab has valid HTTP SPN - using existing keytab"
        klist -k "$SAMBA_KEYTAB"
        cp "$SAMBA_KEYTAB" "$KEYTAB_PATH"
        cp "$SAMBA_KEYTAB" /etc/krb5.keytab
        NEED_SETUP=false
    else
        echo "[NetworkBOX] Keytab exists but missing HTTP SPN"
    fi
fi

# Only do domain join and keytab creation if we don't have a valid keytab
if [ "$NEED_SETUP" = true ]; then
    echo "[NetworkBOX] Need to set up Kerberos from scratch..."

    # Check if already joined (secrets.tdb exists and valid)
    NEED_JOIN=true
    if [ -f "$SAMBA_PRIVATE/secrets.tdb" ]; then
        echo "[NetworkBOX] Found existing Samba secrets - testing domain membership..."
        if net ads testjoin 2>/dev/null; then
            echo "[NetworkBOX] Already joined to domain!"
            NEED_JOIN=false
        else
            echo "[NetworkBOX] Domain membership invalid - will rejoin"
        fi
    fi

    if [ "$NEED_JOIN" = true ]; then
        echo "[NetworkBOX] Joining domain {realm}..."
        echo "{kerberos.domain_admin_password}" | net ads join -U "{kerberos.domain_admin}" --stdin
        JOIN_RESULT=$?
        if [ $JOIN_RESULT -eq 0 ]; then
            echo "[NetworkBOX] Domain join successful!"
        else
            echo "[NetworkBOX] WARNING: Domain join returned code $JOIN_RESULT"
        fi
    fi

    echo "=========================================="
    echo "[NetworkBOX] Creating keytab..."
    echo "=========================================="

    # Create the keytab for Kerberos authentication
    net ads keytab create
    KEYTAB_RESULT=$?
    if [ $KEYTAB_RESULT -eq 0 ]; then
        echo "[NetworkBOX] Keytab created successfully"
    else
        echo "[NetworkBOX] WARNING: Keytab creation returned code $KEYTAB_RESULT"
    fi

    # Add HTTP SPN to keytab - this is critical for Kerberos SSO
    echo "[NetworkBOX] Adding HTTP SPN ({spn}) to keytab..."
    net ads keytab add HTTP -U "{kerberos.domain_admin}%{kerberos.domain_admin_password}"

    # Copy keytab to Squid location and persist it
    echo "[NetworkBOX] Persisting keytab..."
    if [ -f /etc/krb5.keytab ]; then
        cp /etc/krb5.keytab "$KEYTAB_PATH"
        cp /etc/krb5.keytab "$SAMBA_KEYTAB"
        echo "[NetworkBOX] Keytab saved to persistent storage"
    else
        echo "[NetworkBOX] ERROR: /etc/krb5.keytab not found!"
    fi
fi

# Set permissions for Squid
if [ -f "$KEYTAB_PATH" ]; then
    chown proxy:proxy "$KEYTAB_PATH"
    chmod 640 "$KEYTAB_PATH"
    echo "[NetworkBOX] Final keytab contents:"
    klist -k "$KEYTAB_PATH"
else
    echo "[NetworkBOX] ERROR: No keytab available at $KEYTAB_PATH!"
fi

# Set KRB5_KTNAME environment variable for negotiate_kerberos_auth
export KRB5_KTNAME="FILE:$KEYTAB_PATH"
echo "[NetworkBOX] KRB5_KTNAME set to: $KRB5_KTNAME"

echo "=========================================="
echo "[NetworkBOX] Starting Winbind..."
echo "=========================================="

# Start Winbind for NTLM authentication fallback
mkdir -p /run/samba
winbindd -D
sleep 2

# Test winbind
echo "[NetworkBOX] Testing Winbind..."
wbinfo -t && echo "[NetworkBOX] Winbind trust check: OK" || echo "[NetworkBOX] WARNING: Winbind trust check failed"
wbinfo -u | head -5 && echo "[NetworkBOX] Winbind user enumeration: OK" || echo "[NetworkBOX] WARNING: User enumeration failed"

# Make winbind socket accessible to squid (proxy user)
chmod 755 /run/samba
chmod 666 /run/samba/winbindd_privileged/* 2>/dev/null || true
# Add proxy user to winbindd_priv group if it exists
usermod -aG winbindd_priv proxy 2>/dev/null || true

# Test the Kerberos auth helper manually
echo "[NetworkBOX] Testing negotiate_kerberos_auth helper..."
echo "[NetworkBOX] Helper path: /usr/lib/squid/negotiate_kerberos_auth"
ls -la /usr/lib/squid/negotiate_kerberos_auth 2>/dev/null || echo "Helper not found at expected location"
ls -la /usr/lib/squid/ | grep -i kerb || echo "No kerberos helpers found"

# Test ntlm_auth helper for NTLM fallback
echo "[NetworkBOX] Testing ntlm_auth helper..."
echo "YR" | /usr/bin/ntlm_auth --helper-protocol=squid-2.5-ntlmssp && echo "[NetworkBOX] ntlm_auth NTLM test: OK" || echo "[NetworkBOX] WARNING: ntlm_auth NTLM test failed"

echo "=========================================="
echo "[NetworkBOX] Starting Squid..."
echo "=========================================="

# Configure Squid to log to stdout/stderr for Docker
# Create log directory if not exists
mkdir -p /var/log/squid
chown proxy:proxy /var/log/squid

# Start Squid in foreground with logs to stdout
# KRB5_KTNAME must be set for negotiate_kerberos_auth to find the keytab
# -N = no daemon mode, -d 1 = debug level 1 to stderr
export KRB5_KTNAME="FILE:/etc/squid/HTTP.keytab"
ulimit -n 65536
exec squid -N -d 1 -f /etc/squid/squid.conf 2>&1
"""


def generate_kerberos_squid_config(config: ProxyConfig, auth: dict) -> str:
    """Generate Squid configuration with Kerberos SSO + Basic LDAP fallback."""
    kerberos = config.kerberos
    realm = kerberos.realm.upper()
    spn = f"HTTP/{kerberos.proxy_hostname}@{realm}"
    ldap_url = f"{'ldaps' if auth['use_ssl'] else 'ldap'}://{auth['server']}:{auth['port']}"

    # Generate external_acl_type definitions for each allowed group
    # Using ext_kerberos_ldap_group_acl like Linuxmuster does
    # Each group needs its own external_acl_type with -g groupname@REALM
    # Parameters: -a (use auth user), -l (LDAP URL), -u (bind user), -p (bind pw), -g (group@REALM), -D (domain)
    allowed_group_acls = ""
    external_acl_defs = ""
    if config.allowed_groups:
        for i, group in enumerate(config.allowed_groups):
            group_cn = extract_group_cn(group)
            acl_name = f"allowed_group_{i}"
            # ext_kerberos_ldap_group_acl with -g for group check
            external_acl_defs += f'external_acl_type {acl_name} ttl=10 negative_ttl=10 %LOGIN /usr/lib/squid/ext_kerberos_ldap_group_acl -a -l {ldap_url} -u {auth["binduser"]} -p {auth["password"]} -D {realm} -g {group_cn}@{realm}\n'
            allowed_group_acls += f"acl {acl_name} external {acl_name}\n"

    # Generate external_acl_type definitions for bypass groups
    bypass_group_acls = ""
    if config.bypass_groups:
        for i, group in enumerate(config.bypass_groups):
            group_cn = extract_group_cn(group)
            acl_name = f"bypass_group_{i}"
            external_acl_defs += f'external_acl_type {acl_name} ttl=10 negative_ttl=10 %LOGIN /usr/lib/squid/ext_kerberos_ldap_group_acl -a -l {ldap_url} -u {auth["binduser"]} -p {auth["password"]} -D {realm} -g {group_cn}@{realm}\n'
            bypass_group_acls += f"acl {acl_name} external {acl_name}\n"

    # Whitelist/Blacklist configuration - separate domains and IPs
    whitelist_config = ""
    blacklist_config = ""

    whitelist_domains, whitelist_ips = separate_domains_and_ips(config.whitelist_domains)
    blacklist_domains, blacklist_ips = separate_domains_and_ips(config.blacklist_domains)

    if whitelist_domains:
        whitelist_config += "acl whitelist_domains dstdomain \"/etc/squid/whitelist_domains.txt\"\n"
    if whitelist_ips:
        whitelist_config += "acl whitelist_ips dst \"/etc/squid/whitelist_ips.txt\"\n"

    if blacklist_domains:
        blacklist_config += "acl blacklist_domains dstdomain \"/etc/squid/blacklist_domains.txt\"\n"
    if blacklist_ips:
        blacklist_config += "acl blacklist_ips dst \"/etc/squid/blacklist_ips.txt\"\n"

    # Build access rules
    access_rules = ""

    # Whitelist - allow without authentication (both domains and IPs)
    if whitelist_domains:
        access_rules += "http_access allow whitelist_domains\n"
    if whitelist_ips:
        access_rules += "http_access allow whitelist_ips\n"

    # Blacklist handling
    if blacklist_domains or blacklist_ips:
        if config.bypass_groups:
            # Allow bypass groups to access blacklisted domains/IPs
            for i in range(len(config.bypass_groups)):
                if blacklist_domains:
                    access_rules += f"http_access allow authenticated bypass_group_{i} blacklist_domains\n"
                if blacklist_ips:
                    access_rules += f"http_access allow authenticated bypass_group_{i} blacklist_ips\n"
        if blacklist_domains:
            access_rules += "http_access deny blacklist_domains\n"
        if blacklist_ips:
            access_rules += "http_access deny blacklist_ips\n"

    # Standard access - allow if user is in any of the allowed groups
    if config.allowed_groups:
        for i in range(len(config.allowed_groups)):
            access_rules += f"http_access allow authenticated allowed_group_{i}\n"
    else:
        # No groups configured - allow all authenticated users
        access_rules += "http_access allow authenticated\n"
    access_rules += "http_access deny all\n"

    # Generate parent proxy config if enabled
    parent_proxy_config = generate_parent_proxy_config(config.parent_proxy)

    return f"""# Squid Proxy Configuration - Generated by NetworkBOX
# Kerberos SSO enabled with Basic LDAP fallback
http_port {config.listen_port}

# File descriptor limit (prevents "running out of filedescriptors" warnings)
max_filedescriptors 65536

# Logging configuration
# Custom log format with username, URL, and status
# Format: timestamp user client_ip method url status size
logformat networkbox %tl %un %>a %rm %ru %Hs %<st
access_log /var/log/squid/access.log networkbox
cache_log /var/log/squid/cache.log

# Negotiate (Kerberos) Authentication - Primary
# Uses negotiate_kerberos_auth helper for Kerberos SSO
# -i = case-insensitive username matching
# -s = explicit Service Principal Name (HTTP/hostname@REALM)
auth_param negotiate program /usr/lib/squid/negotiate_kerberos_auth -i -s {spn}
auth_param negotiate children 10 startup=0 idle=1
auth_param negotiate keep_alive on

# NTLM Authentication - Secondary (for clients that don't support Kerberos)
# Uses ntlm_auth via Winbind for NTLM fallback
auth_param ntlm program /usr/bin/ntlm_auth --helper-protocol=squid-2.5-ntlmssp
auth_param ntlm children 10 startup=0 idle=1

# Basic LDAP Authentication - Fallback (for non-Windows clients)
# -R disables referral chasing (fixes AD "Operations error")
auth_param basic program /usr/lib/squid/basic_ldap_auth -R -v 3 -b "{auth['basedn']}" -D "{auth['binduser']}" -w "{auth['password']}" -f "{auth['userfilter']}" -H {ldap_url}
auth_param basic children 5
auth_param basic realm NetworkBOX Proxy
auth_param basic credentialsttl 2 hours

# Group membership check using ext_kerberos_ldap_group_acl
# Like Linuxmuster: -a (use authenticated user), -l (LDAP URL), -D (domain), -g (group@REALM)
# ttl=10, negative_ttl=10: cache results for 10 seconds (groups can change frequently)
{external_acl_defs}
# ACLs - Authentication
acl authenticated proxy_auth REQUIRED
{allowed_group_acls}
{bypass_group_acls}
# ACLs - Domain Lists
{whitelist_config}{blacklist_config}
# Access Rules
{access_rules}
# Custom Error Pages
error_directory /etc/squid/errors
deny_info ERR_ACCESS_DENIED all
deny_info ERR_BLACKLIST_DENIED blacklist
{parent_proxy_config}"""


def generate_ip_allow_squid_config(config: ProxyConfig) -> str:
    """Generate Squid configuration for IP-based access control."""
    # Generate parent proxy config if enabled
    parent_proxy_config = generate_parent_proxy_config(config.parent_proxy)

    return f"""# Squid Proxy Configuration - Generated by NetworkBOX
# IP-based access control mode
http_port {config.listen_port}

# File descriptor limit (prevents "running out of filedescriptors" warnings)
max_filedescriptors 65536

# Logging configuration
# Custom log format with client IP, URL, and status
# Format: timestamp client_ip method url status size
logformat networkbox %tl %>a %rm %ru %Hs %<st
access_log /var/log/squid/access.log networkbox
cache_log /var/log/squid/cache.log

# IP-based ACLs
acl allowed_ips src "/etc/squid/allowed_ips.txt"
acl blocked_ips src "/etc/squid/blocked_ips.txt"

# Access Rules - IP based (no authentication)
http_access deny blocked_ips
http_access allow allowed_ips
http_access deny all

# Custom Error Pages
error_directory /etc/squid/errors
deny_info ERR_ACCESS_DENIED all
{parent_proxy_config}"""


def generate_error_page(block_page: ProxyBlockPageConfig, is_blacklist: bool = False) -> str:
    """Generate custom Squid error page with modern light design and animation.

    Squid template variables used:
    - %u: Username
    - %U: Requested URL
    - %t: Local time
    - %a: Client IP address
    - %h: Cache hostname
    """
    logo_html = ""
    if block_page.logo_url:
        logo_html = f'<img src="{block_page.logo_url}" alt="Logo" class="logo">'

    # For blacklist page, show a different message
    title = "Domain gesperrt" if is_blacklist else block_page.title
    message = "Diese Domain ist auf der Sperrliste und kann nicht aufgerufen werden." if is_blacklist else block_page.message

    # Build footer info
    # Squid template variables: %a = client IP, %u = username, %t = time
    # These are inserted into an f-string, so % must be escaped as %%
    # But since footer_html is used inside {footer_html}, we need single %
    footer_items = []
    footer_items.append('<span>Benutzer: %u</span>')
    if block_page.show_ip:
        footer_items.append('<span>IP: %a</span>')
    if block_page.show_time:
        footer_items.append('<span>Zeit: %t</span>')
    footer_html = "\n            ".join(footer_items) if footer_items else ""

    # URL box - %U = requested URL
    # Since this is inserted via {url_html}, we use single %
    url_html = """<div class="url-box">
            <p class="url-label">Angeforderte URL</p>
            <p class="url">%U</p>
        </div>""" if block_page.show_url else ""

    # Animation CSS - braces must be doubled for f-string, % doubled for Squid templates
    animation_css = ("""
        .icon-bg {{
            position: absolute;
            inset: 0;
            background: """ + block_page.accent_color + """20;
            border-radius: 50%%;
            animation: pulse 2s ease-in-out infinite;
        }}

        @keyframes pulse {{
            0%%, 100%% {{ transform: scale(1); opacity: 1; }}
            50%% {{ transform: scale(1.2); opacity: 0.4; }}
        }}""") if block_page.animation_enabled else ""

    animation_bg = '<div class="icon-bg"></div>' if block_page.animation_enabled else ""

    return f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }}

        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background: linear-gradient(135deg, {block_page.background_color} 0%%, #e4e8ec 100%%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }}

        .card {{
            background: {block_page.card_background_color};
            border-radius: 24px;
            padding: 48px;
            max-width: 480px;
            width: 100%%;
            text-align: center;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04);
        }}

        .logo {{
            max-width: 180px;
            max-height: 80px;
            margin-bottom: 24px;
            object-fit: contain;
        }}

        .icon-wrapper {{
            position: relative;
            width: 80px;
            height: 80px;
            margin: 0 auto 32px;
        }}
        {animation_css}

        .icon {{
            position: relative;
            width: 80px;
            height: 80px;
            background: {block_page.accent_color}20;
            border-radius: 50%%;
            display: flex;
            align-items: center;
            justify-content: center;
        }}

        .icon svg {{
            width: 40px;
            height: 40px;
            stroke: {block_page.accent_color};
            stroke-width: 1.5;
        }}

        h1 {{
            font-size: 24px;
            font-weight: 600;
            color: {block_page.title_color};
            margin-bottom: 12px;
        }}

        .message {{
            color: {block_page.text_color};
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 32px;
        }}

        .url-box {{
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 24px;
        }}

        .url-label {{
            font-size: 12px;
            font-weight: 500;
            color: #9ca3af;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }}

        .url {{
            font-family: 'SF Mono', Monaco, 'Cascadia Code', monospace;
            font-size: 13px;
            color: #374151;
            word-break: break-all;
        }}

        .divider {{
            height: 1px;
            background: #e5e7eb;
            margin: 24px 0;
        }}

        .footer {{
            display: flex;
            justify-content: center;
            gap: 24px;
            font-size: 12px;
            color: #9ca3af;
        }}
    </style>
</head>
<body>
    <div class="card">
        {logo_html}
        <div class="icon-wrapper">
            {animation_bg}
            <div class="icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M12 9v3.75m0-10.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.75c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.75h-.152c-3.196 0-6.1-1.249-8.25-3.286zm0 13.036h.008v.008H12v-.008z" />
                </svg>
            </div>
        </div>

        <h1>{title}</h1>
        <p class="message">{message}</p>

        {url_html}

        <div class="divider"></div>

        <div class="footer">
            {footer_html}
        </div>
    </div>
</body>
</html>
"""


@router.get("/config", response_model=ProxyConfig | None)
async def get_proxy_config():
    """Get proxy configuration."""
    return db.find_one("proxy_config", {})


@router.post("/config", response_model=NetworkboxResponse)
async def create_proxy_config(config: ProxyConfig):
    """Create or update proxy configuration."""
    # Verify authentication exists
    auth = db.find_one("authentications", {"name": config.authentication})
    if not auth:
        raise HTTPException(status_code=400, detail="Authentication provider not found")

    db.delete("proxy_config", {})
    db.insert("proxy_config", config.model_dump())
    return NetworkboxResponse(status=True, message="Proxy configuration saved")


@router.patch("/config", response_model=NetworkboxResponse)
async def update_proxy_config(update: ProxyConfigUpdate):
    """Update proxy configuration."""
    existing = db.find_one("proxy_config", {})
    if not existing:
        raise HTTPException(status_code=404, detail="Proxy configuration not found")

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        db.update("proxy_config", {}, update_data)

    return NetworkboxResponse(status=True, message="Proxy configuration updated")


@router.get("/status", response_model=NetworkboxResponse)
async def get_proxy_status():
    """Get proxy server status."""
    if docker_service.container_is_running("NETWORKBOX_PROXY"):
        return NetworkboxResponse(status=True, message="Proxy server is running")
    else:
        return NetworkboxResponse(status=False, message="Proxy server is not running")


@router.get("/logs")
async def get_proxy_logs(
    lines: int = Query(100, description="Number of log lines to fetch", ge=1, le=1000)
):
    """Get proxy access logs."""
    container = docker_service.get_container("NETWORKBOX_PROXY")
    if not container or container.status != "running":
        raise HTTPException(status_code=400, detail="Proxy container not running")

    try:
        result = container.exec_run(
            ["tail", "-n", str(lines), "/var/log/squid/access.log"],
            user="root"
        )
        if result.exit_code == 0:
            log_output = result.output.decode("utf-8", errors="replace")
            log_lines = [line for line in log_output.strip().split("\n") if line]
            return {"logs": log_lines}
        else:
            return {"logs": []}
    except Exception as e:
        logger.error(f"Error fetching logs: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/start", response_model=NetworkboxResponse)
async def start_proxy_server():
    """Start proxy server."""
    config_data = db.find_one("proxy_config", {})
    if not config_data:
        raise HTTPException(status_code=400, detail="Proxy configuration not found")

    config = ProxyConfig(**config_data)

    auth = db.find_one("authentications", {"name": config.authentication})
    if not auth:
        raise HTTPException(status_code=400, detail="Authentication provider not found")

    try:
        # Stop existing
        docker_service.stop_container("NETWORKBOX_PROXY")

        # Pull image
        docker_service.pull_image(settings.image_squid)

        # Generate configs
        squid_conf = generate_squid_config(config, auth)
        error_page = generate_error_page(config.block_page)
        blacklist_page = generate_error_page(config.block_page, is_blacklist=True)

        # Create container
        container = docker_service.create_container(
            image=settings.image_squid,
            name="NETWORKBOX_PROXY",
            ports={f"{config.listen_port}/tcp": config.listen_port}
        )

        # Write configs
        tar_stream = io.BytesIO()
        with tarfile.open(fileobj=tar_stream, mode='w') as tar:
            # Add squid.conf
            conf_bytes = squid_conf.encode('utf-8')
            confinfo = tarfile.TarInfo(name='squid.conf')
            confinfo.size = len(conf_bytes)
            tar.addfile(confinfo, io.BytesIO(conf_bytes))

            # Add whitelist files (separate for domains and IPs)
            whitelist_domains, whitelist_ips = separate_domains_and_ips(config.whitelist_domains)
            if whitelist_domains:
                whitelist_content = "\n".join(whitelist_domains)
                whitelist_bytes = whitelist_content.encode('utf-8')
                whitelist_info = tarfile.TarInfo(name='whitelist_domains.txt')
                whitelist_info.size = len(whitelist_bytes)
                tar.addfile(whitelist_info, io.BytesIO(whitelist_bytes))
            if whitelist_ips:
                whitelist_ip_content = "\n".join(whitelist_ips)
                whitelist_ip_bytes = whitelist_ip_content.encode('utf-8')
                whitelist_ip_info = tarfile.TarInfo(name='whitelist_ips.txt')
                whitelist_ip_info.size = len(whitelist_ip_bytes)
                tar.addfile(whitelist_ip_info, io.BytesIO(whitelist_ip_bytes))

            # Add blacklist files (separate for domains and IPs)
            blacklist_domains, blacklist_ips = separate_domains_and_ips(config.blacklist_domains)
            if blacklist_domains:
                blacklist_content = "\n".join(blacklist_domains)
                blacklist_bytes = blacklist_content.encode('utf-8')
                blacklist_info = tarfile.TarInfo(name='blacklist_domains.txt')
                blacklist_info.size = len(blacklist_bytes)
                tar.addfile(blacklist_info, io.BytesIO(blacklist_bytes))
            if blacklist_ips:
                blacklist_ip_content = "\n".join(blacklist_ips)
                blacklist_ip_bytes = blacklist_ip_content.encode('utf-8')
                blacklist_ip_info = tarfile.TarInfo(name='blacklist_ips.txt')
                blacklist_ip_info.size = len(blacklist_ip_bytes)
                tar.addfile(blacklist_ip_info, io.BytesIO(blacklist_ip_bytes))

            # Create errors directory and add error pages
            errors_dir = tarfile.TarInfo(name='errors')
            errors_dir.type = tarfile.DIRTYPE
            errors_dir.mode = 0o755
            tar.addfile(errors_dir)

            # Access denied page
            error_bytes = error_page.encode('utf-8')
            errorinfo = tarfile.TarInfo(name='errors/ERR_ACCESS_DENIED')
            errorinfo.size = len(error_bytes)
            tar.addfile(errorinfo, io.BytesIO(error_bytes))

            # Blacklist denied page
            blacklist_bytes = blacklist_page.encode('utf-8')
            blacklistinfo = tarfile.TarInfo(name='errors/ERR_BLACKLIST_DENIED')
            blacklistinfo.size = len(blacklist_bytes)
            tar.addfile(blacklistinfo, io.BytesIO(blacklist_bytes))

        tar_stream.seek(0)
        container.put_archive('/etc/squid/', tar_stream)
        container.restart(timeout=10)

        return NetworkboxResponse(status=True, message="Proxy server started")

    except Exception as e:
        logger.exception(e)
        # Cleanup: stop and remove the container on failure
        docker_service.stop_container("NETWORKBOX_PROXY")
        return NetworkboxResponse(status=False, message=f"Failed to start: {str(e)}")


@router.post("/stop", response_model=NetworkboxResponse)
async def stop_proxy_server():
    """Stop proxy server."""
    if docker_service.stop_container("NETWORKBOX_PROXY"):
        return NetworkboxResponse(status=True, message="Proxy server stopped")
    else:
        return NetworkboxResponse(status=False, message="Failed to stop proxy server")


@stream_router.get("/start/stream")
async def start_proxy_stream(_: dict = Depends(verify_token_from_query)):
    """Start proxy server with live progress stream."""
    config_data = db.find_one("proxy_config", {})
    if not config_data:
        raise HTTPException(status_code=400, detail="Proxy configuration not found")

    config = ProxyConfig(**config_data)

    # Only require LDAP auth for ldap and kerberos modes
    auth = None
    if config.auth_mode in ["ldap", "kerberos"]:
        auth = db.find_one("authentications", {"name": config.authentication})
        if not auth:
            raise HTTPException(status_code=400, detail="Authentication provider not found")

    def action(action_logger):
        import time  # Import here to avoid circular imports

        try:
            action_logger.info("Starting Proxy server...")

            # Determine mode
            is_ip_allow_mode = config.auth_mode == "ip_allow"
            kerberos_enabled = config.auth_mode == "kerberos" and config.kerberos is not None

            # Stop existing
            action_logger.info("Stopping existing proxy container...")
            docker_service.stop_container("NETWORKBOX_PROXY", log_callback=action_logger.info)

            # Pull image
            docker_service.pull_image(settings.image_squid, log_callback=action_logger.info)

            # Generate configs based on auth mode
            if is_ip_allow_mode:
                action_logger.info("IP-Allow mode is enabled")
                action_logger.info("Generating IP-based Squid configuration...")
                squid_conf = generate_ip_allow_squid_config(config)
            elif kerberos_enabled:
                action_logger.info("Kerberos SSO is enabled")
                action_logger.info("Generating Kerberos Squid configuration...")
                squid_conf = generate_kerberos_squid_config(config, auth)
                krb5_conf = generate_krb5_conf(config.kerberos)
                startup_script = generate_kerberos_startup_script(config.kerberos)
            else:
                action_logger.info("LDAP authentication mode")
                action_logger.info("Generating Squid configuration...")
                squid_conf = generate_squid_config(config, auth)

            error_page = generate_error_page(config.block_page)
            blacklist_page = generate_error_page(config.block_page, is_blacklist=True)

            # Create container with appropriate settings
            # Timezone configuration via environment variable and volume
            timezone_env = {"TZ": "Europe/Berlin"}
            timezone_volumes = {"/etc/localtime": {"bind": "/etc/localtime", "mode": "ro"}}

            if kerberos_enabled:
                action_logger.info("Creating proxy container with Kerberos support...")
                # Add persistent volume for Kerberos data to avoid KVNO mismatch on restart
                # The keytab and samba secrets are stored in a named volume and reused across container restarts
                kerberos_volumes = {
                    **timezone_volumes,
                    "networkbox_proxy_kerberos": {"bind": "/var/lib/samba", "mode": "rw"}
                }
                container = docker_service.create_container(
                    image=settings.image_squid,
                    name="NETWORKBOX_PROXY",
                    ports={f"{config.listen_port}/tcp": config.listen_port},
                    entrypoint=["/bin/bash", "/etc/squid/startup.sh"],
                    dns=[config.kerberos.kdc],
                    hostname=config.kerberos.proxy_hostname.split('.')[0] if config.kerberos.proxy_hostname else "proxy",
                    environment=timezone_env,
                    volumes=kerberos_volumes,
                    log_callback=action_logger.info
                )
            else:
                action_logger.info("Creating proxy container...")
                container = docker_service.create_container(
                    image=settings.image_squid,
                    name="NETWORKBOX_PROXY",
                    ports={f"{config.listen_port}/tcp": config.listen_port},
                    environment=timezone_env,
                    volumes=timezone_volumes,
                    log_callback=action_logger.info
                )

            # Write configs
            action_logger.info("Writing configuration files...")
            tar_stream = io.BytesIO()
            with tarfile.open(fileobj=tar_stream, mode='w') as tar:
                # Add squid.conf
                conf_bytes = squid_conf.encode('utf-8')
                confinfo = tarfile.TarInfo(name='squid.conf')
                confinfo.size = len(conf_bytes)
                tar.addfile(confinfo, io.BytesIO(conf_bytes))

                # Add Kerberos-specific files
                if kerberos_enabled:
                    action_logger.info("Adding Kerberos configuration files...")
                    # Add krb5.conf
                    krb5_bytes = krb5_conf.encode('utf-8')
                    krb5info = tarfile.TarInfo(name='krb5.conf')
                    krb5info.size = len(krb5_bytes)
                    tar.addfile(krb5info, io.BytesIO(krb5_bytes))

                    # Add startup script (executable)
                    startup_bytes = startup_script.encode('utf-8')
                    startupinfo = tarfile.TarInfo(name='startup.sh')
                    startupinfo.size = len(startup_bytes)
                    startupinfo.mode = 0o755
                    tar.addfile(startupinfo, io.BytesIO(startup_bytes))

                # Add IP lists for IP-Allow mode
                if is_ip_allow_mode:
                    action_logger.info("Adding IP allow/block lists...")
                    # Allowed IPs
                    allowed_ips = config.ip_allow.allowed_ips if config.ip_allow else []
                    allowed_content = "\n".join([ip.ip for ip in allowed_ips]) if allowed_ips else ""
                    allowed_bytes = allowed_content.encode('utf-8')
                    allowed_info = tarfile.TarInfo(name='allowed_ips.txt')
                    allowed_info.size = len(allowed_bytes)
                    tar.addfile(allowed_info, io.BytesIO(allowed_bytes))

                    # Blocked IPs
                    blocked_ips = config.ip_allow.blocked_ips if config.ip_allow else []
                    blocked_content = "\n".join([ip.ip for ip in blocked_ips]) if blocked_ips else ""
                    blocked_bytes = blocked_content.encode('utf-8')
                    blocked_info = tarfile.TarInfo(name='blocked_ips.txt')
                    blocked_info.size = len(blocked_bytes)
                    tar.addfile(blocked_info, io.BytesIO(blocked_bytes))

                    action_logger.info(f"Allowed IPs: {len(allowed_ips)}, Blocked IPs: {len(blocked_ips)}")

                # Add whitelist files if entries exist (not for IP-Allow mode)
                if not is_ip_allow_mode and config.whitelist_domains:
                    whitelist_domains, whitelist_ips = separate_domains_and_ips(config.whitelist_domains)
                    action_logger.info(f"Adding whitelist: {len(whitelist_domains)} domains, {len(whitelist_ips)} IPs/CIDRs...")
                    if whitelist_domains:
                        whitelist_content = "\n".join(whitelist_domains)
                        whitelist_bytes = whitelist_content.encode('utf-8')
                        whitelist_info = tarfile.TarInfo(name='whitelist_domains.txt')
                        whitelist_info.size = len(whitelist_bytes)
                        tar.addfile(whitelist_info, io.BytesIO(whitelist_bytes))
                    if whitelist_ips:
                        whitelist_ip_content = "\n".join(whitelist_ips)
                        whitelist_ip_bytes = whitelist_ip_content.encode('utf-8')
                        whitelist_ip_info = tarfile.TarInfo(name='whitelist_ips.txt')
                        whitelist_ip_info.size = len(whitelist_ip_bytes)
                        tar.addfile(whitelist_ip_info, io.BytesIO(whitelist_ip_bytes))

                # Add blacklist files if entries exist (not for IP-Allow mode)
                if not is_ip_allow_mode and config.blacklist_domains:
                    blacklist_domains, blacklist_ips = separate_domains_and_ips(config.blacklist_domains)
                    action_logger.info(f"Adding blacklist: {len(blacklist_domains)} domains, {len(blacklist_ips)} IPs/CIDRs...")
                    if blacklist_domains:
                        blacklist_content = "\n".join(blacklist_domains)
                        blacklist_bytes = blacklist_content.encode('utf-8')
                        blacklist_info = tarfile.TarInfo(name='blacklist_domains.txt')
                        blacklist_info.size = len(blacklist_bytes)
                        tar.addfile(blacklist_info, io.BytesIO(blacklist_bytes))
                    if blacklist_ips:
                        blacklist_ip_content = "\n".join(blacklist_ips)
                        blacklist_ip_bytes = blacklist_ip_content.encode('utf-8')
                        blacklist_ip_info = tarfile.TarInfo(name='blacklist_ips.txt')
                        blacklist_ip_info.size = len(blacklist_ip_bytes)
                        tar.addfile(blacklist_ip_info, io.BytesIO(blacklist_ip_bytes))

                # Create errors directory and add error pages
                errors_dir = tarfile.TarInfo(name='errors')
                errors_dir.type = tarfile.DIRTYPE
                errors_dir.mode = 0o755
                tar.addfile(errors_dir)

                # Access denied page
                error_bytes = error_page.encode('utf-8')
                errorinfo = tarfile.TarInfo(name='errors/ERR_ACCESS_DENIED')
                errorinfo.size = len(error_bytes)
                tar.addfile(errorinfo, io.BytesIO(error_bytes))

                # Blacklist denied page
                blacklist_bytes = blacklist_page.encode('utf-8')
                blacklistinfo = tarfile.TarInfo(name='errors/ERR_BLACKLIST_DENIED')
                blacklistinfo.size = len(blacklist_bytes)
                tar.addfile(blacklistinfo, io.BytesIO(blacklist_bytes))

            tar_stream.seek(0)
            container.put_archive('/etc/squid/', tar_stream)

            if kerberos_enabled:
                action_logger.info("Starting container (installing Kerberos packages and joining domain)...")
                action_logger.info("This may take 1-2 minutes...")
                container.start()
                # Wait a bit for the startup script to complete
                time.sleep(5)
            else:
                action_logger.info("Restarting container with configuration...")
                container.restart(timeout=10)
                # Small delay to allow stream to stabilize after restart
                time.sleep(1)

            # Verify container is running
            container.reload()
            if container.status == "running":
                action_logger.success("Proxy server is now running")
                return True
            else:
                action_logger.error(f"Container status: {container.status}")
                return False

        except Exception as e:
            logger.exception(e)
            action_logger.error(f"Failed to start: {str(e)}")
            # Cleanup: stop and remove the container on failure
            action_logger.info("Cleaning up failed container...")
            docker_service.stop_container("NETWORKBOX_PROXY", log_callback=action_logger.info)
            return False

    return create_sse_response(action)


@stream_router.get("/stop/stream")
async def stop_proxy_stream(_: dict = Depends(verify_token_from_query)):
    """Stop proxy server with live progress stream."""

    def action(action_logger):
        action_logger.info("Stopping Proxy server...")
        success = docker_service.stop_container("NETWORKBOX_PROXY", log_callback=action_logger.info)

        if success:
            action_logger.success("Proxy server stopped")
        else:
            action_logger.error("Failed to stop proxy server")

        return success

    return create_sse_response(action)


def generate_pac_file(config: ProxyConfig, request_host: str) -> str:
    """Generate a PAC (Proxy Auto-Configuration) file.

    The PAC file is JavaScript that browsers execute to determine
    whether to use the proxy for each request.
    """
    # Use configured hostname or fall back to request host
    proxy_host = config.proxy_hostname or request_host
    proxy_port = config.listen_port

    # Build conditions for direct access (bypass proxy)
    direct_conditions = []

    # Always bypass localhost
    direct_conditions.append('if (isPlainHostName(host)) return "DIRECT";')
    direct_conditions.append('if (shExpMatch(host, "localhost")) return "DIRECT";')
    direct_conditions.append('if (shExpMatch(host, "127.*")) return "DIRECT";')
    direct_conditions.append('if (shExpMatch(host, "::1")) return "DIRECT";')

    # Add configured direct domains
    for domain in config.pac_direct_domains:
        if domain.startswith('.'):
            # Subdomain wildcard: .example.com matches *.example.com
            direct_conditions.append(
                f'if (dnsDomainIs(host, "{domain}") || host == "{domain[1:]}") return "DIRECT";'
            )
        else:
            # Exact match or subdomain
            direct_conditions.append(
                f'if (host == "{domain}" || dnsDomainIs(host, ".{domain}")) return "DIRECT";'
            )

    # Add configured direct networks (using isInNet)
    for network in config.pac_direct_networks:
        try:
            net = ipaddress.ip_network(network, strict=False)
            network_addr = str(net.network_address)
            netmask = str(net.netmask)
            direct_conditions.append(
                f'if (isInNet(dnsResolve(host), "{network_addr}", "{netmask}")) return "DIRECT";'
            )
        except ValueError:
            logger.warning(f"Invalid network in PAC config: {network}")

    direct_conditions_str = "\n    ".join(direct_conditions)

    return f"""// NetworkBOX Proxy Auto-Configuration (PAC) File
// Generated automatically - do not edit manually

function FindProxyForURL(url, host) {{
    // Convert host to lowercase for consistent matching
    host = host.toLowerCase();

    // Direct access conditions (bypass proxy)
    {direct_conditions_str}

    // Use proxy for everything else
    return "PROXY {proxy_host}:{proxy_port}";
}}
"""


@public_router.get("/wpad.dat")
async def get_wpad(request: Request):
    """Serve WPAD (Web Proxy Auto-Discovery) file.

    Clients can auto-discover this file via:
    - DHCP option 252
    - DNS lookup for wpad.domain.local
    - URL: http://wpad.domain.local/wpad.dat
    """
    config_data = db.find_one("proxy_config", {})
    if not config_data:
        raise HTTPException(status_code=404, detail="Proxy not configured")

    config = ProxyConfig(**config_data)

    # Get the host from the request (without port)
    request_host = request.headers.get("host", "").split(":")[0]
    if not request_host:
        request_host = request.client.host if request.client else "localhost"

    pac_content = generate_pac_file(config, request_host)

    return Response(
        content=pac_content,
        media_type="application/x-ns-proxy-autoconfig",
        headers={
            "Content-Disposition": "inline; filename=wpad.dat",
            "Cache-Control": "max-age=3600",
        }
    )


@public_router.get("/proxy.pac")
async def get_proxy_pac(request: Request):
    """Serve proxy.pac file (alternative to wpad.dat).

    Same content as wpad.dat but with .pac extension for
    manual configuration in browsers.
    """
    config_data = db.find_one("proxy_config", {})
    if not config_data:
        raise HTTPException(status_code=404, detail="Proxy not configured")

    config = ProxyConfig(**config_data)

    request_host = request.headers.get("host", "").split(":")[0]
    if not request_host:
        request_host = request.client.host if request.client else "localhost"

    pac_content = generate_pac_file(config, request_host)

    return Response(
        content=pac_content,
        media_type="application/x-ns-proxy-autoconfig",
        headers={
            "Content-Disposition": "inline; filename=proxy.pac",
            "Cache-Control": "max-age=3600",
        }
    )


# ============ Webhook Endpoints for IP-based Access Control ============

async def verify_webhook_api_key(x_api_key: str = Header(..., alias="X-API-Key")):
    """Verify API key for webhook endpoints."""
    config = db.find_one("proxy_config", {})
    if not config:
        raise HTTPException(status_code=404, detail="Proxy not configured")

    ip_allow = config.get("ip_allow", {})
    if not ip_allow.get("api_key"):
        raise HTTPException(status_code=403, detail="IP-Allow mode not configured")

    if ip_allow.get("api_key") != x_api_key:
        raise HTTPException(status_code=401, detail="Invalid API key")

    return config


def update_ip_lists_in_container(allowed_ips: list[AllowedIP], blocked_ips: list[AllowedIP]) -> bool:
    """Update IP lists in the running Squid container and reload config."""
    try:
        container = docker_service.get_container("NETWORKBOX_PROXY")
        if not container or container.status != "running":
            logger.warning("Proxy container not running, skipping IP list update")
            return False

        # Update allowed_ips.txt
        allowed_content = "\n".join([ip.ip for ip in allowed_ips]) if allowed_ips else ""
        container.exec_run(
            ["sh", "-c", f"echo '{allowed_content}' > /etc/squid/allowed_ips.txt"],
            user="root"
        )

        # Update blocked_ips.txt
        blocked_content = "\n".join([ip.ip for ip in blocked_ips]) if blocked_ips else ""
        container.exec_run(
            ["sh", "-c", f"echo '{blocked_content}' > /etc/squid/blocked_ips.txt"],
            user="root"
        )

        # Reload Squid config without restart
        result = container.exec_run(["squid", "-k", "reconfigure"], user="root")
        if result.exit_code != 0:
            logger.warning(f"Squid reconfigure failed: {result.output.decode()}")
            return False

        logger.info("IP lists updated and Squid reconfigured successfully")
        return True

    except Exception as e:
        logger.error(f"Failed to update IP lists in container: {e}")
        return False


@webhook_router.post("/allow", response_model=NetworkboxResponse)
async def webhook_allow_ip(
    request: WebhookIPRequest,
    config: dict = Depends(verify_webhook_api_key)
):
    """
    Allow an IP address via webhook.

    Requires X-API-Key header with the configured API key.
    """
    ip = request.ip.strip()

    # Validate IP address
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid IP address")

    # Get current config
    ip_allow = config.get("ip_allow", {})
    allowed_ips = [AllowedIP(**ip_data) for ip_data in ip_allow.get("allowed_ips", [])]
    blocked_ips = [AllowedIP(**ip_data) for ip_data in ip_allow.get("blocked_ips", [])]

    # Check if already allowed
    if any(existing.ip == ip for existing in allowed_ips):
        return NetworkboxResponse(status=True, message=f"IP {ip} is already allowed")

    # Remove from blocked list if present
    blocked_ips = [b for b in blocked_ips if b.ip != ip]

    # Add to allowed list
    new_ip = AllowedIP(
        ip=ip,
        description=request.description,
        added_at=datetime.utcnow().isoformat(),
        added_by="webhook"
    )
    allowed_ips.append(new_ip)

    # Update database
    db.update("proxy_config", {}, {
        "ip_allow.allowed_ips": [ip_obj.model_dump() for ip_obj in allowed_ips],
        "ip_allow.blocked_ips": [ip_obj.model_dump() for ip_obj in blocked_ips]
    })

    # Update running container
    update_ip_lists_in_container(allowed_ips, blocked_ips)

    return NetworkboxResponse(status=True, message=f"IP {ip} added to allowed list")


@webhook_router.post("/block", response_model=NetworkboxResponse)
async def webhook_block_ip(
    request: WebhookIPRequest,
    config: dict = Depends(verify_webhook_api_key)
):
    """
    Block an IP address via webhook.

    Requires X-API-Key header with the configured API key.
    """
    ip = request.ip.strip()

    # Validate IP address
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid IP address")

    # Get current config
    ip_allow = config.get("ip_allow", {})
    allowed_ips = [AllowedIP(**ip_data) for ip_data in ip_allow.get("allowed_ips", [])]
    blocked_ips = [AllowedIP(**ip_data) for ip_data in ip_allow.get("blocked_ips", [])]

    # Check if already blocked
    if any(existing.ip == ip for existing in blocked_ips):
        return NetworkboxResponse(status=True, message=f"IP {ip} is already blocked")

    # Remove from allowed list if present
    allowed_ips = [a for a in allowed_ips if a.ip != ip]

    # Add to blocked list
    new_ip = AllowedIP(
        ip=ip,
        description=request.description,
        added_at=datetime.utcnow().isoformat(),
        added_by="webhook"
    )
    blocked_ips.append(new_ip)

    # Update database
    db.update("proxy_config", {}, {
        "ip_allow.allowed_ips": [ip_obj.model_dump() for ip_obj in allowed_ips],
        "ip_allow.blocked_ips": [ip_obj.model_dump() for ip_obj in blocked_ips]
    })

    # Update running container
    update_ip_lists_in_container(allowed_ips, blocked_ips)

    return NetworkboxResponse(status=True, message=f"IP {ip} added to blocked list")


@webhook_router.post("/remove", response_model=NetworkboxResponse)
async def webhook_remove_ip(
    request: WebhookIPRequest,
    config: dict = Depends(verify_webhook_api_key)
):
    """
    Remove an IP address from both allowed and blocked lists via webhook.

    Requires X-API-Key header with the configured API key.
    """
    ip = request.ip.strip()

    # Validate IP address
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid IP address")

    # Get current config
    ip_allow = config.get("ip_allow", {})
    allowed_ips = [AllowedIP(**ip_data) for ip_data in ip_allow.get("allowed_ips", [])]
    blocked_ips = [AllowedIP(**ip_data) for ip_data in ip_allow.get("blocked_ips", [])]

    # Remove from both lists
    original_allowed_count = len(allowed_ips)
    original_blocked_count = len(blocked_ips)

    allowed_ips = [a for a in allowed_ips if a.ip != ip]
    blocked_ips = [b for b in blocked_ips if b.ip != ip]

    if len(allowed_ips) == original_allowed_count and len(blocked_ips) == original_blocked_count:
        return NetworkboxResponse(status=False, message=f"IP {ip} was not in any list")

    # Update database
    db.update("proxy_config", {}, {
        "ip_allow.allowed_ips": [ip_obj.model_dump() for ip_obj in allowed_ips],
        "ip_allow.blocked_ips": [ip_obj.model_dump() for ip_obj in blocked_ips]
    })

    # Update running container
    update_ip_lists_in_container(allowed_ips, blocked_ips)

    return NetworkboxResponse(status=True, message=f"IP {ip} removed from lists")


@webhook_router.get("/status", response_model=WebhookIPStatus)
async def webhook_ip_status(
    ip: str = Query(..., description="IP address to check"),
    config: dict = Depends(verify_webhook_api_key)
):
    """
    Check the status of an IP address.

    Requires X-API-Key header with the configured API key.
    """
    ip = ip.strip()

    # Validate IP address
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid IP address")

    # Get current config
    ip_allow = config.get("ip_allow", {})
    allowed_ips = ip_allow.get("allowed_ips", [])
    blocked_ips = ip_allow.get("blocked_ips", [])

    is_allowed = any(existing.get("ip") == ip for existing in allowed_ips)
    is_blocked = any(existing.get("ip") == ip for existing in blocked_ips)

    return WebhookIPStatus(ip=ip, allowed=is_allowed, blocked=is_blocked)


@router.post("/generate-api-key", response_model=NetworkboxResponse)
async def generate_api_key():
    """Generate a new API key for webhook access."""
    config = db.find_one("proxy_config", {})
    if not config:
        raise HTTPException(status_code=404, detail="Proxy not configured")

    # Generate a secure random API key
    api_key = secrets.token_urlsafe(32)

    # Update database
    db.update("proxy_config", {}, {"ip_allow.api_key": api_key})

    return NetworkboxResponse(status=True, message=api_key)


@stream_router.get("/logs/stream")
async def stream_proxy_logs(
    lines: int = Query(100, description="Number of lines to initially fetch"),
    _: dict = Depends(verify_token_from_query)
):
    """Stream proxy access logs in real-time via SSE."""
    import asyncio

    async def log_generator():
        """Generate log events from the proxy container."""
        container = docker_service.get_container("NETWORKBOX_PROXY")
        if not container or container.status != "running":
            yield f"data: {{\"error\": \"Proxy container not running\"}}\n\n"
            return

        try:
            # First, get the last N lines
            result = container.exec_run(
                ["tail", "-n", str(lines), "/var/log/squid/access.log"],
                user="root"
            )
            if result.exit_code == 0:
                initial_logs = result.output.decode("utf-8", errors="replace")
                for line in initial_logs.strip().split("\n"):
                    if line:
                        yield f"data: {line}\n\n"

            # Then follow the log file
            # Use tail -f to stream new entries
            exec_id = container.client.api.exec_create(
                container.id,
                ["tail", "-f", "/var/log/squid/access.log"],
                stdout=True,
                stderr=False
            )
            output = container.client.api.exec_start(exec_id, stream=True)

            for chunk in output:
                if chunk:
                    lines_data = chunk.decode("utf-8", errors="replace")
                    for line in lines_data.strip().split("\n"):
                        if line:
                            yield f"data: {line}\n\n"
                await asyncio.sleep(0.1)

        except Exception as e:
            logger.error(f"Error streaming logs: {e}")
            yield f"data: {{\"error\": \"{str(e)}\"}}\n\n"

    return StreamingResponse(
        log_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )
