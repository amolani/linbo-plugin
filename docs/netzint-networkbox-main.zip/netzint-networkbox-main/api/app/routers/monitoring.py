import logging
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional

from app.dependencies import verify_token
from app.database import db
from app.models import NetworkboxResponse
from app.models.monitoring import (
    MonitoringConfig,
    MonitoringConfigUpdate,
    MonitoredSwitch,
    MonitoredSwitchUpdate,
    SwitchConnection,
    LoopIncident,
    LoopIncidentUpdate,
    IncidentStatus,
    MonitoringStatus,
    UniFiConfig,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/monitoring",
    tags=["Network Monitoring"],
    dependencies=[Depends(verify_token)]
)


# ============================================================================
# Configuration
# ============================================================================

@router.get("/config", response_model=MonitoringConfig)
async def get_monitoring_config():
    """Get monitoring configuration."""
    config = db.find_one("monitoring_config", {})
    return MonitoringConfig(**(config or {}))


@router.post("/config", response_model=NetworkboxResponse)
async def update_monitoring_config(config: MonitoringConfig):
    """Update monitoring configuration (full replace)."""
    db.delete("monitoring_config", {})
    db.insert("monitoring_config", config.model_dump())
    return NetworkboxResponse(status=True, message="Configuration saved")


@router.patch("/config", response_model=NetworkboxResponse)
async def patch_monitoring_config(update: MonitoringConfigUpdate):
    """Partially update monitoring configuration."""
    existing = db.find_one("monitoring_config", {})
    if not existing:
        existing = MonitoringConfig().model_dump()

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        db.update("monitoring_config", {}, update_data)

    return NetworkboxResponse(status=True, message="Configuration updated")


# ============================================================================
# UniFi Integration
# ============================================================================

@router.post("/unifi/test", response_model=NetworkboxResponse)
async def test_unifi_connection(config: UniFiConfig):
    """Test UniFi Controller connection."""
    try:
        from app.services.unifi_service import unifi_service

        success, message = await unifi_service.test_connection(config)
        return NetworkboxResponse(status=success, message=message)
    except Exception as e:
        logger.exception("UniFi connection test failed")
        return NetworkboxResponse(status=False, message=str(e))


@router.post("/unifi/discover", response_model=list[MonitoredSwitch])
async def discover_unifi_switches():
    """Discover switches from UniFi Controller."""
    config_data = db.find_one("monitoring_config", {})
    if not config_data:
        raise HTTPException(status_code=400, detail="Monitoring not configured")

    config = MonitoringConfig(**config_data)
    if not config.unifi.enabled:
        raise HTTPException(status_code=400, detail="UniFi integration disabled")

    try:
        from app.services.unifi_service import unifi_service

        switches = await unifi_service.get_switches(config.unifi)
        return switches
    except Exception as e:
        logger.exception("UniFi discovery failed")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# Switch Management
# ============================================================================

@router.get("/switches", response_model=list[MonitoredSwitch])
async def get_switches():
    """Get all monitored switches."""
    switches = db.find("monitored_switches", {})
    return [MonitoredSwitch(**s) for s in switches] if switches else []


@router.post("/switches", response_model=NetworkboxResponse)
async def add_switch(switch: MonitoredSwitch):
    """Add a switch to monitoring."""
    existing = db.find_one("monitored_switches", {"name": switch.name})
    if existing:
        raise HTTPException(status_code=400, detail="Switch with this name already exists")

    existing_ip = db.find_one("monitored_switches", {"ip_address": switch.ip_address})
    if existing_ip:
        raise HTTPException(status_code=400, detail="Switch with this IP already exists")

    db.insert("monitored_switches", switch.model_dump())
    return NetworkboxResponse(status=True, message="Switch added")


@router.get("/switches/{name}", response_model=MonitoredSwitch)
async def get_switch(name: str):
    """Get a specific switch by name."""
    switch = db.find_one("monitored_switches", {"name": name})
    if not switch:
        raise HTTPException(status_code=404, detail="Switch not found")
    return MonitoredSwitch(**switch)


@router.patch("/switches/{name}", response_model=NetworkboxResponse)
async def update_switch(name: str, update: MonitoredSwitchUpdate):
    """Update a switch configuration."""
    existing = db.find_one("monitored_switches", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Switch not found")

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        db.update("monitored_switches", {"name": name}, update_data)

    return NetworkboxResponse(status=True, message="Switch updated")


@router.delete("/switches/{name}", response_model=NetworkboxResponse)
async def remove_switch(name: str):
    """Remove a switch from monitoring."""
    existing = db.find_one("monitored_switches", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Switch not found")

    db.delete("monitored_switches", {"name": name})
    # Also clean up related data
    db.delete("switch_metrics", {"switch_name": name})
    db.delete("switch_connections", {"$or": [{"from_switch": name}, {"to_switch": name}]})

    return NetworkboxResponse(status=True, message="Switch removed")


@router.post("/switches/{name}/test", response_model=NetworkboxResponse)
async def test_switch_snmp(name: str):
    """Test SNMP connectivity to a switch."""
    switch_data = db.find_one("monitored_switches", {"name": name})
    if not switch_data:
        raise HTTPException(status_code=404, detail="Switch not found")

    switch = MonitoredSwitch(**switch_data)

    try:
        from app.services.loop_scheduler import loop_scheduler

        result = await loop_scheduler.test_switch_connection(switch)
        if result.get("success"):
            return NetworkboxResponse(
                status=True,
                message=f"SNMP connection successful. System: {result.get('system_name', 'Unknown')}"
            )
        return NetworkboxResponse(status=False, message=result.get("error", "SNMP test failed"))
    except Exception as e:
        logger.exception(f"SNMP test failed for switch {name}")
        return NetworkboxResponse(status=False, message=str(e))


# ============================================================================
# Switch Connections (Topology)
# ============================================================================

@router.get("/connections", response_model=list[SwitchConnection])
async def get_connections():
    """Get all switch connections for topology."""
    connections = db.find("switch_connections", {})
    return [SwitchConnection(**c) for c in connections] if connections else []


@router.post("/connections", response_model=NetworkboxResponse)
async def add_connection(connection: SwitchConnection):
    """Add a connection between switches."""
    # Check if both switches exist
    from_switch = db.find_one("monitored_switches", {"name": connection.from_switch})
    to_switch = db.find_one("monitored_switches", {"name": connection.to_switch})

    if not from_switch:
        raise HTTPException(status_code=400, detail=f"Switch '{connection.from_switch}' not found")
    if not to_switch:
        raise HTTPException(status_code=400, detail=f"Switch '{connection.to_switch}' not found")

    # Check for duplicate
    existing = db.find_one("switch_connections", {
        "from_switch": connection.from_switch,
        "from_port": connection.from_port,
        "to_switch": connection.to_switch,
        "to_port": connection.to_port
    })
    if existing:
        raise HTTPException(status_code=400, detail="Connection already exists")

    db.insert("switch_connections", connection.model_dump())
    return NetworkboxResponse(status=True, message="Connection added")


@router.delete("/connections", response_model=NetworkboxResponse)
async def remove_connection(
    from_switch: str,
    from_port: int,
    to_switch: str,
    to_port: int
):
    """Remove a connection between switches."""
    db.delete("switch_connections", {
        "from_switch": from_switch,
        "from_port": from_port,
        "to_switch": to_switch,
        "to_port": to_port
    })
    return NetworkboxResponse(status=True, message="Connection removed")


# ============================================================================
# Incidents
# ============================================================================

@router.get("/incidents", response_model=list[LoopIncident])
async def get_incidents(
    status: Optional[str] = Query(None, description="Filter by status (open, investigating, resolved)"),
    severity: Optional[str] = Query(None, description="Filter by severity (info, warning, critical)"),
    limit: int = Query(50, ge=1, le=500)
):
    """Get loop incidents."""
    query = {}
    if status:
        query["status"] = status
    if severity:
        query["severity"] = severity

    incidents = list(db.find("loop_incidents", query) or [])
    incidents = sorted(incidents, key=lambda x: x.get("detected_at", ""), reverse=True)
    return [LoopIncident(**i) for i in incidents[:limit]]


@router.get("/incidents/{incident_id}", response_model=LoopIncident)
async def get_incident(incident_id: str):
    """Get a specific incident by ID."""
    incident = db.find_one("loop_incidents", {"id": incident_id})
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    return LoopIncident(**incident)


@router.patch("/incidents/{incident_id}", response_model=NetworkboxResponse)
async def update_incident(incident_id: str, update: LoopIncidentUpdate):
    """Update incident status."""
    existing = db.find_one("loop_incidents", {"id": incident_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Incident not found")

    update_data = {}
    if update.status:
        update_data["status"] = update.status.value
        if update.status == IncidentStatus.RESOLVED:
            update_data["resolved_at"] = datetime.now(timezone.utc).isoformat()

    if update_data:
        db.update("loop_incidents", {"id": incident_id}, update_data)

    return NetworkboxResponse(status=True, message=f"Incident updated")


@router.delete("/incidents/{incident_id}", response_model=NetworkboxResponse)
async def delete_incident(incident_id: str):
    """Delete an incident."""
    existing = db.find_one("loop_incidents", {"id": incident_id})
    if not existing:
        raise HTTPException(status_code=404, detail="Incident not found")

    db.delete("loop_incidents", {"id": incident_id})
    return NetworkboxResponse(status=True, message="Incident deleted")


# ============================================================================
# Status & Live Data
# ============================================================================

@router.get("/status", response_model=MonitoringStatus)
async def get_monitoring_status():
    """Get current monitoring status and summary."""
    config = db.find_one("monitoring_config", {})
    switches = list(db.find("monitored_switches", {}) or [])
    open_incidents = list(db.find("loop_incidents", {"status": {"$ne": "resolved"}}) or [])

    # Get flapping count from service if available
    flapping_count = 0
    last_poll = None
    switches_reachable = 0
    try:
        from app.services.loop_detection_service import loop_detection_service
        from app.services.loop_scheduler import loop_scheduler
        flapping = loop_detection_service.get_flapping_macs()
        flapping_count = len(flapping)
        last_poll = loop_scheduler.last_poll
        switch_status = loop_scheduler.get_switch_status()
        switches_reachable = sum(1 for v in switch_status.values() if v)
    except Exception:
        pass

    return MonitoringStatus(
        enabled=config.get("enabled", False) if config else False,
        switches_total=len(switches),
        switches_enabled=len([s for s in switches if s.get("enabled", True)]),
        switches_reachable=switches_reachable,
        open_incidents=len(open_incidents),
        critical_incidents=len([i for i in open_incidents if i.get("severity") == "critical"]),
        warning_incidents=len([i for i in open_incidents if i.get("severity") == "warning"]),
        last_poll=last_poll,
        flapping_macs_count=flapping_count
    )


@router.get("/mac-flapping")
async def get_mac_flapping():
    """Get current MAC flapping data."""
    try:
        from app.services.loop_detection_service import loop_detection_service

        flapping = loop_detection_service.get_flapping_macs()
        return {
            "flapping_macs": [f.model_dump() for f in flapping],
            "total_moves": sum(f.move_count for f in flapping),
            "affected_ports": len(set(
                p for f in flapping for p in f.ports
            ))
        }
    except Exception as e:
        logger.exception("Failed to get MAC flapping data")
        return {
            "flapping_macs": [],
            "total_moves": 0,
            "affected_ports": 0,
            "error": str(e)
        }


@router.get("/metrics/{switch_name}")
async def get_switch_metrics(switch_name: str):
    """Get current metrics for a switch."""
    metrics = db.find_one("switch_metrics", {"switch_name": switch_name})
    if not metrics:
        raise HTTPException(status_code=404, detail="No metrics found for this switch")
    return metrics


# ============================================================================
# Scheduler Control
# ============================================================================

@router.post("/start", response_model=NetworkboxResponse)
async def start_monitoring():
    """Start the monitoring scheduler."""
    try:
        from app.services.loop_scheduler import loop_scheduler
        await loop_scheduler.start()
        return NetworkboxResponse(status=True, message="Monitoring started")
    except Exception as e:
        logger.exception("Failed to start monitoring")
        return NetworkboxResponse(status=False, message=str(e))


@router.post("/stop", response_model=NetworkboxResponse)
async def stop_monitoring():
    """Stop the monitoring scheduler."""
    try:
        from app.services.loop_scheduler import loop_scheduler
        await loop_scheduler.stop()
        return NetworkboxResponse(status=True, message="Monitoring stopped")
    except Exception as e:
        logger.exception("Failed to stop monitoring")
        return NetworkboxResponse(status=False, message=str(e))
