import logging
import re
from fastapi import APIRouter, Depends, HTTPException

from app.dependencies import verify_token, verify_token_from_query
from app.database import db
from app.config import settings
from app.models import (
    Radius, RadiusUpdate, Network, Authentication, NetworkboxResponse
)
from app.services.docker_service import docker_service
from app.services.action_logger import create_sse_response

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/radius",
    tags=["RADIUS Server"],
    dependencies=[Depends(verify_token)]
)

# Separate router for SSE streams (no global auth dependency)
stream_router = APIRouter(
    prefix="/api/v1/radius",
    tags=["RADIUS Server Streams"]
)


def get_cn(dn: str) -> str | None:
    """Extract CN from a DN string."""
    m = re.search(r'cn\s*=\s*([^,]+)\s*(?:,|$)', dn, re.IGNORECASE)
    if not m:
        return None
    cn = m.group(1).strip()
    if len(cn) >= 2 and cn[0] == cn[-1] == '"':
        cn = cn[1:-1]
    return cn


def start_radius_container_internal(
    radius: Radius,
    network: dict,
    auth: dict,
    log_callback=None
) -> bool:
    """Start a RADIUS server container."""
    container_name = f"NETWORKBOX_RADIUS_{radius.name.upper()}"
    try:
        if log_callback:
            log_callback(f"Starting RADIUS server '{radius.name}'...")

        # Build group string
        radius_groups = ""
        for group in radius.groups:
            cn = get_cn(group.name)
            if cn:
                if group.vlan_id != 0:
                    radius_groups += f"{cn}:{group.simultaneous_use}:{group.vlan_id},"
                else:
                    radius_groups += f"{cn}:{group.simultaneous_use},"
        radius_groups = radius_groups.rstrip(",")

        if log_callback:
            log_callback(f"Configured groups: {radius_groups or 'none'}")

        # Pull image
        docker_service.pull_image(settings.image_radius, log_callback=log_callback)

        # Create container
        if log_callback:
            log_callback(f"Creating container with LDAP host: {auth['server']}")

        container = docker_service.create_container(
            image=settings.image_radius,
            name=container_name,
            environment={
                "LDAP_HOST": auth["server"],
                "LDAP_USER": auth["binduser"],
                "LDAP_PASS": auth["password"],
                "LDAP_BASEDN": auth["basedn"],
                "LDAP_USER_BASEDN": auth["basedn"],
                "LDAP_GROUP_BASEDN": auth["basedn"],
                "LDAP_RADIUS_ACCESS_GROUP": radius_groups,
                "LDAP_DOMAIN": radius.samba_domain,
                "LDAP_DOMAIN_SHORT": radius.samba_domain.split(".")[0],
                "LDAP_DOMAIN_ADMIN": radius.samba_domain_admin,
                "LDAP_DOMAIN_ADMIN_PW": radius.samba_domain_admin_password,
                "LDAP_HOSTNAME": radius.name.replace(" ", "_"),
                "RADIUS_CLIENT_CREDENTIALS": ",".join([
                    f"{c.network}:{c.password}" for c in radius.credentials
                ])
            },
            dns=[auth["server"]],
            dns_search=[radius.samba_domain],
            network=None,
            log_callback=log_callback
        )

        # Connect to network
        docker_service.connect_container_to_network(
            container,
            f"NETWORKBOX_{network['name']}",
            ipv4_address=radius.network.address,
            log_callback=log_callback
        )

        if log_callback:
            log_callback(f"RADIUS server '{radius.name}' started successfully")

        return True
    except Exception as e:
        logger.error(f"Failed to start RADIUS container: {e}")
        if log_callback:
            log_callback(f"Failed to start RADIUS container: {e}")
        # Cleanup: stop and remove the container on failure
        if log_callback:
            log_callback(f"Cleaning up failed container...")
        docker_service.stop_container(container_name, log_callback=log_callback)
        return False


def stop_radius_container_internal(radius: Radius, log_callback=None) -> bool:
    """Stop a RADIUS server container."""
    container_name = f"NETWORKBOX_RADIUS_{radius.name.upper()}"
    if log_callback:
        log_callback(f"Stopping RADIUS server '{radius.name}'...")
    result = docker_service.stop_container(container_name, log_callback=log_callback)
    if log_callback and result:
        log_callback(f"RADIUS server '{radius.name}' stopped successfully")
    return result


@router.get("", response_model=list[Radius])
async def get_all_radius():
    """Get all RADIUS servers."""
    result = db.find("radius", {})
    return list(result) if result else []


@router.post("", response_model=NetworkboxResponse)
async def create_radius(radius: Radius):
    """Create a new RADIUS server."""
    # Verify network exists
    network = db.find_one("networks", {"vlan_id": radius.network.vlan_id})
    if not network:
        raise HTTPException(status_code=400, detail="Network not found")

    # Verify authentication exists
    auth = db.find_one("authentications", {"name": radius.authentication})
    if not auth:
        raise HTTPException(status_code=400, detail="Authentication provider not found")

    existing = db.find_one("radius", {"name": radius.name})
    if existing:
        raise HTTPException(status_code=400, detail="RADIUS server with this name already exists")

    db.insert("radius", radius.model_dump())
    return NetworkboxResponse(status=True, message="RADIUS server created")


@router.get("/{name}", response_model=Radius | None)
async def get_radius(name: str):
    """Get a RADIUS server by name."""
    return db.find_one("radius", {"name": name})


@router.patch("/{name}", response_model=NetworkboxResponse)
async def update_radius(name: str, update: RadiusUpdate):
    """Update a RADIUS server."""
    existing = db.find_one("radius", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="RADIUS server not found")

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        db.update("radius", {"name": name}, update_data)

    return NetworkboxResponse(status=True, message="RADIUS server updated")


@router.delete("/{name}", response_model=NetworkboxResponse)
async def delete_radius(name: str):
    """Delete a RADIUS server."""
    radius_data = db.find_one("radius", {"name": name})
    if not radius_data:
        raise HTTPException(status_code=404, detail="RADIUS server not found")

    radius = Radius(**radius_data)
    stop_radius_container_internal(radius)

    db.delete("radius", {"name": name})
    return NetworkboxResponse(status=True, message="RADIUS server deleted")


@router.post("/{name}/start", response_model=NetworkboxResponse)
async def start_radius(name: str):
    """Start a RADIUS server."""
    radius_data = db.find_one("radius", {"name": name})
    if not radius_data:
        raise HTTPException(status_code=404, detail="RADIUS server not found")

    radius = Radius(**radius_data)

    network = db.find_one("networks", {"vlan_id": radius.network.vlan_id})
    if not network:
        raise HTTPException(status_code=400, detail="Network not found")

    auth = db.find_one("authentications", {"name": radius.authentication})
    if not auth:
        raise HTTPException(status_code=400, detail="Authentication provider not found")

    # Stop if already running
    stop_radius_container_internal(radius)

    if start_radius_container_internal(radius, network, auth):
        db.update("radius", {"name": name}, {"status": True})
        return NetworkboxResponse(status=True, message="RADIUS server started")
    else:
        return NetworkboxResponse(status=False, message="Failed to start RADIUS server")


@stream_router.get("/{name}/start/stream")
async def start_radius_stream(
    name: str,
    _: dict = Depends(verify_token_from_query)
):
    """Start a RADIUS server with live progress stream."""
    radius_data = db.find_one("radius", {"name": name})
    if not radius_data:
        raise HTTPException(status_code=404, detail="RADIUS server not found")

    radius = Radius(**radius_data)

    network = db.find_one("networks", {"vlan_id": radius.network.vlan_id})
    if not network:
        raise HTTPException(status_code=400, detail="Network not found")

    auth = db.find_one("authentications", {"name": radius.authentication})
    if not auth:
        raise HTTPException(status_code=400, detail="Authentication provider not found")

    def action(action_logger):
        # Stop if already running
        stop_radius_container_internal(radius, log_callback=action_logger.info)

        success = start_radius_container_internal(
            radius, network, auth,
            log_callback=action_logger.info
        )

        if success:
            db.update("radius", {"name": name}, {"status": True})
            action_logger.success("RADIUS server is now running")
        else:
            action_logger.error("Failed to start RADIUS server")

        return success

    return create_sse_response(action)


@router.post("/{name}/stop", response_model=NetworkboxResponse)
async def stop_radius(name: str):
    """Stop a RADIUS server."""
    radius_data = db.find_one("radius", {"name": name})
    if not radius_data:
        raise HTTPException(status_code=404, detail="RADIUS server not found")

    radius = Radius(**radius_data)

    if stop_radius_container_internal(radius):
        db.update("radius", {"name": name}, {"status": False})
        return NetworkboxResponse(status=True, message="RADIUS server stopped")
    else:
        return NetworkboxResponse(status=False, message="Failed to stop RADIUS server")


@stream_router.get("/{name}/stop/stream")
async def stop_radius_stream(
    name: str,
    _: dict = Depends(verify_token_from_query)
):
    """Stop a RADIUS server with live progress stream."""
    radius_data = db.find_one("radius", {"name": name})
    if not radius_data:
        raise HTTPException(status_code=404, detail="RADIUS server not found")

    radius = Radius(**radius_data)

    def action(action_logger):
        success = stop_radius_container_internal(radius, log_callback=action_logger.info)

        if success:
            db.update("radius", {"name": name}, {"status": False})
            action_logger.success("RADIUS server stopped")
        else:
            action_logger.error("Failed to stop RADIUS server")

        return success

    return create_sse_response(action)
