from fastapi import APIRouter, Depends, HTTPException

from app.dependencies import verify_token
from app.models import SophosXGSConnection, NetworkboxResponse
from app.services.sophos_service import sophos_service

router = APIRouter(
    prefix="/api/v1/sophos",
    tags=["Sophos XGS"],
    dependencies=[Depends(verify_token)]
)


@router.post("/certificates/list")
async def list_sophos_certificates(conn: SophosXGSConnection):
    """List certificates from Sophos XGS."""
    return sophos_service.list_certificates(conn)


@router.post("/network/vlans/list")
async def list_sophos_vlans(conn: SophosXGSConnection):
    """List VLANs from Sophos XGS."""
    success, result = sophos_service.list_network_vlans(conn)
    if success:
        return result
    else:
        raise HTTPException(status_code=401, detail=result)
