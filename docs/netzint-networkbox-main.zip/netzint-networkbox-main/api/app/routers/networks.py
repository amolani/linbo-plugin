import logging

from fastapi import APIRouter, Depends, HTTPException

from app.dependencies import verify_token
from app.database import db
from app.models import Network, NetworkUpdate, NetworkboxResponse
from app.services.network_service import network_service
from app.services.docker_service import docker_service

logger = logging.getLogger(__name__)

NAPI_CONTAINER_NAME = "networkbox-napi"


def connect_napi_to_network(network: Network):
    """Connect NAPI container to a network if ip_address is configured."""
    if not network.ip_address:
        return

    napi_container = docker_service.get_container(NAPI_CONTAINER_NAME)
    if not napi_container:
        logger.warning("NAPI container not found")
        return

    docker_network_name = f"NETWORKBOX_{network.name}"

    # Check if already connected
    napi_container.reload()
    connected_networks = napi_container.attrs.get("NetworkSettings", {}).get("Networks", {})
    if docker_network_name in connected_networks:
        # Disconnect first to update IP
        try:
            docker_network = docker_service.get_network(docker_network_name)
            if docker_network:
                docker_network.disconnect(napi_container)
        except Exception as e:
            logger.warning(f"Failed to disconnect NAPI from {docker_network_name}: {e}")

    # Connect to network
    try:
        docker_service.connect_container_to_network(
            napi_container,
            docker_network_name,
            ipv4_address=network.ip_address
        )
        logger.info(f"Connected NAPI to {network.name} with IP {network.ip_address}")
    except Exception as e:
        logger.error(f"Failed to connect NAPI to {network.name}: {e}")


def disconnect_napi_from_network(network_name: str):
    """Disconnect NAPI container from a network."""
    napi_container = docker_service.get_container(NAPI_CONTAINER_NAME)
    if not napi_container:
        return

    docker_network_name = f"NETWORKBOX_{network_name}"

    try:
        docker_network = docker_service.get_network(docker_network_name)
        if docker_network:
            docker_network.disconnect(napi_container)
            logger.info(f"Disconnected NAPI from {network_name}")
    except Exception as e:
        logger.warning(f"Failed to disconnect NAPI from {network_name}: {e}")


router = APIRouter(
    prefix="/api/v1/networks",
    tags=["Networks"],
    dependencies=[Depends(verify_token)]
)


@router.get("", response_model=list[Network])
async def get_networks():
    """Get all configured networks."""
    result = db.find("networks", {})
    return list(result) if result else []


@router.post("", response_model=NetworkboxResponse)
async def create_network(network: Network):
    """Create a new network (VLAN + macvlan)."""
    # Check if network already exists
    existing = db.find_one("networks", {"name": network.name})
    if existing:
        raise HTTPException(status_code=400, detail="Network with this name already exists")

    existing_vlan = db.find_one("networks", {"vlan_id": network.vlan_id})
    if existing_vlan:
        raise HTTPException(status_code=400, detail="Network with this VLAN ID already exists")

    # Create VLAN interface
    if network.vlan_id != 0:
        if not network_service.create_vlan_interface(network.parent, network.vlan_id):
            raise HTTPException(status_code=400, detail="Failed to create VLAN interface")

    # Create macvlan network
    if not network_service.create_macvlan_network(
        name=network.name,
        parent=network.parent,
        vlan_id=network.vlan_id,
        address=network.address,
        mask=network.mask
    ):
        # Cleanup VLAN interface on failure
        if network.vlan_id != 0:
            network_service.delete_vlan_interface(network.parent, network.vlan_id)
        raise HTTPException(status_code=400, detail="Failed to create Docker network")

    # Save to database
    db.insert("networks", network.model_dump())

    # Connect NAPI to network if ip_address is configured
    connect_napi_to_network(network)

    return NetworkboxResponse(status=True, message="Network created successfully")


@router.get("/{vlan_id}", response_model=Network | None)
async def get_network(vlan_id: int):
    """Get a network by VLAN ID."""
    result = db.find_one("networks", {"vlan_id": vlan_id})
    return result


@router.put("/{vlan_id}", response_model=NetworkboxResponse)
async def update_network(vlan_id: int, update: NetworkUpdate):
    """Update a network's name, address, or mask."""
    network_data = db.find_one("networks", {"vlan_id": vlan_id})
    if not network_data:
        raise HTTPException(status_code=404, detail="Network not found")

    # Check if new name already exists (if name is being changed)
    if update.name and update.name != network_data["name"]:
        existing = db.find_one("networks", {"name": update.name})
        if existing:
            raise HTTPException(status_code=400, detail="Network with this name already exists")

    # Build update dict with only provided fields
    update_dict = {}
    if update.name is not None:
        update_dict["name"] = update.name
    if update.address is not None:
        update_dict["address"] = update.address
    if update.mask is not None:
        update_dict["mask"] = update.mask
    if update.ip_address is not None:
        update_dict["ip_address"] = update.ip_address

    if not update_dict:
        return NetworkboxResponse(status=True, message="No changes provided")

    # Update database
    db.update("networks", {"vlan_id": vlan_id}, update_dict)

    # If ip_address was updated, reconnect NAPI
    if update.ip_address is not None:
        updated_network_data = db.find_one("networks", {"vlan_id": vlan_id})
        if updated_network_data:
            updated_network = Network(**updated_network_data)
            if update.ip_address:
                connect_napi_to_network(updated_network)
            else:
                disconnect_napi_from_network(updated_network.name)

    return NetworkboxResponse(status=True, message="Network updated successfully")


@router.delete("/{vlan_id}", response_model=NetworkboxResponse)
async def delete_network(vlan_id: int):
    """Delete a network by VLAN ID."""
    network_data = db.find_one("networks", {"vlan_id": vlan_id})
    if not network_data:
        raise HTTPException(status_code=404, detail="Network not found")

    network = Network(**network_data)

    # Disconnect NAPI from network first
    disconnect_napi_from_network(network.name)

    # Delete macvlan network
    network_service.delete_macvlan_network(network.name)

    # Delete VLAN interface
    if network.vlan_id != 0:
        network_service.delete_vlan_interface(network.parent, network.vlan_id)

    # Remove from database
    db.delete("networks", {"vlan_id": vlan_id})

    return NetworkboxResponse(status=True, message="Network deleted successfully")
