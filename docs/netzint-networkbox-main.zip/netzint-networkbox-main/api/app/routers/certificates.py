import logging
import ipaddress
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import PlainTextResponse

from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from app.dependencies import verify_token
from app.database import db
from app.models import (
    Certificate, CertificateSource, CertificateSourceUpdate,
    CertificateUpload, CertificateGenerate,
    SophosXGSConnection, NetworkboxResponse
)
from app.services.sophos_service import sophos_service

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/certificates",
    tags=["Certificates"],
    dependencies=[Depends(verify_token)]
)


# ============ Certificate Sources ============

@router.get("/sources", response_model=list[CertificateSource])
async def get_all_certificate_sources():
    """Get all certificate sources."""
    result = db.find("certificate_sources", {})
    return list(result) if result else []


@router.post("/sources", response_model=NetworkboxResponse)
async def create_certificate_source(source: CertificateSource):
    """Create a new certificate source."""
    existing = db.find_one("certificate_sources", {"name": source.name})
    if existing:
        raise HTTPException(status_code=400, detail="Certificate source with this name already exists")

    db.insert("certificate_sources", source.model_dump())
    return NetworkboxResponse(status=True, message="Certificate source created")


@router.get("/sources/{name}", response_model=CertificateSource)
async def get_certificate_source(name: str):
    """Get a certificate source by name."""
    result = db.find_one("certificate_sources", {"name": name})
    if not result:
        raise HTTPException(status_code=404, detail="Certificate source not found")
    return result


@router.patch("/sources/{name}", response_model=NetworkboxResponse)
async def update_certificate_source(name: str, update: CertificateSourceUpdate):
    """Update a certificate source."""
    existing = db.find_one("certificate_sources", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Certificate source not found")

    update_data = {k: v for k, v in update.model_dump().items() if v is not None}
    if update_data:
        db.update("certificate_sources", {"name": name}, update_data)

    return NetworkboxResponse(status=True, message="Certificate source updated")


@router.delete("/sources/{name}", response_model=NetworkboxResponse)
async def delete_certificate_source(name: str):
    """Delete a certificate source and associated certificates."""
    existing = db.find_one("certificate_sources", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Certificate source not found")

    # Delete associated certificates
    db.delete("certificates", {"source": name})
    db.delete("certificate_sources", {"name": name})

    return NetworkboxResponse(status=True, message="Certificate source deleted")


@router.post("/sources/{name}/test", response_model=NetworkboxResponse)
async def test_source_connection(name: str):
    """Test connection to a Sophos source."""
    source_data = db.find_one("certificate_sources", {"name": name})
    if not source_data:
        raise HTTPException(status_code=404, detail="Certificate source not found")

    source = CertificateSource(**source_data)

    # Build Sophos connection
    xgs_conn = SophosXGSConnection(
        hostname=source.sophos_hostname,
        port=source.sophos_port,
        username=source.sophos_username,
        password=source.sophos_password
    )

    success, message = sophos_service.test_connection(xgs_conn)
    return NetworkboxResponse(status=success, message=message)


@router.get("/sources/{name}/certificates")
async def list_source_certificates(name: str):
    """List available certificates from a Sophos source."""
    source_data = db.find_one("certificate_sources", {"name": name})
    if not source_data:
        raise HTTPException(status_code=404, detail="Certificate source not found")

    source = CertificateSource(**source_data)

    # Build Sophos connection
    xgs_conn = SophosXGSConnection(
        hostname=source.sophos_hostname,
        port=source.sophos_port,
        username=source.sophos_username,
        password=source.sophos_password
    )

    try:
        certs = sophos_service.list_certificates(xgs_conn)
        return certs
    except Exception as e:
        logger.exception(e)
        raise HTTPException(status_code=500, detail=f"Failed to list certificates: {str(e)}")


@router.post("/sources/{name}/sync", response_model=NetworkboxResponse)
async def sync_certificate_source(name: str, cert_name: str = None, add: bool = False, remove: bool = False):
    """
    Sync certificates from source.

    - If cert_name is provided with add=True: Add cert to sophos_cert_names and sync it
    - If cert_name is provided with remove=True: Remove cert from sophos_cert_names and delete it
    - If cert_name is provided without add/remove: Just sync that specific certificate
    - If no cert_name: Sync all certificates in sophos_cert_names
    """
    source_data = db.find_one("certificate_sources", {"name": name})
    if not source_data:
        raise HTTPException(status_code=404, detail="Certificate source not found")

    source = CertificateSource(**source_data)

    # Handle remove operation
    if remove and cert_name:
        if cert_name in source.sophos_cert_names:
            new_cert_names = [c for c in source.sophos_cert_names if c != cert_name]
            db.update("certificate_sources", {"name": name}, {"sophos_cert_names": new_cert_names})
            # Delete the certificate from storage
            db.delete("certificates", {"source": name, "name": cert_name})
            return NetworkboxResponse(status=True, message=f"Certificate '{cert_name}' removed")
        return NetworkboxResponse(status=False, message=f"Certificate '{cert_name}' not in selected list")

    # Handle add operation - add to list if not already present
    if add and cert_name:
        if cert_name not in source.sophos_cert_names:
            new_cert_names = source.sophos_cert_names + [cert_name]
            db.update("certificate_sources", {"name": name}, {"sophos_cert_names": new_cert_names})
            source.sophos_cert_names = new_cert_names

    # Determine which certificates to sync
    if cert_name:
        certs_to_sync = [cert_name]
    else:
        certs_to_sync = source.sophos_cert_names

    if not certs_to_sync:
        raise HTTPException(status_code=400, detail="No certificates selected for sync")

    # Build Sophos connection
    xgs_conn = SophosXGSConnection(
        hostname=source.sophos_hostname,
        port=source.sophos_port,
        username=source.sophos_username,
        password=source.sophos_password
    )

    synced = []
    failed = []

    for target_cert_name in certs_to_sync:
        try:
            cert, error = sophos_service.get_certificate(xgs_conn, target_cert_name)
            if not cert:
                failed.append(f"{target_cert_name}: {error}")
                continue

            # Parse certificate for metadata
            cert_obj = x509.load_pem_x509_certificate(cert.cert_pem.encode("utf-8"))
            sha256 = cert_obj.fingerprint(hashes.SHA256()).hex()
            subject = cert_obj.subject.rfc4514_string()
            issuer = cert_obj.issuer.rfc4514_string()
            valid_from = cert_obj.not_valid_before_utc.isoformat()
            valid_to = cert_obj.not_valid_after_utc.isoformat()

            # Check if unchanged
            existing_cert = db.find_one("certificates", {"source": name, "name": target_cert_name})
            if existing_cert and existing_cert.get("sha256") == sha256:
                db.update("certificates", {"source": name, "name": target_cert_name}, {
                    "last_updated": datetime.now(timezone.utc).isoformat()
                })
                synced.append(target_cert_name)
                continue

            # Store certificate
            cert_data = {
                "name": target_cert_name,
                "source": name,
                "cert_pem": cert.cert_pem,
                "key_pem": cert.key_pem,
                "subject": subject,
                "issuer": issuer,
                "valid_from": valid_from,
                "valid_to": valid_to,
                "sha256": sha256,
                "last_updated": datetime.now(timezone.utc).isoformat()
            }

            # Delete existing and insert new
            db.delete("certificates", {"source": name, "name": target_cert_name})
            db.insert("certificates", cert_data)
            synced.append(target_cert_name)

        except Exception as e:
            logger.exception(e)
            failed.append(f"{target_cert_name}: {str(e)}")

    # Update sync timestamp
    db.update("certificate_sources", {"name": name}, {
        "last_sync": datetime.now(timezone.utc).isoformat()
    })

    if failed:
        return NetworkboxResponse(
            status=len(synced) > 0,
            message=f"Synced: {len(synced)}, Failed: {len(failed)} - {', '.join(failed)}"
        )

    return NetworkboxResponse(
        status=True,
        message=f"Successfully synced {len(synced)} certificate(s)"
    )


# ============ Certificates ============

@router.get("", response_model=list[Certificate])
async def get_all_certificates():
    """Get all certificates."""
    result = db.find("certificates", {})
    return list(result) if result else []


@router.get("/{name}", response_model=Certificate)
async def get_certificate(name: str):
    """Get a certificate by name."""
    result = db.find_one("certificates", {"name": name})
    if not result:
        raise HTTPException(status_code=404, detail="Certificate not found")
    return result


@router.get("/{name}/download")
async def download_certificate(name: str, format: str = "pem"):
    """Download certificate in various formats."""
    cert = db.find_one("certificates", {"name": name})
    if not cert:
        raise HTTPException(status_code=404, detail="Certificate not found")

    if format == "pem":
        content = cert["cert_pem"] + "\n" + cert["key_pem"]
        return PlainTextResponse(
            content,
            media_type="application/x-pem-file",
            headers={"Content-Disposition": f"attachment; filename={name}.pem"}
        )
    elif format == "cert":
        return PlainTextResponse(
            cert["cert_pem"],
            media_type="application/x-pem-file",
            headers={"Content-Disposition": f"attachment; filename={name}.crt"}
        )
    elif format == "key":
        return PlainTextResponse(
            cert["key_pem"],
            media_type="application/x-pem-file",
            headers={"Content-Disposition": f"attachment; filename={name}.key"}
        )
    else:
        raise HTTPException(status_code=400, detail="Invalid format. Use: pem, cert, or key")


@router.post("/upload", response_model=NetworkboxResponse)
async def upload_certificate(upload: CertificateUpload):
    """Upload a certificate with key."""
    # Check if name already exists
    existing = db.find_one("certificates", {"name": upload.name})
    if existing:
        raise HTTPException(status_code=400, detail="Certificate with this name already exists")

    try:
        # Parse and validate the certificate
        cert_obj = x509.load_pem_x509_certificate(upload.cert_pem.encode("utf-8"))

        # Validate the key
        try:
            serialization.load_pem_private_key(upload.key_pem.encode("utf-8"), password=None)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid private key")

        # Extract metadata
        sha256 = cert_obj.fingerprint(hashes.SHA256()).hex()
        subject = cert_obj.subject.rfc4514_string()
        issuer = cert_obj.issuer.rfc4514_string()
        valid_from = cert_obj.not_valid_before_utc.isoformat()
        valid_to = cert_obj.not_valid_after_utc.isoformat()

        # Store certificate
        cert_data = {
            "name": upload.name,
            "source": "upload",
            "cert_pem": upload.cert_pem,
            "key_pem": upload.key_pem,
            "subject": subject,
            "issuer": issuer,
            "valid_from": valid_from,
            "valid_to": valid_to,
            "sha256": sha256,
            "last_updated": datetime.now(timezone.utc).isoformat()
        }

        db.insert("certificates", cert_data)
        return NetworkboxResponse(status=True, message="Certificate uploaded successfully")

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(e)
        raise HTTPException(status_code=400, detail=f"Invalid certificate: {str(e)}")


@router.post("/generate", response_model=NetworkboxResponse)
async def generate_certificate(gen: CertificateGenerate):
    """Generate a self-signed certificate."""
    # Check if name already exists
    existing = db.find_one("certificates", {"name": gen.name})
    if existing:
        raise HTTPException(status_code=400, detail="Certificate with this name already exists")

    try:
        # Generate private key
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=gen.key_size,
        )

        # Build subject name
        name_attrs = [x509.NameAttribute(NameOID.COMMON_NAME, gen.common_name)]
        if gen.organization:
            name_attrs.append(x509.NameAttribute(NameOID.ORGANIZATION_NAME, gen.organization))
        if gen.organizational_unit:
            name_attrs.append(x509.NameAttribute(NameOID.ORGANIZATIONAL_UNIT_NAME, gen.organizational_unit))
        if gen.country:
            name_attrs.append(x509.NameAttribute(NameOID.COUNTRY_NAME, gen.country))
        if gen.state:
            name_attrs.append(x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, gen.state))
        if gen.locality:
            name_attrs.append(x509.NameAttribute(NameOID.LOCALITY_NAME, gen.locality))

        subject = issuer = x509.Name(name_attrs)

        # Build SANs
        san_list = []
        for dns_name in gen.san_dns:
            san_list.append(x509.DNSName(dns_name))
        for ip_str in gen.san_ip:
            san_list.append(x509.IPAddress(ipaddress.ip_address(ip_str)))

        # Always add CN as DNS SAN
        if gen.common_name not in gen.san_dns:
            san_list.insert(0, x509.DNSName(gen.common_name))

        # Build certificate
        now = datetime.now(timezone.utc)
        builder = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(private_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(now + timedelta(days=gen.validity_days))
            .add_extension(
                x509.BasicConstraints(ca=False, path_length=None),
                critical=True,
            )
        )

        if san_list:
            builder = builder.add_extension(
                x509.SubjectAlternativeName(san_list),
                critical=False,
            )

        # Sign certificate
        cert = builder.sign(private_key, hashes.SHA256())

        # Serialize to PEM
        cert_pem = cert.public_bytes(serialization.Encoding.PEM).decode("utf-8")
        key_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode("utf-8")

        # Extract metadata
        sha256 = cert.fingerprint(hashes.SHA256()).hex()
        subject_str = cert.subject.rfc4514_string()
        issuer_str = cert.issuer.rfc4514_string()
        valid_from = cert.not_valid_before_utc.isoformat()
        valid_to = cert.not_valid_after_utc.isoformat()

        # Store certificate
        cert_data = {
            "name": gen.name,
            "source": "generated",
            "cert_pem": cert_pem,
            "key_pem": key_pem,
            "subject": subject_str,
            "issuer": issuer_str,
            "valid_from": valid_from,
            "valid_to": valid_to,
            "sha256": sha256,
            "last_updated": datetime.now(timezone.utc).isoformat()
        }

        db.insert("certificates", cert_data)
        return NetworkboxResponse(status=True, message="Certificate generated successfully")

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(e)
        raise HTTPException(status_code=500, detail=f"Failed to generate certificate: {str(e)}")


@router.delete("/{name}", response_model=NetworkboxResponse)
async def delete_certificate(name: str):
    """Delete a certificate."""
    existing = db.find_one("certificates", {"name": name})
    if not existing:
        raise HTTPException(status_code=404, detail="Certificate not found")

    db.delete("certificates", {"name": name})
    return NetworkboxResponse(status=True, message="Certificate deleted")
