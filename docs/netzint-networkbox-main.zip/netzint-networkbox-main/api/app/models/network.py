from pydantic import BaseModel, field_validator
import ipaddress


class Network(BaseModel):
    name: str
    parent: str
    vlan_id: int
    address: str
    mask: str
    ip_address: str = ""

    @field_validator("address")
    @classmethod
    def validate_address(cls, v: str) -> str:
        try:
            ipaddress.ip_address(v)
        except ValueError:
            raise ValueError(f"Invalid IP address: {v}")
        return v

    @field_validator("mask")
    @classmethod
    def validate_mask(cls, v: str) -> str:
        try:
            ipaddress.ip_address(v)
        except ValueError:
            raise ValueError(f"Invalid subnet mask: {v}")
        return v


class NetworkUpdate(BaseModel):
    name: str | None = None
    address: str | None = None
    mask: str | None = None
    ip_address: str | None = None

    @field_validator("address", "ip_address")
    @classmethod
    def validate_address(cls, v: str | None) -> str | None:
        if v:
            try:
                ipaddress.ip_address(v)
            except ValueError:
                raise ValueError(f"Invalid IP address: {v}")
        return v

    @field_validator("mask")
    @classmethod
    def validate_mask(cls, v: str | None) -> str | None:
        if v:
            try:
                ipaddress.ip_address(v)
            except ValueError:
                raise ValueError(f"Invalid subnet mask: {v}")
        return v


class ContainerNetwork(BaseModel):
    vlan_id: int
    address: str
    mask: str = ""

    @field_validator("address")
    @classmethod
    def validate_address(cls, v: str) -> str:
        if v:
            try:
                ipaddress.ip_address(v)
            except ValueError:
                raise ValueError(f"Invalid IP address: {v}")
        return v
