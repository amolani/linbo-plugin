from pydantic import BaseModel
from typing import Optional
from .network import ContainerNetwork


class RadiusGroups(BaseModel):
    name: str
    simultaneous_use: int
    vlan_id: int = 0


class RadiusCredentials(BaseModel):
    network: str
    password: str


class Radius(BaseModel):
    name: str
    network: ContainerNetwork
    authentication: str
    samba_domain: str
    samba_domain_admin: str
    samba_domain_admin_password: str
    credentials: list[RadiusCredentials]
    groups: list[RadiusGroups]
    status: bool = False


class RadiusUpdate(BaseModel):
    network: Optional[ContainerNetwork] = None
    authentication: Optional[str] = None
    samba_domain: Optional[str] = None
    samba_domain_admin: Optional[str] = None
    samba_domain_admin_password: Optional[str] = None
    credentials: Optional[list[RadiusCredentials]] = None
    groups: Optional[list[RadiusGroups]] = None
