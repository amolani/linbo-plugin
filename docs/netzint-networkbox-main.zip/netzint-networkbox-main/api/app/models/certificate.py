from pydantic import BaseModel
from typing import Optional


class CertificateSource(BaseModel):
    name: str
    type: str = "sophos"
    sophos_hostname: str
    sophos_port: int = 4444
    sophos_username: str
    sophos_password: str
    sophos_cert_names: list[str] = []  # Multiple certificates can be selected
    sync_interval: int = 60
    enabled: bool = True
    last_sync: Optional[str] = None


class CertificateSourceUpdate(BaseModel):
    sophos_hostname: Optional[str] = None
    sophos_port: Optional[int] = None
    sophos_username: Optional[str] = None
    sophos_password: Optional[str] = None
    sophos_cert_names: Optional[list[str]] = None  # Multiple certificates
    sync_interval: Optional[int] = None
    enabled: Optional[bool] = None


class Certificate(BaseModel):
    name: str
    source: str
    cert_pem: str
    key_pem: str
    subject: str
    issuer: str
    valid_from: str
    valid_to: str
    sha256: str
    last_updated: str


class CertificateUpload(BaseModel):
    name: str
    cert_pem: str
    key_pem: str


class CertificateGenerate(BaseModel):
    name: str
    common_name: str
    organization: Optional[str] = None
    organizational_unit: Optional[str] = None
    country: Optional[str] = None
    state: Optional[str] = None
    locality: Optional[str] = None
    san_dns: list[str] = []
    san_ip: list[str] = []
    validity_days: int = 365
    key_size: int = 2048
