from pydantic import BaseModel, field_validator
from typing import Optional
import ipaddress


class NAPINetworkConfig(BaseModel):
    """Configuration for a single network in NAPI."""
    vlan_id: int
    ip_address: str
    enabled: bool = True

    @field_validator("ip_address")
    @classmethod
    def validate_ip(cls, v: str) -> str:
        try:
            ipaddress.ip_address(v)
        except ValueError:
            raise ValueError(f"Invalid IP address: {v}")
        return v


class NAPIConfig(BaseModel):
    """NAPI service configuration."""
    auto_start: bool = True
    networks: list[NAPINetworkConfig] = []
    default_wol_port: int = 9
    ping_timeout: float = 1.0
    ping_workers: int = 50
    arp_timeout: float = 2.0
    dns_timeout: float = 0.5


class NAPIConfigUpdate(BaseModel):
    """NAPI configuration update model."""
    auto_start: Optional[bool] = None
    networks: Optional[list[NAPINetworkConfig]] = None
    default_wol_port: Optional[int] = None
    ping_timeout: Optional[float] = None
    ping_workers: Optional[int] = None
    arp_timeout: Optional[float] = None
    dns_timeout: Optional[float] = None


class NAPIStatus(BaseModel):
    """NAPI service status."""
    running: bool
    version: Optional[str] = None
    connected_networks: list[str] = []
