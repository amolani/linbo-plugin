from pydantic import BaseModel
from typing import Optional


class ReverseProxyTarget(BaseModel):
    address: str
    port: int
    weight: int = 1


class ReverseProxy(BaseModel):
    name: str
    protocol: str  # http, https, ldap, ldaps, smtp, smtps, imap, imaps, pop3, pop3s
    listen_address: str
    listen_port: int
    targets: list[ReverseProxyTarget]
    certificate: str = ""
    load_balancing: str = "round-robin"
    status: bool = False


class ReverseProxyUpdate(BaseModel):
    listen_address: Optional[str] = None
    listen_port: Optional[int] = None
    targets: Optional[list[ReverseProxyTarget]] = None
    certificate: Optional[str] = None
    load_balancing: Optional[str] = None
