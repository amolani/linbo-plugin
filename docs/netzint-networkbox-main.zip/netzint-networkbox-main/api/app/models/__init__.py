from .auth import Login, TokenResponse, PasswordChange
from .common import NetworkboxResponse
from .network import Network, NetworkUpdate, ContainerNetwork
from .container import Container, ContainerNetworkInfo
from .mdns import MDNSRepeater, MDNSRepeaterUpdate, MDNSRepeaterCluster
from .radius import Radius, RadiusUpdate, RadiusGroups, RadiusCredentials
from .authentication import Authentication, AuthenticationUpdate, AuthenticationTest
from .certificate import Certificate, CertificateSource, CertificateSourceUpdate, CertificateUpload, CertificateGenerate
from .sophos import SophosXGSConnection, SophosXGSCertificate, SophosXGSNetworkVLAN
from .reverseproxy import ReverseProxy, ReverseProxyUpdate, ReverseProxyTarget
from .proxy import (
    ProxyConfig, ProxyConfigUpdate, ProxyBlockPageConfig, KerberosConfig, ParentProxyConfig,
    IPAllowConfig, AllowedIP, WebhookIPRequest, WebhookIPStatus
)
from .kms import KMSConfig, KMSConfigUpdate
from .napi import WOLRequest, WOLClientRequest, ScanRequest, PingScanResponse, ArpScanResponse, DeviceInfo
from .napi_config import NAPIConfig, NAPIConfigUpdate, NAPINetworkConfig, NAPIStatus

__all__ = [
    # Auth
    "Login", "TokenResponse", "PasswordChange",
    # Common
    "NetworkboxResponse",
    # Network
    "Network", "NetworkUpdate", "ContainerNetwork",
    # Container
    "Container", "ContainerNetworkInfo",
    # MDNS
    "MDNSRepeater", "MDNSRepeaterUpdate", "MDNSRepeaterCluster",
    # RADIUS
    "Radius", "RadiusUpdate", "RadiusGroups", "RadiusCredentials",
    # Authentication
    "Authentication", "AuthenticationUpdate", "AuthenticationTest",
    # Certificate
    "Certificate", "CertificateSource", "CertificateSourceUpdate", "CertificateUpload", "CertificateGenerate",
    # Sophos
    "SophosXGSConnection", "SophosXGSCertificate", "SophosXGSNetworkVLAN",
    # Reverse Proxy
    "ReverseProxy", "ReverseProxyUpdate", "ReverseProxyTarget",
    # Proxy
    "ProxyConfig", "ProxyConfigUpdate", "ProxyBlockPageConfig", "KerberosConfig", "ParentProxyConfig",
    "IPAllowConfig", "AllowedIP", "WebhookIPRequest", "WebhookIPStatus",
    # KMS
    "KMSConfig", "KMSConfigUpdate",
    # NAPI
    "WOLRequest", "WOLClientRequest", "ScanRequest", "PingScanResponse", "ArpScanResponse", "DeviceInfo",
    # NAPI Config
    "NAPIConfig", "NAPIConfigUpdate", "NAPINetworkConfig", "NAPIStatus",
]
