from pydantic import BaseModel
from typing import Optional
from .network import ContainerNetwork


class MDNSRepeater(BaseModel):
    name: str
    network1: ContainerNetwork
    network2: ContainerNetwork
    status: bool = False


class MDNSRepeaterUpdate(BaseModel):
    network1_address: Optional[str] = None
    network2_address: Optional[str] = None


class MDNSRepeaterClusterNode(BaseModel):
    id: str
    label: str


class MDNSRepeaterClusterLink(BaseModel):
    source: str
    target: str
    id: str
    label: str


class MDNSRepeaterCluster(BaseModel):
    nodes: list[MDNSRepeaterClusterNode]
    links: list[MDNSRepeaterClusterLink]
