from pydantic import BaseModel, field_validator
from typing import Optional
import re


class WOLRequest(BaseModel):
    mac: str
    ip: str = "255.255.255.255"
    port: int = 9

    @field_validator("mac")
    @classmethod
    def validate_mac(cls, v: str) -> str:
        mac = v.upper().replace("-", ":").replace(".", ":")
        pattern = r"^([0-9A-F]{2}:){5}[0-9A-F]{2}$"
        if not re.match(pattern, mac):
            raise ValueError("Invalid MAC address format")
        return mac


class WOLClientRequest(BaseModel):
    """WOL request from wakeonlan-networkbox client package."""
    mac_address: str
    port: int = 9

    @field_validator("mac_address")
    @classmethod
    def validate_mac(cls, v: str) -> str:
        mac = v.upper().replace("-", ":").replace(".", ":")
        pattern = r"^([0-9A-F]{2}:){5}[0-9A-F]{2}$"
        if not re.match(pattern, mac):
            raise ValueError("Invalid MAC address format")
        return mac


class ScanRequest(BaseModel):
    vlan_id: int


class DeviceInfo(BaseModel):
    ip: str
    mac: str
    hostname: Optional[str] = None
    vendor: Optional[str] = None


class PingScanResponse(BaseModel):
    subnet: str
    total_hosts: int
    reachable_count: int
    reachable: list[str]


class ArpScanResponse(BaseModel):
    subnet: str
    device_count: int
    devices: list[DeviceInfo]
