from pydantic import BaseModel
from typing import Optional


class ContainerNetworkInfo(BaseModel):
    network: str
    ip: str


class Container(BaseModel):
    id: str
    image: str
    name: str
    status: str
    labels: dict
    networks: list[ContainerNetworkInfo]
