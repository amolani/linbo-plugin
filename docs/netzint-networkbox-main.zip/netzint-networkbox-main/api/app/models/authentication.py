from pydantic import BaseModel
from typing import Optional


class Authentication(BaseModel):
    name: str
    server: str
    port: int
    use_ssl: bool
    validate_cert: bool
    binduser: str
    password: str
    basedn: str
    userfilter: str


class AuthenticationUpdate(BaseModel):
    server: Optional[str] = None
    port: Optional[int] = None
    use_ssl: Optional[bool] = None
    validate_cert: Optional[bool] = None
    binduser: Optional[str] = None
    password: Optional[str] = None
    basedn: Optional[str] = None
    userfilter: Optional[str] = None


class AuthenticationTest(BaseModel):
    """Model for testing authentication with optional password (uses stored if empty)."""
    name: Optional[str] = None  # If provided and password empty, use stored password
    server: str
    port: int
    use_ssl: bool
    validate_cert: bool
    binduser: str
    password: Optional[str] = None  # Optional - will use stored if name provided
    basedn: str
    userfilter: str
