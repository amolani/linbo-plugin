from pydantic import BaseModel


class SophosXGSConnection(BaseModel):
    username: str
    password: str
    hostname: str
    port: int


class SophosXGSCertificate(BaseModel):
    name: str
    cert_pem: str
    key_pem: str
    valid_from: str = ""
    valid_to: str = ""


class SophosXGSNetworkVLAN(BaseModel):
    name: str
    vlan_id: int
    address: str
    mask: str
