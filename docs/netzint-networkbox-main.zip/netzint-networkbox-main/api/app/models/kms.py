from pydantic import BaseModel
from typing import Optional


class KMSConfig(BaseModel):
    listen_address: str = "0.0.0.0"
    listen_port: int = 1688
    allowed_networks: list[int] = []


class KMSConfigUpdate(BaseModel):
    listen_address: Optional[str] = None
    listen_port: Optional[int] = None
    allowed_networks: Optional[list[int]] = None
