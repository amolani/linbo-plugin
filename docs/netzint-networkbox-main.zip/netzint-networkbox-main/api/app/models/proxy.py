from pydantic import BaseModel
from typing import Optional


class KerberosConfig(BaseModel):
    """Kerberos SSO configuration for the proxy."""
    enabled: bool = False
    realm: str = ""  # e.g., "AD.EXAMPLE.COM" (uppercase)
    kdc: str = ""  # IP address of Domain Controller (Key Distribution Center)
    domain_admin: str = ""  # Username for domain join
    domain_admin_password: str = ""  # Password for domain join
    proxy_hostname: str = ""  # FQDN for SPN, e.g., "proxy.ad.example.com"
    # Ticket lifetime settings
    ticket_lifetime: str = "24h"  # How long a ticket is valid (e.g., "24h", "1d", "8h")
    renew_lifetime: str = "7d"  # How long a ticket can be renewed (e.g., "7d", "30d")


class ParentProxyConfig(BaseModel):
    """Parent/upstream proxy configuration (e.g., Sophos XGS)."""
    enabled: bool = False
    host: str = ""  # Parent proxy hostname or IP
    port: int = 8080  # Parent proxy port
    # Authentication forwarding options
    forward_auth: str = "none"  # "none", "basic", "header"
    # For header mode: send X-Authenticated-User header
    auth_header_name: str = "X-Authenticated-User"
    # For basic auth mode: credentials for parent proxy (if parent requires auth)
    username: str = ""
    password: str = ""


class AllowedIP(BaseModel):
    """A single allowed or blocked IP address."""
    ip: str  # IP address
    description: str = ""  # Optional description/hostname
    added_at: str = ""  # ISO timestamp when added
    added_by: str = ""  # Source: "webhook" or "manual"


class IPAllowConfig(BaseModel):
    """IP-based allow/block configuration."""
    api_key: str = ""  # API key for webhook access
    allowed_ips: list[AllowedIP] = []  # Allowed IP addresses
    blocked_ips: list[AllowedIP] = []  # Explicitly blocked IP addresses


class ProxyBlockPageConfig(BaseModel):
    """Configuration for the proxy block page styling."""
    title: str = "Zugriff nicht erlaubt"
    message: str = "Ihr Gerät ist nicht für den Internetzugang freigeschaltet."
    logo_url: Optional[str] = None
    # Light theme defaults
    background_color: str = "#f5f7fa"
    card_background_color: str = "#ffffff"
    title_color: str = "#1f2937"
    text_color: str = "#6b7280"
    accent_color: str = "#dc2626"  # For icon/accent elements
    show_url: bool = True
    show_ip: bool = True  # Show client IP
    show_time: bool = True
    animation_enabled: bool = True  # Enable pulse animation


class ProxyConfig(BaseModel):
    listen_address: str = "0.0.0.0"
    listen_port: int = 3128
    # Authentication mode: "ldap", "kerberos", "ip_allow"
    auth_mode: str = "ldap"
    authentication: str = ""  # LDAP authentication provider name (for ldap/kerberos modes)
    allowed_groups: list[str] = []  # LDAP groups allowed (for ldap/kerberos modes)
    # IP-based allow/block configuration (for ip_allow mode)
    ip_allow: IPAllowConfig = IPAllowConfig()
    # Whitelist/Blacklist (only applies to ldap/kerberos modes)
    whitelist_domains: list[str] = []
    blacklist_domains: list[str] = []
    bypass_groups: list[str] = []  # Groups that can bypass blacklist
    # Block page configuration
    block_page: ProxyBlockPageConfig = ProxyBlockPageConfig()
    # WPAD/PAC configuration
    proxy_hostname: str = ""  # Hostname or IP clients use to reach the proxy
    pac_direct_domains: list[str] = []  # Domains that should bypass the proxy (DIRECT)
    pac_direct_networks: list[str] = []  # Networks that should bypass the proxy (e.g., "10.0.0.0/8")
    # Kerberos SSO configuration (for kerberos mode)
    kerberos: KerberosConfig = KerberosConfig()
    # Parent proxy configuration
    parent_proxy: ParentProxyConfig = ParentProxyConfig()


class ProxyConfigUpdate(BaseModel):
    listen_address: Optional[str] = None
    listen_port: Optional[int] = None
    auth_mode: Optional[str] = None
    authentication: Optional[str] = None
    allowed_groups: Optional[list[str]] = None
    ip_allow: Optional[IPAllowConfig] = None
    whitelist_domains: Optional[list[str]] = None
    blacklist_domains: Optional[list[str]] = None
    bypass_groups: Optional[list[str]] = None
    block_page: Optional[ProxyBlockPageConfig] = None
    proxy_hostname: Optional[str] = None
    pac_direct_domains: Optional[list[str]] = None
    pac_direct_networks: Optional[list[str]] = None
    kerberos: Optional[KerberosConfig] = None
    parent_proxy: Optional[ParentProxyConfig] = None


class WebhookIPRequest(BaseModel):
    """Request model for webhook IP operations."""
    ip: str
    description: str = ""


class WebhookIPStatus(BaseModel):
    """Response model for webhook IP status check."""
    ip: str
    allowed: bool
    blocked: bool
