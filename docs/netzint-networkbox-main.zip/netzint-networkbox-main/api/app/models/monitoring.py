from pydantic import BaseModel, field_validator
from typing import Optional
from datetime import datetime
from enum import Enum
import ipaddress


class SNMPVersion(str, Enum):
    V2C = "v2c"
    V3 = "v3"


class SNMPConfig(BaseModel):
    """SNMP configuration for a switch."""
    version: SNMPVersion = SNMPVersion.V2C
    community: str = "public"  # v2c
    # v3 options
    username: str = ""
    auth_protocol: str = "SHA"  # MD5, SHA, SHA256
    auth_password: str = ""
    priv_protocol: str = "AES"  # DES, AES, AES256
    priv_password: str = ""


class UniFiConfig(BaseModel):
    """UniFi Controller connection configuration (Classic Controller)."""
    enabled: bool = False
    controller_url: str = ""  # https://unifi.example.com:8443
    username: str = ""
    password: str = ""
    site: str = "default"
    verify_ssl: bool = False


class MonitoredSwitch(BaseModel):
    """A switch being monitored."""
    name: str
    ip_address: str
    snmp_config: SNMPConfig = SNMPConfig()
    # UniFi metadata (if discovered)
    unifi_device_id: Optional[str] = None
    unifi_mac: Optional[str] = None
    model: str = ""
    # Port info
    port_count: int = 0
    uplink_ports: list[int] = []
    enabled: bool = True
    # Position for topology (optional)
    position_x: Optional[float] = None
    position_y: Optional[float] = None

    @field_validator("ip_address")
    @classmethod
    def validate_ip(cls, v: str) -> str:
        ipaddress.ip_address(v)
        return v


class MonitoredSwitchUpdate(BaseModel):
    """Update model for a monitored switch."""
    name: Optional[str] = None
    ip_address: Optional[str] = None
    snmp_config: Optional[SNMPConfig] = None
    model: Optional[str] = None
    port_count: Optional[int] = None
    uplink_ports: Optional[list[int]] = None
    enabled: Optional[bool] = None
    position_x: Optional[float] = None
    position_y: Optional[float] = None


class SwitchPort(BaseModel):
    """Port information from a switch."""
    switch_name: str
    port_number: int
    if_index: int
    name: str = ""  # ifName/ifDescr
    alias: str = ""  # ifAlias
    vlan_id: int = 0
    is_uplink: bool = False
    speed_mbps: int = 0
    admin_status: str = "up"
    oper_status: str = "up"


class SwitchConnection(BaseModel):
    """A connection between two switches (for topology)."""
    from_switch: str
    from_port: int
    to_switch: str
    to_port: int
    discovered_via: str = "manual"  # manual, lldp, cdp


class MonitoringConfig(BaseModel):
    """Global monitoring configuration."""
    enabled: bool = False
    poll_interval_seconds: int = 30
    mac_table_interval_seconds: int = 60
    # Alerting
    alert_email: str = ""
    alert_webhook_url: str = ""
    # UniFi integration
    unifi: UniFiConfig = UniFiConfig()
    # Detection thresholds
    mac_flap_threshold: int = 4  # Moves in 60s to trigger
    mac_flap_window_seconds: int = 60
    stp_tc_threshold: int = 5    # Topology changes in 5min
    discard_rate_threshold: float = 1.0  # % of packets
    # Incident scoring thresholds
    warning_score: int = 40
    critical_score: int = 70


class MonitoringConfigUpdate(BaseModel):
    """Update model for monitoring configuration."""
    enabled: Optional[bool] = None
    poll_interval_seconds: Optional[int] = None
    mac_table_interval_seconds: Optional[int] = None
    alert_email: Optional[str] = None
    alert_webhook_url: Optional[str] = None
    unifi: Optional[UniFiConfig] = None
    mac_flap_threshold: Optional[int] = None
    mac_flap_window_seconds: Optional[int] = None
    stp_tc_threshold: Optional[int] = None
    discard_rate_threshold: Optional[float] = None
    warning_score: Optional[int] = None
    critical_score: Optional[int] = None


class MACEntry(BaseModel):
    """A single MAC address observation."""
    mac: str
    switch_name: str
    port: int
    vlan_id: int = 0
    timestamp: datetime


class MACMoveEvent(BaseModel):
    """A MAC address move event (potential loop indicator)."""
    mac: str
    from_switch: str
    from_port: int
    to_switch: str
    to_port: int
    vlan_id: int = 0
    timestamp: datetime


class IncidentSeverity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class IncidentStatus(str, Enum):
    OPEN = "open"
    INVESTIGATING = "investigating"
    RESOLVED = "resolved"


class LoopIncident(BaseModel):
    """A detected loop incident."""
    id: str
    severity: IncidentSeverity = IncidentSeverity.WARNING
    score: int = 0
    status: IncidentStatus = IncidentStatus.OPEN
    detected_at: datetime
    resolved_at: Optional[datetime] = None
    # Location
    switch_name: str
    suspected_ports: list[int] = []
    # Evidence
    mac_moves_count: int = 0
    top_flapping_macs: list[str] = []
    stp_topology_changes: int = 0
    discard_rate: float = 0.0
    # Description
    summary: str = ""
    details: str = ""


class LoopIncidentUpdate(BaseModel):
    """Update model for a loop incident."""
    status: Optional[IncidentStatus] = None
    resolved_at: Optional[datetime] = None


class SwitchMetrics(BaseModel):
    """Current metrics for a switch."""
    switch_name: str
    timestamp: datetime
    # STP
    stp_topology_changes: int = 0
    stp_time_since_tc: int = 0
    # Interface counters (aggregated)
    total_in_octets: int = 0
    total_out_octets: int = 0
    total_in_errors: int = 0
    total_out_errors: int = 0
    total_in_discards: int = 0
    total_out_discards: int = 0
    # Per-port discard rates
    port_discard_rates: dict[int, float] = {}


class MACFlappingInfo(BaseModel):
    """Information about a flapping MAC address."""
    mac: str
    move_count: int
    ports: list[tuple[str, int]]  # (switch_name, port)
    last_move: datetime


class MonitoringStatus(BaseModel):
    """Current monitoring status summary."""
    enabled: bool = False
    switches_total: int = 0
    switches_enabled: int = 0
    switches_reachable: int = 0
    open_incidents: int = 0
    critical_incidents: int = 0
    warning_incidents: int = 0
    last_poll: Optional[datetime] = None
    flapping_macs_count: int = 0
