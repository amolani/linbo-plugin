from pydantic import BaseModel
from typing import Any, Optional


class NetworkboxResponse(BaseModel):
    status: bool
    message: str
    error: str = ""
    data: Optional[Any] = None
