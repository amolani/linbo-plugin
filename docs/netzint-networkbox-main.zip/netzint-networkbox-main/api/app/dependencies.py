import hashlib
import logging
from datetime import datetime, timedelta, timezone
from typing import Annotated

from fastapi import Depends, HTTPException, Cookie, Query
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt

from app.config import settings

logger = logging.getLogger(__name__)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")


def create_token(data: dict, expires_delta: timedelta) -> str:
    """Create a JWT token with the given data and expiration."""
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + expires_delta
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def verify_token(token: Annotated[str, Depends(oauth2_scheme)]) -> dict:
    """Verify a JWT token from the Authorization header."""
    try:
        payload = jwt.decode(
            token,
            settings.jwt_secret,
            algorithms=[settings.jwt_algorithm]
        )
        return payload
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid credentials")


def verify_token_from_query(token: str | None = Query(None)) -> dict:
    """Verify a JWT token from a query parameter (for SSE endpoints)."""
    if not token:
        logger.error("SSE Auth: No token provided in query parameter")
        raise HTTPException(status_code=401, detail="No token provided")

    try:
        logger.debug(f"SSE Auth: Attempting to verify token: {token[:50]}...")
        payload = jwt.decode(
            token,
            settings.jwt_secret,
            algorithms=[settings.jwt_algorithm]
        )
        logger.debug(f"SSE Auth: Token verified successfully for user: {payload.get('sub')}")
        return payload
    except JWTError as e:
        logger.error(f"SSE Auth: Token verification failed: {e}")
        raise HTTPException(status_code=401, detail="Invalid credentials")


def verify_password(username: str, password: str) -> bool:
    """Verify username and password against configured admin credentials."""
    if username != settings.admin_username:
        return False

    password_hash = hashlib.sha256(password.encode()).hexdigest()

    # Check DB first (runtime-changed password takes precedence over env)
    from app.database import db
    db_setting = db.find_one("settings", {"key": "admin_password_hash"})
    if db_setting:
        return password_hash == db_setting["value"]

    return password_hash == settings.admin_password_hash


def create_access_token(username: str) -> str:
    """Create an access token for the given user."""
    return create_token(
        {"sub": username},
        timedelta(minutes=settings.access_token_lifetime_minutes)
    )


def create_refresh_token(username: str) -> str:
    """Create a refresh token for the given user."""
    return create_token(
        {"sub": username},
        timedelta(days=settings.refresh_token_lifetime_days)
    )
