import logging
import sys
from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.config import settings
from app.database import db
from app.routers import (
    auth, networks, interfaces, containers, napi,
    authentications, mdns, radius, certificates,
    sophos, reverseproxy, proxy, kms, monitoring
)

# Configure logging
logging.basicConfig(
    stream=sys.stdout,
    format="%(levelname)s: %(asctime)s %(message)s",
    level=logging.DEBUG if settings.debug else logging.INFO
)
logger = logging.getLogger(__name__)


def ensure_networks_exist():
    """Ensure all configured networks have their VLAN interfaces and Docker networks."""
    from app.models import Network
    from app.services.network_service import network_service
    from app.services.docker_service import docker_service

    networks_list = db.find("networks", {})
    for network_data in networks_list:
        network = Network(**network_data)
        docker_network_name = f"NETWORKBOX_{network.name}"

        # Check if Docker network exists
        docker_network = docker_service.get_network(docker_network_name)
        if docker_network:
            continue

        logger.info(f"Recreating network {network.name} (VLAN {network.vlan_id})...")

        # Create VLAN interface if needed
        if network.vlan_id != 0:
            network_service.create_vlan_interface(network.parent, network.vlan_id)

        # Create macvlan network
        if network_service.create_macvlan_network(
            name=network.name,
            parent=network.parent,
            vlan_id=network.vlan_id,
            address=network.address,
            mask=network.mask
        ):
            logger.info(f"  -> Network {network.name} recreated successfully")
        else:
            logger.error(f"  -> Failed to recreate network {network.name}")


def connect_napi_to_networks():
    """Connect NAPI container to all configured networks."""
    from app.models import Network
    from app.services.docker_service import docker_service

    napi_container = docker_service.get_container("networkbox-napi")
    if not napi_container:
        logger.warning("NAPI container not found, skipping network connections")
        return

    # Get all networks with an IP address configured
    networks_list = db.find("networks", {})
    for network_data in networks_list:
        network = Network(**network_data)
        if not network.ip_address:
            continue

        docker_network_name = f"NETWORKBOX_{network.name}"

        # Check if Docker network exists
        docker_network = docker_service.get_network(docker_network_name)
        if not docker_network:
            logger.warning(f"Docker network {docker_network_name} not found, skipping")
            continue

        # Check if already connected
        napi_container.reload()
        connected_networks = napi_container.attrs.get("NetworkSettings", {}).get("Networks", {})
        if docker_network_name in connected_networks:
            logger.debug(f"NAPI already connected to {docker_network_name}")
            continue

        # Connect to network
        try:
            docker_service.connect_container_to_network(
                napi_container,
                docker_network_name,
                ipv4_address=network.ip_address
            )
            logger.info(f"Connected NAPI to {network.name} (VLAN {network.vlan_id}) with IP {network.ip_address}")
        except Exception as e:
            logger.error(f"Failed to connect NAPI to {network.name}: {e}")


def start_active_containers():
    """Start all containers that were marked as active."""
    from app.models import MDNSRepeater, Radius, Authentication, Network
    from app.routers.mdns import start_mdns_container_internal
    from app.routers.radius import start_radius_container_internal

    # Start MDNS repeaters
    active_mdns = db.find("mdns_repeater", {"status": True})
    for mdns_data in active_mdns:
        mdns = MDNSRepeater(**mdns_data)
        logger.info(f"Starting MDNS container: {mdns.name}")

        network1 = db.find_one("networks", {"vlan_id": mdns.network1.vlan_id})
        network2 = db.find_one("networks", {"vlan_id": mdns.network2.vlan_id})

        if not network1 or not network2:
            logger.error(f"  -> Networks not found, skipping")
            continue

        if start_mdns_container_internal(mdns, network1, network2):
            logger.info(f"  -> Success")
        else:
            logger.error(f"  -> Failed")

    # Start RADIUS servers
    active_radius = db.find("radius", {"status": True})
    for radius_data in active_radius:
        radius_obj = Radius(**radius_data)
        logger.info(f"Starting RADIUS container: {radius_obj.name}")

        network = db.find_one("networks", {"vlan_id": radius_obj.network.vlan_id})
        if not network:
            logger.error(f"  -> Network not found, skipping")
            continue

        auth = db.find_one("authentications", {"name": radius_obj.authentication})
        if not auth:
            logger.error(f"  -> Authentication not found, skipping")
            continue

        if start_radius_container_internal(radius_obj, network, auth):
            logger.info(f"  -> Success")
        else:
            logger.error(f"  -> Failed")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    from app.services.certificate_scheduler import certificate_scheduler

    print("#" * 75, flush=True)
    print("Welcome to Netzint Network-Box!", flush=True)
    print("#" * 75, flush=True)
    print("", flush=True)

    # Ensure all configured networks exist
    print("Checking configured networks...", flush=True)
    ensure_networks_exist()
    print("", flush=True)

    # Connect NAPI to all configured networks
    print("Connecting NAPI to configured networks...", flush=True)
    connect_napi_to_networks()
    print("", flush=True)

    # Start active containers
    logger.info("(Re-)Starting all active containers...")
    start_active_containers()
    logger.info("")

    # Start certificate scheduler
    logger.info("Starting certificate scheduler...")
    await certificate_scheduler.start()
    logger.info("")

    logger.info(f"Starting {settings.app_name} v{settings.app_version}")
    yield
    logger.info("Shutting down NetworkBox API")

    # Stop certificate scheduler
    await certificate_scheduler.stop()


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="NetworkBox API - Network Management Platform",
    lifespan=lifespan
)

# Include routers
app.include_router(auth.router)
app.include_router(networks.router)
app.include_router(interfaces.router)
app.include_router(containers.router)
app.include_router(napi.router)
app.include_router(napi.ws_router)
app.include_router(authentications.router)
app.include_router(mdns.router)
app.include_router(mdns.stream_router)
app.include_router(radius.router)
app.include_router(radius.stream_router)
app.include_router(certificates.router)
app.include_router(sophos.router)
app.include_router(reverseproxy.router)
app.include_router(proxy.router)
app.include_router(proxy.stream_router)
app.include_router(proxy.public_router)
app.include_router(proxy.webhook_router)
app.include_router(kms.router)
app.include_router(kms.stream_router)
app.include_router(monitoring.router)


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "name": settings.app_name,
        "version": settings.app_version,
        "status": "running"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, access_log=False)
