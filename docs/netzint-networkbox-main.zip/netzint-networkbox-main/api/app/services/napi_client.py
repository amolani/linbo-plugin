import logging
import httpx
from typing import Optional

from app.config import settings
from app.models.napi import DeviceInfo

logger = logging.getLogger(__name__)


class NAPIClient:
    """HTTP client for communicating with the NAPI service."""

    def __init__(self):
        self.base_url = settings.napi_url
        self.timeout = settings.napi_timeout

    async def health_check(self) -> bool:
        """Check if NAPI is healthy."""
        try:
            logger.debug(f"NAPI health check URL: {self.base_url}/health")
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(f"{self.base_url}/health")
                return response.status_code == 200
        except Exception as e:
            logger.warning(f"NAPI health check failed (URL: {self.base_url}): {e}")
            return False

    async def wake_on_lan(
        self,
        mac: str,
        ip: str = "255.255.255.255",
        port: int = 9
    ) -> dict:
        """Send a Wake-on-LAN packet via NAPI."""
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/wake",
                    json={"mac": mac, "ip": ip, "port": port}
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"NAPI WOL request failed: {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"NAPI WOL request failed: {e}")
            raise

    async def ping_scan(self, subnet: str) -> dict:
        """Perform a ping scan on a subnet via NAPI."""
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:  # Longer timeout for scans
                response = await client.post(
                    f"{self.base_url}/scan/ping",
                    json={"subnet": subnet}
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"NAPI ping scan failed: {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"NAPI ping scan failed: {e}")
            raise

    async def arp_scan(self, subnet: str) -> dict:
        """Perform an ARP scan on a subnet via NAPI."""
        try:
            async with httpx.AsyncClient(timeout=120.0) as client:
                response = await client.post(
                    f"{self.base_url}/scan/arp",
                    json={"subnet": subnet}
                )
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"NAPI ARP scan failed: {e.response.text}")
            raise
        except Exception as e:
            logger.error(f"NAPI ARP scan failed: {e}")
            raise

    async def get_interfaces(self) -> list:
        """Get available network interfaces from NAPI."""
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(f"{self.base_url}/tcpdump/interfaces")
                response.raise_for_status()
                return response.json()
        except Exception as e:
            logger.error(f"NAPI get interfaces failed: {e}")
            raise

    async def tcpdump_capture(
        self,
        interface: str = "any",
        filter: str = "",
        count: int = 10,
        timeout: int = 5
    ) -> dict:
        """Capture packets via NAPI tcpdump."""
        try:
            params = {
                "interface": interface,
                "filter": filter,
                "count": count,
                "timeout": timeout
            }
            async with httpx.AsyncClient(timeout=float(timeout + 5)) as client:
                response = await client.post(
                    f"{self.base_url}/tcpdump/capture",
                    params=params
                )
                response.raise_for_status()
                return response.json()
        except Exception as e:
            logger.error(f"NAPI tcpdump capture failed: {e}")
            raise

    def get_websocket_url(self, interface: str, filter: str, count: int) -> str:
        """Get the WebSocket URL for live tcpdump."""
        params = f"interface={interface}&filter={filter}&count={count}"
        # Replace http with ws in base URL
        ws_url = self.base_url.replace("http://", "ws://").replace("https://", "wss://")
        return f"{ws_url}/tcpdump/live?{params}"


# Singleton instance
napi_client = NAPIClient()
