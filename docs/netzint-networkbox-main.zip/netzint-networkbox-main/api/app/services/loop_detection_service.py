"""
Loop Detection Service for Network Monitoring.

Analyzes MAC address movements and STP changes to detect Layer-2 loops.
Implements a scoring system to determine loop probability.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional
from collections import defaultdict
import uuid

from app.models.monitoring import (
    MACEntry, MACMoveEvent, LoopIncident, IncidentSeverity,
    IncidentStatus, SwitchMetrics, MACFlappingInfo, MonitoringConfig
)

logger = logging.getLogger(__name__)


class LoopDetectionService:
    """
    Service for detecting Layer-2 loops based on MAC flapping and STP changes.

    Detection signals:
    - MAC address moves between ports/switches
    - High frequency of MAC moves (flapping)
    - STP topology changes
    - Interface discard rate increases
    """

    def __init__(self):
        # In-memory state for MAC tracking
        # mac -> MACEntry (last known location)
        self._mac_state: dict[str, MACEntry] = {}

        # Recent MAC moves for flapping detection
        # mac -> list of MACMoveEvent (within window)
        self._mac_moves: dict[str, list[MACMoveEvent]] = defaultdict(list)

        # Current metrics per switch
        self._switch_metrics: dict[str, SwitchMetrics] = {}

        # Active incidents
        self._incidents: dict[str, LoopIncident] = {}

        # Configuration (will be loaded from DB)
        self._config: Optional[MonitoringConfig] = None

    def set_config(self, config: MonitoringConfig):
        """Update the monitoring configuration."""
        self._config = config

    def get_config(self) -> MonitoringConfig:
        """Get current config or default."""
        if self._config is None:
            self._config = MonitoringConfig()
        return self._config

    def process_mac_table(
        self,
        switch_name: str,
        mac_entries: list[dict],
        timestamp: datetime
    ) -> list[MACMoveEvent]:
        """
        Process a MAC table update from a switch.

        Args:
            switch_name: Name of the switch
            mac_entries: List of MAC entries from SNMP poll
            timestamp: Time of the poll

        Returns:
            List of detected MAC move events
        """
        moves = []

        for entry in mac_entries:
            mac = entry.get("mac", "").upper()
            port = entry.get("port", 0)
            vlan = entry.get("vlan", 0)

            if not mac or port == 0:
                continue

            # Create current entry
            current = MACEntry(
                mac=mac,
                switch_name=switch_name,
                port=port,
                vlan_id=vlan,
                timestamp=timestamp
            )

            # Check for move
            if mac in self._mac_state:
                prev = self._mac_state[mac]

                # Detect move (different switch OR different port on same switch)
                if prev.switch_name != switch_name or prev.port != port:
                    move = MACMoveEvent(
                        mac=mac,
                        from_switch=prev.switch_name,
                        from_port=prev.port,
                        to_switch=switch_name,
                        to_port=port,
                        vlan_id=vlan,
                        timestamp=timestamp
                    )
                    moves.append(move)

                    # Track for flapping detection
                    self._mac_moves[mac].append(move)
                    self._cleanup_old_moves(mac)

                    logger.debug(
                        f"MAC move detected: {mac} "
                        f"{prev.switch_name}:{prev.port} -> {switch_name}:{port}"
                    )

            # Update state
            self._mac_state[mac] = current

        return moves

    def _cleanup_old_moves(self, mac: str):
        """Remove MAC moves outside the detection window."""
        config = self.get_config()
        window = timedelta(seconds=config.mac_flap_window_seconds)
        cutoff = datetime.now() - window

        self._mac_moves[mac] = [
            m for m in self._mac_moves[mac]
            if m.timestamp > cutoff
        ]

    def update_switch_metrics(
        self,
        switch_name: str,
        snmp_data: dict,
        timestamp: datetime
    ):
        """
        Update metrics for a switch from SNMP poll data.

        Args:
            switch_name: Name of the switch
            snmp_data: Data from SNMP poll (stp_status, interface_counters)
            timestamp: Time of the poll
        """
        stp = snmp_data.get("stp_status", {})
        interfaces = snmp_data.get("interfaces", [])

        # Calculate aggregated counters
        total_in_octets = 0
        total_out_octets = 0
        total_in_errors = 0
        total_out_errors = 0
        total_in_discards = 0
        total_out_discards = 0
        port_discard_rates: dict[int, float] = {}

        for iface in interfaces:
            total_in_octets += iface.get("in_octets", 0)
            total_out_octets += iface.get("out_octets", 0)
            total_in_errors += iface.get("in_errors", 0)
            total_out_errors += iface.get("out_errors", 0)
            total_in_discards += iface.get("in_discards", 0)
            total_out_discards += iface.get("out_discards", 0)

            # Calculate discard rate per port
            if_index = iface.get("if_index", 0)
            total_packets = (
                iface.get("in_octets", 0) + iface.get("out_octets", 0)
            )
            total_discards = (
                iface.get("in_discards", 0) + iface.get("out_discards", 0)
            )
            if total_packets > 0:
                port_discard_rates[if_index] = (total_discards / total_packets) * 100

        metrics = SwitchMetrics(
            switch_name=switch_name,
            timestamp=timestamp,
            stp_topology_changes=stp.get("topology_changes", 0),
            stp_time_since_tc=stp.get("time_since_topology_change", 0),
            total_in_octets=total_in_octets,
            total_out_octets=total_out_octets,
            total_in_errors=total_in_errors,
            total_out_errors=total_out_errors,
            total_in_discards=total_in_discards,
            total_out_discards=total_out_discards,
            port_discard_rates=port_discard_rates
        )

        self._switch_metrics[switch_name] = metrics

    def get_flapping_macs(self) -> list[MACFlappingInfo]:
        """
        Get list of currently flapping MAC addresses.

        Returns:
            List of MACFlappingInfo for MACs exceeding flap threshold
        """
        config = self.get_config()
        threshold = config.mac_flap_threshold
        flapping = []

        # Cleanup old moves first
        for mac in list(self._mac_moves.keys()):
            self._cleanup_old_moves(mac)

        for mac, moves in self._mac_moves.items():
            if len(moves) >= threshold:
                # Collect unique ports
                ports: list[tuple[str, int]] = []
                seen = set()
                for move in moves:
                    key_from = (move.from_switch, move.from_port)
                    key_to = (move.to_switch, move.to_port)
                    if key_from not in seen:
                        ports.append(key_from)
                        seen.add(key_from)
                    if key_to not in seen:
                        ports.append(key_to)
                        seen.add(key_to)

                flapping.append(MACFlappingInfo(
                    mac=mac,
                    move_count=len(moves),
                    ports=ports,
                    last_move=moves[-1].timestamp
                ))

        return sorted(flapping, key=lambda x: x.move_count, reverse=True)

    def calculate_loop_score(self, switch_name: str) -> tuple[int, dict]:
        """
        Calculate loop probability score for a switch.

        Returns:
            Tuple of (score, details dict with breakdown)
        """
        score = 0
        details = {
            "mac_moves_score": 0,
            "flapping_macs_score": 0,
            "bidirectional_score": 0,
            "stp_score": 0,
            "discard_score": 0
        }
        config = self.get_config()

        # Count MAC moves involving this switch
        mac_move_count = 0
        flapping_macs_on_switch = 0
        bidirectional_pairs = set()

        for mac, moves in self._mac_moves.items():
            switch_moves = [
                m for m in moves
                if m.from_switch == switch_name or m.to_switch == switch_name
            ]
            mac_move_count += len(switch_moves)

            if len(switch_moves) >= config.mac_flap_threshold:
                flapping_macs_on_switch += 1

            # Check for bidirectional flapping (A↔B)
            for move in switch_moves:
                pair = tuple(sorted([
                    (move.from_switch, move.from_port),
                    (move.to_switch, move.to_port)
                ], key=str))
                bidirectional_pairs.add(pair)

        # MAC moves scoring
        if mac_move_count >= 20:
            details["mac_moves_score"] = 40
        elif mac_move_count >= 10:
            details["mac_moves_score"] = 25
        elif mac_move_count >= 5:
            details["mac_moves_score"] = 10
        score += details["mac_moves_score"]

        # Flapping MACs scoring
        if flapping_macs_on_switch >= 5:
            details["flapping_macs_score"] = 10
        score += details["flapping_macs_score"]

        # Bidirectional flapping scoring
        if len(bidirectional_pairs) >= 2:
            details["bidirectional_score"] = 25
        elif len(bidirectional_pairs) >= 1:
            details["bidirectional_score"] = 15
        score += details["bidirectional_score"]

        # STP topology changes scoring
        metrics = self._switch_metrics.get(switch_name)
        if metrics:
            if metrics.stp_topology_changes >= config.stp_tc_threshold * 2:
                details["stp_score"] = 20
            elif metrics.stp_topology_changes >= config.stp_tc_threshold:
                details["stp_score"] = 10
            score += details["stp_score"]

            # Discard rate scoring
            high_discard_ports = sum(
                1 for rate in metrics.port_discard_rates.values()
                if rate >= config.discard_rate_threshold
            )
            if high_discard_ports >= 3:
                details["discard_score"] = 10
            score += details["discard_score"]

        return min(score, 100), details

    def analyze_and_create_incidents(self) -> list[LoopIncident]:
        """
        Analyze current state and create/update incidents.

        Returns:
            List of new or updated incidents
        """
        config = self.get_config()
        new_incidents = []

        # Get all switches with activity
        switches_with_activity = set()
        for mac, moves in self._mac_moves.items():
            for move in moves:
                switches_with_activity.add(move.from_switch)
                switches_with_activity.add(move.to_switch)

        for switch_name in switches_with_activity:
            score, details = self.calculate_loop_score(switch_name)

            # Determine severity
            if score >= config.critical_score:
                severity = IncidentSeverity.CRITICAL
            elif score >= config.warning_score:
                severity = IncidentSeverity.WARNING
            else:
                # Below threshold, no incident
                continue

            # Check for existing open incident for this switch
            existing = None
            for incident in self._incidents.values():
                if (incident.switch_name == switch_name and
                    incident.status != IncidentStatus.RESOLVED):
                    existing = incident
                    break

            if existing:
                # Update existing incident
                existing.score = score
                existing.severity = severity
                existing.mac_moves_count = sum(
                    len([m for m in moves if m.from_switch == switch_name or m.to_switch == switch_name])
                    for moves in self._mac_moves.values()
                )
                existing.top_flapping_macs = [
                    info.mac for info in self.get_flapping_macs()[:5]
                    if any(p[0] == switch_name for p in info.ports)
                ]

                # Update suspected ports
                suspected_ports = set()
                for info in self.get_flapping_macs():
                    for sw, port in info.ports:
                        if sw == switch_name:
                            suspected_ports.add(port)
                existing.suspected_ports = list(suspected_ports)[:10]

                metrics = self._switch_metrics.get(switch_name)
                if metrics:
                    existing.stp_topology_changes = metrics.stp_topology_changes
                    high_discard_ports = [
                        port for port, rate in metrics.port_discard_rates.items()
                        if rate >= config.discard_rate_threshold
                    ]
                    if high_discard_ports:
                        existing.discard_rate = max(
                            metrics.port_discard_rates.get(p, 0)
                            for p in high_discard_ports
                        )

                new_incidents.append(existing)
            else:
                # Create new incident
                incident_id = str(uuid.uuid4())[:8]

                # Gather evidence
                mac_moves_count = sum(
                    len([m for m in moves if m.from_switch == switch_name or m.to_switch == switch_name])
                    for moves in self._mac_moves.values()
                )

                top_flapping = [
                    info.mac for info in self.get_flapping_macs()[:5]
                    if any(p[0] == switch_name for p in info.ports)
                ]

                suspected_ports = set()
                for info in self.get_flapping_macs():
                    for sw, port in info.ports:
                        if sw == switch_name:
                            suspected_ports.add(port)

                stp_tc = 0
                discard_rate = 0.0
                metrics = self._switch_metrics.get(switch_name)
                if metrics:
                    stp_tc = metrics.stp_topology_changes
                    if metrics.port_discard_rates:
                        discard_rate = max(metrics.port_discard_rates.values())

                # Generate summary
                summary = f"Möglicher Loop auf {switch_name} erkannt (Score: {score})"
                details_text = (
                    f"MAC-Bewegungen: {mac_moves_count}, "
                    f"Flapping MACs: {len(top_flapping)}, "
                    f"STP Topology Changes: {stp_tc}"
                )

                incident = LoopIncident(
                    id=incident_id,
                    severity=severity,
                    score=score,
                    status=IncidentStatus.OPEN,
                    detected_at=datetime.now(),
                    switch_name=switch_name,
                    suspected_ports=list(suspected_ports)[:10],
                    mac_moves_count=mac_moves_count,
                    top_flapping_macs=top_flapping,
                    stp_topology_changes=stp_tc,
                    discard_rate=discard_rate,
                    summary=summary,
                    details=details_text
                )

                self._incidents[incident_id] = incident
                new_incidents.append(incident)

                logger.warning(
                    f"New loop incident created: {incident_id} on {switch_name} "
                    f"(score={score}, severity={severity.value})"
                )

        return new_incidents

    def get_incidents(
        self,
        status: Optional[IncidentStatus] = None,
        switch_name: Optional[str] = None
    ) -> list[LoopIncident]:
        """
        Get incidents with optional filtering.

        Args:
            status: Filter by status (None for all)
            switch_name: Filter by switch (None for all)

        Returns:
            List of matching incidents
        """
        incidents = list(self._incidents.values())

        if status:
            incidents = [i for i in incidents if i.status == status]

        if switch_name:
            incidents = [i for i in incidents if i.switch_name == switch_name]

        return sorted(incidents, key=lambda x: x.detected_at, reverse=True)

    def update_incident(
        self,
        incident_id: str,
        status: Optional[IncidentStatus] = None,
        resolved_at: Optional[datetime] = None
    ) -> Optional[LoopIncident]:
        """
        Update an incident's status.

        Args:
            incident_id: ID of the incident
            status: New status (optional)
            resolved_at: Resolution time (optional)

        Returns:
            Updated incident or None if not found
        """
        incident = self._incidents.get(incident_id)
        if not incident:
            return None

        if status:
            incident.status = status

        if resolved_at:
            incident.resolved_at = resolved_at
        elif status == IncidentStatus.RESOLVED and not incident.resolved_at:
            incident.resolved_at = datetime.now()

        return incident

    def get_switch_metrics(self, switch_name: str) -> Optional[SwitchMetrics]:
        """Get current metrics for a switch."""
        return self._switch_metrics.get(switch_name)

    def get_all_metrics(self) -> dict[str, SwitchMetrics]:
        """Get metrics for all switches."""
        return dict(self._switch_metrics)

    def clear_mac_state(self):
        """Clear all MAC tracking state (for testing or reset)."""
        self._mac_state.clear()
        self._mac_moves.clear()

    def clear_incidents(self, resolved_only: bool = True):
        """
        Clear incidents.

        Args:
            resolved_only: If True, only clear resolved incidents
        """
        if resolved_only:
            self._incidents = {
                k: v for k, v in self._incidents.items()
                if v.status != IncidentStatus.RESOLVED
            }
        else:
            self._incidents.clear()

    def get_mac_move_history(
        self,
        mac: Optional[str] = None,
        switch_name: Optional[str] = None,
        limit: int = 100
    ) -> list[MACMoveEvent]:
        """
        Get MAC move history with optional filtering.

        Args:
            mac: Filter by MAC address (None for all)
            switch_name: Filter by switch (None for all)
            limit: Maximum number of events to return

        Returns:
            List of MAC move events
        """
        all_moves = []

        for m, moves in self._mac_moves.items():
            if mac and m.upper() != mac.upper():
                continue

            for move in moves:
                if switch_name:
                    if move.from_switch != switch_name and move.to_switch != switch_name:
                        continue
                all_moves.append(move)

        return sorted(all_moves, key=lambda x: x.timestamp, reverse=True)[:limit]


# Singleton instance
loop_detection_service = LoopDetectionService()
