import logging
import docker
from typing import Optional

from app.config import settings
from app.models import Container, ContainerNetworkInfo

logger = logging.getLogger(__name__)


class DockerService:
    """Service for managing Docker containers."""

    def __init__(self):
        self.client = docker.from_env()

    def list_networkbox_containers(self) -> list[Container]:
        """List all containers with the networkbox label."""
        result = []
        for container in self.client.containers.list(
            filters={"label": settings.docker_label}
        ):
            networks = []
            container_networks = container.attrs.get("NetworkSettings", {}).get("Networks", {})
            for net_name, net_info in container_networks.items():
                networks.append(ContainerNetworkInfo(
                    network=net_name,
                    ip=net_info.get("IPAddress", "")
                ))

            image_tags = container.image.tags
            image_name = image_tags[0] if image_tags else container.image.short_id

            result.append(Container(
                id=container.id,
                image=image_name,
                name=container.name,
                status=container.status,
                labels=container.labels,
                networks=networks
            ))

        return result

    def get_container(self, container_id: str):
        """Get a container by ID or name."""
        try:
            return self.client.containers.get(container_id)
        except docker.errors.NotFound:
            return None

    def get_container_logs(self, container_id: str, tail: int = 50):
        """Stream container logs."""
        container = self.get_container(container_id)
        if not container:
            return None

        for raw in container.logs(
            stream=True,
            follow=True,
            tail=tail,
            stdout=True,
            stderr=True,
            timestamps=True
        ):
            yield raw.decode("utf-8", errors="ignore").rstrip("\n")

    def pull_image(self, image: str, log_callback=None) -> bool:
        """Pull a Docker image."""
        try:
            if log_callback:
                log_callback(f"Pulling image {image}...")
            for line in self.client.api.pull(image, stream=True, decode=True):
                if log_callback and 'status' in line:
                    status = line.get('status', '')
                    progress = line.get('progress', '')
                    layer_id = line.get('id', '')
                    if progress:
                        log_callback(f"  {layer_id}: {status} {progress}")
                    elif layer_id:
                        log_callback(f"  {layer_id}: {status}")
                    elif status:
                        log_callback(f"  {status}")
            if log_callback:
                log_callback(f"Image {image} pulled successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to pull image {image}: {e}")
            if log_callback:
                log_callback(f"Failed to pull image: {e}")
            return False

    def create_container(
        self,
        image: str,
        name: str,
        environment: dict = None,
        labels: list = None,
        ports: dict = None,
        network: str = None,
        command: list = None,
        log_callback=None,
        **kwargs
    ):
        """Create and run a Docker container."""
        if labels is None:
            labels = [settings.docker_label]
        elif settings.docker_label not in labels:
            labels.append(settings.docker_label)

        if log_callback:
            log_callback(f"Creating container {name}...")

        container = self.client.containers.run(
            image,
            name=name,
            detach=True,
            environment=environment,
            labels=labels,
            ports=ports,
            network=network,
            command=command,
            **kwargs
        )

        if log_callback:
            log_callback(f"Container {name} created successfully")

        return container

    def stop_container(self, name: str, log_callback=None) -> bool:
        """Stop and remove a container by name."""
        try:
            if log_callback:
                log_callback(f"Stopping container {name}...")
            container = self.client.containers.get(name)
            container.reload()
            # Only kill if running
            if container.status == "running":
                container.kill()
            # Always try to remove
            container.remove(force=True)
            if log_callback:
                log_callback(f"Container {name} stopped and removed")
            return True
        except docker.errors.NotFound:
            logger.debug(f"Container {name} not found (already removed)")
            if log_callback:
                log_callback(f"Container {name} not found (already removed)")
            return True
        except Exception as e:
            logger.error(f"Failed to stop container {name}: {e}")
            if log_callback:
                log_callback(f"Failed to stop container: {e}")
            return False

    def container_is_running(self, name: str) -> bool:
        """Check if a container is running."""
        try:
            container = self.client.containers.get(name)
            container.reload()
            return container.status == "running"
        except docker.errors.NotFound:
            return False

    def get_network(self, name: str):
        """Get a Docker network by name."""
        try:
            return self.client.networks.get(name)
        except docker.errors.NotFound:
            return None

    def create_network(
        self,
        name: str,
        driver: str = "bridge",
        options: dict = None,
        ipam_config=None
    ):
        """Create a Docker network."""
        return self.client.networks.create(
            name=name,
            driver=driver,
            options=options,
            ipam=ipam_config
        )

    def connect_container_to_network(
        self,
        container,
        network_name: str,
        ipv4_address: str = None,
        log_callback=None
    ):
        """Connect a container to a network."""
        if log_callback:
            log_callback(f"Connecting container to network {network_name}...")
        network = self.get_network(network_name)
        if network:
            network.connect(container, ipv4_address=ipv4_address)
            if log_callback:
                log_callback(f"Container connected to {network_name} with IP {ipv4_address or 'DHCP'}")


# Singleton instance
docker_service = DockerService()
