import logging
import subprocess
import ipaddress
import docker

from app.config import settings
from app.services.docker_service import docker_service
from app.database import db

logger = logging.getLogger(__name__)


class NetworkService:
    """Service for managing VLAN and macvlan networks."""

    def create_vlan_interface(self, parent: str, vlan_id: int) -> bool:
        """Create a VLAN interface on the host."""
        if vlan_id == 0:
            return True  # No VLAN needed for untagged traffic

        interface_name = f"{parent}.{vlan_id}"

        result = subprocess.run(
            ["ip", "link", "add", "link", parent, "name", interface_name,
             "type", "vlan", "id", str(vlan_id)],
            capture_output=True
        )

        if result.returncode != 0:
            logger.error(f"Failed to create VLAN interface: {result.stderr.decode()}")
            return False

        # Bring up interfaces
        subprocess.run(["ip", "link", "set", parent, "up"], capture_output=True)
        subprocess.run(["ip", "link", "set", interface_name, "up"], capture_output=True)

        return True

    def delete_vlan_interface(self, parent: str, vlan_id: int) -> bool:
        """Delete a VLAN interface from the host."""
        if vlan_id == 0:
            return True

        interface_name = f"{parent}.{vlan_id}"

        result = subprocess.run(
            ["ip", "link", "delete", interface_name],
            capture_output=True
        )

        if result.returncode != 0:
            logger.warning(f"Failed to delete VLAN interface: {result.stderr.decode()}")
            return False

        return True

    def create_macvlan_network(
        self,
        name: str,
        parent: str,
        vlan_id: int,
        address: str,
        mask: str
    ) -> bool:
        """Create a Docker macvlan network."""
        # Calculate network from address and mask
        network = ipaddress.IPv4Network(f"{address}/{mask}", strict=False)

        # Determine parent interface
        if vlan_id == 0:
            parent_interface = parent
        else:
            parent_interface = f"{parent}.{vlan_id}"

        try:
            docker_service.create_network(
                name=f"NETWORKBOX_{name}",
                driver="macvlan",
                options={"parent": parent_interface},
                ipam_config=docker.types.IPAMConfig(
                    pool_configs=[
                        docker.types.IPAMPool(
                            subnet=str(network.network_address) + "/" + str(network.prefixlen)
                        )
                    ]
                )
            )
            return True
        except docker.errors.APIError as e:
            logger.error(f"Failed to create macvlan network: {e}")
            return False

    def delete_macvlan_network(self, name: str) -> bool:
        """Delete a Docker macvlan network."""
        try:
            network = docker_service.get_network(f"NETWORKBOX_{name}")
            if network:
                network.remove()
            return True
        except Exception as e:
            logger.error(f"Failed to delete macvlan network: {e}")
            return False

    def get_host_interfaces(self) -> list[str]:
        """Get a list of physical network interfaces on the host."""
        result = subprocess.run(["ip", "link", "show"], capture_output=True)

        if result.returncode != 0:
            return []

        import re
        output = result.stdout.decode()
        interfaces = []

        for line in output.splitlines():
            match = re.match(r'^\d+:\s+([^\s:]+):', line)
            if match:
                iface = match.group(1)
                # Filter out virtual interfaces
                if not (
                    iface.startswith("lo") or
                    iface.startswith("br-") or
                    iface.startswith("docker") or
                    iface.startswith("veth") or
                    iface.startswith("virbr") or
                    iface.startswith("wl") or
                    iface.startswith("dm") or
                    "@" in iface
                ):
                    interfaces.append(iface)

        return interfaces

    def get_network_by_vlan(self, vlan_id: int):
        """Get network configuration by VLAN ID."""
        return db.find_one("networks", {"vlan_id": vlan_id})

    def get_subnet_for_vlan(self, vlan_id: int) -> str | None:
        """Get the subnet string for a VLAN."""
        network = self.get_network_by_vlan(vlan_id)
        if not network:
            return None

        net = ipaddress.IPv4Network(
            f"{network['address']}/{network['mask']}",
            strict=False
        )
        return str(net)


# Singleton instance
network_service = NetworkService()
