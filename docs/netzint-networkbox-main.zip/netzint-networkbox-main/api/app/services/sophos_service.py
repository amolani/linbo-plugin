import re
import logging
import requests
import xmltodict
import codecs
import ipaddress
import tarfile
import io

from typing import Tuple, Any, Optional
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from datetime import timezone

from app.models import SophosXGSConnection, SophosXGSCertificate, SophosXGSNetworkVLAN

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = logging.getLogger(__name__)

CLOSE_TAG = b'</Response>'

_PEM_CERT_RE = re.compile(
    br"-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----",
    re.S
)
_PEM_KEY_RE = re.compile(
    br"-----BEGIN (?:RSA |EC |)PRIVATE KEY-----.*?-----END (?:RSA |EC |)PRIVATE KEY-----",
    re.S
)


class SophosService:
    """Service for Sophos XGS API operations."""

    def _request_api(self, request_xml: str, conn: SophosXGSConnection) -> bytes | None:
        """Make API request to Sophos XGS."""
        login_xml = f"<Login><Username>{conn.username}</Username><Password>{conn.password}</Password></Login>"
        data = {"reqxml": f"<Request>{login_xml}{request_xml}</Request>"}

        logger.debug(f"Sophos API request to {conn.hostname}:{conn.port} with XML: {data['reqxml'][:200]}")

        try:
            resp = requests.post(
                f"https://{conn.hostname}:{conn.port}/webconsole/APIController",
                data=data,
                verify=False,
                timeout=30
            )

            logger.debug(f"Sophos API response status: {resp.status_code}, content length: {len(resp.content)}")
            logger.debug(f"Sophos API response content (first 500 bytes): {resp.content[:500]}")

            if resp.status_code == 200:
                return resp.content
        except Exception as e:
            logger.error(f"Sophos API request failed: {e}")

        return None

    def _split_xml_and_archive(self, raw: bytes) -> Tuple[bytes, bytes]:
        """Split XML response and archive data."""
        raw = raw.replace(b'\x00', b'').lstrip()
        raw = raw.lstrip(codecs.BOM_UTF8)

        lt = raw.find(b'<')
        if lt == -1:
            raise ValueError("No valid XML found")
        raw = raw[lt:]

        end = raw.find(CLOSE_TAG)
        if end == -1:
            raise ValueError("No valid XML found")
        end += len(CLOSE_TAG)

        return raw[:end], raw[end:]

    def _extract_pems(self, blob: bytes) -> Tuple[Optional[str], Optional[str]]:
        """Extract certificate and key PEM from blob."""
        cert = _PEM_CERT_RE.search(blob)
        key = _PEM_KEY_RE.search(blob)
        cert_pem = cert.group(0).decode("utf-8") if cert else None
        key_pem = key.group(0).decode("utf-8") if key else None
        return cert_pem, key_pem

    def _extract_pems_from_tar(self, data: bytes) -> Tuple[Optional[str], Optional[str]]:
        """Extract certificate and key PEM from a TAR archive."""
        cert_pem = None
        key_pem = None

        try:
            # Try to open as TAR archive
            tar_stream = io.BytesIO(data)
            with tarfile.open(fileobj=tar_stream, mode='r:*') as tar:
                for member in tar.getmembers():
                    if member.isfile():
                        file_content = tar.extractfile(member)
                        if file_content:
                            content = file_content.read()
                            # Check for PEM content
                            cert_match = _PEM_CERT_RE.search(content)
                            key_match = _PEM_KEY_RE.search(content)

                            if cert_match and not cert_pem:
                                cert_pem = cert_match.group(0).decode("utf-8")
                            if key_match and not key_pem:
                                key_pem = key_match.group(0).decode("utf-8")

                            # If we found both, we can stop
                            if cert_pem and key_pem:
                                break
        except tarfile.TarError as e:
            logger.debug(f"Not a valid TAR archive: {e}")
        except Exception as e:
            logger.debug(f"Error extracting from TAR: {e}")

        return cert_pem, key_pem

    def test_connection(self, conn: SophosXGSConnection) -> Tuple[bool, str]:
        """
        Test connection to Sophos XGS and return detailed status.

        Returns:
            Tuple of (success, message)

        Note on 2FA: If the user has Two-Factor Authentication enabled,
        API access will fail. The API user should either:
        1. Have 2FA disabled, or
        2. Use a dedicated API-only admin account without 2FA
        """
        # First, test basic connectivity
        try:
            resp = requests.get(
                f"https://{conn.hostname}:{conn.port}/webconsole/APIController",
                verify=False,
                timeout=10
            )
            # API endpoint exists if we get any response
        except requests.exceptions.ConnectTimeout:
            return False, f"Connection timeout - cannot reach {conn.hostname}:{conn.port}"
        except requests.exceptions.ConnectionError as e:
            return False, f"Connection failed - {conn.hostname}:{conn.port} is not reachable"
        except Exception as e:
            return False, f"Connection error: {str(e)}"

        # Now test authentication with a simple query
        query = "<Get><AdminSettings></AdminSettings></Get>"
        raw = self._request_api(query, conn)

        if not raw:
            return False, "API request failed - check hostname and port"

        try:
            xml_part, _ = self._split_xml_and_archive(raw)
            doc = xmltodict.parse(xml_part.decode("utf-8", errors="replace"))

            login_status = doc.get("Response", {}).get("Login", {})
            status = login_status.get("status", "")

            if "Successful" in status:
                return True, "Connection successful"

            # Check for specific error messages
            if "Authentication" in status or "Invalid" in status.lower():
                return False, "Authentication failed - check username and password. Note: 2FA must be disabled for API access."

            if "OTP" in status or "two-factor" in status.lower() or "2fa" in status.lower():
                return False, "Two-Factor Authentication is enabled for this user. API access requires 2FA to be disabled."

            # Generic auth failure
            return False, f"Login failed: {status}"

        except Exception as e:
            logger.error(f"Failed to parse connection test response: {e}")
            return False, f"Failed to parse response: {str(e)}"

    def list_certificates(self, conn: SophosXGSConnection) -> list[dict]:
        """List certificates from Sophos XGS."""
        query = "<Get><Certificate></Certificate></Get>"
        raw = self._request_api(query, conn)
        if not raw:
            return []

        try:
            xml_part, _ = self._split_xml_and_archive(raw)
            doc = xmltodict.parse(xml_part.decode("utf-8", errors="replace"))

            certs = doc.get("Response", {}).get("Certificate", [])
            if isinstance(certs, dict):
                certs = [certs]

            return [{
                "name": c.get("Name"),
                "action": c.get("Action"),
                "valid_from": c.get("ValidFrom"),
                "valid_to": c.get("ValidUpto") or c.get("ValidTo"),
                "cert_file": c.get("CertificateFile"),
                "key_file": c.get("PrivateKeyFile"),
            } for c in certs]
        except Exception as e:
            logger.error(f"Failed to parse certificates: {e}")
            return []

    def get_certificate(
        self,
        conn: SophosXGSConnection,
        cert_name: str
    ) -> Tuple[Optional[SophosXGSCertificate], str]:
        """
        Get a certificate from Sophos XGS.

        Returns:
            Tuple of (certificate, error_message). If successful, error_message is empty.
        """
        # Use criteria='=' for exact match to get full certificate data including PEM
        query = f"<Get><Certificate><Filter><key name='Name' criteria='='>{cert_name}</key></Filter></Certificate></Get>"
        raw = self._request_api(query, conn)
        if not raw:
            logger.error(f"No response from Sophos API for certificate '{cert_name}'")
            return None, "No response from Sophos API"

        try:
            # Check if response is a TAR archive (starts with './' or has TAR magic)
            is_tar = raw.startswith(b'./') or raw.startswith(b'.\x00') or b'ustar' in raw[:512]

            cert_pem = None
            key_pem = None

            if is_tar:
                # Response is a TAR archive containing the certificate files
                logger.debug(f"Sophos response is a TAR archive, extracting PEMs...")
                cert_pem, key_pem = self._extract_pems_from_tar(raw)
            else:
                # Traditional XML + appended archive format
                xml_part, archive_part = self._split_xml_and_archive(raw)

                # Log the XML response for debugging
                logger.debug(f"XML response: {xml_part[:500]}")

                # Check login status
                doc = xmltodict.parse(xml_part.decode("utf-8", errors="replace"))
                login_status = doc.get("Response", {}).get("Login", {}).get("status", "")
                if "Successful" not in login_status:
                    logger.error(f"Login failed when fetching certificate: {login_status}")
                    return None, f"Authentication failed: {login_status}"

                # Check if certificate was found in the response
                cert_response = doc.get("Response", {}).get("Certificate")
                if not cert_response:
                    logger.error(f"No certificate data in response for '{cert_name}'")
                    return None, f"Certificate '{cert_name}' not found on Sophos"

                cert_pem, key_pem = self._extract_pems(archive_part)

            if not cert_pem:
                logger.error(f"No PEM certificate found for '{cert_name}'. Response size: {len(raw)} bytes")
                return None, f"Certificate '{cert_name}' found but PEM data could not be extracted"

            return SophosXGSCertificate(
                name=cert_name,
                cert_pem=cert_pem,
                key_pem=key_pem or ""
            ), ""
        except Exception as e:
            logger.error(f"Failed to get certificate '{cert_name}': {e}")
            return None, str(e)

    def list_network_vlans(
        self,
        conn: SophosXGSConnection
    ) -> Tuple[bool, Any]:
        """List VLANs from Sophos XGS."""
        query = "<Get><VLAN></VLAN></Get>"
        raw = self._request_api(query, conn)
        if not raw:
            return False, "Failed to connect to Sophos XGS"

        try:
            xml_part, _ = self._split_xml_and_archive(raw)
            doc = xmltodict.parse(xml_part.decode("utf-8", errors="replace"))

            if "Successful" not in doc.get("Response", {}).get("Login", {}).get("status", ""):
                return False, "Invalid credentials"

            result = []
            vlans = doc.get("Response", {}).get("VLAN", [])
            if isinstance(vlans, dict):
                vlans = [vlans]

            for vlan in vlans:
                if isinstance(vlan, dict):
                    ip_address = vlan.get("IPAddress")
                    netmask = vlan.get("Netmask")

                    # Convert to network address
                    if ip_address and netmask:
                        try:
                            network = ipaddress.IPv4Network(
                                f"{ip_address}/{netmask}",
                                strict=False
                            )
                            network_address = str(network.network_address)
                        except (ValueError, ipaddress.AddressValueError):
                            network_address = ip_address
                    else:
                        network_address = ip_address

                    result.append({
                        "name": vlan.get("Name"),
                        "vlan_id": vlan.get("VLANID"),
                        "address": network_address,
                        "mask": netmask
                    })

            return True, result
        except Exception as e:
            logger.error(f"Failed to list VLANs: {e}")
            return False, str(e)


# Singleton instance
sophos_service = SophosService()
