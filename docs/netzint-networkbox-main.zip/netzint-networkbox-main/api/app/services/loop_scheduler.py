"""
Loop Scheduler for Network Monitoring.

Manages periodic SNMP polling and loop detection analysis.
Uses asyncio tasks for background scheduling.
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional
import aiohttp

from app.models.monitoring import (
    MonitoringConfig, MonitoredSwitch, IncidentSeverity
)
from app.services.loop_detection_service import loop_detection_service

logger = logging.getLogger(__name__)


class LoopScheduler:
    """
    Scheduler for periodic SNMP polling and loop detection.

    Coordinates:
    - Periodic polling of all enabled switches
    - MAC table collection and analysis
    - Loop detection and incident creation
    - Alert triggering
    """

    def __init__(self):
        self._running = False
        self._poll_task: Optional[asyncio.Task] = None
        self._config: Optional[MonitoringConfig] = None
        self._switches: list[MonitoredSwitch] = []
        self._napi_url: str = "http://networkbox-napi:8000"
        self._last_poll: Optional[datetime] = None
        self._switch_status: dict[str, bool] = {}  # switch_name -> reachable

        # Alerting callback (set by alerting service)
        self._on_incident_callback = None

    def set_napi_url(self, url: str):
        """Set the NAPI service URL."""
        self._napi_url = url.rstrip("/")

    def set_config(self, config: MonitoringConfig):
        """Update the monitoring configuration."""
        self._config = config
        loop_detection_service.set_config(config)

    def get_config(self) -> MonitoringConfig:
        """Get current config or default."""
        if self._config is None:
            self._config = MonitoringConfig()
        return self._config

    def set_switches(self, switches: list[MonitoredSwitch]):
        """Update the list of monitored switches."""
        self._switches = switches

    def set_incident_callback(self, callback):
        """Set callback for new/updated incidents."""
        self._on_incident_callback = callback

    @property
    def is_running(self) -> bool:
        """Check if scheduler is running."""
        return self._running

    @property
    def last_poll(self) -> Optional[datetime]:
        """Get timestamp of last poll."""
        return self._last_poll

    def get_switch_status(self) -> dict[str, bool]:
        """Get reachability status for all switches."""
        return dict(self._switch_status)

    async def start(self):
        """Start the polling scheduler."""
        if self._running:
            logger.warning("Scheduler already running")
            return

        config = self.get_config()
        if not config.enabled:
            logger.info("Monitoring is disabled, not starting scheduler")
            return

        self._running = True
        self._poll_task = asyncio.create_task(self._poll_loop())
        logger.info("Loop scheduler started")

    async def stop(self):
        """Stop the polling scheduler."""
        self._running = False
        if self._poll_task:
            self._poll_task.cancel()
            try:
                await self._poll_task
            except asyncio.CancelledError:
                pass
            self._poll_task = None
        logger.info("Loop scheduler stopped")

    async def _poll_loop(self):
        """Main polling loop."""
        while self._running:
            try:
                config = self.get_config()
                if not config.enabled:
                    await asyncio.sleep(10)
                    continue

                await self._poll_all_switches()
                self._last_poll = datetime.now()

                # Run loop detection analysis
                incidents = loop_detection_service.analyze_and_create_incidents()

                # Trigger alerts for new/critical incidents
                if incidents and self._on_incident_callback:
                    for incident in incidents:
                        if incident.severity in [IncidentSeverity.WARNING, IncidentSeverity.CRITICAL]:
                            try:
                                await self._on_incident_callback(incident)
                            except Exception as e:
                                logger.error(f"Error in incident callback: {e}")

                # Wait for next poll interval
                await asyncio.sleep(config.poll_interval_seconds)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.exception(f"Error in poll loop: {e}")
                await asyncio.sleep(10)  # Wait before retry

    async def _poll_all_switches(self):
        """Poll all enabled switches."""
        enabled_switches = [s for s in self._switches if s.enabled]

        if not enabled_switches:
            logger.debug("No enabled switches to poll")
            return

        logger.debug(f"Polling {len(enabled_switches)} switches")

        # Poll switches concurrently
        tasks = [
            self._poll_switch(switch)
            for switch in enabled_switches
        ]

        await asyncio.gather(*tasks, return_exceptions=True)

    async def _poll_switch(self, switch: MonitoredSwitch):
        """
        Poll a single switch via NAPI.

        Args:
            switch: The switch to poll
        """
        try:
            async with aiohttp.ClientSession() as session:
                # Build SNMP target payload
                target = {
                    "ip_address": switch.ip_address,
                    "version": switch.snmp_config.version.value,
                    "community": switch.snmp_config.community,
                    "username": switch.snmp_config.username,
                    "auth_protocol": switch.snmp_config.auth_protocol,
                    "auth_password": switch.snmp_config.auth_password,
                    "priv_protocol": switch.snmp_config.priv_protocol,
                    "priv_password": switch.snmp_config.priv_password,
                    "port": 161,
                    "timeout": 2.0,
                    "retries": 2
                }

                # Call NAPI poll endpoint (gets all data at once)
                url = f"{self._napi_url}/snmp/poll"
                async with session.post(url, json=target, timeout=30) as response:
                    if response.status == 200:
                        data = await response.json()

                        if data.get("success"):
                            self._switch_status[switch.name] = True
                            timestamp = datetime.now()

                            # Process MAC table
                            mac_table = data.get("mac_table", [])
                            if mac_table:
                                loop_detection_service.process_mac_table(
                                    switch.name,
                                    mac_table,
                                    timestamp
                                )

                            # Update metrics
                            loop_detection_service.update_switch_metrics(
                                switch.name,
                                {
                                    "stp_status": data.get("stp_status", {}),
                                    "interfaces": data.get("interfaces", [])
                                },
                                timestamp
                            )

                            logger.debug(
                                f"Switch {switch.name} polled: "
                                f"{len(mac_table)} MACs, "
                                f"{len(data.get('interfaces', []))} interfaces"
                            )
                        else:
                            self._switch_status[switch.name] = False
                            logger.warning(
                                f"SNMP poll failed for {switch.name}: "
                                f"{data.get('error', 'Unknown error')}"
                            )
                    else:
                        self._switch_status[switch.name] = False
                        logger.warning(
                            f"NAPI request failed for {switch.name}: "
                            f"HTTP {response.status}"
                        )

        except asyncio.TimeoutError:
            self._switch_status[switch.name] = False
            logger.warning(f"Timeout polling switch {switch.name}")
        except aiohttp.ClientError as e:
            self._switch_status[switch.name] = False
            logger.warning(f"Connection error polling {switch.name}: {e}")
        except Exception as e:
            self._switch_status[switch.name] = False
            logger.exception(f"Error polling switch {switch.name}: {e}")

    async def poll_now(self) -> dict:
        """
        Trigger an immediate poll of all switches.

        Returns:
            Dict with poll results summary
        """
        await self._poll_all_switches()
        self._last_poll = datetime.now()

        # Run analysis
        incidents = loop_detection_service.analyze_and_create_incidents()

        # Trigger alerts
        if incidents and self._on_incident_callback:
            for incident in incidents:
                if incident.severity in [IncidentSeverity.WARNING, IncidentSeverity.CRITICAL]:
                    try:
                        await self._on_incident_callback(incident)
                    except Exception as e:
                        logger.error(f"Error in incident callback: {e}")

        # Return summary
        reachable = sum(1 for r in self._switch_status.values() if r)
        return {
            "polled": len(self._switches),
            "reachable": reachable,
            "unreachable": len(self._switch_status) - reachable,
            "new_incidents": len(incidents),
            "timestamp": self._last_poll.isoformat() if self._last_poll else None
        }

    async def test_switch_connection(self, switch: MonitoredSwitch) -> dict:
        """
        Test SNMP connection to a specific switch.

        Args:
            switch: The switch to test

        Returns:
            Dict with test results
        """
        try:
            async with aiohttp.ClientSession() as session:
                target = {
                    "ip_address": switch.ip_address,
                    "version": switch.snmp_config.version.value,
                    "community": switch.snmp_config.community,
                    "username": switch.snmp_config.username,
                    "auth_protocol": switch.snmp_config.auth_protocol,
                    "auth_password": switch.snmp_config.auth_password,
                    "priv_protocol": switch.snmp_config.priv_protocol,
                    "priv_password": switch.snmp_config.priv_password,
                    "port": 161,
                    "timeout": 2.0,
                    "retries": 2
                }

                url = f"{self._napi_url}/snmp/test"
                async with session.post(url, json=target, timeout=10) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        return {
                            "success": False,
                            "error": f"HTTP {response.status}"
                        }

        except asyncio.TimeoutError:
            return {"success": False, "error": "Connection timeout"}
        except aiohttp.ClientError as e:
            return {"success": False, "error": str(e)}
        except Exception as e:
            return {"success": False, "error": str(e)}


# Singleton instance
loop_scheduler = LoopScheduler()
