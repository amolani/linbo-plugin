import asyncio
import logging
from datetime import datetime, timezone

from cryptography import x509
from cryptography.hazmat.primitives import hashes

from app.database import db
from app.models import CertificateSource, SophosXGSConnection
from app.services.sophos_service import sophos_service

logger = logging.getLogger(__name__)


class CertificateScheduler:
    """Background scheduler for automatic certificate synchronization."""

    def __init__(self):
        self._task: asyncio.Task | None = None
        self._running = False

    async def start(self):
        """Start the certificate sync scheduler."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._scheduler_loop())
        logger.info("Certificate scheduler started")

    async def stop(self):
        """Stop the certificate sync scheduler."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        logger.info("Certificate scheduler stopped")

    async def _scheduler_loop(self):
        """Main scheduler loop that runs sync checks every minute."""
        while self._running:
            try:
                await self._check_and_sync_sources()
            except Exception as e:
                logger.error(f"Error in certificate scheduler: {e}")

            # Check every minute
            await asyncio.sleep(60)

    async def _check_and_sync_sources(self):
        """Check all sources and sync those that are due."""
        sources = list(db.find("certificate_sources", {"enabled": True}))

        for source_data in sources:
            try:
                source = CertificateSource(**source_data)

                # Skip if no certificates selected
                if not source.sophos_cert_names:
                    continue

                # Check if sync is due
                if not self._is_sync_due(source):
                    continue

                logger.info(f"Auto-syncing {len(source.sophos_cert_names)} certificate(s) from source: {source.name}")
                await self._sync_source(source)

            except Exception as e:
                logger.error(f"Error checking source {source_data.get('name', 'unknown')}: {e}")

    def _is_sync_due(self, source: CertificateSource) -> bool:
        """Check if a source is due for synchronization."""
        if not source.last_sync:
            return True

        try:
            last_sync = datetime.fromisoformat(source.last_sync.replace('Z', '+00:00'))
            now = datetime.now(timezone.utc)
            elapsed_minutes = (now - last_sync).total_seconds() / 60

            return elapsed_minutes >= source.sync_interval
        except Exception:
            return True

    async def _sync_source(self, source: CertificateSource):
        """Sync all certificates from a source."""
        xgs_conn = SophosXGSConnection(
            hostname=source.sophos_hostname,
            port=source.sophos_port,
            username=source.sophos_username,
            password=source.sophos_password
        )

        changed_certs = []

        for cert_name in source.sophos_cert_names:
            try:
                cert, error = sophos_service.get_certificate(xgs_conn, cert_name)
                if not cert:
                    logger.error(f"Failed to fetch certificate '{cert_name}' from Sophos for source {source.name}: {error}")
                    continue

                # Parse certificate for metadata
                cert_obj = x509.load_pem_x509_certificate(cert.cert_pem.encode("utf-8"))
                sha256 = cert_obj.fingerprint(hashes.SHA256()).hex()
                subject = cert_obj.subject.rfc4514_string()
                issuer = cert_obj.issuer.rfc4514_string()
                valid_from = cert_obj.not_valid_before_utc.isoformat()
                valid_to = cert_obj.not_valid_after_utc.isoformat()

                # Check if unchanged
                existing_cert = db.find_one("certificates", {"source": source.name, "name": cert_name})
                old_sha256 = existing_cert.get("sha256") if existing_cert else None

                if old_sha256 == sha256:
                    # Certificate unchanged, just update timestamp
                    db.update("certificates", {"source": source.name, "name": cert_name}, {
                        "last_updated": datetime.now(timezone.utc).isoformat()
                    })
                    logger.debug(f"Certificate '{cert_name}' unchanged for source: {source.name}")
                    continue

                # Certificate changed - store new certificate
                cert_data = {
                    "name": cert_name,
                    "source": source.name,
                    "cert_pem": cert.cert_pem,
                    "key_pem": cert.key_pem,
                    "subject": subject,
                    "issuer": issuer,
                    "valid_from": valid_from,
                    "valid_to": valid_to,
                    "sha256": sha256,
                    "last_updated": datetime.now(timezone.utc).isoformat()
                }

                db.delete("certificates", {"source": source.name, "name": cert_name})
                db.insert("certificates", cert_data)

                logger.info(f"Certificate '{cert_name}' synced successfully for source: {source.name}")

                # Track changed certificates for service restart
                if old_sha256 and old_sha256 != sha256:
                    changed_certs.append(cert_name)

            except Exception as e:
                logger.error(f"Failed to sync certificate '{cert_name}' from source {source.name}: {e}")

        # Update sync timestamp for source
        db.update("certificate_sources", {"name": source.name}, {
            "last_sync": datetime.now(timezone.utc).isoformat()
        })

        # Restart dependent services for changed certificates
        for cert_name in changed_certs:
            logger.info(f"Certificate '{cert_name}' changed for source: {source.name}, restarting dependent services...")
            await self._restart_dependent_services(cert_name)

    async def _restart_dependent_services(self, cert_name: str):
        """Restart services that depend on a certificate."""
        from app.services.docker_service import docker_service

        # Find reverse proxies using this certificate
        reverse_proxies = list(db.find("reverse_proxy", {"certificate": cert_name, "status": True}))

        for rp_data in reverse_proxies:
            try:
                container_name = f"NETWORKBOX_REVERSEPROXY_{rp_data['name'].upper()}"
                container = docker_service.get_container(container_name)
                if container:
                    logger.info(f"Restarting reverse proxy: {rp_data['name']}")
                    container.restart()
            except Exception as e:
                logger.error(f"Failed to restart reverse proxy {rp_data['name']}: {e}")


# Singleton instance
certificate_scheduler = CertificateScheduler()
