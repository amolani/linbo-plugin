"""
UniFi Controller API Service for Classic Controller (Self-hosted).

This service interfaces with the UniFi Classic Controller API to discover
switches and gather network information.
"""

import logging
import ssl
from typing import Optional
import aiohttp

from app.models.monitoring import UniFiConfig, MonitoredSwitch, SNMPConfig

logger = logging.getLogger(__name__)


class UniFiService:
    """Service for interacting with UniFi Classic Controller API."""

    def __init__(self):
        self._session: Optional[aiohttp.ClientSession] = None
        self._cookies: Optional[dict] = None

    def _get_ssl_context(self, verify_ssl: bool) -> ssl.SSLContext:
        """Create SSL context based on verification settings."""
        if verify_ssl:
            return ssl.create_default_context()
        else:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            return ctx

    async def _get_session(self, config: UniFiConfig) -> aiohttp.ClientSession:
        """Get or create aiohttp session."""
        if self._session is None or self._session.closed:
            connector = aiohttp.TCPConnector(
                ssl=self._get_ssl_context(config.verify_ssl)
            )
            self._session = aiohttp.ClientSession(connector=connector)
        return self._session

    async def _login(self, config: UniFiConfig) -> bool:
        """
        Authenticate with UniFi Classic Controller.
        Returns True if login successful.
        """
        session = await self._get_session(config)

        # Classic Controller login endpoint
        login_url = f"{config.controller_url}/api/login"

        payload = {
            "username": config.username,
            "password": config.password
        }

        try:
            async with session.post(login_url, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("meta", {}).get("rc") == "ok":
                        # Store cookies for subsequent requests
                        self._cookies = {
                            key: morsel.value
                            for key, morsel in response.cookies.items()
                        }
                        logger.info("UniFi login successful")
                        return True
                    else:
                        logger.error(f"UniFi login failed: {data.get('meta', {}).get('msg', 'Unknown error')}")
                        return False
                else:
                    logger.error(f"UniFi login failed with status {response.status}")
                    return False
        except Exception as e:
            logger.exception(f"UniFi login error: {e}")
            return False

    async def _api_request(self, config: UniFiConfig, endpoint: str) -> Optional[dict]:
        """
        Make an authenticated API request.
        Endpoint should not include the base URL.
        """
        session = await self._get_session(config)

        # Ensure we're logged in
        if not self._cookies:
            if not await self._login(config):
                return None

        url = f"{config.controller_url}{endpoint}"

        try:
            async with session.get(url, cookies=self._cookies) as response:
                if response.status == 401:
                    # Session expired, try to re-login
                    if await self._login(config):
                        async with session.get(url, cookies=self._cookies) as retry_response:
                            if retry_response.status == 200:
                                return await retry_response.json()
                    return None

                if response.status == 200:
                    return await response.json()
                else:
                    logger.error(f"UniFi API request failed: {response.status}")
                    return None
        except Exception as e:
            logger.exception(f"UniFi API error: {e}")
            return None

    async def test_connection(self, config: UniFiConfig) -> tuple[bool, str]:
        """
        Test connection to UniFi Controller.
        Returns (success, message).
        """
        try:
            if await self._login(config):
                # Try to get site info to verify
                data = await self._api_request(config, f"/api/s/{config.site}/self")
                if data and data.get("meta", {}).get("rc") == "ok":
                    return True, "Connection successful"
                return True, "Login successful, but site access may be limited"
            return False, "Login failed - check credentials"
        except aiohttp.ClientConnectorError:
            return False, "Connection failed - check URL"
        except Exception as e:
            return False, f"Error: {str(e)}"
        finally:
            await self.close()

    async def get_devices(self, config: UniFiConfig) -> list[dict]:
        """
        Get all network devices from UniFi Controller.
        Returns raw device data.
        """
        data = await self._api_request(config, f"/api/s/{config.site}/stat/device")

        if data and data.get("meta", {}).get("rc") == "ok":
            return data.get("data", [])
        return []

    async def get_switches(self, config: UniFiConfig) -> list[MonitoredSwitch]:
        """
        Get only switch devices from UniFi Controller.
        Returns list of MonitoredSwitch objects.
        """
        devices = await self.get_devices(config)
        switches = []

        for device in devices:
            # Filter for switches (USW = UniFi Switch)
            device_type = device.get("type", "")
            if device_type not in ["usw", "switch"]:
                continue

            # Skip if not adopted
            if not device.get("adopted", False):
                continue

            name = device.get("name") or device.get("mac", "Unknown")
            ip = device.get("ip", "")

            if not ip:
                logger.warning(f"Switch {name} has no IP address, skipping")
                continue

            switch = MonitoredSwitch(
                name=name,
                ip_address=ip,
                snmp_config=SNMPConfig(),  # Default SNMP config, user can customize
                unifi_device_id=device.get("device_id", ""),
                unifi_mac=device.get("mac", ""),
                model=device.get("model", ""),
                port_count=device.get("port_table", []) and len(device.get("port_table", [])) or 0,
                uplink_ports=self._get_uplink_ports(device),
                enabled=True
            )
            switches.append(switch)

        logger.info(f"Discovered {len(switches)} switches from UniFi Controller")
        return switches

    def _get_uplink_ports(self, device: dict) -> list[int]:
        """Extract uplink port numbers from device data."""
        uplink_ports = []
        port_table = device.get("port_table", [])

        for port in port_table:
            if port.get("is_uplink", False):
                port_idx = port.get("port_idx")
                if port_idx is not None:
                    uplink_ports.append(port_idx)

        return uplink_ports

    async def get_port_profiles(self, config: UniFiConfig) -> list[dict]:
        """Get VLAN/port profiles from UniFi Controller."""
        data = await self._api_request(config, f"/api/s/{config.site}/rest/portconf")

        if data and data.get("meta", {}).get("rc") == "ok":
            return data.get("data", [])
        return []

    async def get_clients(self, config: UniFiConfig) -> list[dict]:
        """Get connected clients (useful for MAC-to-device mapping)."""
        data = await self._api_request(config, f"/api/s/{config.site}/stat/sta")

        if data and data.get("meta", {}).get("rc") == "ok":
            return data.get("data", [])
        return []

    async def close(self):
        """Close the aiohttp session."""
        if self._session and not self._session.closed:
            await self._session.close()
            self._session = None
        self._cookies = None


# Singleton instance
unifi_service = UniFiService()
