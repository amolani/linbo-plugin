import logging
import time
from typing import Generator, Callable
from queue import Queue
from threading import Thread

from fastapi.responses import StreamingResponse

logger = logging.getLogger(__name__)

# Headers to prevent buffering for SSE
SSE_HEADERS = {
    "Cache-Control": "no-cache, no-store, must-revalidate",
    "X-Accel-Buffering": "no",
    "Connection": "keep-alive",
}


class ActionLogger:
    """Logger for streaming action progress to clients."""

    def __init__(self):
        self.queue: Queue = Queue()
        self._stop = False

    def log(self, message: str, level: str = "info"):
        """Add a log message to the queue."""
        timestamp = time.strftime("%H:%M:%S")
        self.queue.put({"timestamp": timestamp, "level": level, "message": message})

    def info(self, message: str):
        self.log(message, "info")

    def success(self, message: str):
        self.log(message, "success")

    def error(self, message: str):
        self.log(message, "error")

    def warning(self, message: str):
        self.log(message, "warning")

    def done(self, success: bool = True):
        """Signal that the action is complete."""
        self.queue.put({"done": True, "success": success})

    def stream(self) -> Generator[str, None, None]:
        """Generate SSE events from the queue."""
        yield "retry: 1000\n\n"
        while True:
            try:
                item = self.queue.get(timeout=30)
                if item.get("done"):
                    success = item.get("success", True)
                    yield f"event: done\ndata: {{\"success\": {str(success).lower()}}}\n\n"
                    break
                timestamp = item.get("timestamp", "")
                level = item.get("level", "info")
                message = item.get("message", "")
                yield f"data: [{timestamp}] [{level.upper()}] {message}\n\n"
            except Exception:
                # Timeout - send keepalive
                yield ": keepalive\n\n"


def run_with_logging(action_func: Callable[[ActionLogger], bool]) -> Generator[str, None, None]:
    """Run an action function with logging and stream results."""
    action_logger = ActionLogger()

    def run_action():
        try:
            success = action_func(action_logger)
            action_logger.done(success)
        except Exception as e:
            action_logger.error(f"Action failed: {str(e)}")
            action_logger.done(False)

    thread = Thread(target=run_action)
    thread.start()

    yield from action_logger.stream()
    thread.join()


def create_sse_response(action_func: Callable[[ActionLogger], bool]) -> StreamingResponse:
    """Create a StreamingResponse for SSE with proper headers."""
    return StreamingResponse(
        run_with_logging(action_func),
        media_type="text/event-stream",
        headers=SSE_HEADERS
    )
