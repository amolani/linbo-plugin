import logging
import ssl
from typing import Optional

from ldap3 import Server, Connection, Tls, ALL, SUBTREE
from ldap3.core.exceptions import (
    LDAPBindError,
    LDAPSocketOpenError,
    LDAPInvalidCredentialsResult
)

from app.models import Authentication

logger = logging.getLogger(__name__)


class LDAPService:
    """Service for LDAP operations."""

    def test_connection(self, auth: Authentication) -> tuple[bool, str, list]:
        """
        Test LDAP connection and return status.

        Returns:
            Tuple of (success, message, entries)
        """
        try:
            tls = None
            if auth.use_ssl:
                tls = Tls(
                    validate=ssl.CERT_REQUIRED if auth.validate_cert else ssl.CERT_NONE
                )

            server = Server(
                auth.server,
                port=auth.port,
                use_ssl=auth.use_ssl,
                tls=tls,
                get_info=ALL,
                connect_timeout=5
            )

            conn = Connection(
                server,
                user=auth.binduser,
                password=auth.password,
                raise_exceptions=True,
                auto_referrals=False,
                receive_timeout=5
            )

            conn.open()
            conn.bind()

            entries = []
            if auth.basedn:
                search_filter = auth.userfilter or "(objectClass=*)"
                conn.search(
                    search_base=auth.basedn,
                    search_filter=search_filter,
                    search_scope=SUBTREE,
                    attributes=["cn"],
                    size_limit=1
                )
                entries = [e.entry_dn for e in conn.entries]

            conn.unbind()
            return True, f"LDAP test successful. Found {len(entries)} entries.", entries

        except LDAPBindError as e:
            return False, "Bind failed. Please check credentials!", []
        except LDAPInvalidCredentialsResult as e:
            return False, "Bind failed. Invalid credentials!", []
        except LDAPSocketOpenError as e:
            return False, "Failed to connect. Please check server and port!", []
        except Exception as e:
            logger.exception(e)
            return False, f"LDAP test failed: {str(e)}", []

    def get_groups(self, auth: Authentication) -> list[str]:
        """Get list of groups from LDAP."""
        try:
            tls = None
            if auth.use_ssl:
                tls = Tls(
                    validate=ssl.CERT_REQUIRED if auth.validate_cert else ssl.CERT_NONE
                )

            server = Server(
                auth.server,
                port=auth.port,
                use_ssl=auth.use_ssl,
                tls=tls,
                get_info=ALL,
                connect_timeout=5
            )

            conn = Connection(
                server,
                user=auth.binduser,
                password=auth.password,
                raise_exceptions=True,
                auto_referrals=False,
                receive_timeout=10
            )

            conn.open()
            conn.bind()

            entries = []
            if auth.basedn:
                conn.search(
                    search_base=auth.basedn,
                    search_filter="(objectClass=group)",
                    search_scope=SUBTREE,
                    attributes=["cn"]
                )
                entries = [e.entry_dn for e in conn.entries]

            conn.unbind()
            return entries

        except Exception as e:
            logger.exception(e)
            return []


# Singleton instance
ldap_service = LDAPService()
