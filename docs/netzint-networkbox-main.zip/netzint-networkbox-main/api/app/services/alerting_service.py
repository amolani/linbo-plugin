"""
Alerting Service for Network Monitoring.

Sends alerts via webhooks and email when loop incidents are detected.
"""

import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from typing import Optional
import aiohttp

from app.models.monitoring import LoopIncident, MonitoringConfig, IncidentSeverity

logger = logging.getLogger(__name__)


class AlertingService:
    """
    Service for sending alerts about network monitoring incidents.

    Supports:
    - Webhook notifications (JSON payload)
    - Email notifications (SMTP)
    """

    def __init__(self):
        self._config: Optional[MonitoringConfig] = None
        # Track sent alerts to avoid duplicates
        self._sent_alerts: dict[str, datetime] = {}
        # Minimum time between alerts for same incident (seconds)
        self._alert_cooldown = 300  # 5 minutes

    def set_config(self, config: MonitoringConfig):
        """Update the monitoring configuration."""
        self._config = config

    def get_config(self) -> MonitoringConfig:
        """Get current config or default."""
        if self._config is None:
            self._config = MonitoringConfig()
        return self._config

    def _should_alert(self, incident: LoopIncident) -> bool:
        """
        Check if we should send an alert for this incident.

        Prevents alert spam by enforcing cooldown period.
        """
        last_alert = self._sent_alerts.get(incident.id)
        if last_alert:
            elapsed = (datetime.now() - last_alert).total_seconds()
            if elapsed < self._alert_cooldown:
                return False
        return True

    def _mark_alerted(self, incident: LoopIncident):
        """Mark incident as alerted."""
        self._sent_alerts[incident.id] = datetime.now()

    async def send_alert(self, incident: LoopIncident) -> bool:
        """
        Send alert for an incident via configured channels.

        Args:
            incident: The loop incident to alert about

        Returns:
            True if at least one alert was sent successfully
        """
        if not self._should_alert(incident):
            logger.debug(f"Skipping alert for {incident.id} (cooldown)")
            return False

        config = self.get_config()
        success = False

        # Send webhook alert
        if config.alert_webhook_url:
            try:
                webhook_success = await self._send_webhook(incident, config.alert_webhook_url)
                success = success or webhook_success
            except Exception as e:
                logger.error(f"Webhook alert failed: {e}")

        # Send email alert
        if config.alert_email:
            try:
                email_success = await self._send_email(incident, config.alert_email)
                success = success or email_success
            except Exception as e:
                logger.error(f"Email alert failed: {e}")

        if success:
            self._mark_alerted(incident)

        return success

    async def _send_webhook(self, incident: LoopIncident, webhook_url: str) -> bool:
        """
        Send webhook notification.

        Args:
            incident: The incident to report
            webhook_url: URL to POST to

        Returns:
            True if successful
        """
        severity_colors = {
            IncidentSeverity.INFO: "#3498db",      # Blue
            IncidentSeverity.WARNING: "#f39c12",   # Orange
            IncidentSeverity.CRITICAL: "#e74c3c"   # Red
        }

        # Build payload (compatible with Discord, Slack, etc.)
        payload = {
            "username": "NetworkBOX Monitor",
            "embeds": [{
                "title": f"🔴 Loop Detected: {incident.switch_name}",
                "description": incident.summary,
                "color": int(severity_colors.get(incident.severity, "#95a5a6").replace("#", ""), 16),
                "fields": [
                    {
                        "name": "Severity",
                        "value": incident.severity.value.upper(),
                        "inline": True
                    },
                    {
                        "name": "Score",
                        "value": str(incident.score),
                        "inline": True
                    },
                    {
                        "name": "Status",
                        "value": incident.status.value,
                        "inline": True
                    },
                    {
                        "name": "Suspected Ports",
                        "value": ", ".join(map(str, incident.suspected_ports)) or "N/A",
                        "inline": True
                    },
                    {
                        "name": "MAC Moves",
                        "value": str(incident.mac_moves_count),
                        "inline": True
                    },
                    {
                        "name": "STP Changes",
                        "value": str(incident.stp_topology_changes),
                        "inline": True
                    },
                    {
                        "name": "Details",
                        "value": incident.details or "No additional details",
                        "inline": False
                    }
                ],
                "timestamp": incident.detected_at.isoformat(),
                "footer": {
                    "text": f"Incident ID: {incident.id}"
                }
            }]
        }

        # Also send a simpler format for generic webhooks
        simple_payload = {
            "event": "loop_detected",
            "incident_id": incident.id,
            "switch_name": incident.switch_name,
            "severity": incident.severity.value,
            "score": incident.score,
            "status": incident.status.value,
            "suspected_ports": incident.suspected_ports,
            "mac_moves_count": incident.mac_moves_count,
            "stp_topology_changes": incident.stp_topology_changes,
            "flapping_macs": incident.top_flapping_macs,
            "summary": incident.summary,
            "details": incident.details,
            "detected_at": incident.detected_at.isoformat()
        }

        try:
            async with aiohttp.ClientSession() as session:
                # Try Discord/Slack format first
                async with session.post(
                    webhook_url,
                    json=payload,
                    timeout=10
                ) as response:
                    if response.status in [200, 204]:
                        logger.info(f"Webhook alert sent for incident {incident.id}")
                        return True

                    # If Discord format fails, try simple format
                    if response.status >= 400:
                        async with session.post(
                            webhook_url,
                            json=simple_payload,
                            timeout=10
                        ) as retry_response:
                            if retry_response.status in [200, 204]:
                                logger.info(f"Webhook alert sent (simple format) for {incident.id}")
                                return True

                    logger.warning(
                        f"Webhook returned status {response.status} for {incident.id}"
                    )
                    return False

        except aiohttp.ClientError as e:
            logger.error(f"Webhook connection error: {e}")
            return False
        except Exception as e:
            logger.exception(f"Webhook error: {e}")
            return False

    async def _send_email(self, incident: LoopIncident, email: str) -> bool:
        """
        Send email notification.

        Note: Requires SMTP configuration (not yet implemented in config).
        For now, logs the email that would be sent.

        Args:
            incident: The incident to report
            email: Destination email address

        Returns:
            True if successful
        """
        # Build email content
        severity_emoji = {
            IncidentSeverity.INFO: "ℹ️",
            IncidentSeverity.WARNING: "⚠️",
            IncidentSeverity.CRITICAL: "🔴"
        }

        subject = (
            f"{severity_emoji.get(incident.severity, '❓')} "
            f"Loop Detected on {incident.switch_name} "
            f"(Score: {incident.score})"
        )

        body = f"""
Network Loop Incident Detected

Switch: {incident.switch_name}
Severity: {incident.severity.value.upper()}
Score: {incident.score}/100
Status: {incident.status.value}

Summary:
{incident.summary}

Details:
- Suspected Ports: {', '.join(map(str, incident.suspected_ports)) or 'N/A'}
- MAC Moves: {incident.mac_moves_count}
- STP Topology Changes: {incident.stp_topology_changes}
- Discard Rate: {incident.discard_rate:.2f}%
- Top Flapping MACs: {', '.join(incident.top_flapping_macs[:5]) or 'N/A'}

{incident.details}

Detected at: {incident.detected_at.strftime('%Y-%m-%d %H:%M:%S')}
Incident ID: {incident.id}

---
This alert was sent by NetworkBOX Loop Detection
"""

        # TODO: Implement actual SMTP sending when config is extended
        # For now, just log the email
        logger.info(
            f"Email alert would be sent to {email}:\n"
            f"Subject: {subject}\n"
            f"(Email sending requires SMTP configuration)"
        )

        # Return True to indicate we processed it (even though we didn't actually send)
        # This prevents retry spam until SMTP is configured
        return True

    async def test_webhook(self, webhook_url: str) -> dict:
        """
        Send a test webhook notification.

        Args:
            webhook_url: URL to test

        Returns:
            Dict with test results
        """
        test_payload = {
            "username": "NetworkBOX Monitor",
            "embeds": [{
                "title": "✅ Webhook Test Successful",
                "description": "This is a test notification from NetworkBOX Loop Detection.",
                "color": 0x2ecc71,  # Green
                "timestamp": datetime.now().isoformat(),
                "footer": {
                    "text": "Test notification"
                }
            }]
        }

        simple_payload = {
            "event": "test",
            "message": "NetworkBOX Loop Detection webhook test",
            "timestamp": datetime.now().isoformat()
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    webhook_url,
                    json=test_payload,
                    timeout=10
                ) as response:
                    if response.status in [200, 204]:
                        return {
                            "success": True,
                            "message": "Webhook test successful"
                        }

                    # Try simple format
                    async with session.post(
                        webhook_url,
                        json=simple_payload,
                        timeout=10
                    ) as retry_response:
                        if retry_response.status in [200, 204]:
                            return {
                                "success": True,
                                "message": "Webhook test successful (simple format)"
                            }

                        return {
                            "success": False,
                            "message": f"Webhook returned HTTP {response.status}"
                        }

        except aiohttp.ClientError as e:
            return {
                "success": False,
                "message": f"Connection error: {str(e)}"
            }
        except Exception as e:
            return {
                "success": False,
                "message": f"Error: {str(e)}"
            }

    def clear_alert_history(self):
        """Clear the sent alerts history."""
        self._sent_alerts.clear()


# Singleton instance
alerting_service = AlertingService()
