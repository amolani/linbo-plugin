import logging

from pymongo import MongoClient

from app.config import settings


class Database:
    """MongoDB database wrapper."""

    def __init__(self):
        logging.info(f"Initializing {type(self).__name__}")
        self.client = MongoClient(settings.mongo_uri)
        self.database = self.client[settings.mongo_database]

    def insert(self, collection: str, data: dict) -> None:
        """Insert a document into a collection."""
        self.database[collection].insert_one(data)

    def find(self, collection: str, query: dict) -> list:
        """Find documents in a collection."""
        return self.database[collection].find(query)

    def find_one(self, collection: str, query: dict) -> dict | None:
        """Find a single document in a collection."""
        return self.database[collection].find_one(query)

    def update(self, collection: str, query: dict, data: dict) -> bool:
        """Update a document in a collection."""
        result = self.database[collection].update_one(query, {"$set": data})
        return result.acknowledged

    def upsert(self, collection: str, query: dict, data: dict) -> bool:
        """Insert or update a document in a collection."""
        result = self.database[collection].update_one(query, {"$set": data}, upsert=True)
        return result.acknowledged

    def delete(self, collection: str, query: dict) -> None:
        """Delete a document from a collection."""
        self.database[collection].delete_one(query)


# Singleton instance
db = Database()