import os
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "NetworkBox API"
    app_version: str = "2.0.0"
    debug: bool = os.getenv("NETWORKBOX_DEBUG", "false").lower() == "true"

    # Authentication
    jwt_secret: str = os.getenv("NETWORKBOX_JWT_SECRET", "change-me-in-production")
    jwt_algorithm: str = "HS256"
    access_token_lifetime_minutes: int = 60
    refresh_token_lifetime_days: int = 7

    # Admin credentials
    admin_username: str = os.getenv("NETWORKBOX_USERNAME", "admin")
    admin_password_hash: str = os.getenv(
        "NETWORKBOX_PASSWORD",
        "2a3a100d193d125752b42e97976963630b9d2d11513df94a235b5c6d3da53e46"  # Default: Muster!
    )

    # Database
    mongo_uri: str = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    mongo_database: str = os.getenv("MONGO_DATABASE", "networkbox")

    # NAPI
    napi_url: str = os.getenv("NAPI_URL", "http://networkbox-napi:8080")
    napi_timeout: float = 30.0

    # Docker
    docker_label: str = "networkbox"

    # Docker images
    image_napi: str = "ghcr.io/netzint/networkbox-napi:latest"
    image_mdns: str = "flungo/avahi"
    image_radius: str = "ghcr.io/netzint/radius-server:latest"
    image_haproxy: str = "haproxy:2.9-alpine"
    image_squid: str = "ubuntu/squid:latest"
    image_kms: str = "ghcr.io/py-kms-organization/py-kms:latest"

    class Config:
        env_prefix = "NETWORKBOX_"


settings = Settings()
