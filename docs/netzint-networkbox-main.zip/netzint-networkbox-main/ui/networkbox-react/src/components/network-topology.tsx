import { useCallback, useMemo } from 'react'
import {
  ReactFlow,
  Controls,
  Background,
  MiniMap,
  useNodesState,
  useEdgesState,
  Handle,
  Position,
  MarkerType,
} from '@xyflow/react'
import type { Node, Edge, NodeProps } from '@xyflow/react'
import '@xyflow/react/dist/style.css'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { Network, AlertTriangle, CheckCircle2 } from 'lucide-react'
import type { MonitoredSwitch, SwitchConnection, LoopIncident } from '@/types'

interface SwitchNodeData extends Record<string, unknown> {
  label: string
  model: string
  ip: string
  portCount: number
  enabled: boolean
  reachable: boolean
  hasIncident: boolean
  incidentSeverity?: string
  affectedPorts: number[]
}

function SwitchNode({ data }: NodeProps<Node<SwitchNodeData>>) {
  const nodeData = data as SwitchNodeData

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Card
            className={`p-3 min-w-[160px] cursor-pointer transition-all ${
              nodeData.hasIncident
                ? nodeData.incidentSeverity === 'critical'
                  ? 'border-red-500 border-2 shadow-red-500/20 shadow-lg'
                  : 'border-yellow-500 border-2 shadow-yellow-500/20 shadow-lg'
                : nodeData.reachable
                ? 'border-green-500/50'
                : 'border-muted opacity-60'
            }`}
          >
            <Handle type="target" position={Position.Top} className="!bg-primary" />
            <Handle type="source" position={Position.Bottom} className="!bg-primary" />
            <Handle type="target" position={Position.Left} className="!bg-primary" />
            <Handle type="source" position={Position.Right} className="!bg-primary" />

            <div className="flex items-center gap-2 mb-2">
              {nodeData.hasIncident ? (
                <AlertTriangle
                  className={`h-5 w-5 ${
                    nodeData.incidentSeverity === 'critical' ? 'text-red-500' : 'text-yellow-500'
                  }`}
                />
              ) : nodeData.reachable ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : (
                <Network className="h-5 w-5 text-muted-foreground" />
              )}
              <span className="font-semibold text-sm truncate">{nodeData.label}</span>
            </div>

            <div className="text-xs text-muted-foreground space-y-1">
              <div className="font-mono">{nodeData.ip}</div>
              {nodeData.model && <div>{nodeData.model}</div>}
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {nodeData.portCount} ports
                </Badge>
                {nodeData.hasIncident && nodeData.affectedPorts.length > 0 && (
                  <Badge variant="destructive" className="text-xs">
                    {nodeData.affectedPorts.length} affected
                  </Badge>
                )}
              </div>
            </div>
          </Card>
        </TooltipTrigger>
        <TooltipContent side="right" className="max-w-xs">
          <div className="space-y-1">
            <p className="font-semibold">{nodeData.label}</p>
            <p className="text-sm">IP: {nodeData.ip}</p>
            {nodeData.model && <p className="text-sm">Model: {nodeData.model}</p>}
            <p className="text-sm">Ports: {nodeData.portCount}</p>
            <p className="text-sm">
              Status: {nodeData.reachable ? 'Reachable' : 'Unreachable'}
            </p>
            {nodeData.hasIncident && (
              <p className="text-sm text-destructive">
                Incident: {nodeData.incidentSeverity?.toUpperCase()}
              </p>
            )}
            {nodeData.affectedPorts.length > 0 && (
              <p className="text-sm text-destructive">
                Affected ports: {nodeData.affectedPorts.join(', ')}
              </p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}

const nodeTypes = {
  switch: SwitchNode,
}

interface NetworkTopologyProps {
  switches: MonitoredSwitch[]
  connections: SwitchConnection[]
  incidents: LoopIncident[]
  switchStatus: Record<string, boolean>
  onSwitchClick?: (switchName: string) => void
}

export function NetworkTopology({
  switches,
  connections,
  incidents,
  switchStatus,
  onSwitchClick,
}: NetworkTopologyProps) {
  // Build incident map
  const incidentMap = useMemo(() => {
    const map: Record<string, LoopIncident> = {}
    for (const incident of incidents) {
      if (incident.status !== 'resolved') {
        const existing = map[incident.switch_name]
        if (!existing || incident.severity === 'critical') {
          map[incident.switch_name] = incident
        }
      }
    }
    return map
  }, [incidents])

  // Create nodes from switches
  const initialNodes: Node<SwitchNodeData>[] = useMemo(() => {
    // Calculate grid layout
    const cols = Math.ceil(Math.sqrt(switches.length))
    const spacing = { x: 250, y: 180 }

    return switches.map((sw, index) => {
      const col = index % cols
      const row = Math.floor(index / cols)
      const incident = incidentMap[sw.name]

      return {
        id: sw.name,
        type: 'switch',
        position: {
          x: sw.position_x ?? col * spacing.x + 50,
          y: sw.position_y ?? row * spacing.y + 50,
        },
        data: {
          label: sw.name,
          model: sw.model,
          ip: sw.ip_address,
          portCount: sw.port_count,
          enabled: sw.enabled,
          reachable: switchStatus[sw.name] ?? false,
          hasIncident: !!incident,
          incidentSeverity: incident?.severity,
          affectedPorts: incident?.suspected_ports ?? [],
        },
      }
    })
  }, [switches, incidentMap, switchStatus])

  // Create edges from connections
  const initialEdges: Edge[] = useMemo(() => {
    return connections.map((conn, index) => {
      // Check if this connection involves affected ports
      const fromIncident = incidentMap[conn.from_switch]
      const toIncident = incidentMap[conn.to_switch]
      const isAffected =
        (fromIncident?.suspected_ports?.includes(conn.from_port)) ||
        (toIncident?.suspected_ports?.includes(conn.to_port))

      return {
        id: `edge-${index}`,
        source: conn.from_switch,
        target: conn.to_switch,
        label: `${conn.from_port} - ${conn.to_port}`,
        labelStyle: { fontSize: 10 },
        style: {
          stroke: isAffected ? '#ef4444' : '#6b7280',
          strokeWidth: isAffected ? 3 : 2,
        },
        animated: isAffected,
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: isAffected ? '#ef4444' : '#6b7280',
        },
      }
    })
  }, [connections, incidentMap])

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)

  // Update nodes when props change
  useMemo(() => {
    setNodes(initialNodes)
  }, [initialNodes, setNodes])

  useMemo(() => {
    setEdges(initialEdges)
  }, [initialEdges, setEdges])

  const onNodeClick = useCallback(
    (_: React.MouseEvent, node: Node) => {
      if (onSwitchClick) {
        onSwitchClick(node.id)
      }
    },
    [onSwitchClick]
  )

  if (switches.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[400px] text-muted-foreground">
        <Network className="h-12 w-12 mb-2" />
        <p>No switches configured</p>
        <p className="text-sm">Add switches to see the network topology</p>
      </div>
    )
  }

  return (
    <div className="h-[500px] w-full border rounded-lg bg-background">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={onNodeClick}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        defaultEdgeOptions={{
          type: 'smoothstep',
        }}
      >
        <Controls />
        <MiniMap
          nodeStrokeColor={(node) => {
            const data = node.data as SwitchNodeData
            if (data.hasIncident) {
              return data.incidentSeverity === 'critical' ? '#ef4444' : '#eab308'
            }
            return data.reachable ? '#22c55e' : '#6b7280'
          }}
          nodeColor={(node) => {
            const data = node.data as SwitchNodeData
            if (data.hasIncident) {
              return data.incidentSeverity === 'critical' ? '#fecaca' : '#fef08a'
            }
            return data.reachable ? '#dcfce7' : '#e5e7eb'
          }}
        />
        <Background gap={20} size={1} />
      </ReactFlow>
    </div>
  )
}
