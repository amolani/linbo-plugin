import { Link, useLocation } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { cn } from '@/lib/utils'
import { useAuth } from '@/context/auth-context'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import {
  Home,
  Network,
  Radio,
  Shield,
  KeyRound,
  Container,
  Zap,
  Award,
  Globe,
  Lock,
  Server,
  LogOut,
  ChevronLeft,
  Cpu,
  Circle,
  Waypoints,
  Wrench,
  Activity,
  Key,
} from 'lucide-react'
import { useState } from 'react'
import api from '@/lib/api'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'

interface NAPIStatus {
  running: boolean
  version: string | null
  connected_networks: string[]
}

// Konfiguration - Grundeinstellungen und Netzwerk
const configNavigation = [
  { name: 'Dashboard', href: '/admin/home', icon: Home },
  { name: 'Networks', href: '/admin/networks', icon: Network },
  { name: 'NAPI', href: '/admin/napi', icon: Cpu },
  { name: 'Authentication', href: '/admin/authentication', icon: KeyRound },
  { name: 'Certificates', href: '/admin/certificates', icon: Award },
  { name: 'Containers', href: '/admin/containers', icon: Container },
  { name: 'Tools', href: '/admin/tools', icon: Wrench },
]

// Services - Aktive Dienste
const servicesNavigation = [
  { name: 'mDNS Repeater', href: '/admin/mdns', icon: Radio },
  { name: 'RADIUS Server', href: '/admin/radius', icon: Shield },
  { name: 'Reverse Proxy', href: '/admin/reverseproxy', icon: Globe },
  { name: 'Proxy Server', href: '/admin/proxy', icon: Lock },
  { name: 'KMS Server', href: '/admin/kms', icon: Server },
  { name: 'Wake on LAN', href: '/admin/wol', icon: Zap },
  { name: 'Monitoring', href: '/admin/monitoring', icon: Activity, badge: 'BETA' },
]

interface SidebarContentProps {
  collapsed: boolean
  onCollapse?: (collapsed: boolean) => void
  onNavigate?: () => void
}

function SidebarContent({ collapsed, onCollapse, onNavigate }: SidebarContentProps) {
  const location = useLocation()
  const { logout, changePassword } = useAuth()
  const [isPasswordOpen, setIsPasswordOpen] = useState(false)
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [isChanging, setIsChanging] = useState(false)

  const { data: napiStatus } = useQuery<NAPIStatus>({
    queryKey: ['napi-status'],
    queryFn: async () => {
      const response = await api.get('/napi/status')
      return response.data
    },
    refetchInterval: 10000,
  })

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <div className="flex h-14 shrink-0 items-center justify-between border-b px-4">
        <div
          className={cn(
            'flex items-center gap-3',
            collapsed && 'mx-auto',
            onCollapse && collapsed && 'cursor-pointer'
          )}
          onClick={onCollapse && collapsed ? () => onCollapse(false) : undefined}
        >
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary">
            <Waypoints className="h-4 w-4 text-primary-foreground" />
          </div>
          {!collapsed && (
            <span className="text-lg font-semibold text-primary">NetworkBOX</span>
          )}
        </div>
        {onCollapse && !collapsed && (
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onCollapse(true)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Scrollable Navigation */}
      <ScrollArea className="flex-1">
        <div className="px-2 py-4">
          {/* Konfiguration Section */}
          {!collapsed && (
            <p className="px-3 pb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Konfiguration
            </p>
          )}
          <nav className="space-y-1">
            {configNavigation.map((item) => {
              const isActive = location.pathname === item.href
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={onNavigate}
                  className={cn(
                    'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                  )}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  {!collapsed && <span>{item.name}</span>}
                </Link>
              )
            })}
          </nav>

          <Separator className="my-4" />

          {/* Services Section */}
          {!collapsed && (
            <p className="px-3 pb-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Services
            </p>
          )}
          <nav className="space-y-1">
            {servicesNavigation.map((item) => {
              const isActive = location.pathname === item.href
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={onNavigate}
                  className={cn(
                    'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                    isActive
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground'
                  )}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  {!collapsed && (
                    <span className="flex items-center gap-2">
                      {item.name}
                      {item.badge && (
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4">
                          {item.badge}
                        </Badge>
                      )}
                    </span>
                  )}
                </Link>
              )
            })}
          </nav>
        </div>
      </ScrollArea>

      {/* Footer - Fixed at bottom */}
      <div className="shrink-0 border-t bg-card p-2 space-y-2">
        {/* NAPI Status */}
        <div className={cn(
          'flex items-center gap-2 px-3 py-2 text-xs',
          collapsed && 'justify-center px-0'
        )}>
          <Circle
            className={cn(
              'h-2 w-2 shrink-0 fill-current',
              napiStatus?.running ? 'text-green-500' : 'text-red-500'
            )}
          />
          {!collapsed && (
            <div className="flex flex-col">
              <span className="text-muted-foreground">
                NAPI {napiStatus?.running ? 'Online' : 'Offline'}
              </span>
              {napiStatus?.version && (
                <span className="text-muted-foreground/60">v{napiStatus.version}</span>
              )}
            </div>
          )}
        </div>

        <Button
          variant="ghost"
          className={cn('w-full justify-start gap-3', collapsed && 'justify-center')}
          onClick={() => setIsPasswordOpen(true)}
        >
          <Key className="h-4 w-4" />
          {!collapsed && <span>Change Password</span>}
        </Button>

        <Button
          variant="ghost"
          className={cn('w-full justify-start gap-3', collapsed && 'justify-center')}
          onClick={logout}
        >
          <LogOut className="h-4 w-4" />
          {!collapsed && <span>Logout</span>}
        </Button>
      </div>

      <Dialog open={isPasswordOpen} onOpenChange={(open) => {
        setIsPasswordOpen(open)
        if (!open) {
          setCurrentPassword('')
          setNewPassword('')
        }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Change Password</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Current Password</Label>
              <Input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Current password"
              />
            </div>
            <div className="space-y-2">
              <Label>New Password</Label>
              <Input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="New password"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPasswordOpen(false)}>
              Cancel
            </Button>
            <Button
              disabled={isChanging || !currentPassword || !newPassword}
              onClick={async () => {
                setIsChanging(true)
                const success = await changePassword(currentPassword, newPassword)
                setIsChanging(false)
                if (success) {
                  toast.success('Password changed successfully')
                  setIsPasswordOpen(false)
                  setCurrentPassword('')
                  setNewPassword('')
                } else {
                  toast.error('Failed to change password. Check your current password.')
                }
              }}
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <aside
      className={cn(
        'hidden md:flex flex-col border-r bg-card transition-all duration-300',
        collapsed ? 'w-16' : 'w-64'
      )}
    >
      <SidebarContent
        collapsed={collapsed}
        onCollapse={setCollapsed}
      />
    </aside>
  )
}

export function MobileSidebar({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  return (
    <>
      {/* Backdrop */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/50 md:hidden"
          onClick={() => onOpenChange(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 w-64 bg-card transform transition-transform duration-300 ease-in-out md:hidden',
          open ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <SidebarContent
          collapsed={false}
          onNavigate={() => onOpenChange(false)}
        />
      </aside>
    </>
  )
}
