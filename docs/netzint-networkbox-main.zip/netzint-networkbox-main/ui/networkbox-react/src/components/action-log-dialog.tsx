import { useEffect, useRef } from 'react'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { CheckCircle2, XCircle, Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { LogEntry } from '@/hooks/use-action-stream'

interface ActionLogDialogProps {
  open: boolean
  onClose: () => void
  title: string
  logs: LogEntry[]
  isRunning: boolean
  success: boolean | null
}

export function ActionLogDialog({
  open,
  onClose,
  title,
  logs,
  isRunning,
  success,
}: ActionLogDialogProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (scrollContainerRef.current) {
      // Find the actual scrollable viewport inside ScrollArea
      const viewport = scrollContainerRef.current.querySelector('[data-radix-scroll-area-viewport]')
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight
      }
    }
  }, [logs])

  const getLevelColor = (level: LogEntry['level']) => {
    switch (level) {
      case 'success':
        return 'text-green-500'
      case 'error':
        return 'text-red-500'
      case 'warning':
        return 'text-yellow-500'
      default:
        return 'text-muted-foreground'
    }
  }

  return (
    <Dialog open={open} onOpenChange={(open) => !open && !isRunning && onClose()}>
      <DialogContent className="sm:max-w-4xl" showCloseButton={!isRunning}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {isRunning ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : success ? (
              <CheckCircle2 className="h-5 w-5 text-green-500" />
            ) : success === false ? (
              <XCircle className="h-5 w-5 text-red-500" />
            ) : null}
            {title}
            {isRunning && (
              <Badge variant="secondary" className="ml-2">
                Running
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="h-[400px] rounded-md border bg-muted/30" ref={scrollContainerRef}>
          <div className="p-4 font-mono text-sm space-y-1">
            {logs.length === 0 && isRunning && (
              <div className="text-muted-foreground">Waiting for output...</div>
            )}
            {logs.map((log, index) => (
              <div key={index} className="flex gap-2">
                <span className="text-muted-foreground shrink-0">[{log.timestamp}]</span>
                <span className={cn('shrink-0 uppercase w-20', getLevelColor(log.level))}>
                  [{log.level}]
                </span>
                <span className="break-all">{log.message}</span>
              </div>
            ))}
            {isRunning && (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-3 w-3 animate-spin" />
                <span>Processing...</span>
              </div>
            )}
          </div>
        </ScrollArea>

        <DialogFooter>
          {!isRunning && (
            <Button onClick={onClose}>
              Close
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
