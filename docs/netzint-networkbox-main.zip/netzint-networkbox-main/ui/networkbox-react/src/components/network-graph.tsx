import { useState, useEffect, useRef, useCallback } from 'react'
import * as d3 from 'd3'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  Network,
  Waypoints,
  Monitor,
  RefreshCw,
  Loader2,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  AlertCircle,
  Focus,
  Pause,
  Radio,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface NetworkNode {
  vlan_id: number
  name: string
  address: string
  mask: string
}

interface DeviceNode {
  ip: string
  mac: string
  hostname?: string
  vendor?: string
}

interface GraphNode extends d3.SimulationNodeDatum {
  id: string
  type: 'root' | 'network' | 'device'
  label: string
  data?: NetworkNode | DeviceNode
  vlan_id?: number
  deviceCount?: number
}

interface GraphLink extends d3.SimulationLinkDatum<GraphNode> {
  source: string | GraphNode
  target: string | GraphNode
}

interface ScanMessage {
  type: 'networks' | 'scanning' | 'device' | 'network_complete' | 'complete' | 'error'
  networks?: NetworkNode[]
  vlan_id?: number
  name?: string
  device?: DeviceNode
  device_count?: number
  total_devices?: number
  message?: string
  error?: string
}

// Fixed colors for network topology
const NETWORK_COLOR = '#f97316' // orange for networks
const DEVICE_COLOR = '#8b5cf6' // violet/purple for hosts
const ROOT_COLOR = '#3b82f6' // blue for NetworkBox

// Helper to truncate text
const truncateText = (text: string, maxLength: number): string => {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength - 1) + '…'
}


export function NetworkGraph() {
  const svgRef = useRef<SVGSVGElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  const tooltipRef = useRef<HTMLDivElement>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [scanStatus, setScanStatus] = useState('')
  const [networks, setNetworks] = useState<NetworkNode[]>([])
  const [devices, setDevices] = useState<Map<number, DeviceNode[]>>(new Map())
  const [totalDevices, setTotalDevices] = useState(0)
  const [currentNetwork, setCurrentNetwork] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [tooltipData, setTooltipData] = useState<{ node: GraphNode; x: number; y: number } | null>(null)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isLiveMode, setIsLiveMode] = useState(true)
  const wsRef = useRef<WebSocket | null>(null)
  const simulationRef = useRef<d3.Simulation<GraphNode, GraphLink> | null>(null)
  const zoomRef = useRef<d3.ZoomBehavior<SVGSVGElement, unknown> | null>(null)
  const cardRef = useRef<HTMLDivElement>(null)
  const restartTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const currentTransformRef = useRef<d3.ZoomTransform | null>(null)
  const hasInitializedRef = useRef(false)

  const startScan = useCallback((clearData = true) => {
    if (wsRef.current) {
      wsRef.current.close()
    }

    setIsScanning(true)
    setError(null)
    setScanStatus('Connecting...')
    if (clearData) {
      setNetworks([])
      setDevices(new Map())
      setTotalDevices(0)
      // Reset initialization flag so the graph will center again
      hasInitializedRef.current = false
      currentTransformRef.current = null
    }
    setCurrentNetwork(null)

    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const wsUrl = `${wsProtocol}//${window.location.host}/api/v1/napi/arp-scan/all`

    const ws = new WebSocket(wsUrl)
    wsRef.current = ws

    ws.onopen = () => {
      setScanStatus('Starting scan...')
    }

    ws.onmessage = (event) => {
      const msg: ScanMessage = JSON.parse(event.data)

      switch (msg.type) {
        case 'networks':
          if (msg.networks) {
            setNetworks(msg.networks)
            setScanStatus(`Found ${msg.networks.length} networks`)
          }
          break
        case 'scanning':
          if (msg.vlan_id !== undefined) {
            setCurrentNetwork(msg.vlan_id)
            setScanStatus(`Scanning ${msg.name || `VLAN ${msg.vlan_id}`}...`)
          }
          break
        case 'device':
          if (msg.vlan_id !== undefined && msg.device) {
            setDevices((prev) => {
              const newMap = new Map(prev)
              const existing = newMap.get(msg.vlan_id!) || []
              // Avoid duplicates - only add if IP doesn't exist
              if (!existing.some((d) => d.ip === msg.device!.ip)) {
                newMap.set(msg.vlan_id!, [...existing, msg.device!])
                // Only increment count when actually adding a new device
                setTotalDevices((prevCount) => prevCount + 1)
              }
              return newMap
            })
          }
          break
        case 'network_complete':
          if (msg.error) {
            setScanStatus(`Error on VLAN ${msg.vlan_id}: ${msg.error}`)
          }
          break
        case 'complete':
          setIsScanning(false)
          setCurrentNetwork(null)
          const deviceCount = msg.total_devices || totalDevices
          setScanStatus(`Live - ${deviceCount} devices`)
          break
        case 'error':
          setError(msg.message || 'Unknown error')
          setIsScanning(false)
          setScanStatus('Scan failed')
          break
      }
    }

    ws.onerror = () => {
      setError('WebSocket connection failed')
      setIsScanning(false)
      setScanStatus('Connection failed')
    }

    ws.onclose = () => {
      if (isScanning) {
        setIsScanning(false)
      }
    }
  }, [totalDevices])

  // Auto-start scan on mount
  useEffect(() => {
    startScan()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Auto-restart scan in live mode after completion
  useEffect(() => {
    if (isLiveMode && !isScanning && !error && networks.length > 0) {
      // Wait 5 seconds before restarting scan
      restartTimeoutRef.current = setTimeout(() => {
        startScan(false) // Don't clear data on restart
      }, 5000)
    }

    return () => {
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
      }
    }
  }, [isLiveMode, isScanning, error, networks.length, startScan])

  // Toggle live mode handler
  const toggleLiveMode = useCallback(() => {
    setIsLiveMode((prev) => {
      if (prev) {
        // Stopping live mode - cancel any pending restart
        if (restartTimeoutRef.current) {
          clearTimeout(restartTimeoutRef.current)
        }
        if (wsRef.current) {
          wsRef.current.close()
        }
        setIsScanning(false)
        setScanStatus(`Paused - ${totalDevices} devices`)
      } else {
        // Starting live mode - trigger a scan
        setTimeout(() => startScan(false), 0)
      }
      return !prev
    })
  }, [totalDevices, startScan])

  // Build graph data
  const buildGraphData = useCallback((): { nodes: GraphNode[]; links: GraphLink[] } => {
    const nodes: GraphNode[] = []
    const links: GraphLink[] = []

    // Root node (NetworkBox)
    nodes.push({
      id: 'networkbox',
      type: 'root',
      label: 'NetworkBox',
    })

    // Network nodes
    networks.forEach((network) => {
      const deviceList = devices.get(network.vlan_id) || []
      nodes.push({
        id: `network-${network.vlan_id}`,
        type: 'network',
        label: network.name || `VLAN ${network.vlan_id}`,
        data: network,
        vlan_id: network.vlan_id,
        deviceCount: deviceList.length,
      })

      links.push({
        source: 'networkbox',
        target: `network-${network.vlan_id}`,
      })

      // Device nodes (limit to 50 per network for performance)
      deviceList.slice(0, 50).forEach((device, idx) => {
        const deviceId = `device-${network.vlan_id}-${idx}`
        nodes.push({
          id: deviceId,
          type: 'device',
          label: device.hostname || device.ip,
          data: device,
          vlan_id: network.vlan_id,
        })

        links.push({
          source: `network-${network.vlan_id}`,
          target: deviceId,
        })
      })
    })

    return { nodes, links }
  }, [networks, devices])

  // Render graph
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return

    const svg = d3.select(svgRef.current)
    const container = containerRef.current
    const width = container.clientWidth
    const height = container.clientHeight || 500

    // Clear previous content
    svg.selectAll('*').remove()

    const { nodes, links } = buildGraphData()

    if (nodes.length === 0) {
      // Show placeholder
      svg
        .append('text')
        .attr('x', width / 2)
        .attr('y', height / 2)
        .attr('text-anchor', 'middle')
        .attr('fill', 'currentColor')
        .attr('opacity', 0.5)
        .text('Click "Scan All" to discover network devices')
      return
    }

    // Create main group for zoom/pan
    const g = svg.append('g')

    // Create zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 4])
      .on('zoom', (event) => {
        g.attr('transform', event.transform)
        // Save current transform for restoration on re-render
        currentTransformRef.current = event.transform
      })

    zoomRef.current = zoom
    svg.call(zoom)

    // Restore previous transform if it exists
    if (currentTransformRef.current) {
      svg.call(zoom.transform, currentTransformRef.current)
    }

    // Create simulation with more spacing
    const simulation = d3.forceSimulation<GraphNode>(nodes)
      .force('link', d3.forceLink<GraphNode, GraphLink>(links)
        .id((d) => d.id)
        .distance((d) => {
          const source = d.source as GraphNode
          const target = d.target as GraphNode
          // Large distance between root and networks
          if (source.type === 'root' || target.type === 'root') return 280
          // Medium distance between networks and devices
          if (source.type === 'network' || target.type === 'network') return 150
          return 100
        })
      )
      .force('charge', d3.forceManyBody<GraphNode>()
        .strength((d) => {
          // Strong repulsion from root
          if (d.type === 'root') return -1500
          // Medium repulsion from networks
          if (d.type === 'network') return -600
          return -100
        })
      )
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide<GraphNode>()
        .radius((d) => {
          if (d.type === 'root') return 80
          if (d.type === 'network') return 60
          return 30
        })
      )

    simulationRef.current = simulation

    // Draw links
    const link = g.append('g')
      .attr('class', 'links')
      .selectAll('line')
      .data(links)
      .join('line')
      .attr('stroke', 'currentColor')
      .attr('stroke-opacity', 0.3)
      .attr('stroke-width', (d) => {
        const source = d.source as GraphNode
        if (source.type === 'root') return 2
        return 1
      })

    // Define drag behavior
    const dragBehavior = d3.drag<SVGGElement, GraphNode>()
      .on('start', (event, d) => {
        if (!event.active) simulation.alphaTarget(0.3).restart()
        d.fx = d.x
        d.fy = d.y
      })
      .on('drag', (event, d) => {
        d.fx = event.x
        d.fy = event.y
      })
      .on('end', (event, d) => {
        if (!event.active) simulation.alphaTarget(0)
        d.fx = null
        d.fy = null
      })

    // Draw nodes
    const node = g.append('g')
      .attr('class', 'nodes')
      .selectAll<SVGGElement, GraphNode>('g')
      .data(nodes)
      .join('g')
      .attr('cursor', 'pointer')
      .call(dragBehavior)
      .on('mouseenter', (event, d) => {
        const rect = containerRef.current?.getBoundingClientRect()
        if (rect) {
          setTooltipData({
            node: d,
            x: event.clientX - rect.left,
            y: event.clientY - rect.top,
          })
        }
      })
      .on('mousemove', (event) => {
        const rect = containerRef.current?.getBoundingClientRect()
        if (rect && tooltipData) {
          setTooltipData((prev) => prev ? {
            ...prev,
            x: event.clientX - rect.left,
            y: event.clientY - rect.top,
          } : null)
        }
      })
      .on('mouseleave', () => {
        setTooltipData(null)
      })

    // Node circles
    node.append('circle')
      .attr('r', (d) => {
        if (d.type === 'root') return 28
        if (d.type === 'network') return 22
        return 10
      })
      .attr('fill', (d) => {
        if (d.type === 'root') return ROOT_COLOR // blue
        if (d.type === 'network') {
          if (currentNetwork === d.vlan_id) {
            return d3.color(NETWORK_COLOR)?.brighter(0.3)?.formatHex() || NETWORK_COLOR
          }
          return NETWORK_COLOR // orange
        }
        // Device - purple
        return DEVICE_COLOR
      })
      .attr('stroke', (d) => {
        if (d.type === 'root') return '#f8fafc' // slate-50
        if (d.type === 'network') {
          return d3.color(NETWORK_COLOR)?.darker(0.3)?.formatHex() || NETWORK_COLOR
        }
        // Device border - darker purple
        return d3.color(DEVICE_COLOR)?.darker(0.3)?.formatHex() || DEVICE_COLOR
      })
      .attr('stroke-width', (d) => d.type === 'device' ? 2 : 3)

    // Root icon (NetworkBox logo from networkbox.svg)
    const rootNodes = node.filter((d) => d.type === 'root')
    // NetworkBox logo: 4 circles connected by lines (waypoints pattern)
    // Top circle
    rootNodes.append('circle')
      .attr('cx', 0)
      .attr('cy', -10)
      .attr('r', 2.5)
      .attr('fill', 'none')
      .attr('stroke', '#f8fafc')
      .attr('stroke-width', 2)
    // Left circle
    rootNodes.append('circle')
      .attr('cx', -10)
      .attr('cy', 0)
      .attr('r', 2.5)
      .attr('fill', 'none')
      .attr('stroke', '#f8fafc')
      .attr('stroke-width', 2)
    // Right circle
    rootNodes.append('circle')
      .attr('cx', 10)
      .attr('cy', 0)
      .attr('r', 2.5)
      .attr('fill', 'none')
      .attr('stroke', '#f8fafc')
      .attr('stroke-width', 2)
    // Bottom circle
    rootNodes.append('circle')
      .attr('cx', 0)
      .attr('cy', 10)
      .attr('r', 2.5)
      .attr('fill', 'none')
      .attr('stroke', '#f8fafc')
      .attr('stroke-width', 2)
    // Connecting lines (matching networkbox.svg pattern)
    // Top-left diagonal, horizontal line, bottom-right diagonal
    rootNodes.append('path')
      .attr('d', 'M-1.8,-7.7 L-7.5,-2 M-7,0 L7,0 M1.8,7.7 L7.5,2')
      .attr('fill', 'none')
      .attr('stroke', '#f8fafc')
      .attr('stroke-width', 2)
      .attr('stroke-linecap', 'round')

    // Network icon (from network.svg - tree structure with 3 boxes)
    const networkNodes = node.filter((d) => d.type === 'network')
    // Three boxes and connecting lines (scaled to fit in circle)
    // Top box
    networkNodes.append('rect')
      .attr('x', -3)
      .attr('y', -10)
      .attr('width', 6)
      .attr('height', 6)
      .attr('rx', 1)
      .attr('fill', 'none')
      .attr('stroke', 'white')
      .attr('stroke-width', 1.5)
    // Left box
    networkNodes.append('rect')
      .attr('x', -10)
      .attr('y', 4)
      .attr('width', 6)
      .attr('height', 6)
      .attr('rx', 1)
      .attr('fill', 'none')
      .attr('stroke', 'white')
      .attr('stroke-width', 1.5)
    // Right box
    networkNodes.append('rect')
      .attr('x', 4)
      .attr('y', 4)
      .attr('width', 6)
      .attr('height', 6)
      .attr('rx', 1)
      .attr('fill', 'none')
      .attr('stroke', 'white')
      .attr('stroke-width', 1.5)
    // Vertical line from top box
    networkNodes.append('path')
      .attr('d', 'M0,-4 L0,0 M-7,4 L-7,0 L7,0 L7,4')
      .attr('fill', 'none')
      .attr('stroke', 'white')
      .attr('stroke-width', 1.5)
      .attr('stroke-linecap', 'round')

    // Device icon (from laptop.svg - laptop shape)
    node.filter((d) => d.type === 'device')
      .append('path')
      .attr('d', 'M-4,-3 L4,-3 C5,-3 5,-2 5,-2 L5,2 C5,2.5 4.5,3 4,3 L-4,3 C-4.5,3 -5,2.5 -5,2 L-5,-2 C-5,-2 -5,-3 -4,-3 M-5,2 L5,2')
      .attr('fill', 'none')
      .attr('stroke', 'white')
      .attr('stroke-width', 1.5)
      .attr('stroke-linecap', 'round')
      .attr('stroke-linejoin', 'round')

    // Device count badge for networks
    node.filter((d) => d.type === 'network' && (d.deviceCount || 0) > 0)
      .append('circle')
      .attr('cx', 14)
      .attr('cy', -14)
      .attr('r', 10)
      .attr('fill', '#ef4444') // red-500

    node.filter((d) => d.type === 'network' && (d.deviceCount || 0) > 0)
      .append('text')
      .attr('x', 14)
      .attr('y', -10)
      .attr('text-anchor', 'middle')
      .attr('fill', 'white')
      .attr('font-size', '10px')
      .attr('font-weight', 'bold')
      .text((d) => d.deviceCount && d.deviceCount > 99 ? '99+' : d.deviceCount?.toString() || '0')

    // Node labels
    node.append('text')
      .attr('x', (d) => {
        if (d.type === 'root') return 0
        if (d.type === 'network') return 28
        return 14
      })
      .attr('y', (d) => {
        if (d.type === 'root') return 42
        return 4
      })
      .attr('text-anchor', (d) => d.type === 'root' ? 'middle' : 'start')
      .attr('fill', 'currentColor')
      .attr('font-size', (d) => {
        if (d.type === 'root') return '13px'
        if (d.type === 'network') return '11px'
        return '9px'
      })
      .attr('font-weight', (d) => d.type === 'root' ? '600' : '500')
      .text((d) => {
        if (d.type === 'root') return 'NetworkBox'
        if (d.type === 'device') {
          const device = d.data as DeviceNode
          const text = device.hostname || device.ip
          return truncateText(text, 12)
        }
        return truncateText(d.label, 14)
      })

    // Function to center the graph (only used for initial render or manual reset)
    const centerGraph = () => {
      const bounds = g.node()?.getBBox()
      if (bounds && bounds.width > 0 && bounds.height > 0) {
        const dx = bounds.width
        const dy = bounds.height
        const x = bounds.x + bounds.width / 2
        const y = bounds.y + bounds.height / 2
        const scale = Math.min(0.8 / Math.max(dx / width, dy / height), 1.2)
        const translate = [width / 2 - scale * x, height / 2 - scale * y]

        const newTransform = d3.zoomIdentity.translate(translate[0], translate[1]).scale(scale)
        svg.transition()
          .duration(500)
          .call(zoom.transform, newTransform)
        currentTransformRef.current = newTransform
      }
    }

    // Update positions on tick
    let tickCount = 0
    let hasCentered = false
    simulation.on('tick', () => {
      link
        .attr('x1', (d) => (d.source as GraphNode).x!)
        .attr('y1', (d) => (d.source as GraphNode).y!)
        .attr('x2', (d) => (d.target as GraphNode).x!)
        .attr('y2', (d) => (d.target as GraphNode).y!)

      node.attr('transform', (d) => `translate(${d.x},${d.y})`)

      // Only center on first initialization, not on subsequent updates
      tickCount++
      if (tickCount === 50 && !hasInitializedRef.current && !hasCentered) {
        centerGraph()
        hasCentered = true
        hasInitializedRef.current = true
      }
    })

    // Only center when simulation ends if this is the first render
    simulation.on('end', () => {
      if (!hasInitializedRef.current && !hasCentered) {
        centerGraph()
        hasInitializedRef.current = true
      }
    })

    return () => {
      simulation.stop()
    }
  }, [buildGraphData, currentNetwork, isFullscreen])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close()
      }
      if (simulationRef.current) {
        simulationRef.current.stop()
      }
      if (restartTimeoutRef.current) {
        clearTimeout(restartTimeoutRef.current)
      }
    }
  }, [])

  const handleZoomIn = () => {
    if (svgRef.current && zoomRef.current) {
      d3.select(svgRef.current)
        .transition()
        .duration(300)
        .call(zoomRef.current.scaleBy, 1.5)
    }
  }

  const handleZoomOut = () => {
    if (svgRef.current && zoomRef.current) {
      d3.select(svgRef.current)
        .transition()
        .duration(300)
        .call(zoomRef.current.scaleBy, 0.67)
    }
  }

  const handleResetZoom = () => {
    if (svgRef.current && zoomRef.current && containerRef.current) {
      const svg = d3.select(svgRef.current)
      const g = svg.select('g')
      const bounds = (g.node() as SVGGElement)?.getBBox()

      if (bounds && bounds.width > 0 && bounds.height > 0) {
        const width = containerRef.current.clientWidth
        const height = containerRef.current.clientHeight || 500
        const dx = bounds.width
        const dy = bounds.height
        const x = bounds.x + bounds.width / 2
        const y = bounds.y + bounds.height / 2
        const scale = Math.min(0.8 / Math.max(dx / width, dy / height), 1.2)
        const translate = [width / 2 - scale * x, height / 2 - scale * y]

        const newTransform = d3.zoomIdentity.translate(translate[0], translate[1]).scale(scale)
        svg.transition()
          .duration(500)
          .call(zoomRef.current.transform, newTransform)
        currentTransformRef.current = newTransform
      }
    }
  }

  const toggleFullscreen = useCallback(async () => {
    if (!cardRef.current) return

    try {
      if (!document.fullscreenElement) {
        await cardRef.current.requestFullscreen()
        setIsFullscreen(true)
      } else {
        await document.exitFullscreen()
        setIsFullscreen(false)
      }
      // Reset zoom after fullscreen toggle to fit the new container size
      setTimeout(() => {
        handleResetZoom()
      }, 100)
    } catch (err) {
      console.error('Fullscreen error:', err)
    }
  }, [])

  // Listen for fullscreen change events (e.g., user presses ESC)
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
      // Reset zoom when fullscreen state changes
      setTimeout(() => {
        handleResetZoom()
      }, 100)
    }
    document.addEventListener('fullscreenchange', handleFullscreenChange)
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange)
  }, [])

  return (
    <Card
      ref={cardRef}
      className={cn(
        'col-span-full',
        isFullscreen && 'h-screen rounded-none'
      )}
    >
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div className="flex items-center gap-2">
          <Network className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg">Network Topology</CardTitle>
        </div>
        <div className="flex items-center gap-2">
          {scanStatus && (
            <Badge
              variant={error ? 'destructive' : 'secondary'}
              className={cn(
                'font-normal',
                isLiveMode && !error && 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100'
              )}
            >
              {error ? (
                <AlertCircle className="h-3 w-3 mr-1" />
              ) : isScanning ? (
                <Loader2 className="h-3 w-3 mr-1 animate-spin" />
              ) : isLiveMode ? (
                <span className="relative flex h-2 w-2 mr-1.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
              ) : null}
              {scanStatus}
            </Badge>
          )}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={handleZoomOut} disabled={networks.length === 0}>
                  <ZoomOut className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Zoom Out</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={handleZoomIn} disabled={networks.length === 0}>
                  <ZoomIn className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Zoom In</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={handleResetZoom} disabled={networks.length === 0}>
                  <Focus className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Reset View</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={toggleFullscreen}>
                  {isFullscreen ? (
                    <Minimize2 className="h-4 w-4" />
                  ) : (
                    <Maximize2 className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={isLiveMode ? 'default' : 'outline'}
                  size="icon"
                  onClick={toggleLiveMode}
                  className={cn(isLiveMode && 'bg-green-600 hover:bg-green-700')}
                >
                  {isLiveMode ? (
                    <Radio className="h-4 w-4" />
                  ) : (
                    <Pause className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>{isLiveMode ? 'Live Mode Active - Click to Pause' : 'Paused - Click to Resume'}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="icon" onClick={() => startScan(true)} disabled={isScanning}>
                  {isScanning ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCw className="h-4 w-4" />
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Refresh Scan</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </CardHeader>
      <CardContent className={cn(isFullscreen && 'flex-1 pb-4')}>
        <div
          ref={containerRef}
          className={cn(
            'relative w-full rounded-lg border bg-muted/20',
            isFullscreen ? 'h-[calc(100vh-120px)]' : 'h-[500px]',
            'overflow-hidden'
          )}
        >
          <svg
            ref={svgRef}
            width="100%"
            height="100%"
            className="text-foreground"
          />

          {/* Custom Tooltip */}
          {tooltipData && (
            <div
              ref={tooltipRef}
              className="absolute z-50 pointer-events-none bg-popover text-popover-foreground border rounded-lg shadow-lg p-3 text-sm max-w-xs"
              style={{
                left: tooltipData.x + 15,
                top: tooltipData.y - 10,
                transform: tooltipData.x > 400 ? 'translateX(-100%)' : undefined,
              }}
            >
              {tooltipData.node.type === 'root' && (
                <div className="space-y-1">
                  <div className="flex items-center gap-2 font-semibold">
                    <Waypoints className="h-4 w-4" />
                    NetworkBox
                  </div>
                  <p className="text-muted-foreground text-xs">Central management server</p>
                  <div className="flex gap-4 text-xs mt-2">
                    <span><strong>{networks.length}</strong> Networks</span>
                    <span><strong>{totalDevices}</strong> Devices</span>
                  </div>
                </div>
              )}
              {tooltipData.node.type === 'network' && tooltipData.node.data && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 font-semibold">
                    <Network className="h-4 w-4" style={{ color: NETWORK_COLOR }} />
                    {(tooltipData.node.data as NetworkNode).name}
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
                    <span className="text-muted-foreground">VLAN:</span>
                    <span className="font-mono">{(tooltipData.node.data as NetworkNode).vlan_id}</span>
                    <span className="text-muted-foreground">Subnet:</span>
                    <span className="font-mono">{(tooltipData.node.data as NetworkNode).address}/{(tooltipData.node.data as NetworkNode).mask}</span>
                    <span className="text-muted-foreground">Devices:</span>
                    <span className="font-semibold">{tooltipData.node.deviceCount || 0}</span>
                  </div>
                </div>
              )}
              {tooltipData.node.type === 'device' && tooltipData.node.data && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2 font-semibold">
                    <Monitor className="h-4 w-4" style={{ color: DEVICE_COLOR }} />
                    {(tooltipData.node.data as DeviceNode).hostname || 'Unknown Host'}
                  </div>
                  <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-xs">
                    <span className="text-muted-foreground">IP:</span>
                    <span className="font-mono">{(tooltipData.node.data as DeviceNode).ip}</span>
                    <span className="text-muted-foreground">MAC:</span>
                    <span className="font-mono text-[11px]">{(tooltipData.node.data as DeviceNode).mac}</span>
                    {(tooltipData.node.data as DeviceNode).vendor && (
                      <>
                        <span className="text-muted-foreground">Vendor:</span>
                        <span>{(tooltipData.node.data as DeviceNode).vendor}</span>
                      </>
                    )}
                    <span className="text-muted-foreground">Network:</span>
                    <span>VLAN {tooltipData.node.vlan_id}</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Legend */}
          <div className="absolute bottom-4 left-4 flex gap-4 text-xs text-muted-foreground bg-background/80 backdrop-blur-sm rounded-md px-3 py-2">
            <div className="flex items-center gap-1.5">
              <Waypoints className="h-3 w-3" style={{ color: ROOT_COLOR }} />
              <span>NetworkBox</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Network className="h-3 w-3" style={{ color: NETWORK_COLOR }} />
              <span>Network</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Monitor className="h-3 w-3" style={{ color: DEVICE_COLOR }} />
              <span>Host</span>
            </div>
          </div>

          {/* Stats */}
          {totalDevices > 0 && (
            <div className="absolute top-4 right-4 text-xs text-muted-foreground bg-background/80 backdrop-blur-sm rounded-md px-3 py-2">
              <div className="flex items-center gap-2">
                <Monitor className="h-3 w-3" style={{ color: DEVICE_COLOR }} />
                <span>{totalDevices} hosts</span>
              </div>
              <div className="flex items-center gap-2">
                <Network className="h-3 w-3" style={{ color: NETWORK_COLOR }} />
                <span>{networks.length} networks</span>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
