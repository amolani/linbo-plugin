import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AuthProvider } from '@/context/auth-context'
import { AdminLayout } from '@/components/layout/admin-layout'
import { LoginPage } from '@/pages/login'
import { DashboardPage } from '@/pages/dashboard'
import { NetworksPage } from '@/pages/networks'
import { NAPIPage } from '@/pages/napi'
import { MDNSPage } from '@/pages/mdns'
import { RadiusPage } from '@/pages/radius'
import { AuthenticationPage } from '@/pages/authentication'
import { ContainersPage } from '@/pages/containers'
import { WOLPage } from '@/pages/wol'
import { CertificatesPage } from '@/pages/certificates'
import { ReverseProxyPage } from '@/pages/reverseproxy'
import { ProxyPage } from '@/pages/proxy'
import { KMSPage } from '@/pages/kms'
import { ToolsPage } from '@/pages/tools'
import { MonitoringPage } from '@/pages/monitoring'

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <AuthProvider>
          <div className="dark">
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<Navigate to="home" replace />} />
                <Route path="home" element={<DashboardPage />} />
                <Route path="networks" element={<NetworksPage />} />
                <Route path="napi" element={<NAPIPage />} />
                <Route path="mdns" element={<MDNSPage />} />
                <Route path="radius" element={<RadiusPage />} />
                <Route path="authentication" element={<AuthenticationPage />} />
                <Route path="containers" element={<ContainersPage />} />
                <Route path="wol" element={<WOLPage />} />
                <Route path="certificates" element={<CertificatesPage />} />
                <Route path="reverseproxy" element={<ReverseProxyPage />} />
                <Route path="proxy" element={<ProxyPage />} />
                <Route path="kms" element={<KMSPage />} />
                <Route path="tools" element={<ToolsPage />} />
                <Route path="monitoring" element={<MonitoringPage />} />
              </Route>
              <Route path="/" element={<Navigate to="/login" replace />} />
              <Route path="*" element={<Navigate to="/login" replace />} />
            </Routes>
          </div>
        </AuthProvider>
      </BrowserRouter>
    </QueryClientProvider>
  )
}

export default App
