import { useQuery } from '@tanstack/react-query'
import api from '@/lib/api'
import type { Container } from '@/types'
import { useState, useEffect, useCallback } from 'react'

export function useContainers() {
  return useQuery<Container[]>({
    queryKey: ['containers'],
    queryFn: async () => {
      const response = await api.get('/containers')
      return response.data
    },
    refetchInterval: 5000,
  })
}

export function useContainerLogs(containerId: string | null) {
  const [logs, setLogs] = useState<string[]>([])
  const [isConnected, setIsConnected] = useState(false)

  const clearLogs = useCallback(() => {
    setLogs([])
  }, [])

  useEffect(() => {
    if (!containerId) {
      setLogs([])
      setIsConnected(false)
      return
    }

    const token = localStorage.getItem('access_token')
    const eventSource = new EventSource(
      `/api/v1/containers/${containerId}/logs?token=${token}`
    )

    eventSource.onopen = () => {
      setIsConnected(true)
    }

    eventSource.onmessage = (event) => {
      setLogs((prev) => [...prev, event.data])
    }

    eventSource.onerror = () => {
      setIsConnected(false)
      eventSource.close()
    }

    return () => {
      eventSource.close()
      setIsConnected(false)
    }
  }, [containerId])

  return { logs, isConnected, clearLogs }
}
