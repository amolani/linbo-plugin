import { useMutation } from '@tanstack/react-query'
import api from '@/lib/api'
import type { SophosXGSConnection, SophosXGSNetworkVLAN } from '@/types'

export function useSophosNetworkVLANs() {
  return useMutation<SophosXGSNetworkVLAN[], Error, SophosXGSConnection>({
    mutationFn: async (connection) => {
      const response = await api.post('/sophos/network/vlans/list', connection)
      return response.data
    },
  })
}

export function useSophosCertificatesList() {
  return useMutation<
    { name: string; valid_from: string; valid_to: string }[],
    Error,
    SophosXGSConnection
  >({
    mutationFn: async (connection) => {
      const response = await api.post('/sophos/certificates/list', connection)
      return response.data
    },
  })
}

export function useSophosCertificateDownload() {
  return useMutation<
    { cert_pem: string; key_pem: string; valid_from: string; valid_to: string },
    Error,
    { connection: SophosXGSConnection; certName: string }
  >({
    mutationFn: async ({ connection, certName }) => {
      const response = await api.post(`/sophos/certificates/${certName}/download`, connection)
      return response.data
    },
  })
}
