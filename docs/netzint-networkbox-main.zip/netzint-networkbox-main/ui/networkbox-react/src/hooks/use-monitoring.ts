import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type {
  MonitoringConfig,
  MonitoredSwitch,
  MonitoredSwitchUpdate,
  SwitchConnection,
  LoopIncident,
  LoopIncidentUpdate,
  MonitoringStatus,
  MACFlappingData,
  SwitchMetrics,
  UniFiConfig,
  APIResponse,
} from '@/types'

// ============================================================================
// Configuration
// ============================================================================

export function useMonitoringConfig() {
  return useQuery<MonitoringConfig>({
    queryKey: ['monitoring', 'config'],
    queryFn: async () => {
      const response = await api.get('/monitoring/config')
      return response.data
    },
  })
}

export function useUpdateMonitoringConfig() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, MonitoringConfig>({
    mutationFn: async (config) => {
      const response = await api.post('/monitoring/config', config)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'config'] })
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'status'] })
    },
  })
}

// ============================================================================
// UniFi Integration
// ============================================================================

export function useTestUniFiConnection() {
  return useMutation<APIResponse, Error, UniFiConfig>({
    mutationFn: async (config) => {
      const response = await api.post('/monitoring/unifi/test', config)
      return response.data
    },
  })
}

export function useDiscoverUniFiSwitches() {
  const queryClient = useQueryClient()

  return useMutation<MonitoredSwitch[], Error, void>({
    mutationFn: async () => {
      const response = await api.post('/monitoring/unifi/discover')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'switches'] })
    },
  })
}

// ============================================================================
// Switches
// ============================================================================

export function useMonitoredSwitches() {
  return useQuery<MonitoredSwitch[]>({
    queryKey: ['monitoring', 'switches'],
    queryFn: async () => {
      const response = await api.get('/monitoring/switches')
      return response.data
    },
  })
}

export function useMonitoredSwitch(name: string) {
  return useQuery<MonitoredSwitch>({
    queryKey: ['monitoring', 'switches', name],
    queryFn: async () => {
      const response = await api.get(`/monitoring/switches/${name}`)
      return response.data
    },
    enabled: !!name,
  })
}

export function useAddSwitch() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, MonitoredSwitch>({
    mutationFn: async (switchData) => {
      const response = await api.post('/monitoring/switches', switchData)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'switches'] })
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'status'] })
    },
  })
}

export function useUpdateSwitch() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, { name: string; update: MonitoredSwitchUpdate }>({
    mutationFn: async ({ name, update }) => {
      const response = await api.patch(`/monitoring/switches/${name}`, update)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'switches'] })
    },
  })
}

export function useDeleteSwitch() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.delete(`/monitoring/switches/${name}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'switches'] })
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'status'] })
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'connections'] })
    },
  })
}

export function useTestSwitchSNMP() {
  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.post(`/monitoring/switches/${name}/test`)
      return response.data
    },
  })
}

// ============================================================================
// Connections (Topology)
// ============================================================================

export function useSwitchConnections() {
  return useQuery<SwitchConnection[]>({
    queryKey: ['monitoring', 'connections'],
    queryFn: async () => {
      const response = await api.get('/monitoring/connections')
      return response.data
    },
  })
}

export function useAddConnection() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, SwitchConnection>({
    mutationFn: async (connection) => {
      const response = await api.post('/monitoring/connections', connection)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'connections'] })
    },
  })
}

export function useDeleteConnection() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, SwitchConnection>({
    mutationFn: async (connection) => {
      const response = await api.delete('/monitoring/connections', {
        params: {
          from_switch: connection.from_switch,
          from_port: connection.from_port,
          to_switch: connection.to_switch,
          to_port: connection.to_port,
        },
      })
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'connections'] })
    },
  })
}

// ============================================================================
// Incidents
// ============================================================================

export function useIncidents(status?: string, severity?: string) {
  return useQuery<LoopIncident[]>({
    queryKey: ['monitoring', 'incidents', { status, severity }],
    queryFn: async () => {
      const params = new URLSearchParams()
      if (status) params.append('status', status)
      if (severity) params.append('severity', severity)
      const response = await api.get(`/monitoring/incidents?${params.toString()}`)
      return response.data
    },
    refetchInterval: 10000,
  })
}

export function useIncident(id: string) {
  return useQuery<LoopIncident>({
    queryKey: ['monitoring', 'incidents', id],
    queryFn: async () => {
      const response = await api.get(`/monitoring/incidents/${id}`)
      return response.data
    },
    enabled: !!id,
  })
}

export function useUpdateIncident() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, { id: string; update: LoopIncidentUpdate }>({
    mutationFn: async ({ id, update }) => {
      const response = await api.patch(`/monitoring/incidents/${id}`, update)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'incidents'] })
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'status'] })
    },
  })
}

export function useDeleteIncident() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (id) => {
      const response = await api.delete(`/monitoring/incidents/${id}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'incidents'] })
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'status'] })
    },
  })
}

// ============================================================================
// Status & Live Data
// ============================================================================

export function useMonitoringStatus() {
  return useQuery<MonitoringStatus>({
    queryKey: ['monitoring', 'status'],
    queryFn: async () => {
      const response = await api.get('/monitoring/status')
      return response.data
    },
    refetchInterval: 5000,
  })
}

export function useMACFlapping() {
  return useQuery<MACFlappingData>({
    queryKey: ['monitoring', 'mac-flapping'],
    queryFn: async () => {
      const response = await api.get('/monitoring/mac-flapping')
      return response.data
    },
    refetchInterval: 5000,
  })
}

export function useSwitchMetrics(switchName: string) {
  return useQuery<SwitchMetrics>({
    queryKey: ['monitoring', 'metrics', switchName],
    queryFn: async () => {
      const response = await api.get(`/monitoring/metrics/${switchName}`)
      return response.data
    },
    enabled: !!switchName,
    refetchInterval: 10000,
  })
}

// ============================================================================
// Scheduler Control
// ============================================================================

export function useStartMonitoring() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, void>({
    mutationFn: async () => {
      const response = await api.post('/monitoring/start')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'status'] })
    },
  })
}

export function useStopMonitoring() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, void>({
    mutationFn: async () => {
      const response = await api.post('/monitoring/stop')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['monitoring', 'status'] })
    },
  })
}
