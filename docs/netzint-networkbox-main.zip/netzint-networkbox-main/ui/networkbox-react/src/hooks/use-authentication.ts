import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { Authentication, AuthenticationTest, APIResponse } from '@/types'

export function useAuthenticationList() {
  return useQuery<Authentication[]>({
    queryKey: ['authentications'],
    queryFn: async () => {
      const response = await api.get('/authentications')
      return response.data
    },
  })
}

export function useAuthentication(name: string) {
  return useQuery<Authentication>({
    queryKey: ['authentications', name],
    queryFn: async () => {
      const response = await api.get(`/authentications/${name}`)
      return response.data
    },
    enabled: !!name,
  })
}

export function useCreateAuthentication() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, Authentication>({
    mutationFn: async (auth) => {
      const response = await api.post('/authentications', auth)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['authentications'] })
    },
  })
}

export function useUpdateAuthentication() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, { name: string; data: Partial<Authentication> }>({
    mutationFn: async ({ name, data }) => {
      const response = await api.patch(`/authentications/${name}`, data)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['authentications'] })
    },
  })
}

export function useDeleteAuthentication() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.delete(`/authentications/${name}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['authentications'] })
    },
  })
}

export function useTestAuthentication() {
  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.post(`/authentications/${name}/test`)
      return response.data
    },
  })
}

export function useTestAuthenticationInline() {
  return useMutation<APIResponse, Error, AuthenticationTest>({
    mutationFn: async (auth) => {
      const response = await api.post('/authentications/test', auth)
      return response.data
    },
  })
}

export function useAuthenticationGroups(name: string) {
  return useQuery<string[]>({
    queryKey: ['authentications', name, 'groups'],
    queryFn: async () => {
      const response = await api.get(`/authentications/${name}/groups`)
      return response.data
    },
    enabled: !!name,
  })
}
