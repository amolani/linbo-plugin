import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { CertificateSource, Certificate, APIResponse } from '@/types'

// Certificate Sources
export function useCertificateSources() {
  return useQuery<CertificateSource[]>({
    queryKey: ['certificate-sources'],
    queryFn: async () => {
      const response = await api.get('/certificates/sources')
      return response.data
    },
  })
}

export function useCreateCertificateSource() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, CertificateSource>({
    mutationFn: async (source) => {
      const response = await api.post('/certificates/sources', source)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificate-sources'] })
    },
  })
}

export function useDeleteCertificateSource() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.delete(`/certificates/sources/${name}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificate-sources'] })
      queryClient.invalidateQueries({ queryKey: ['certificates'] })
    },
  })
}

export interface SophosCertificateInfo {
  name: string
  action: string
  valid_from: string
  valid_to: string
  cert_file: string | null
  key_file: string | null
}

export function useSourceCertificates(sourceName: string) {
  return useQuery<SophosCertificateInfo[]>({
    queryKey: ['certificate-sources', sourceName, 'certificates'],
    queryFn: async () => {
      const response = await api.get(`/certificates/sources/${sourceName}/certificates`)
      return response.data
    },
    enabled: !!sourceName,
  })
}

export function useTestCertificateSource() {
  return useMutation<APIResponse, Error, string>({
    mutationFn: async (sourceName) => {
      const response = await api.post(`/certificates/sources/${sourceName}/test`)
      return response.data
    },
  })
}

export function useSyncCertificateSource() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, { sourceName: string; certName?: string; add?: boolean; remove?: boolean }>({
    mutationFn: async ({ sourceName, certName, add, remove }) => {
      const params = new URLSearchParams()
      if (certName) params.append('cert_name', certName)
      if (add) params.append('add', 'true')
      if (remove) params.append('remove', 'true')
      const query = params.toString()
      const url = query
        ? `/certificates/sources/${sourceName}/sync?${query}`
        : `/certificates/sources/${sourceName}/sync`
      const response = await api.post(url)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificates'] })
      queryClient.invalidateQueries({ queryKey: ['certificate-sources'] })
    },
  })
}

// Certificates
export function useCertificates() {
  return useQuery<Certificate[]>({
    queryKey: ['certificates'],
    queryFn: async () => {
      const response = await api.get('/certificates')
      return response.data
    },
  })
}

export function useCertificate(name: string) {
  return useQuery<Certificate>({
    queryKey: ['certificates', name],
    queryFn: async () => {
      const response = await api.get(`/certificates/${name}`)
      return response.data
    },
    enabled: !!name,
  })
}

export function useUploadCertificate() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, { name: string; cert_pem: string; key_pem: string }>({
    mutationFn: async (data) => {
      const response = await api.post('/certificates/upload', data)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificates'] })
    },
  })
}

export function useGenerateCertificate() {
  const queryClient = useQueryClient()

  return useMutation<
    APIResponse,
    Error,
    {
      name: string
      common_name: string
      organization?: string
      organizational_unit?: string
      country?: string
      state?: string
      locality?: string
      san_dns?: string[]
      san_ip?: string[]
      validity_days?: number
      key_size?: number
    }
  >({
    mutationFn: async (data) => {
      const response = await api.post('/certificates/generate', data)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificates'] })
    },
  })
}

export function useDeleteCertificate() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.delete(`/certificates/${name}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['certificates'] })
    },
  })
}
