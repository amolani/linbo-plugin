import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { ProxyConfig, APIResponse } from '@/types'

export function useProxyConfig() {
  return useQuery<ProxyConfig | null>({
    queryKey: ['proxy-config'],
    queryFn: async () => {
      const response = await api.get('/proxy/config')
      return response.data
    },
  })
}

export function useProxyStatus() {
  return useQuery<APIResponse>({
    queryKey: ['proxy-status'],
    queryFn: async () => {
      const response = await api.get('/proxy/status')
      return response.data
    },
    refetchInterval: 5000,
  })
}

export function useCreateProxyConfig() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, ProxyConfig>({
    mutationFn: async (config) => {
      const response = await api.post('/proxy/config', config)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proxy-config'] })
    },
  })
}

export function useUpdateProxyConfig() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, Partial<ProxyConfig>>({
    mutationFn: async (data) => {
      const response = await api.patch('/proxy/config', data)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proxy-config'] })
    },
  })
}

export function useStartProxy() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error>({
    mutationFn: async () => {
      const response = await api.post('/proxy/start')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proxy-status'] })
    },
  })
}

export function useStopProxy() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error>({
    mutationFn: async () => {
      const response = await api.post('/proxy/stop')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proxy-status'] })
    },
  })
}
