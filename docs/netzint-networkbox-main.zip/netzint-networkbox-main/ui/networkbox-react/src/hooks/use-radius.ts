import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { Radius, APIResponse } from '@/types'

export function useRadiusList() {
  return useQuery<Radius[]>({
    queryKey: ['radius'],
    queryFn: async () => {
      const response = await api.get('/radius')
      return response.data
    },
  })
}

export function useRadius(name: string) {
  return useQuery<Radius>({
    queryKey: ['radius', name],
    queryFn: async () => {
      const response = await api.get(`/radius/${name}`)
      return response.data
    },
    enabled: !!name,
  })
}

export function useCreateRadius() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, Radius>({
    mutationFn: async (radius) => {
      const response = await api.post('/radius', radius)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['radius'] })
    },
  })
}

export function useUpdateRadius() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, { name: string; data: Partial<Radius> }>({
    mutationFn: async ({ name, data }) => {
      const response = await api.patch(`/radius/${name}`, data)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['radius'] })
    },
  })
}

export function useDeleteRadius() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.delete(`/radius/${name}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['radius'] })
    },
  })
}

export function useStartRadius() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.post(`/radius/${name}/start`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['radius'] })
    },
  })
}

export function useStopRadius() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.post(`/radius/${name}/stop`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['radius'] })
    },
  })
}
