import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { ReverseProxy, APIResponse } from '@/types'

export function useReverseProxies() {
  return useQuery<ReverseProxy[]>({
    queryKey: ['reverse-proxies'],
    queryFn: async () => {
      const response = await api.get('/reverseproxy')
      return response.data
    },
  })
}

export function useReverseProxy(name: string) {
  return useQuery<ReverseProxy>({
    queryKey: ['reverse-proxies', name],
    queryFn: async () => {
      const response = await api.get(`/reverseproxy/${name}`)
      return response.data
    },
    enabled: !!name,
  })
}

export function useCreateReverseProxy() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, ReverseProxy>({
    mutationFn: async (proxy) => {
      const response = await api.post('/reverseproxy', proxy)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reverse-proxies'] })
    },
  })
}

export function useUpdateReverseProxy() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, { name: string; data: Partial<ReverseProxy> }>({
    mutationFn: async ({ name, data }) => {
      const response = await api.patch(`/reverseproxy/${name}`, data)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reverse-proxies'] })
    },
  })
}

export function useDeleteReverseProxy() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.delete(`/reverseproxy/${name}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reverse-proxies'] })
    },
  })
}

export function useStartReverseProxy() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.post(`/reverseproxy/${name}/start`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reverse-proxies'] })
    },
  })
}

export function useStopReverseProxy() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.post(`/reverseproxy/${name}/stop`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reverse-proxies'] })
    },
  })
}
