import { useState, useCallback, useRef } from 'react'
import axios from 'axios'

export interface LogEntry {
  timestamp: string
  level: 'info' | 'success' | 'error' | 'warning'
  message: string
}

export interface ActionStreamState {
  isOpen: boolean
  isRunning: boolean
  logs: LogEntry[]
  title: string
  success: boolean | null
}

async function getValidToken(): Promise<string | null> {
  let token = localStorage.getItem('access_token')

  if (!token) {
    // Try to refresh
    try {
      const response = await axios.post('/api/v1/refresh', {}, { withCredentials: true })
      token = response.data.access_token
      if (token) {
        localStorage.setItem('access_token', token)
      }
    } catch {
      return null
    }
  }

  return token
}

export function useActionStream() {
  const [state, setState] = useState<ActionStreamState>({
    isOpen: false,
    isRunning: false,
    logs: [],
    title: '',
    success: null,
  })

  const abortControllerRef = useRef<AbortController | null>(null)

  const startStream = useCallback((url: string, title: string) => {
    // Abort any existing connection
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
    }

    const abortController = new AbortController()
    abortControllerRef.current = abortController

    setState({
      isOpen: true,
      isRunning: true,
      logs: [],
      title,
      success: null,
    })

    const processStream = async () => {
      try {
        // Get valid token (refresh if needed)
        const token = await getValidToken()

        if (!token) {
          throw new Error('No authentication token available')
        }

        // Add token to URL for authentication
        const separator = url.includes('?') ? '&' : '?'
        const streamUrl = `${url}${separator}token=${encodeURIComponent(token)}`

        let response = await fetch(streamUrl, {
          method: 'GET',
          headers: {
            'Accept': 'text/event-stream',
          },
          signal: abortController.signal,
        })

        // If unauthorized, try to refresh token and retry
        if (response.status === 401) {
          try {
            const refreshResponse = await axios.post('/api/v1/refresh', {}, { withCredentials: true })
            const newToken = refreshResponse.data.access_token
            if (newToken) {
              localStorage.setItem('access_token', newToken)
              const newStreamUrl = `${url}${separator}token=${encodeURIComponent(newToken)}`
              response = await fetch(newStreamUrl, {
                method: 'GET',
                headers: {
                  'Accept': 'text/event-stream',
                },
                signal: abortController.signal,
              })
            }
          } catch {
            throw new Error('Authentication failed - please log in again')
          }
        }

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`)
        }

        const reader = response.body?.getReader()
        if (!reader) {
          throw new Error('No response body')
        }

        const decoder = new TextDecoder()
        let buffer = ''

        while (true) {
          const { done, value } = await reader.read()

          if (done) {
            break
          }

          buffer += decoder.decode(value, { stream: true })

          // Process complete SSE messages
          const lines = buffer.split('\n')
          buffer = lines.pop() || '' // Keep incomplete line in buffer

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6)
              // Parse log line: [HH:MM:SS] [LEVEL] message
              const match = data.match(/^\[(\d{2}:\d{2}:\d{2})\] \[(\w+)\] (.*)$/)
              if (match) {
                const [, timestamp, level, message] = match
                setState((prev) => ({
                  ...prev,
                  logs: [
                    ...prev.logs,
                    {
                      timestamp,
                      level: level.toLowerCase() as LogEntry['level'],
                      message,
                    },
                  ],
                }))
              }
            } else if (line.startsWith('event: done')) {
              // Next data line will contain the done event data
            } else if (line.includes('"success"')) {
              // Parse done event data
              try {
                const jsonMatch = line.match(/\{.*\}/)
                if (jsonMatch) {
                  const doneData = JSON.parse(jsonMatch[0])
                  setState((prev) => ({
                    ...prev,
                    isRunning: false,
                    success: doneData.success,
                  }))
                  // Close the connection after receiving done event
                  try {
                    await reader.cancel()
                  } catch {
                    // Ignore cancel errors - stream may already be closed
                  }
                  return
                }
              } catch {
                // Ignore parse errors
              }
            }
          }
        }

        // Stream completed normally
        setState((prev) => {
          if (prev.isRunning) {
            return { ...prev, isRunning: false }
          }
          return prev
        })

      } catch (error) {
        if (error instanceof Error && error.name === 'AbortError') {
          // Intentional abort, ignore
          return
        }

        // Check if this is a stream read error
        const errorMessage = error instanceof Error ? error.message : 'Connection lost'
        const isStreamReadError = errorMessage.includes('input stream') ||
                                   errorMessage.includes('network') ||
                                   errorMessage.includes('TypeError') ||
                                   errorMessage.includes('Failed to fetch')

        setState((prev) => {
          // If we already have a success result, don't override it with an error
          if (prev.success === true) {
            return { ...prev, isRunning: false }
          }

          // If it's a stream read error and we're not running anymore, ignore it
          if (isStreamReadError && !prev.isRunning) {
            return prev
          }

          // For stream read errors during container operations (restart, start, etc.),
          // check if the last log message indicates the operation was in progress.
          // The connection may drop during container restart but the operation likely succeeded.
          if (isStreamReadError && prev.logs.length > 0) {
            const lastLog = prev.logs[prev.logs.length - 1]
            const operationInProgress =
              lastLog.message.toLowerCase().includes('restarting') ||
              lastLog.message.toLowerCase().includes('starting') ||
              lastLog.message.toLowerCase().includes('stopping') ||
              lastLog.message.toLowerCase().includes('installing') ||
              lastLog.message.toLowerCase().includes('may take')

            if (operationInProgress) {
              // Assume success since the operation was in progress when connection dropped
              return {
                ...prev,
                isRunning: false,
                success: true,
                logs: [
                  ...prev.logs,
                  {
                    timestamp: new Date().toLocaleTimeString('de-DE', {
                      hour: '2-digit',
                      minute: '2-digit',
                      second: '2-digit',
                    }),
                    level: 'success',
                    message: 'Operation completed (connection closed)',
                  },
                ],
              }
            }
          }

          console.error('Stream error:', error)
          return {
            ...prev,
            isRunning: false,
            success: false,
            logs: [
              ...prev.logs,
              {
                timestamp: new Date().toLocaleTimeString('de-DE', {
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                }),
                level: 'error',
                message: errorMessage,
              },
            ],
          }
        })
      }
    }

    processStream()
  }, [])

  const close = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort()
      abortControllerRef.current = null
    }
    setState((prev) => ({ ...prev, isOpen: false }))
  }, [])

  return {
    ...state,
    startStream,
    close,
  }
}
