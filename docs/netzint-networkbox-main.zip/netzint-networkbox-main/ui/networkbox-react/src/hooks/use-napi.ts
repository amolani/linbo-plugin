import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { APIResponse, ARPScanResult, PINGScanResult, NAPIStatus } from '@/types'

export function useNAPIStatus() {
  return useQuery<NAPIStatus>({
    queryKey: ['napi', 'status'],
    queryFn: async () => {
      const response = await api.get('/napi/status')
      return response.data
    },
    refetchInterval: 30000,
  })
}

export function useStartNAPI() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error>({
    mutationFn: async () => {
      const response = await api.post('/napi/start')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['napi', 'status'] })
    },
  })
}

export function useStopNAPI() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error>({
    mutationFn: async () => {
      const response = await api.post('/napi/stop')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['napi', 'status'] })
    },
  })
}

export function useRestartNAPI() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error>({
    mutationFn: async () => {
      const response = await api.post('/napi/restart')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['napi', 'status'] })
    },
  })
}

export function useWakeOnLAN() {
  return useMutation<APIResponse, Error, { mac: string; ip?: string; port?: number }>({
    mutationFn: async ({ mac, ip = '255.255.255.255', port = 9 }) => {
      const response = await api.post('/napi/wake', { mac, ip, port })
      return response.data
    },
  })
}

export function useARPScan() {
  return useMutation<ARPScanResult, Error, number>({
    mutationFn: async (vlanId) => {
      const response = await api.post('/napi/arp-scan', { vlan_id: vlanId })
      return response.data
    },
  })
}

export function usePingScan() {
  return useMutation<PINGScanResult, Error, number>({
    mutationFn: async (vlanId) => {
      const response = await api.post('/napi/ping-scan', { vlan_id: vlanId })
      return response.data
    },
  })
}
