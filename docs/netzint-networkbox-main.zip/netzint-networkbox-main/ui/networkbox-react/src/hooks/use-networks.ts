import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { Network, APIResponse } from '@/types'

export function useNetworks() {
  return useQuery<Network[]>({
    queryKey: ['networks'],
    queryFn: async () => {
      const response = await api.get('/networks')
      return response.data
    },
  })
}

export function useInterfaces() {
  return useQuery<string[]>({
    queryKey: ['interfaces'],
    queryFn: async () => {
      const response = await api.get('/interfaces')
      return response.data
    },
  })
}

export function useNetwork(vlanId: number) {
  return useQuery<Network>({
    queryKey: ['networks', vlanId],
    queryFn: async () => {
      const response = await api.get(`/networks/${vlanId}`)
      return response.data
    },
    enabled: !!vlanId,
  })
}

export function useCreateNetwork() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, Network>({
    mutationFn: async (network) => {
      const response = await api.post('/networks', network)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['networks'] })
    },
  })
}

export function useUpdateNetwork() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, { vlanId: number; data: Partial<Network> }>({
    mutationFn: async ({ vlanId, data }) => {
      const response = await api.put(`/networks/${vlanId}`, data)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['networks'] })
    },
  })
}

export function useDeleteNetwork() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, number>({
    mutationFn: async (vlanId) => {
      const response = await api.delete(`/networks/${vlanId}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['networks'] })
    },
  })
}

// Network utility functions
export function maskToCidr(mask: string): number {
  return mask
    .split('.')
    .map(Number)
    .reduce((acc, octet) => acc + octet.toString(2).split('1').length - 1, 0)
}

export function isIpInNetwork(ip: string, network: string, mask: string): boolean {
  const ipInt = ipv4ToInt(ip)
  const networkInt = ipv4ToInt(network)
  const maskInt = maskToInt(mask)
  return (ipInt & maskInt) === (networkInt & maskInt)
}

export function getSecondToLastIP(network: string, mask: string): string {
  const networkInt = ipv4ToInt(network)
  const maskInt = maskToInt(mask)
  const broadcastInt = networkInt | ~maskInt
  return intToIpv4(broadcastInt - 1)
}

function ipv4ToInt(ip: string): number {
  return ip.split('.').reduce((acc, octet) => (acc << 8) + parseInt(octet, 10), 0) >>> 0
}

function maskToInt(mask: string): number {
  return ipv4ToInt(mask)
}

function intToIpv4(n: number): string {
  return [(n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.')
}
