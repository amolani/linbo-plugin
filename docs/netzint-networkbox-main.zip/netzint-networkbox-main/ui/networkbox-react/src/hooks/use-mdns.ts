import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { MDNS, MDNSCluster, APIResponse } from '@/types'

export function useMDNSList() {
  return useQuery<MDNS[]>({
    queryKey: ['mdns'],
    queryFn: async () => {
      const response = await api.get('/mdns')
      return response.data
    },
  })
}

export function useMDNSCluster() {
  return useQuery<MDNSCluster>({
    queryKey: ['mdns', 'cluster'],
    queryFn: async () => {
      const response = await api.get('/mdns/cluster')
      return response.data
    },
  })
}

export function useMDNS(name: string) {
  return useQuery<MDNS>({
    queryKey: ['mdns', name],
    queryFn: async () => {
      const response = await api.get(`/mdns/${name}`)
      return response.data
    },
    enabled: !!name,
  })
}

export function useCreateMDNS() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, MDNS>({
    mutationFn: async (mdns) => {
      const response = await api.post('/mdns', mdns)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mdns'] })
    },
  })
}

export function useUpdateMDNS() {
  const queryClient = useQueryClient()

  return useMutation<
    APIResponse,
    Error,
    { name: string; network1_address: string; network2_address: string }
  >({
    mutationFn: async ({ name, network1_address, network2_address }) => {
      const response = await api.patch(`/mdns/${name}`, {
        network1_address,
        network2_address,
      })
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mdns'] })
    },
  })
}

export function useDeleteMDNS() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.delete(`/mdns/${name}`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mdns'] })
    },
  })
}

export function useStartMDNS() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.post(`/mdns/${name}/start`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mdns'] })
    },
  })
}

export function useStopMDNS() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, string>({
    mutationFn: async (name) => {
      const response = await api.post(`/mdns/${name}/stop`)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['mdns'] })
    },
  })
}
