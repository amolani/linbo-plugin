import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import api from '@/lib/api'
import type { KMSConfig, APIResponse } from '@/types'

export function useKMSConfig() {
  return useQuery<KMSConfig | null>({
    queryKey: ['kms-config'],
    queryFn: async () => {
      const response = await api.get('/kms/config')
      return response.data
    },
  })
}

export function useKMSStatus() {
  return useQuery<APIResponse>({
    queryKey: ['kms-status'],
    queryFn: async () => {
      const response = await api.get('/kms/status')
      return response.data
    },
    refetchInterval: 5000,
  })
}

export function useCreateKMSConfig() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, KMSConfig>({
    mutationFn: async (config) => {
      const response = await api.post('/kms/config', config)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kms-config'] })
    },
  })
}

export function useUpdateKMSConfig() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error, Partial<KMSConfig>>({
    mutationFn: async (data) => {
      const response = await api.patch('/kms/config', data)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kms-config'] })
    },
  })
}

export function useStartKMS() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error>({
    mutationFn: async () => {
      const response = await api.post('/kms/start')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kms-status'] })
    },
  })
}

export function useStopKMS() {
  const queryClient = useQueryClient()

  return useMutation<APIResponse, Error>({
    mutationFn: async () => {
      const response = await api.post('/kms/stop')
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['kms-status'] })
    },
  })
}
