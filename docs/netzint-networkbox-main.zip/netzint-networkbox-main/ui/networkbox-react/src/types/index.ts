export interface APIResponse {
  status: boolean
  message: string
  error?: string
}

export interface Network {
  name: string
  parent: string
  vlan_id: number
  address: string
  mask: string
  ip_address?: string
}

export interface ContainerNetwork {
  vlan_id: number
  address: string
  mask: string
}

export interface MDNSNetwork {
  vlan_id: number
  address: string
  mask: string
}

export interface MDNS {
  name: string
  network1: MDNSNetwork
  network2: MDNSNetwork
  status: boolean
}

export interface MDNSCluster {
  nodes: { id: string; label: string }[]
  links: { source: string; target: string }[]
}

export interface RadiusGroups {
  name: string
  simultaneous_use: number
  vlan_id?: number
}

export interface RadiusCredentials {
  network: string
  password: string
  show_pw?: boolean
}

export interface Radius {
  name: string
  network: ContainerNetwork
  authentication: string
  samba_domain: string
  samba_domain_admin: string
  samba_domain_admin_password: string
  credentials: RadiusCredentials[]
  groups: RadiusGroups[]
  status: boolean
  show_pw?: boolean
}

export interface Authentication {
  name: string
  server: string
  port: number
  use_ssl: boolean
  validate_cert: boolean
  binduser: string
  password: string
  basedn: string
  userfilter: string
  status?: boolean
  status_message?: string
  show_pw?: boolean
}

export interface AuthenticationTest {
  name?: string
  server: string
  port: number
  use_ssl: boolean
  validate_cert: boolean
  binduser: string
  password?: string
  basedn: string
  userfilter: string
}

export interface Container {
  id: string
  image: string
  name: string
  status: string
  labels: Record<string, string>
  networks: { network: string; ip: string }[]
}

export interface ARPDevice {
  ip: string
  mac: string
  hostname: string | null
  vendor: string | null
}

// Alias for consistency with backend naming
export type DeviceInfo = ARPDevice

export interface ARPScanResult {
  subnet: string
  device_count: number
  devices: ARPDevice[]
}

export interface PINGScanResult {
  hosts: string[]
  reachable: string[]
}

export interface SophosXGSConnection {
  username: string
  password: string
  hostname: string
  port: number
}

export interface SophosXGSCertificate {
  name: string
  cert_pem: string
  key_pem: string
  valid_from: string
  valid_to: string
}

export interface SophosXGSNetworkVLAN {
  name: string
  vlan_id: number
  address: string
  mask: string
}

// Certificate Manager types
export interface CertificateSource {
  name: string
  type: 'sophos'
  sophos_hostname: string
  sophos_port: number
  sophos_username: string
  sophos_password: string
  sophos_cert_names: string[]  // Multiple certificates can be selected
  sync_interval: number
  last_sync?: string
  enabled: boolean
}

export interface Certificate {
  name: string
  source: string
  cert_pem: string
  key_pem: string
  valid_from: string
  valid_to: string
  subject: string
  issuer: string
  sha256: string
  last_updated: string
}

export interface ReverseProxyTarget {
  address: string
  port: number
  weight: number
}

export interface ReverseProxy {
  name: string
  protocol: string
  listen_address: string
  listen_port: number
  targets: ReverseProxyTarget[]
  certificate: string
  load_balancing: string
  status: boolean
}

export interface ProxyBlockPageConfig {
  title: string
  message: string
  logo_url?: string
  background_color: string
  card_background_color: string
  title_color: string
  text_color: string
  accent_color: string
  show_url: boolean
  show_ip: boolean
  show_time: boolean
  animation_enabled: boolean
}

export interface AllowedIP {
  ip: string
  description: string
  added_at: string
  added_by: string
}

export interface IPAllowConfig {
  api_key: string
  allowed_ips: AllowedIP[]
  blocked_ips: AllowedIP[]
}

export interface KerberosConfig {
  enabled: boolean
  realm: string
  kdc: string
  domain_admin: string
  domain_admin_password: string
  proxy_hostname: string
  ticket_lifetime: string
  renew_lifetime: string
}

export interface ParentProxyConfig {
  enabled: boolean
  host: string
  port: number
  forward_auth: 'none' | 'basic' | 'header'
  auth_header_name: string
  username: string
  password: string
}

export interface ProxyConfig {
  listen_address: string
  listen_port: number
  // Authentication mode: "ldap", "kerberos", "ip_allow"
  auth_mode: 'ldap' | 'kerberos' | 'ip_allow'
  authentication: string
  allowed_groups: string[]
  // IP-based allow/block configuration
  ip_allow: IPAllowConfig
  whitelist_domains: string[]
  blacklist_domains: string[]
  bypass_groups: string[]
  block_page: ProxyBlockPageConfig
  // WPAD/PAC configuration
  proxy_hostname: string
  pac_direct_domains: string[]
  pac_direct_networks: string[]
  // Kerberos SSO configuration
  kerberos: KerberosConfig
  // Parent proxy configuration
  parent_proxy: ParentProxyConfig
  status: boolean
}

export interface KMSConfig {
  listen_address: string
  listen_port: number
  allowed_networks: number[]
  status: boolean
}

export interface NAPIStatus {
  running: boolean
  version: string | null
  connected_networks: string[]
}

// ============================================================================
// Network Monitoring Types
// ============================================================================

export type SNMPVersion = 'v2c' | 'v3'

export interface SNMPConfig {
  version: SNMPVersion
  community: string
  // v3 options
  username: string
  auth_protocol: string
  auth_password: string
  priv_protocol: string
  priv_password: string
}

export interface UniFiConfig {
  enabled: boolean
  controller_url: string
  username: string
  password: string
  site: string
  verify_ssl: boolean
}

export interface MonitoredSwitch {
  name: string
  ip_address: string
  snmp_config: SNMPConfig
  unifi_device_id?: string
  unifi_mac?: string
  model: string
  port_count: number
  uplink_ports: number[]
  enabled: boolean
  position_x?: number
  position_y?: number
}

export interface MonitoredSwitchUpdate {
  name?: string
  ip_address?: string
  snmp_config?: SNMPConfig
  model?: string
  port_count?: number
  uplink_ports?: number[]
  enabled?: boolean
  position_x?: number
  position_y?: number
}

export interface SwitchConnection {
  from_switch: string
  from_port: number
  to_switch: string
  to_port: number
  discovered_via: string
}

export interface MonitoringConfig {
  enabled: boolean
  poll_interval_seconds: number
  mac_table_interval_seconds: number
  alert_email: string
  alert_webhook_url: string
  unifi: UniFiConfig
  mac_flap_threshold: number
  mac_flap_window_seconds: number
  stp_tc_threshold: number
  discard_rate_threshold: number
  warning_score: number
  critical_score: number
}

export type IncidentSeverity = 'info' | 'warning' | 'critical'
export type IncidentStatus = 'open' | 'investigating' | 'resolved'

export interface LoopIncident {
  id: string
  severity: IncidentSeverity
  score: number
  status: IncidentStatus
  detected_at: string
  resolved_at?: string
  switch_name: string
  suspected_ports: number[]
  mac_moves_count: number
  top_flapping_macs: string[]
  stp_topology_changes: number
  discard_rate: number
  summary: string
  details: string
}

export interface LoopIncidentUpdate {
  status?: IncidentStatus
  resolved_at?: string
}

export interface MonitoringStatus {
  enabled: boolean
  switches_total: number
  switches_enabled: number
  switches_reachable: number
  open_incidents: number
  critical_incidents: number
  warning_incidents: number
  last_poll?: string
  flapping_macs_count: number
}

export interface MACFlappingInfo {
  mac: string
  move_count: number
  ports: [string, number][]
  last_move: string
}

export interface MACFlappingData {
  flapping_macs: MACFlappingInfo[]
  total_moves: number
  affected_ports: number
}

export interface SwitchMetrics {
  switch_name: string
  timestamp: string
  stp_topology_changes: number
  stp_time_since_tc: number
  total_in_octets: number
  total_out_octets: number
  total_in_errors: number
  total_out_errors: number
  total_in_discards: number
  total_out_discards: number
  port_discard_rates: Record<number, number>
}
