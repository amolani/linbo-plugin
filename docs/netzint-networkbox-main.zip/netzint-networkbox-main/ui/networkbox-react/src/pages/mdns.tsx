import { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  useMDNSList,
  useCreateMDNS,
  useDeleteMDNS,
} from '@/hooks/use-mdns'
import { useNetworks, getSecondToLastIP } from '@/hooks/use-networks'
import { useContainers, useContainerLogs } from '@/hooks/use-containers'
import { useActionStream } from '@/hooks/use-action-stream'
import { ActionLogDialog } from '@/components/action-log-dialog'
import { Plus, Trash2, Play, Square, RefreshCw, Radio, Terminal, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import type { MDNS } from '@/types'

export function MDNSPage() {
  const { data: mdnsList, isLoading, refetch } = useMDNSList()
  const { data: networks } = useNetworks()
  const { data: containers } = useContainers()
  const createMDNS = useCreateMDNS()
  const deleteMDNS = useDeleteMDNS()
  const actionStream = useActionStream()

  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [network1, setNetwork1] = useState('')
  const [network2, setNetwork2] = useState('')
  const [ip1, setIp1] = useState('')
  const [ip2, setIp2] = useState('')

  // Pre-fill IP with second-to-last address when network is selected
  useEffect(() => {
    const net = networks?.find((n) => n.vlan_id.toString() === network1)
    if (net) setIp1(getSecondToLastIP(net.address, net.mask))
  }, [network1, networks])

  useEffect(() => {
    const net = networks?.find((n) => n.vlan_id.toString() === network2)
    if (net) setIp2(getSecondToLastIP(net.address, net.mask))
  }, [network2, networks])
  const [selectedContainer, setSelectedContainer] = useState<string | null>(null)
  const { logs, isConnected, clearLogs } = useContainerLogs(selectedContainer)
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (scrollContainerRef.current) {
      const viewport = scrollContainerRef.current.querySelector('[data-radix-scroll-area-viewport]')
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight
      }
    }
  }, [logs])

  // Get the container ID for an MDNS repeater
  const getContainerId = (mdnsName: string) => {
    const containerName = `NETWORKBOX_MDNS_${mdnsName.toUpperCase()}`
    return containers?.find((c) => c.name === containerName)?.id || null
  }

  // Check if MDNS container is actually running
  const isContainerRunning = (mdnsName: string) => {
    const containerName = `NETWORKBOX_MDNS_${mdnsName.toUpperCase()}`
    const container = containers?.find((c) => c.name === containerName)
    return container?.status === 'running'
  }

  const handleOpenLogs = (mdnsName: string) => {
    const containerId = getContainerId(mdnsName)
    if (containerId) {
      clearLogs()
      setSelectedContainer(containerId)
    } else {
      toast.error('Container not found')
    }
  }

  const handleCloseLogs = () => {
    setSelectedContainer(null)
  }

  const handleCreate = async () => {
    const net1 = networks?.find((n) => n.vlan_id.toString() === network1)
    const net2 = networks?.find((n) => n.vlan_id.toString() === network2)

    if (!net1 || !net2) {
      toast.error('Please select both networks')
      return
    }

    const newMDNS: MDNS = {
      name: `mdns-${net1.vlan_id}-${net2.vlan_id}`,
      network1: {
        vlan_id: net1.vlan_id,
        address: ip1,
        mask: net1.mask,
      },
      network2: {
        vlan_id: net2.vlan_id,
        address: ip2,
        mask: net2.mask,
      },
      status: false,
    }

    try {
      await createMDNS.mutateAsync(newMDNS)
      toast.success('mDNS Repeater created successfully')
      setIsCreateOpen(false)
      setNetwork1('')
      setNetwork2('')
      setIp1('')
      setIp2('')
    } catch {
      toast.error('Failed to create mDNS Repeater')
    }
  }

  const handleDelete = async (name: string) => {
    if (!confirm('Are you sure you want to delete this mDNS Repeater?')) return
    try {
      await deleteMDNS.mutateAsync(name)
      toast.success('mDNS Repeater deleted successfully')
    } catch {
      toast.error('Failed to delete mDNS Repeater')
    }
  }

  const handleStart = (name: string) => {
    actionStream.startStream(`/api/v1/mdns/${name}/start/stream`, `Starting mDNS: ${name}`)
  }

  const handleStop = (name: string) => {
    actionStream.startStream(`/api/v1/mdns/${name}/stop/stream`, `Stopping mDNS: ${name}`)
  }

  const handleActionClose = () => {
    actionStream.close()
    refetch()
  }

  const getNetworkName = (vlanId: number) => {
    return networks?.find((n) => n.vlan_id === vlanId)?.name || `VLAN ${vlanId}`
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">mDNS Repeaters</h1>
          <p className="text-muted-foreground">
            Manage mDNS repeaters between network segments
          </p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Repeater
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create mDNS Repeater</DialogTitle>
              <DialogDescription>
                Create a repeater to bridge mDNS between two networks
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label>Network 1</Label>
                <Select value={network1} onValueChange={setNetwork1}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select first network" />
                  </SelectTrigger>
                  <SelectContent>
                    {networks
                      ?.filter((n) => n.vlan_id.toString() !== network2)
                      .map((network) => (
                        <SelectItem key={network.vlan_id} value={network.vlan_id.toString()}>
                          {network.name} (VLAN {network.vlan_id})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>IP Address (Network 1)</Label>
                <Input
                  value={ip1}
                  onChange={(e) => setIp1(e.target.value)}
                  placeholder="e.g. 10.0.1.253"
                  disabled={!network1}
                />
              </div>
              <div className="space-y-2">
                <Label>Network 2</Label>
                <Select value={network2} onValueChange={setNetwork2}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select second network" />
                  </SelectTrigger>
                  <SelectContent>
                    {networks
                      ?.filter((n) => n.vlan_id.toString() !== network1)
                      .map((network) => (
                        <SelectItem key={network.vlan_id} value={network.vlan_id.toString()}>
                          {network.name} (VLAN {network.vlan_id})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>IP Address (Network 2)</Label>
                <Input
                  value={ip2}
                  onChange={(e) => setIp2(e.target.value)}
                  placeholder="e.g. 10.0.2.253"
                  disabled={!network2}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreate} disabled={createMDNS.isPending || !network1 || !network2 || !ip1 || !ip2}>
                Create
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Active Repeaters</CardTitle>
          <CardDescription>mDNS repeaters bridging network segments</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Network 1</TableHead>
                  <TableHead>Network 2</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-32"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mdnsList?.map((mdns) => (
                  <TableRow key={mdns.name}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Radio className="h-4 w-4 text-primary" />
                        <span className="font-medium">{mdns.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">
                          {getNetworkName(mdns.network1.vlan_id)}
                        </div>
                        <div className="text-sm text-muted-foreground font-mono">
                          {mdns.network1.address}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">
                          {getNetworkName(mdns.network2.vlan_id)}
                        </div>
                        <div className="text-sm text-muted-foreground font-mono">
                          {mdns.network2.address}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={isContainerRunning(mdns.name) ? 'success' : 'destructive'}>
                        {isContainerRunning(mdns.name) ? 'Running' : 'Stopped'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {isContainerRunning(mdns.name) ? (
                          <>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleOpenLogs(mdns.name)}
                            >
                              <Terminal className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleStop(mdns.name)}
                              disabled={actionStream.isRunning}
                            >
                              <Square className="h-4 w-4" />
                            </Button>
                          </>
                        ) : (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleStart(mdns.name)}
                            disabled={actionStream.isRunning}
                          >
                            <Play className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(mdns.name)}
                          className="text-destructive hover:text-destructive"
                          disabled={isContainerRunning(mdns.name)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!mdnsList || mdnsList.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground">
                      No mDNS repeaters configured
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Action Log Dialog */}
      <ActionLogDialog
        open={actionStream.isOpen}
        onClose={handleActionClose}
        title={actionStream.title}
        logs={actionStream.logs}
        isRunning={actionStream.isRunning}
        success={actionStream.success}
      />

      {/* Container Log Dialog */}
      <Dialog open={!!selectedContainer} onOpenChange={() => handleCloseLogs()}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Container Logs
              {isConnected ? (
                <Badge variant="secondary" className="ml-2">
                  <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse mr-1.5" />
                  Connected
                </Badge>
              ) : (
                <Badge variant="outline" className="ml-2">
                  <Loader2 className="h-3 w-3 animate-spin mr-1.5" />
                  Connecting
                </Badge>
              )}
            </DialogTitle>
          </DialogHeader>

          <ScrollArea className="h-[400px] rounded-md border bg-muted/30" ref={scrollContainerRef}>
            <div className="p-4 font-mono text-sm space-y-1">
              {logs.length === 0 ? (
                <div className="text-muted-foreground">Waiting for logs...</div>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className="break-all text-foreground">
                    {log}
                  </div>
                ))
              )}
              {isConnected && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span>Streaming...</span>
                </div>
              )}
            </div>
          </ScrollArea>

          <DialogFooter className="flex-row justify-between sm:justify-between">
            <Button variant="outline" onClick={clearLogs}>
              Clear
            </Button>
            <Button onClick={handleCloseLogs}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
