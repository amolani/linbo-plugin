import { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  useRadiusList,
  useCreateRadius,
  useUpdateRadius,
  useDeleteRadius,
} from '@/hooks/use-radius'
import { useNetworks, getSecondToLastIP } from '@/hooks/use-networks'
import { useAuthenticationList, useAuthenticationGroups } from '@/hooks/use-authentication'
import { useContainers, useContainerLogs } from '@/hooks/use-containers'
import { useActionStream } from '@/hooks/use-action-stream'
import { ActionLogDialog } from '@/components/action-log-dialog'
import { Plus, Trash2, Play, Square, RefreshCw, Shield, Eye, EyeOff, Pencil, Check, ChevronsUpDown, Terminal, Loader2 } from 'lucide-react'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'
import type { Radius, RadiusCredentials, RadiusGroups } from '@/types'

export function RadiusPage() {
  const { data: radiusList, isLoading, refetch } = useRadiusList()
  const { data: networks } = useNetworks()
  const { data: authentications } = useAuthenticationList()
  const { data: containers } = useContainers()
  const createRadius = useCreateRadius()
  const updateRadius = useUpdateRadius()
  const deleteRadius = useDeleteRadius()
  const actionStream = useActionStream()

  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [isEditOpen, setIsEditOpen] = useState(false)
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({})
  const [selectedAuth, setSelectedAuth] = useState('')
  const [editSelectedAuth, setEditSelectedAuth] = useState('')
  const [openGroupPopover, setOpenGroupPopover] = useState<number | null>(null)
  const [openEditGroupPopover, setOpenEditGroupPopover] = useState<number | null>(null)
  const { data: authGroups } = useAuthenticationGroups(selectedAuth)
  const { data: editAuthGroups } = useAuthenticationGroups(editSelectedAuth)
  const [selectedContainer, setSelectedContainer] = useState<string | null>(null)
  const { logs, isConnected, clearLogs } = useContainerLogs(selectedContainer)
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (scrollContainerRef.current) {
      const viewport = scrollContainerRef.current.querySelector('[data-radix-scroll-area-viewport]')
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight
      }
    }
  }, [logs])

  // Get the container ID for a RADIUS server
  const getContainerId = (radiusName: string) => {
    const containerName = `NETWORKBOX_RADIUS_${radiusName.toUpperCase()}`
    return containers?.find((c) => c.name === containerName)?.id || null
  }

  // Check if RADIUS container is actually running
  const isContainerRunning = (radiusName: string) => {
    const containerName = `NETWORKBOX_RADIUS_${radiusName.toUpperCase()}`
    const container = containers?.find((c) => c.name === containerName)
    return container?.status === 'running'
  }

  const handleOpenLogs = (radiusName: string) => {
    const containerId = getContainerId(radiusName)
    if (containerId) {
      clearLogs()
      setSelectedContainer(containerId)
    } else {
      toast.error('Container not found')
    }
  }

  const handleCloseLogs = () => {
    setSelectedContainer(null)
  }

  const [newRadius, setNewRadius] = useState<Partial<Radius>>({
    name: '',
    network: { vlan_id: 0, address: '', mask: '' },
    authentication: '',
    samba_domain: '',
    samba_domain_admin: '',
    samba_domain_admin_password: '',
    credentials: [],
    groups: [],
  })

  const [editRadius, setEditRadius] = useState<Partial<Radius> & { originalName?: string }>({
    name: '',
    network: { vlan_id: 0, address: '', mask: '' },
    authentication: '',
    samba_domain: '',
    samba_domain_admin: '',
    samba_domain_admin_password: '',
    credentials: [],
    groups: [],
  })

  const handleCreate = async () => {
    const network = networks?.find((n) => n.vlan_id === newRadius.network?.vlan_id)
    if (!network) {
      toast.error('Please select a network')
      return
    }

    const radiusData: Radius = {
      ...newRadius as Radius,
      network: {
        vlan_id: network.vlan_id,
        address: newRadius.network?.address || getSecondToLastIP(network.address, network.mask),
        mask: network.mask,
      },
    }

    try {
      await createRadius.mutateAsync(radiusData)
      toast.success('RADIUS server created successfully')
      setIsCreateOpen(false)
      resetForm()
    } catch {
      toast.error('Failed to create RADIUS server')
    }
  }

  const resetForm = () => {
    setNewRadius({
      name: '',
      network: { vlan_id: 0, address: '', mask: '' },
      authentication: '',
      samba_domain: '',
      samba_domain_admin: '',
      samba_domain_admin_password: '',
      credentials: [],
      groups: [],
    })
    setSelectedAuth('')
  }

  const handleDelete = async (name: string) => {
    if (!confirm('Are you sure you want to delete this RADIUS server?')) return
    try {
      await deleteRadius.mutateAsync(name)
      toast.success('RADIUS server deleted successfully')
    } catch {
      toast.error('Failed to delete RADIUS server')
    }
  }

  const handleStart = (name: string) => {
    actionStream.startStream(`/api/v1/radius/${name}/start/stream`, `Starting RADIUS: ${name}`)
  }

  const handleStop = (name: string) => {
    actionStream.startStream(`/api/v1/radius/${name}/stop/stream`, `Stopping RADIUS: ${name}`)
  }

  const handleActionClose = () => {
    actionStream.close()
    refetch()
  }

  const addCredential = () => {
    setNewRadius({
      ...newRadius,
      credentials: [...(newRadius.credentials || []), { network: '', password: '' }],
    })
  }

  const removeCredential = (index: number) => {
    setNewRadius({
      ...newRadius,
      credentials: newRadius.credentials?.filter((_, i) => i !== index),
    })
  }

  const updateCredential = (index: number, field: keyof RadiusCredentials, value: string) => {
    const updated = [...(newRadius.credentials || [])]
    updated[index] = { ...updated[index], [field]: value }
    setNewRadius({ ...newRadius, credentials: updated })
  }

  const addGroup = () => {
    setNewRadius({
      ...newRadius,
      groups: [...(newRadius.groups || []), { name: '', simultaneous_use: 1, vlan_id: 0 }],
    })
  }

  const removeGroup = (index: number) => {
    setNewRadius({
      ...newRadius,
      groups: newRadius.groups?.filter((_, i) => i !== index),
    })
  }

  const updateGroup = (index: number, field: keyof RadiusGroups, value: string | number) => {
    const updated = [...(newRadius.groups || [])]
    updated[index] = { ...updated[index], [field]: value }
    setNewRadius({ ...newRadius, groups: updated })
  }

  const togglePassword = (key: string) => {
    setShowPasswords((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const getNetworkName = (vlanId: number) => {
    return networks?.find((n) => n.vlan_id === vlanId)?.name || `VLAN ${vlanId}`
  }

  const handleEdit = (radius: Radius) => {
    setEditRadius({
      ...radius,
      originalName: radius.name,
      samba_domain_admin_password: '', // Don't show existing password
    })
    setEditSelectedAuth(radius.authentication)
    setIsEditOpen(true)
  }

  const handleUpdate = async () => {
    try {
      const { originalName, ...updateData } = editRadius
      // Remove empty password to keep existing one
      const filteredData = {
        ...updateData,
        samba_domain_admin_password: updateData.samba_domain_admin_password || undefined,
      }
      await updateRadius.mutateAsync({ name: originalName!, data: filteredData })
      toast.success('RADIUS server updated successfully')
      setIsEditOpen(false)
    } catch {
      toast.error('Failed to update RADIUS server')
    }
  }

  const addEditCredential = () => {
    setEditRadius({
      ...editRadius,
      credentials: [...(editRadius.credentials || []), { network: '', password: '' }],
    })
  }

  const removeEditCredential = (index: number) => {
    setEditRadius({
      ...editRadius,
      credentials: editRadius.credentials?.filter((_, i) => i !== index),
    })
  }

  const updateEditCredential = (index: number, field: keyof RadiusCredentials, value: string) => {
    const updated = [...(editRadius.credentials || [])]
    updated[index] = { ...updated[index], [field]: value }
    setEditRadius({ ...editRadius, credentials: updated })
  }

  const addEditGroup = () => {
    setEditRadius({
      ...editRadius,
      groups: [...(editRadius.groups || []), { name: '', simultaneous_use: 1, vlan_id: 0 }],
    })
  }

  const removeEditGroup = (index: number) => {
    setEditRadius({
      ...editRadius,
      groups: editRadius.groups?.filter((_, i) => i !== index),
    })
  }

  const updateEditGroup = (index: number, field: keyof RadiusGroups, value: string | number) => {
    const updated = [...(editRadius.groups || [])]
    updated[index] = { ...updated[index], [field]: value }
    setEditRadius({ ...editRadius, groups: updated })
  }

  // Extract group name from DN (e.g., "CN=Teachers,OU=Groups,DC=..." -> "Teachers")
  const extractGroupName = (dn: string) => {
    const match = dn.match(/^CN=([^,]+)/i)
    return match ? match[1] : dn
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">RADIUS Servers</h1>
          <p className="text-muted-foreground">Manage RADIUS authentication servers</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add RADIUS
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create RADIUS Server</DialogTitle>
              <DialogDescription>Configure a new RADIUS authentication server</DialogDescription>
            </DialogHeader>
            <Tabs defaultValue="general" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="credentials">Credentials</TabsTrigger>
                <TabsTrigger value="groups">Groups</TabsTrigger>
              </TabsList>

              <TabsContent value="general" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    value={newRadius.name}
                    onChange={(e) => setNewRadius({ ...newRadius, name: e.target.value })}
                    placeholder="radius-server-1"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Network</Label>
                  <Select
                    value={newRadius.network?.vlan_id?.toString()}
                    onValueChange={(value) => {
                      const net = networks?.find((n) => n.vlan_id === parseInt(value))
                      setNewRadius({
                        ...newRadius,
                        network: {
                          vlan_id: parseInt(value),
                          address: net ? getSecondToLastIP(net.address, net.mask) : '',
                          mask: net?.mask || '',
                        },
                      })
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select network" />
                    </SelectTrigger>
                    <SelectContent>
                      {networks?.map((network) => (
                        <SelectItem key={network.vlan_id} value={network.vlan_id.toString()}>
                          {network.name} (VLAN {network.vlan_id})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>IP Address</Label>
                  <Input
                    value={newRadius.network?.address || ''}
                    onChange={(e) =>
                      setNewRadius({
                        ...newRadius,
                        network: { ...newRadius.network!, address: e.target.value },
                      })
                    }
                    placeholder="e.g. 10.0.1.253"
                    disabled={!newRadius.network?.vlan_id}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Authentication Provider</Label>
                  <Select
                    value={newRadius.authentication}
                    onValueChange={(value) => {
                      setNewRadius({ ...newRadius, authentication: value })
                      setSelectedAuth(value)
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select authentication" />
                    </SelectTrigger>
                    <SelectContent>
                      {authentications?.map((auth) => (
                        <SelectItem key={auth.name} value={auth.name}>
                          {auth.name} ({auth.server})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Samba Domain</Label>
                  <Input
                    value={newRadius.samba_domain}
                    onChange={(e) => setNewRadius({ ...newRadius, samba_domain: e.target.value })}
                    placeholder="DOMAIN"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Domain Admin</Label>
                    <Input
                      value={newRadius.samba_domain_admin}
                      onChange={(e) =>
                        setNewRadius({ ...newRadius, samba_domain_admin: e.target.value })
                      }
                      placeholder="Administrator"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Admin Password</Label>
                    <div className="relative">
                      <Input
                        type={showPasswords['admin'] ? 'text' : 'password'}
                        value={newRadius.samba_domain_admin_password}
                        onChange={(e) =>
                          setNewRadius({
                            ...newRadius,
                            samba_domain_admin_password: e.target.value,
                          })
                        }
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0"
                        onClick={() => togglePassword('admin')}
                      >
                        {showPasswords['admin'] ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="credentials" className="space-y-4 mt-4">
                {newRadius.credentials?.map((cred, index) => (
                  <div key={index} className="flex gap-2 items-end">
                    <div className="flex-1 space-y-2">
                      <Label>Network</Label>
                      <Input
                        value={cred.network}
                        onChange={(e) => updateCredential(index, 'network', e.target.value)}
                        placeholder="192.168.1.0/24"
                      />
                    </div>
                    <div className="flex-1 space-y-2">
                      <Label>Password</Label>
                      <Input
                        type="password"
                        value={cred.password}
                        onChange={(e) => updateCredential(index, 'password', e.target.value)}
                      />
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeCredential(index)}
                      className="text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button variant="outline" onClick={addCredential} className="w-full">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Credential
                </Button>
              </TabsContent>

              <TabsContent value="groups" className="space-y-4 mt-4">
                {!selectedAuth && (
                  <p className="text-sm text-muted-foreground">
                    Please select an authentication provider in the General tab first.
                  </p>
                )}
                {newRadius.groups?.map((group, index) => (
                  <div key={index} className="flex gap-2 items-end">
                    <div className="flex-1 space-y-2">
                      <Label>Group</Label>
                      <Popover open={openGroupPopover === index} onOpenChange={(open) => setOpenGroupPopover(open ? index : null)}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={openGroupPopover === index}
                            className="w-full justify-between font-normal"
                            disabled={!selectedAuth}
                          >
                            {group.name ? extractGroupName(group.name) : "Select group..."}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-[300px] p-0">
                          <Command>
                            <CommandInput placeholder="Search group..." />
                            <CommandList>
                              <CommandEmpty>No groups found.</CommandEmpty>
                              <CommandGroup>
                                {authGroups?.map((g) => (
                                  <CommandItem
                                    key={g}
                                    value={g}
                                    onSelect={() => {
                                      updateGroup(index, 'name', g)
                                      setOpenGroupPopover(null)
                                    }}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        group.name === g ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {extractGroupName(g)}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                    </div>
                    <div className="w-24 space-y-2">
                      <Label>Sim. Use</Label>
                      <Input
                        type="number"
                        value={group.simultaneous_use}
                        onChange={(e) =>
                          updateGroup(index, 'simultaneous_use', parseInt(e.target.value))
                        }
                      />
                    </div>
                    <div className="w-32 space-y-2">
                      <Label>VLAN</Label>
                      <Select
                        value={group.vlan_id?.toString() || '0'}
                        onValueChange={(value) => updateGroup(index, 'vlan_id', parseInt(value))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">None</SelectItem>
                          {networks?.map((n) => (
                            <SelectItem key={n.vlan_id} value={n.vlan_id.toString()}>
                              {n.vlan_id}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeGroup(index)}
                      className="text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button variant="outline" onClick={addGroup} className="w-full" disabled={!selectedAuth}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Group
                </Button>
              </TabsContent>
            </Tabs>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreate} disabled={createRadius.isPending}>
                Create
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>RADIUS Servers</CardTitle>
          <CardDescription>Configured RADIUS authentication servers</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Network</TableHead>
                  <TableHead>Authentication</TableHead>
                  <TableHead>Groups</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-32"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {radiusList?.map((radius) => (
                  <TableRow key={radius.name}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4 text-primary" />
                        <span className="font-medium">{radius.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="font-medium">
                          {getNetworkName(radius.network.vlan_id)}
                        </div>
                        <div className="text-sm text-muted-foreground font-mono">
                          {radius.network.address}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{radius.authentication}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {radius.groups.slice(0, 3).map((g) => (
                          <Badge key={g.name} variant="secondary" className="text-xs">
                            {g.name}
                          </Badge>
                        ))}
                        {radius.groups.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{radius.groups.length - 3}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={isContainerRunning(radius.name) ? 'success' : 'destructive'}>
                        {isContainerRunning(radius.name) ? 'Running' : 'Stopped'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        {isContainerRunning(radius.name) ? (
                          <>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleOpenLogs(radius.name)}
                            >
                              <Terminal className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleStop(radius.name)}
                              disabled={actionStream.isRunning}
                            >
                              <Square className="h-4 w-4" />
                            </Button>
                          </>
                        ) : (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleStart(radius.name)}
                            disabled={actionStream.isRunning}
                          >
                            <Play className="h-4 w-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(radius)}
                          disabled={isContainerRunning(radius.name)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(radius.name)}
                          className="text-destructive hover:text-destructive"
                          disabled={isContainerRunning(radius.name)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!radiusList || radiusList.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground">
                      No RADIUS servers configured
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit RADIUS Server</DialogTitle>
            <DialogDescription>Update RADIUS server configuration</DialogDescription>
          </DialogHeader>
          <Tabs defaultValue="general" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="credentials">Credentials</TabsTrigger>
              <TabsTrigger value="groups">Groups</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Name</Label>
                <Input
                  value={editRadius.name}
                  disabled
                  className="bg-muted"
                />
              </div>
              <div className="space-y-2">
                <Label>Network</Label>
                <Select
                  value={editRadius.network?.vlan_id?.toString()}
                  onValueChange={(value) => {
                    const net = networks?.find((n) => n.vlan_id === parseInt(value))
                    setEditRadius({
                      ...editRadius,
                      network: {
                        vlan_id: parseInt(value),
                        address: net ? getSecondToLastIP(net.address, net.mask) : '',
                        mask: net?.mask || '',
                      },
                    })
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select network" />
                  </SelectTrigger>
                  <SelectContent>
                    {networks?.map((network) => (
                      <SelectItem key={network.vlan_id} value={network.vlan_id.toString()}>
                        {network.name} (VLAN {network.vlan_id})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>IP Address</Label>
                <Input
                  value={editRadius.network?.address || ''}
                  onChange={(e) =>
                    setEditRadius({
                      ...editRadius,
                      network: { ...editRadius.network!, address: e.target.value },
                    })
                  }
                  placeholder="e.g. 10.0.1.253"
                  disabled={!editRadius.network?.vlan_id}
                />
              </div>
              <div className="space-y-2">
                <Label>Authentication Provider</Label>
                <Select
                  value={editRadius.authentication}
                  onValueChange={(value) => {
                    setEditRadius({ ...editRadius, authentication: value })
                    setEditSelectedAuth(value)
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select authentication" />
                  </SelectTrigger>
                  <SelectContent>
                    {authentications?.map((auth) => (
                      <SelectItem key={auth.name} value={auth.name}>
                        {auth.name} ({auth.server})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Samba Domain</Label>
                <Input
                  value={editRadius.samba_domain}
                  onChange={(e) => setEditRadius({ ...editRadius, samba_domain: e.target.value })}
                  placeholder="DOMAIN"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Domain Admin</Label>
                  <Input
                    value={editRadius.samba_domain_admin}
                    onChange={(e) =>
                      setEditRadius({ ...editRadius, samba_domain_admin: e.target.value })
                    }
                    placeholder="Administrator"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Admin Password (leave empty to keep)</Label>
                  <div className="relative">
                    <Input
                      type={showPasswords['edit_admin'] ? 'text' : 'password'}
                      value={editRadius.samba_domain_admin_password}
                      onChange={(e) =>
                        setEditRadius({
                          ...editRadius,
                          samba_domain_admin_password: e.target.value,
                        })
                      }
                      placeholder="••••••••"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="absolute right-0 top-0"
                      onClick={() => togglePassword('edit_admin')}
                    >
                      {showPasswords['edit_admin'] ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="credentials" className="space-y-4 mt-4">
              {editRadius.credentials?.map((cred, index) => (
                <div key={index} className="flex gap-2 items-end">
                  <div className="flex-1 space-y-2">
                    <Label>Network</Label>
                    <Input
                      value={cred.network}
                      onChange={(e) => updateEditCredential(index, 'network', e.target.value)}
                      placeholder="192.168.1.0/24"
                    />
                  </div>
                  <div className="flex-1 space-y-2">
                    <Label>Password</Label>
                    <Input
                      type="password"
                      value={cred.password}
                      onChange={(e) => updateEditCredential(index, 'password', e.target.value)}
                    />
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeEditCredential(index)}
                    className="text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button variant="outline" onClick={addEditCredential} className="w-full">
                <Plus className="mr-2 h-4 w-4" />
                Add Credential
              </Button>
            </TabsContent>

            <TabsContent value="groups" className="space-y-4 mt-4">
              {!editSelectedAuth && (
                <p className="text-sm text-muted-foreground">
                  Please select an authentication provider in the General tab first.
                </p>
              )}
              {editRadius.groups?.map((group, index) => (
                <div key={index} className="flex gap-2 items-end">
                  <div className="flex-1 space-y-2">
                    <Label>Group</Label>
                    <Popover open={openEditGroupPopover === index} onOpenChange={(open) => setOpenEditGroupPopover(open ? index : null)}>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          role="combobox"
                          aria-expanded={openEditGroupPopover === index}
                          className="w-full justify-between font-normal"
                          disabled={!editSelectedAuth}
                        >
                          {group.name ? extractGroupName(group.name) : "Select group..."}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[300px] p-0">
                        <Command>
                          <CommandInput placeholder="Search group..." />
                          <CommandList>
                            <CommandEmpty>No groups found.</CommandEmpty>
                            <CommandGroup>
                              {editAuthGroups?.map((g) => (
                                <CommandItem
                                  key={g}
                                  value={g}
                                  onSelect={() => {
                                    updateEditGroup(index, 'name', g)
                                    setOpenEditGroupPopover(null)
                                  }}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      group.name === g ? "opacity-100" : "opacity-0"
                                    )}
                                  />
                                  {extractGroupName(g)}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="w-24 space-y-2">
                    <Label>Sim. Use</Label>
                    <Input
                      type="number"
                      value={group.simultaneous_use}
                      onChange={(e) =>
                        updateEditGroup(index, 'simultaneous_use', parseInt(e.target.value))
                      }
                    />
                  </div>
                  <div className="w-32 space-y-2">
                    <Label>VLAN</Label>
                    <Select
                      value={group.vlan_id?.toString() || '0'}
                      onValueChange={(value) => updateEditGroup(index, 'vlan_id', parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">None</SelectItem>
                        {networks?.map((n) => (
                          <SelectItem key={n.vlan_id} value={n.vlan_id.toString()}>
                            {n.vlan_id}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeEditGroup(index)}
                    className="text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
              <Button variant="outline" onClick={addEditGroup} className="w-full" disabled={!editSelectedAuth}>
                <Plus className="mr-2 h-4 w-4" />
                Add Group
              </Button>
            </TabsContent>
          </Tabs>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdate} disabled={updateRadius.isPending}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Action Log Dialog */}
      <ActionLogDialog
        open={actionStream.isOpen}
        onClose={handleActionClose}
        title={actionStream.title}
        logs={actionStream.logs}
        isRunning={actionStream.isRunning}
        success={actionStream.success}
      />

      {/* Container Log Dialog */}
      <Dialog open={!!selectedContainer} onOpenChange={() => handleCloseLogs()}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Container Logs
              {isConnected ? (
                <Badge variant="secondary" className="ml-2">
                  <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse mr-1.5" />
                  Connected
                </Badge>
              ) : (
                <Badge variant="outline" className="ml-2">
                  <Loader2 className="h-3 w-3 animate-spin mr-1.5" />
                  Connecting
                </Badge>
              )}
            </DialogTitle>
          </DialogHeader>

          <ScrollArea className="h-[400px] rounded-md border bg-muted/30" ref={scrollContainerRef}>
            <div className="p-4 font-mono text-sm space-y-1">
              {logs.length === 0 ? (
                <div className="text-muted-foreground">Waiting for logs...</div>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className="break-all text-foreground">
                    {log}
                  </div>
                ))
              )}
              {isConnected && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span>Streaming...</span>
                </div>
              )}
            </div>
          </ScrollArea>

          <DialogFooter className="flex-row justify-between sm:justify-between">
            <Button variant="outline" onClick={clearLogs}>
              Clear
            </Button>
            <Button onClick={handleCloseLogs}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
