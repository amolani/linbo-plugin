import { useState, useRef, useCallback, useEffect } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import { Separator } from '@/components/ui/separator'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Upload,
  FileSearch,
  AlertTriangle,
  AlertCircle,
  Info,
  CheckCircle2,
  Loader2,
  Activity,
  Network,
  MessageSquare,
  Terminal,
  HardDrive,
  Layers,
  Globe,
  Play,
  Square,
  Download,
  Radio,
  Trash2,
  Lock,
  Key,
  File,
  Server,
  Shield,
  ExternalLink,
} from 'lucide-react'
import api from '@/lib/api'

interface AnalysisIssue {
  severity: 'error' | 'warning' | 'note' | 'info'
  protocol: string
  count: string
  message: string
  description?: string
}

interface AnalysisConversation {
  endpoint_a: string
  endpoint_b: string
  packets: string
  bytes: string
}

interface HttpRequest {
  method: string
  host: string
  uri: string
  user_agent: string
}

interface HttpResponse {
  status_code: string
  content_type: string
  content_length: string
}

interface DnsQuery {
  name: string
  type: string
}

interface TlsConnection {
  server_name: string
  version: string
  cipher: string
}

interface Credential {
  protocol: string
  info: string
}

interface FileObject {
  filename: string
  content_type: string
  size: string
}

interface TopTalker {
  ip: string
  packets: string
  bytes: string
}

interface AnalysisResult {
  total_packets: number
  duration_seconds: number
  protocols: Record<string, number>
  conversations: AnalysisConversation[]
  issues: AnalysisIssue[]
  statistics: {
    total_bytes?: number
    dns_queries?: number
    dns_responses?: number
    top_talkers?: TopTalker[]
  }
  filename: string
  file_size: number
  http_requests: HttpRequest[]
  http_responses: HttpResponse[]
  dns_queries: DnsQuery[]
  tls_connections: TlsConnection[]
  credentials: Credential[]
  files: FileObject[]
}

interface AnalysisMessage {
  type: 'status' | 'progress' | 'result' | 'error'
  message?: string
  step?: string
  percent?: number
  data?: AnalysisResult
}

interface TCPDumpMessage {
  type: 'status' | 'packet' | 'complete' | 'error' | 'ping' | 'pcap'
  message?: string
  data?: string
  count?: number
  command?: string
  file_size?: number
  filename?: string
  size?: number
  packet_count?: number
}

interface InterfaceInfo {
  name: string
  ip_address: string | null
}

interface CapturedPacket {
  timestamp: string
  data: string
}

export function ToolsPage() {
  // PCAP Analysis state
  const [analyzing, setAnalyzing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [progressStep, setProgressStep] = useState('')
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [analysisDialogOpen, setAnalysisDialogOpen] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const analysisWsRef = useRef<WebSocket | null>(null)

  // TCPDump state
  const [capturing, setCapturing] = useState(false)
  const [selectedInterface, setSelectedInterface] = useState<string>('any')
  const [captureFilter, setCaptureFilter] = useState<string>('')
  const [packets, setPackets] = useState<CapturedPacket[]>([])
  const [packetCount, setPacketCount] = useState(0)
  const [captureStatus, setCaptureStatus] = useState<string>('')
  const [captureFileSize, setCaptureFileSize] = useState(0)
  const [pcapData, setPcapData] = useState<string | null>(null)
  const [pcapFilename, setPcapFilename] = useState<string>('')
  const tcpdumpWsRef = useRef<WebSocket | null>(null)
  const packetsEndRef = useRef<HTMLDivElement>(null)

  // Fetch interfaces
  const { data: interfaces } = useQuery<InterfaceInfo[]>({
    queryKey: ['tcpdump-interfaces'],
    queryFn: async () => {
      const response = await api.get('/napi/tcpdump/interfaces')
      return response.data
    },
  })

  // Auto-scroll packets
  useEffect(() => {
    if (packetsEndRef.current && capturing) {
      packetsEndRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [packets, capturing])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (analysisWsRef.current) {
        analysisWsRef.current.close()
      }
      if (tcpdumpWsRef.current) {
        tcpdumpWsRef.current.close()
      }
    }
  }, [])

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'error':
        return <AlertCircle className="h-4 w-4 text-destructive" />
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />
      case 'note':
        return <Info className="h-4 w-4 text-blue-500" />
      default:
        return <Info className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'error':
        return <Badge variant="destructive">Error</Badge>
      case 'warning':
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Warning</Badge>
      case 'note':
        return <Badge variant="secondary">Note</Badge>
      default:
        return <Badge variant="outline">Info</Badge>
    }
  }

  const formatBytes = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  }

  // ============ PCAP Analysis Functions ============

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedFile(file)
      setError(null)
    }
  }, [])

  const startFileAnalysis = useCallback(async () => {
    if (!selectedFile) return

    if (analysisWsRef.current) {
      analysisWsRef.current.close()
    }

    setAnalyzing(true)
    setProgress(0)
    setProgressStep('Connecting...')
    setResult(null)
    setError(null)
    setAnalysisDialogOpen(true)

    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const wsUrl = `${wsProtocol}//${window.location.host}/api/v1/napi/analyze/pcap`

    const ws = new WebSocket(wsUrl)
    analysisWsRef.current = ws

    ws.onopen = async () => {
      setProgressStep('Sending file...')
      ws.send(JSON.stringify({ type: 'start', filename: selectedFile.name }))

      const chunkSize = 64 * 1024
      let offset = 0

      while (offset < selectedFile.size) {
        const chunk = selectedFile.slice(offset, offset + chunkSize)
        const buffer = await chunk.arrayBuffer()
        ws.send(buffer)
        offset += chunkSize
        const uploadProgress = Math.min((offset / selectedFile.size) * 10, 10)
        setProgress(uploadProgress)
      }

      ws.send(JSON.stringify({ type: 'end' }))
      setProgressStep('Analyzing...')
    }

    ws.onmessage = (event) => {
      const msg: AnalysisMessage = JSON.parse(event.data)

      switch (msg.type) {
        case 'status':
          // Status messages only update the step text, not progress
          setProgressStep(msg.message || 'Processing...')
          break
        case 'progress':
          // Only update progress if percent is provided
          if (typeof msg.percent === 'number') {
            setProgress(msg.percent)
          }
          if (msg.message) {
            setProgressStep(msg.message)
          }
          break
        case 'result':
          if (msg.data) {
            setResult(msg.data)
            setAnalyzing(false)
            setProgress(100)
            setProgressStep('Complete')
          }
          break
        case 'error':
          setError(msg.message || 'An error occurred')
          setAnalyzing(false)
          break
      }
    }

    ws.onerror = () => {
      setError('Connection error')
      setAnalyzing(false)
    }

    ws.onclose = () => {
      if (analysisWsRef.current === ws) {
        analysisWsRef.current = null
      }
    }
  }, [selectedFile])

  const analyzePcapData = useCallback(async (base64Data: string, filename: string) => {
    if (analysisWsRef.current) {
      analysisWsRef.current.close()
    }

    // Convert base64 to binary
    const binaryString = atob(base64Data)
    const bytes = new Uint8Array(binaryString.length)
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i)
    }
    const blob = new Blob([bytes], { type: 'application/vnd.tcpdump.pcap' })

    setAnalyzing(true)
    setProgress(0)
    setProgressStep('Connecting...')
    setResult(null)
    setError(null)
    setAnalysisDialogOpen(true)

    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const wsUrl = `${wsProtocol}//${window.location.host}/api/v1/napi/analyze/pcap`

    const ws = new WebSocket(wsUrl)
    analysisWsRef.current = ws

    ws.onopen = async () => {
      setProgressStep('Sending capture data...')
      ws.send(JSON.stringify({ type: 'start', filename }))

      const chunkSize = 64 * 1024
      let offset = 0

      while (offset < blob.size) {
        const chunk = blob.slice(offset, offset + chunkSize)
        const buffer = await chunk.arrayBuffer()
        ws.send(buffer)
        offset += chunkSize
        const uploadProgress = Math.min((offset / blob.size) * 10, 10)
        setProgress(uploadProgress)
      }

      ws.send(JSON.stringify({ type: 'end' }))
      setProgressStep('Analyzing...')
    }

    ws.onmessage = (event) => {
      const msg: AnalysisMessage = JSON.parse(event.data)

      switch (msg.type) {
        case 'status':
          // Status messages only update the step text, not progress
          setProgressStep(msg.message || 'Processing...')
          break
        case 'progress':
          // Only update progress if percent is provided
          if (typeof msg.percent === 'number') {
            setProgress(msg.percent)
          }
          if (msg.message) {
            setProgressStep(msg.message)
          }
          break
        case 'result':
          if (msg.data) {
            setResult(msg.data)
            setAnalyzing(false)
            setProgress(100)
            setProgressStep('Complete')
          }
          break
        case 'error':
          setError(msg.message || 'An error occurred')
          setAnalyzing(false)
          break
      }
    }

    ws.onerror = () => {
      setError('Connection error')
      setAnalyzing(false)
    }

    ws.onclose = () => {
      if (analysisWsRef.current === ws) {
        analysisWsRef.current = null
      }
    }
  }, [])

  const closeAnalysisDialog = useCallback(() => {
    if (analysisWsRef.current) {
      analysisWsRef.current.close()
      analysisWsRef.current = null
    }
    setAnalysisDialogOpen(false)
    setAnalyzing(false)
    setProgress(0)
    setProgressStep('')
  }, [])

  // ============ TCPDump Functions ============

  const startCapture = useCallback(() => {
    if (tcpdumpWsRef.current) {
      tcpdumpWsRef.current.close()
    }

    setCapturing(true)
    setPackets([])
    setPacketCount(0)
    setCaptureStatus('Connecting...')
    setCaptureFileSize(0)
    setPcapData(null)
    setPcapFilename('')

    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
    const params = new URLSearchParams({
      interface: selectedInterface,
      filter: captureFilter,
    })
    // Use the new live-pcap endpoint
    const wsUrl = `${wsProtocol}//${window.location.host}/api/v1/napi/tcpdump/live-pcap?${params}`

    const ws = new WebSocket(wsUrl)
    tcpdumpWsRef.current = ws

    ws.onopen = () => {
      setCaptureStatus('Capturing...')
    }

    ws.onmessage = (event) => {
      const msg: TCPDumpMessage = JSON.parse(event.data)

      switch (msg.type) {
        case 'status':
          setCaptureStatus(msg.message || 'Capturing...')
          if (msg.file_size !== undefined) {
            setCaptureFileSize(msg.file_size)
          }
          break
        case 'packet':
          if (msg.data) {
            const timestamp = new Date().toISOString()
            setPackets((prev) => [...prev.slice(-999), { timestamp, data: msg.data! }])
            setPacketCount(msg.count || 0)
          }
          break
        case 'pcap':
          // Store the pcap data for download/analysis
          if (msg.data) {
            setPcapData(msg.data)
            setPcapFilename(msg.filename || 'capture.pcap')
            if (msg.size !== undefined) {
              setCaptureFileSize(msg.size)
            }
          }
          break
        case 'complete':
          setCaptureStatus(msg.message || 'Capture complete')
          setCapturing(false)
          if (msg.file_size !== undefined) {
            setCaptureFileSize(msg.file_size)
          }
          if (msg.packet_count !== undefined) {
            setPacketCount(msg.packet_count)
          }
          break
        case 'error':
          setCaptureStatus(`Error: ${msg.message}`)
          setCapturing(false)
          break
        case 'ping':
          break
      }
    }

    ws.onerror = () => {
      setCaptureStatus('Connection error')
      setCapturing(false)
    }

    ws.onclose = () => {
      if (tcpdumpWsRef.current === ws) {
        tcpdumpWsRef.current = null
        setCapturing(false)
      }
    }
  }, [selectedInterface, captureFilter])

  const stopCapture = useCallback(() => {
    if (tcpdumpWsRef.current) {
      // Send stop command to get the pcap data
      tcpdumpWsRef.current.send(JSON.stringify({ type: 'stop' }))
    }
    setCaptureStatus('Stopping capture...')
  }, [])

  const clearCapture = useCallback(() => {
    setPackets([])
    setPacketCount(0)
    setCaptureStatus('')
    setCaptureFileSize(0)
    setPcapData(null)
    setPcapFilename('')
  }, [])

  const downloadPcap = useCallback(() => {
    if (!pcapData) return

    // Convert base64 to binary
    const binaryString = atob(pcapData)
    const bytes = new Uint8Array(binaryString.length)
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i)
    }

    const blob = new Blob([bytes], { type: 'application/vnd.tcpdump.pcap' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = pcapFilename || `capture_${new Date().toISOString().replace(/[:.]/g, '-')}.pcap`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, [pcapData, pcapFilename])

  const analyzeCapture = useCallback(() => {
    if (!pcapData) return
    analyzePcapData(pcapData, pcapFilename || 'capture.pcap')
  }, [pcapData, pcapFilename, analyzePcapData])

  // Sort issues by severity
  const sortedIssues = result?.issues.sort((a, b) => {
    const severityOrder = { error: 0, warning: 1, note: 2, info: 3 }
    return (severityOrder[a.severity] || 3) - (severityOrder[b.severity] || 3)
  })

  const issueCount = {
    error: result?.issues.filter((i) => i.severity === 'error').length || 0,
    warning: result?.issues.filter((i) => i.severity === 'warning').length || 0,
    note: result?.issues.filter((i) => i.severity === 'note').length || 0,
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Network Tools</h1>
        <p className="text-muted-foreground">Capture and analyze network traffic</p>
      </div>

      <Tabs defaultValue="capture" className="space-y-4">
        <TabsList>
          <TabsTrigger value="capture" className="flex items-center gap-2">
            <Radio className="h-4 w-4" />
            Live Capture
          </TabsTrigger>
          <TabsTrigger value="analyze" className="flex items-center gap-2">
            <FileSearch className="h-4 w-4" />
            PCAP Analysis
          </TabsTrigger>
        </TabsList>

        {/* Live Capture Tab */}
        <TabsContent value="capture" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Radio className="h-5 w-5" />
                TCPDump Live Capture
              </CardTitle>
              <CardDescription>
                Capture network traffic in real-time. The capture is saved as a PCAP file that can
                be downloaded or analyzed directly.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="interface">Interface</Label>
                  <Select
                    value={selectedInterface}
                    onValueChange={setSelectedInterface}
                    disabled={capturing}
                  >
                    <SelectTrigger id="interface">
                      <SelectValue placeholder="Select interface" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">any (all interfaces)</SelectItem>
                      {interfaces?.map((iface) => (
                        <SelectItem key={iface.name} value={iface.name}>
                          {iface.name}
                          {iface.ip_address && ` (${iface.ip_address})`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="filter">BPF Filter (optional)</Label>
                  <Input
                    id="filter"
                    placeholder="e.g., port 80, host 192.168.1.1, icmp, arp"
                    value={captureFilter}
                    onChange={(e) => setCaptureFilter(e.target.value)}
                    disabled={capturing}
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {!capturing ? (
                  <Button onClick={startCapture}>
                    <Play className="mr-2 h-4 w-4" />
                    Start Capture
                  </Button>
                ) : (
                  <Button variant="destructive" onClick={stopCapture}>
                    <Square className="mr-2 h-4 w-4" />
                    Stop Capture
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={downloadPcap}
                  disabled={!pcapData}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Download PCAP
                </Button>
                <Button
                  variant="default"
                  onClick={analyzeCapture}
                  disabled={!pcapData}
                >
                  <FileSearch className="mr-2 h-4 w-4" />
                  Analyze
                </Button>
                <Button
                  variant="outline"
                  onClick={clearCapture}
                  disabled={capturing}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Clear
                </Button>
              </div>

              {(captureStatus || captureFileSize > 0) && (
                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    {capturing && <Loader2 className="h-4 w-4 animate-spin" />}
                    <span className="text-muted-foreground">{captureStatus}</span>
                  </div>
                  {captureFileSize > 0 && (
                    <Badge variant="secondary">
                      <HardDrive className="mr-1 h-3 w-3" />
                      {formatBytes(captureFileSize)}
                    </Badge>
                  )}
                  {pcapData && !capturing && (
                    <Badge variant="default">
                      <CheckCircle2 className="mr-1 h-3 w-3" />
                      PCAP ready
                    </Badge>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Captured Packets */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <Terminal className="h-4 w-4" />
                Capture Log ({packetCount} packets)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] rounded-md border bg-muted/50 p-2">
                {packets.length > 0 ? (
                  <div className="font-mono text-xs space-y-1">
                    {packets.map((packet, index) => (
                      <div
                        key={index}
                        className="hover:bg-muted/80 px-2 py-1 rounded whitespace-pre-wrap break-all"
                      >
                        {packet.data}
                      </div>
                    ))}
                    <div ref={packetsEndRef} />
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    {capturing ? 'Capturing packets...' : 'No packets captured yet'}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* PCAP Analysis Tab */}
        <TabsContent value="analyze" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSearch className="h-5 w-5" />
                PCAP File Analysis
              </CardTitle>
              <CardDescription>
                Upload a tcpdump/pcap file to analyze for network problems such as TCP
                retransmissions, connection resets, DNS issues, and more.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-end gap-4">
                  <div className="flex-1 space-y-2">
                    <Label htmlFor="pcap-file">PCAP File</Label>
                    <Input
                      id="pcap-file"
                      type="file"
                      accept=".pcap,.pcapng,.cap"
                      ref={fileInputRef}
                      onChange={handleFileSelect}
                      disabled={analyzing}
                    />
                  </div>
                  <Button onClick={startFileAnalysis} disabled={!selectedFile || analyzing}>
                    {analyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Analyze
                      </>
                    )}
                  </Button>
                </div>

                {selectedFile && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <HardDrive className="h-4 w-4" />
                    {selectedFile.name} ({formatBytes(selectedFile.size)})
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm font-medium">
                How to capture traffic for analysis
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground space-y-2">
              <p>
                Use the <strong>Live Capture</strong> tab above to capture traffic directly, or use
                tcpdump on the command line:
              </p>
              <pre className="bg-muted rounded-md p-3 font-mono text-xs overflow-x-auto">
                tcpdump -i eth0 -w capture.pcap
              </pre>
              <p>Common filter examples:</p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>
                  <code className="bg-muted px-1 rounded">port 80</code> - HTTP traffic
                </li>
                <li>
                  <code className="bg-muted px-1 rounded">host 192.168.1.100</code> - Specific host
                </li>
                <li>
                  <code className="bg-muted px-1 rounded">icmp</code> - ICMP/Ping traffic
                </li>
                <li>
                  <code className="bg-muted px-1 rounded">tcp port 443</code> - HTTPS traffic
                </li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Analysis Results Dialog */}
      <Dialog open={analysisDialogOpen} onOpenChange={(open) => !open && closeAnalysisDialog()}>
        <DialogContent className="max-w-5xl sm:max-w-5xl w-full max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader className="shrink-0 pb-2 pr-8">
            <DialogTitle className="flex items-center gap-2 text-xl">
              <FileSearch className="h-5 w-5" />
              PCAP Analysis Results
            </DialogTitle>
            <DialogDescription>
              {analyzing ? (
                <span className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  {progressStep}
                </span>
              ) : result ? (
                `${result.filename} - ${result.total_packets} packets analyzed`
              ) : error ? (
                <span className="text-destructive">{error}</span>
              ) : progressStep ? (
                <span className="text-yellow-500">{progressStep}</span>
              ) : null}
            </DialogDescription>
          </DialogHeader>

          <Separator />

          <div className="flex-1 overflow-y-auto min-h-0 pt-4">
            {analyzing && !result ? (
              <div className="flex flex-col items-center justify-center h-64 gap-4">
                <Loader2 className="h-16 w-16 animate-spin text-muted-foreground" />
                <p className="text-lg text-muted-foreground">{progressStep}</p>
                <div className="w-64">
                  <Progress value={progress} className="h-2" />
                </div>
                <p className="text-sm text-muted-foreground">{progress}%</p>
              </div>
            ) : error && !result ? (
              <div className="flex flex-col items-center justify-center h-64 gap-4">
                <AlertCircle className="h-16 w-16 text-destructive" />
                <p className="text-lg text-destructive">{error}</p>
              </div>
            ) : result ? (
              <div className="pr-2 space-y-4">
                {/* Summary Cards */}
                <div className="grid gap-4 grid-cols-2 md:grid-cols-4">
                  <Card>
                    <CardContent className="pt-4">
                      <div className="flex items-center gap-2">
                        <Activity className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Packets</span>
                      </div>
                      <p className="text-2xl font-bold">{result.total_packets.toLocaleString()}</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="flex items-center gap-2">
                        <HardDrive className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Size</span>
                      </div>
                      <p className="text-2xl font-bold">
                        {formatBytes(result.statistics.total_bytes || result.file_size)}
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Issues</span>
                      </div>
                      <p className="text-2xl font-bold">
                        {result.issues.length}
                        {issueCount.error > 0 && (
                          <span className="text-sm text-destructive ml-2">
                            ({issueCount.error} errors)
                          </span>
                        )}
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-4">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Conversations</span>
                      </div>
                      <p className="text-2xl font-bold">{result.conversations.length}</p>
                    </CardContent>
                  </Card>
                </div>

                {/* Issues Section */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4" />
                      Network Issues ({result.issues.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {result.issues.length > 0 ? (
                      <div className="rounded-md border">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead className="w-[100px]">Severity</TableHead>
                              <TableHead className="w-[80px]">Protocol</TableHead>
                              <TableHead className="w-[80px]">Count</TableHead>
                              <TableHead>Issue</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {sortedIssues?.map((issue, index) => (
                              <TableRow key={index}>
                                <TableCell>
                                  <div className="flex items-center gap-2">
                                    {getSeverityIcon(issue.severity)}
                                    {getSeverityBadge(issue.severity)}
                                  </div>
                                </TableCell>
                                <TableCell className="font-mono text-sm">{issue.protocol}</TableCell>
                                <TableCell className="font-bold">{issue.count}</TableCell>
                                <TableCell>
                                  <div>
                                    <p className="font-medium">{issue.message}</p>
                                    {issue.description && (
                                      <p className="text-xs text-muted-foreground">
                                        {issue.description}
                                      </p>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center py-8 gap-2 text-muted-foreground">
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                        No network issues detected
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Two-column layout: Protocols + Conversations */}
                <div className="grid gap-4 grid-cols-1 md:grid-cols-2">
                  {/* Protocol Breakdown */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Layers className="h-4 w-4" />
                        Protocol Breakdown
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {Object.keys(result.protocols).length > 0 ? (
                        <div className="space-y-2">
                          {Object.entries(result.protocols)
                            .sort(([, a], [, b]) => b - a)
                            .slice(0, 10)
                            .map(([protocol, count]) => (
                              <div
                                key={protocol}
                                className="flex items-center justify-between text-sm"
                              >
                                <span className="font-mono">{protocol}</span>
                                <Badge variant="secondary">{count.toLocaleString()}</Badge>
                              </div>
                            ))}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground text-center py-4">
                          No protocol data available
                        </p>
                      )}
                    </CardContent>
                  </Card>

                  {/* Top Conversations */}
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Network className="h-4 w-4" />
                        Top Conversations
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {result.conversations.length > 0 ? (
                        <div className="space-y-2 text-sm">
                          {result.conversations.slice(0, 8).map((conv, index) => (
                            <div key={index} className="flex items-center justify-between gap-2">
                              <span
                                className="font-mono text-xs truncate flex-1"
                                title={`${conv.endpoint_a} ↔ ${conv.endpoint_b}`}
                              >
                                {conv.endpoint_a} ↔ {conv.endpoint_b}
                              </span>
                              <Badge variant="outline" className="shrink-0">
                                {conv.packets} pkts
                              </Badge>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground text-center py-4">
                          No conversation data available
                        </p>
                      )}
                    </CardContent>
                  </Card>
                </div>

                {/* DNS Statistics and Queries */}
                {(result.statistics.dns_queries || result.dns_queries?.length > 0) && (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Globe className="h-4 w-4" />
                        DNS Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-sm text-muted-foreground">Queries</span>
                          <p className="text-xl font-bold">{result.statistics.dns_queries || 0}</p>
                        </div>
                        <div>
                          <span className="text-sm text-muted-foreground">Responses</span>
                          <p className="text-xl font-bold">{result.statistics.dns_responses || 0}</p>
                        </div>
                      </div>
                      {result.dns_queries?.length > 0 && (
                        <>
                          <Separator />
                          <div>
                            <p className="text-xs font-medium text-muted-foreground mb-2">
                              Resolved Domains ({result.dns_queries.length})
                            </p>
                            <ScrollArea className="h-32">
                              <div className="space-y-1">
                                {result.dns_queries.map((query, idx) => (
                                  <div
                                    key={idx}
                                    className="flex items-center justify-between text-xs font-mono"
                                  >
                                    <span className="truncate flex-1" title={query.name}>
                                      {query.name}
                                    </span>
                                    <Badge variant="outline" className="ml-2 text-[10px]">
                                      {query.type}
                                    </Badge>
                                  </div>
                                ))}
                              </div>
                            </ScrollArea>
                          </div>
                        </>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* HTTP Traffic */}
                {(result.http_requests?.length > 0 || result.http_responses?.length > 0) && (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <ExternalLink className="h-4 w-4" />
                        HTTP Traffic
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {result.http_requests?.length > 0 && (
                        <div>
                          <p className="text-xs font-medium text-muted-foreground mb-2">
                            Requests ({result.http_requests.length})
                          </p>
                          <ScrollArea className="h-40">
                            <div className="space-y-2">
                              {result.http_requests.map((req, idx) => (
                                <div
                                  key={idx}
                                  className="text-xs p-2 rounded bg-muted/50 space-y-1"
                                >
                                  <div className="flex items-center gap-2">
                                    <Badge
                                      variant={
                                        req.method === 'GET'
                                          ? 'secondary'
                                          : req.method === 'POST'
                                            ? 'default'
                                            : 'outline'
                                      }
                                      className="text-[10px]"
                                    >
                                      {req.method}
                                    </Badge>
                                    <span className="font-medium truncate">{req.host}</span>
                                  </div>
                                  <p className="font-mono text-muted-foreground truncate" title={req.uri}>
                                    {req.uri}
                                  </p>
                                  {req.user_agent && (
                                    <p className="text-muted-foreground truncate text-[10px]">
                                      UA: {req.user_agent}
                                    </p>
                                  )}
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        </div>
                      )}
                      {result.http_responses?.length > 0 && (
                        <div>
                          <p className="text-xs font-medium text-muted-foreground mb-2">
                            Response Summary
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {Object.entries(
                              result.http_responses.reduce(
                                (acc, res) => {
                                  const code = res.status_code || 'unknown'
                                  acc[code] = (acc[code] || 0) + 1
                                  return acc
                                },
                                {} as Record<string, number>
                              )
                            )
                              .sort(([a], [b]) => a.localeCompare(b))
                              .map(([code, count]) => (
                                <Badge
                                  key={code}
                                  variant={
                                    code.startsWith('2')
                                      ? 'default'
                                      : code.startsWith('3')
                                        ? 'secondary'
                                        : code.startsWith('4')
                                          ? 'outline'
                                          : 'destructive'
                                  }
                                >
                                  {code}: {count}x
                                </Badge>
                              ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}

                {/* TLS/SSL Connections */}
                {result.tls_connections?.length > 0 && (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Lock className="h-4 w-4" />
                        TLS/SSL Connections ({result.tls_connections.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-32">
                        <div className="space-y-1">
                          {result.tls_connections.map((tls, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between text-xs"
                            >
                              <span className="font-mono truncate flex-1" title={tls.server_name}>
                                {tls.server_name}
                              </span>
                              {tls.version && (
                                <Badge variant="outline" className="ml-2 text-[10px]">
                                  {tls.version}
                                </Badge>
                              )}
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                )}

                {/* Credentials Warning */}
                {result.credentials?.length > 0 && (
                  <Card className="border-destructive">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2 text-destructive">
                        <Key className="h-4 w-4" />
                        Clear Text Credentials Detected!
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {result.credentials.map((cred, idx) => (
                          <div
                            key={idx}
                            className="flex items-center gap-2 text-xs p-2 rounded bg-destructive/10"
                          >
                            <Shield className="h-3 w-3 text-destructive" />
                            <span className="font-medium">{cred.protocol}:</span>
                            <span className="text-muted-foreground">{cred.info}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* File Transfers */}
                {result.files?.length > 0 && (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <File className="h-4 w-4" />
                        File Transfers ({result.files.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-32">
                        <div className="space-y-1">
                          {result.files.map((file, idx) => (
                            <div
                              key={idx}
                              className="flex items-center justify-between text-xs"
                            >
                              <span className="truncate flex-1" title={file.filename}>
                                {file.filename || 'unnamed'}
                              </span>
                              <span className="text-muted-foreground ml-2">
                                {file.content_type}
                              </span>
                              {file.size && (
                                <Badge variant="outline" className="ml-2 text-[10px]">
                                  {formatBytes(parseInt(file.size) || 0)}
                                </Badge>
                              )}
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                )}

                {/* Top Talkers */}
                {result.statistics.top_talkers && result.statistics.top_talkers.length > 0 && (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm font-medium flex items-center gap-2">
                        <Server className="h-4 w-4" />
                        Top Talkers
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        {result.statistics.top_talkers.slice(0, 5).map((talker, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between text-sm"
                          >
                            <span className="font-mono">{talker.ip}</span>
                            <div className="flex gap-2">
                              <Badge variant="secondary">{talker.packets} pkts</Badge>
                              <Badge variant="outline">{formatBytes(parseInt(talker.bytes) || 0)}</Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Raw JSON */}
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="raw-json" className="border-none">
                    <AccordionTrigger className="text-xs text-muted-foreground py-2">
                      <span className="flex items-center gap-2">
                        <Terminal className="h-3 w-3" />
                        Raw JSON Data
                      </span>
                    </AccordionTrigger>
                    <AccordionContent>
                      <pre className="bg-muted rounded-md p-4 text-xs overflow-x-auto whitespace-pre-wrap max-h-64">
                        {JSON.stringify(result, null, 2)}
                      </pre>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </div>
            ) : !analyzing && !error && progressStep ? (
              <div className="flex flex-col items-center justify-center h-64 gap-4">
                <Info className="h-16 w-16 text-yellow-500" />
                <p className="text-center text-muted-foreground max-w-md">{progressStep}</p>
              </div>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
