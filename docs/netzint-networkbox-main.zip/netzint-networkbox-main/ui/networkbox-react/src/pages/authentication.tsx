import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  useAuthenticationList,
  useCreateAuthentication,
  useUpdateAuthentication,
  useDeleteAuthentication,
  useTestAuthentication,
  useTestAuthenticationInline,
} from '@/hooks/use-authentication'
import { Plus, Trash2, RefreshCw, KeyRound, TestTube, Eye, EyeOff, Check, X, Pencil } from 'lucide-react'
import { toast } from 'sonner'
import type { Authentication, AuthenticationTest } from '@/types'

export function AuthenticationPage() {
  const { data: authList, isLoading } = useAuthenticationList()
  const createAuth = useCreateAuthentication()
  const updateAuth = useUpdateAuthentication()
  const deleteAuth = useDeleteAuthentication()
  const testAuth = useTestAuthentication()
  const testAuthInline = useTestAuthenticationInline()

  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [isEditOpen, setIsEditOpen] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showEditPassword, setShowEditPassword] = useState(false)
  const [testingAuth, setTestingAuth] = useState<string | null>(null)
  const [testingInline, setTestingInline] = useState(false)

  const [newAuth, setNewAuth] = useState<Partial<Authentication>>({
    name: '',
    server: '',
    port: 389,
    use_ssl: false,
    validate_cert: false,
    binduser: '',
    password: '',
    basedn: '',
    userfilter: '(&(objectClass=user)(sAMAccountName=%s))',
  })

  const [editAuth, setEditAuth] = useState<Partial<Authentication> & { originalName?: string }>({
    name: '',
    server: '',
    port: 389,
    use_ssl: false,
    validate_cert: false,
    binduser: '',
    password: '',
    basedn: '',
    userfilter: '',
  })

  const handleCreate = async () => {
    try {
      await createAuth.mutateAsync(newAuth as Authentication)
      toast.success('Authentication provider created successfully')
      setIsCreateOpen(false)
      resetForm()
    } catch {
      toast.error('Failed to create authentication provider')
    }
  }

  const resetForm = () => {
    setNewAuth({
      name: '',
      server: '',
      port: 389,
      use_ssl: false,
      validate_cert: false,
      binduser: '',
      password: '',
      basedn: '',
      userfilter: '(&(objectClass=user)(sAMAccountName=%s))',
    })
  }

  const handleDelete = async (name: string) => {
    if (!confirm('Are you sure you want to delete this authentication provider?')) return
    try {
      await deleteAuth.mutateAsync(name)
      toast.success('Authentication provider deleted successfully')
    } catch {
      toast.error('Failed to delete authentication provider')
    }
  }

  const handleTest = async (name: string) => {
    setTestingAuth(name)
    try {
      const result = await testAuth.mutateAsync(name)
      if (result.status) {
        toast.success('Connection successful')
      } else {
        toast.error(result.message || 'Connection failed')
      }
    } catch {
      toast.error('Connection test failed')
    } finally {
      setTestingAuth(null)
    }
  }

  const handleTestInline = async (auth: AuthenticationTest) => {
    setTestingInline(true)
    try {
      const result = await testAuthInline.mutateAsync(auth)
      if (result.status) {
        toast.success('Connection successful')
      } else {
        toast.error(result.message || 'Connection failed')
      }
    } catch {
      toast.error('Connection test failed')
    } finally {
      setTestingInline(false)
    }
  }

  const handleEdit = (auth: Authentication) => {
    setEditAuth({
      ...auth,
      originalName: auth.name,
      password: '', // Don't show existing password
    })
    setIsEditOpen(true)
    setShowEditPassword(false)
  }

  const handleUpdate = async () => {
    try {
      const { originalName, ...updateData } = editAuth
      // Remove empty password to keep existing one
      const filteredData = Object.fromEntries(
        Object.entries(updateData).filter(([key, value]) => key !== 'password' || value)
      )
      await updateAuth.mutateAsync({ name: originalName!, data: filteredData })
      toast.success('Authentication provider updated successfully')
      setIsEditOpen(false)
    } catch {
      toast.error('Failed to update authentication provider')
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Authentication</h1>
          <p className="text-muted-foreground">Manage LDAP authentication providers</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Provider
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Create Authentication Provider</DialogTitle>
              <DialogDescription>Configure a new LDAP authentication provider</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label>Name</Label>
                <Input
                  value={newAuth.name}
                  onChange={(e) => setNewAuth({ ...newAuth, name: e.target.value })}
                  placeholder="ldap-provider"
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2 space-y-2">
                  <Label>Server</Label>
                  <Input
                    value={newAuth.server}
                    onChange={(e) => setNewAuth({ ...newAuth, server: e.target.value })}
                    placeholder="ldap.example.com"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Port</Label>
                  <Input
                    type="number"
                    value={newAuth.port}
                    onChange={(e) => setNewAuth({ ...newAuth, port: parseInt(e.target.value) })}
                  />
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Switch
                    id="use_ssl"
                    checked={newAuth.use_ssl}
                    onCheckedChange={(checked) => {
                      setNewAuth({
                        ...newAuth,
                        use_ssl: checked,
                        port: checked ? 636 : 389,
                      })
                    }}
                  />
                  <Label htmlFor="use_ssl">Use SSL</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    id="validate_cert"
                    checked={newAuth.validate_cert}
                    onCheckedChange={(checked) =>
                      setNewAuth({ ...newAuth, validate_cert: checked })
                    }
                    disabled={!newAuth.use_ssl}
                  />
                  <Label htmlFor="validate_cert">Validate Certificate</Label>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Bind User (DN)</Label>
                <Input
                  value={newAuth.binduser}
                  onChange={(e) => setNewAuth({ ...newAuth, binduser: e.target.value })}
                  placeholder="CN=Admin,OU=Users,DC=example,DC=com"
                />
              </div>
              <div className="space-y-2">
                <Label>Password</Label>
                <div className="relative">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={newAuth.password}
                    onChange={(e) => setNewAuth({ ...newAuth, password: e.target.value })}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Base DN</Label>
                <Input
                  value={newAuth.basedn}
                  onChange={(e) => setNewAuth({ ...newAuth, basedn: e.target.value })}
                  placeholder="DC=example,DC=com"
                />
              </div>
              <div className="space-y-2">
                <Label>User Filter</Label>
                <Input
                  value={newAuth.userfilter}
                  onChange={(e) => setNewAuth({ ...newAuth, userfilter: e.target.value })}
                  placeholder="(&(objectClass=user)(sAMAccountName=%s))"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => handleTestInline(newAuth as AuthenticationTest)}
                disabled={testingInline || !newAuth.server || !newAuth.binduser || !newAuth.password}
              >
                {testingInline ? (
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <TestTube className="mr-2 h-4 w-4" />
                )}
                Test Connection
              </Button>
              <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreate} disabled={createAuth.isPending}>
                Create
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Authentication Providers</CardTitle>
          <CardDescription>Configured LDAP authentication providers</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Server</TableHead>
                  <TableHead>Port</TableHead>
                  <TableHead>SSL</TableHead>
                  <TableHead>Base DN</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-32"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {authList?.map((auth) => (
                  <TableRow key={auth.name}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <KeyRound className="h-4 w-4 text-primary" />
                        <span className="font-medium">{auth.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono">{auth.server}</TableCell>
                    <TableCell>{auth.port}</TableCell>
                    <TableCell>
                      {auth.use_ssl ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <X className="h-4 w-4 text-muted-foreground" />
                      )}
                    </TableCell>
                    <TableCell className="max-w-48 truncate font-mono text-sm">
                      {auth.basedn}
                    </TableCell>
                    <TableCell>
                      {auth.status !== undefined && (
                        <Badge variant={auth.status ? 'default' : 'destructive'}>
                          {auth.status ? 'OK' : 'Error'}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleTest(auth.name)}
                          disabled={testingAuth === auth.name}
                        >
                          {testingAuth === auth.name ? (
                            <RefreshCw className="h-4 w-4 animate-spin" />
                          ) : (
                            <TestTube className="h-4 w-4" />
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(auth)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(auth.name)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!authList || authList.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground">
                      No authentication providers configured
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Authentication Provider</DialogTitle>
            <DialogDescription>Update LDAP authentication provider settings</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input
                value={editAuth.name}
                disabled
                className="bg-muted"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2 space-y-2">
                <Label>Server</Label>
                <Input
                  value={editAuth.server}
                  onChange={(e) => setEditAuth({ ...editAuth, server: e.target.value })}
                  placeholder="ldap.example.com"
                />
              </div>
              <div className="space-y-2">
                <Label>Port</Label>
                <Input
                  type="number"
                  value={editAuth.port}
                  onChange={(e) => setEditAuth({ ...editAuth, port: parseInt(e.target.value) })}
                />
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Switch
                  id="edit_use_ssl"
                  checked={editAuth.use_ssl}
                  onCheckedChange={(checked) => {
                    setEditAuth({
                      ...editAuth,
                      use_ssl: checked,
                      port: checked ? 636 : 389,
                    })
                  }}
                />
                <Label htmlFor="edit_use_ssl">Use SSL</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  id="edit_validate_cert"
                  checked={editAuth.validate_cert}
                  onCheckedChange={(checked) =>
                    setEditAuth({ ...editAuth, validate_cert: checked })
                  }
                  disabled={!editAuth.use_ssl}
                />
                <Label htmlFor="edit_validate_cert">Validate Certificate</Label>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Bind User (DN)</Label>
              <Input
                value={editAuth.binduser}
                onChange={(e) => setEditAuth({ ...editAuth, binduser: e.target.value })}
                placeholder="CN=Admin,OU=Users,DC=example,DC=com"
              />
            </div>
            <div className="space-y-2">
              <Label>Password (leave empty to keep current)</Label>
              <div className="relative">
                <Input
                  type={showEditPassword ? 'text' : 'password'}
                  value={editAuth.password}
                  onChange={(e) => setEditAuth({ ...editAuth, password: e.target.value })}
                  placeholder="••••••••"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0"
                  onClick={() => setShowEditPassword(!showEditPassword)}
                >
                  {showEditPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Base DN</Label>
              <Input
                value={editAuth.basedn}
                onChange={(e) => setEditAuth({ ...editAuth, basedn: e.target.value })}
                placeholder="DC=example,DC=com"
              />
            </div>
            <div className="space-y-2">
              <Label>User Filter</Label>
              <Input
                value={editAuth.userfilter}
                onChange={(e) => setEditAuth({ ...editAuth, userfilter: e.target.value })}
                placeholder="(&(objectClass=user)(sAMAccountName=%s))"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => handleTestInline(editAuth as AuthenticationTest)}
              disabled={testingInline || !editAuth.server || !editAuth.binduser}
            >
              {testingInline ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <TestTube className="mr-2 h-4 w-4" />
              )}
              Test Connection
            </Button>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdate} disabled={updateAuth.isPending}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
