import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { useNetworks, useInterfaces, useCreateNetwork, useUpdateNetwork, useDeleteNetwork, maskToCidr } from '@/hooks/use-networks'
import { useSophosNetworkVLANs } from '@/hooks/use-sophos'
import { Plus, Trash2, Download, RefreshCw, Pencil } from 'lucide-react'
import { toast } from 'sonner'
import type { Network, SophosXGSConnection } from '@/types'

export function NetworksPage() {
  const { data: networks, isLoading } = useNetworks()
  const { data: interfaces } = useInterfaces()
  const createNetwork = useCreateNetwork()
  const updateNetwork = useUpdateNetwork()
  const deleteNetwork = useDeleteNetwork()
  const sophosVLANs = useSophosNetworkVLANs()

  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [isEditOpen, setIsEditOpen] = useState(false)
  const [isDeleteOpen, setIsDeleteOpen] = useState(false)
  const [isImportOpen, setIsImportOpen] = useState(false)
  const [editingNetwork, setEditingNetwork] = useState<Network | null>(null)
  const [deletingNetwork, setDeletingNetwork] = useState<Network | null>(null)
  const [newNetwork, setNewNetwork] = useState<Partial<Network>>({
    name: '',
    parent: '',
    vlan_id: 0,
    address: '',
    mask: '255.255.255.0',
    ip_address: '',
  })

  const [sophosConnection, setSophosConnection] = useState<SophosXGSConnection>({
    hostname: '',
    port: 4444,
    username: '',
    password: '',
  })
  const [sophosVLANList, setSophosVLANList] = useState<Network[]>([])

  const handleCreate = async () => {
    try {
      await createNetwork.mutateAsync(newNetwork as Network)
      toast.success('Network created successfully')
      setIsCreateOpen(false)
      setNewNetwork({ name: '', parent: '', vlan_id: 0, address: '', mask: '255.255.255.0', ip_address: '' })
    } catch {
      toast.error('Failed to create network')
    }
  }

  const handleEdit = (network: Network) => {
    setEditingNetwork({ ...network })
    setIsEditOpen(true)
  }

  const handleUpdate = async () => {
    if (!editingNetwork) return
    try {
      await updateNetwork.mutateAsync({
        vlanId: editingNetwork.vlan_id,
        data: {
          name: editingNetwork.name,
          address: editingNetwork.address,
          mask: editingNetwork.mask,
          ip_address: editingNetwork.ip_address,
        },
      })
      toast.success('Network updated successfully')
      setIsEditOpen(false)
      setEditingNetwork(null)
    } catch {
      toast.error('Failed to update network')
    }
  }

  const handleDeleteClick = (network: Network) => {
    setDeletingNetwork(network)
    setIsDeleteOpen(true)
  }

  const handleDelete = async () => {
    if (!deletingNetwork) return
    try {
      await deleteNetwork.mutateAsync(deletingNetwork.vlan_id)
      toast.success('Network deleted successfully')
      setIsDeleteOpen(false)
      setDeletingNetwork(null)
    } catch {
      toast.error('Failed to delete network')
    }
  }

  const handleSophosImport = async () => {
    try {
      const vlans = await sophosVLANs.mutateAsync(sophosConnection)
      const defaultParent = interfaces?.[0] ?? ''
      setSophosVLANList(
        vlans.map((v) => ({
          name: v.name,
          parent: defaultParent,
          vlan_id: v.vlan_id,
          address: v.address,
          mask: v.mask,
        }))
      )
    } catch {
      toast.error('Failed to connect to Sophos')
    }
  }

  const handleImportVLAN = async (vlan: Network) => {
    try {
      await createNetwork.mutateAsync(vlan)
      toast.success(`Network ${vlan.name} imported successfully`)
      setSophosVLANList((prev) => prev.filter((v) => v.vlan_id !== vlan.vlan_id))
    } catch {
      toast.error('Failed to import network')
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Networks</h1>
          <p className="text-muted-foreground">Manage network interfaces and VLANs</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isImportOpen} onOpenChange={setIsImportOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" />
                Import from Sophos
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Import from Sophos XGS</DialogTitle>
                <DialogDescription>
                  Connect to your Sophos XGS to import VLAN configurations
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Hostname</Label>
                    <Input
                      value={sophosConnection.hostname}
                      onChange={(e) =>
                        setSophosConnection({ ...sophosConnection, hostname: e.target.value })
                      }
                      placeholder="192.168.1.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Port</Label>
                    <Input
                      type="number"
                      value={sophosConnection.port}
                      onChange={(e) =>
                        setSophosConnection({
                          ...sophosConnection,
                          port: parseInt(e.target.value),
                        })
                      }
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Username</Label>
                    <Input
                      value={sophosConnection.username}
                      onChange={(e) =>
                        setSophosConnection({ ...sophosConnection, username: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Password</Label>
                    <Input
                      type="password"
                      value={sophosConnection.password}
                      onChange={(e) =>
                        setSophosConnection({ ...sophosConnection, password: e.target.value })
                      }
                    />
                  </div>
                </div>
                <Button onClick={handleSophosImport} disabled={sophosVLANs.isPending}>
                  {sophosVLANs.isPending ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    'Fetch VLANs'
                  )}
                </Button>
                {sophosVLANList.length > 0 && (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>VLAN ID</TableHead>
                        <TableHead>Network</TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sophosVLANList.map((vlan) => (
                        <TableRow key={vlan.vlan_id}>
                          <TableCell>{vlan.name}</TableCell>
                          <TableCell>{vlan.vlan_id}</TableCell>
                          <TableCell>
                            {vlan.address}/{maskToCidr(vlan.mask)}
                          </TableCell>
                          <TableCell>
                            <Button
                              size="sm"
                              onClick={() => handleImportVLAN(vlan)}
                              disabled={networks?.some((n) => n.vlan_id === vlan.vlan_id)}
                            >
                              {networks?.some((n) => n.vlan_id === vlan.vlan_id)
                                ? 'Already exists'
                                : 'Import'}
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Network
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Network</DialogTitle>
                <DialogDescription>Add a new network interface with VLAN</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input
                    value={newNetwork.name}
                    onChange={(e) => setNewNetwork({ ...newNetwork, name: e.target.value })}
                    placeholder="Network name"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Parent Interface</Label>
                    <Select
                      value={newNetwork.parent}
                      onValueChange={(value) => setNewNetwork({ ...newNetwork, parent: value })}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select interface" />
                      </SelectTrigger>
                      <SelectContent>
                        {interfaces?.map((iface) => (
                          <SelectItem key={iface} value={iface}>
                            {iface}
                          </SelectItem>
                        ))}
                        {(!interfaces || interfaces.length === 0) && (
                          <SelectItem value="" disabled>
                            No interfaces available
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>VLAN ID</Label>
                    <Input
                      type="number"
                      value={newNetwork.vlan_id}
                      onChange={(e) =>
                        setNewNetwork({ ...newNetwork, vlan_id: parseInt(e.target.value) })
                      }
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Network Address</Label>
                    <Input
                      value={newNetwork.address}
                      onChange={(e) => setNewNetwork({ ...newNetwork, address: e.target.value })}
                      placeholder="192.168.1.0"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Subnet Mask</Label>
                    <Input
                      value={newNetwork.mask}
                      onChange={(e) => setNewNetwork({ ...newNetwork, mask: e.target.value })}
                      placeholder="255.255.255.0"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>NAPI IP Address</Label>
                  <Input
                    value={newNetwork.ip_address}
                    onChange={(e) => setNewNetwork({ ...newNetwork, ip_address: e.target.value })}
                    placeholder="192.168.1.250 (optional)"
                  />
                  <p className="text-xs text-muted-foreground">
                    IP address for the NAPI container in this network. Leave empty to disable NAPI access.
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={createNetwork.isPending}>
                  Create
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Network Interfaces</CardTitle>
          <CardDescription>All configured network interfaces and VLANs</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Parent</TableHead>
                  <TableHead>VLAN ID</TableHead>
                  <TableHead>Network</TableHead>
                  <TableHead>Subnet Mask</TableHead>
                  <TableHead>NAPI IP</TableHead>
                  <TableHead className="w-24"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {networks?.map((network) => (
                  <TableRow key={network.vlan_id}>
                    <TableCell className="font-medium">{network.name}</TableCell>
                    <TableCell>{network.parent}</TableCell>
                    <TableCell>{network.vlan_id}</TableCell>
                    <TableCell className="font-mono">{network.address}</TableCell>
                    <TableCell className="font-mono">
                      {network.mask} (/{maskToCidr(network.mask)})
                    </TableCell>
                    <TableCell className="font-mono">
                      {network.ip_address || <span className="text-muted-foreground">-</span>}
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(network)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDeleteClick(network)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {(!networks || networks.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground">
                      No networks configured
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Network</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the network "{deletingNetwork?.name}"?
              This will also remove the associated VLAN interface and Docker network.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={handleDelete}
              disabled={deleteNetwork.isPending}
            >
              {deleteNetwork.isPending ? 'Deleting...' : 'Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Network Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Network</DialogTitle>
            <DialogDescription>
              Update network configuration. Parent interface and VLAN ID cannot be changed.
            </DialogDescription>
          </DialogHeader>
          {editingNetwork && (
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label>Name</Label>
                <Input
                  value={editingNetwork.name}
                  onChange={(e) =>
                    setEditingNetwork({ ...editingNetwork, name: e.target.value })
                  }
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Parent Interface</Label>
                  <Input value={editingNetwork.parent} disabled className="bg-muted" />
                </div>
                <div className="space-y-2">
                  <Label>VLAN ID</Label>
                  <Input value={editingNetwork.vlan_id} disabled className="bg-muted" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Network Address</Label>
                  <Input
                    value={editingNetwork.address}
                    onChange={(e) =>
                      setEditingNetwork({ ...editingNetwork, address: e.target.value })
                    }
                    placeholder="192.168.1.0"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Subnet Mask</Label>
                  <Input
                    value={editingNetwork.mask}
                    onChange={(e) =>
                      setEditingNetwork({ ...editingNetwork, mask: e.target.value })
                    }
                    placeholder="255.255.255.0"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>NAPI IP Address</Label>
                <Input
                  value={editingNetwork.ip_address || ''}
                  onChange={(e) =>
                    setEditingNetwork({ ...editingNetwork, ip_address: e.target.value })
                  }
                  placeholder="192.168.1.250 (optional)"
                />
                <p className="text-xs text-muted-foreground">
                  IP address for the NAPI container in this network. Leave empty to disable NAPI access.
                </p>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdate} disabled={updateNetwork.isPending}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
