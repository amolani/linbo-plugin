import { useState, useRef, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { useContainers, useContainerLogs } from '@/hooks/use-containers'
import { RefreshCw, Container, Terminal, Loader2 } from 'lucide-react'

export function ContainersPage() {
  const { data: containers, isLoading } = useContainers()
  const [selectedContainer, setSelectedContainer] = useState<string | null>(null)
  const { logs, isConnected, clearLogs } = useContainerLogs(selectedContainer)
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  // Auto-scroll to bottom when new logs arrive
  useEffect(() => {
    if (scrollContainerRef.current) {
      const viewport = scrollContainerRef.current.querySelector('[data-radix-scroll-area-viewport]')
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight
      }
    }
  }, [logs])

  const handleOpenLogs = (containerId: string) => {
    clearLogs()
    setSelectedContainer(containerId)
  }

  const handleCloseLogs = () => {
    setSelectedContainer(null)
  }

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'running':
        return 'default'
      case 'exited':
        return 'secondary'
      case 'paused':
        return 'outline'
      default:
        return 'secondary'
    }
  }

  const selectedContainerName =
    containers?.find((c) => c.id === selectedContainer)?.name || 'Container'

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Containers</h1>
        <p className="text-muted-foreground">Monitor and manage Docker containers</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Active Containers</CardTitle>
          <CardDescription>All Docker containers managed by NetworkBOX</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Image</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Networks</TableHead>
                  <TableHead className="w-16"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {containers?.map((container) => (
                  <TableRow key={container.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Container className="h-4 w-4 text-primary" />
                        <span className="font-medium">{container.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-sm text-muted-foreground">
                      {container.image.split(':')[0].split('/').pop()}
                    </TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(container.status)}>{container.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {container.networks.map((n, i) => (
                          <Badge key={i} variant="outline" className="text-xs font-mono">
                            {n.network}: {n.ip}
                          </Badge>
                        ))}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleOpenLogs(container.id)}
                        disabled={container.status !== 'running'}
                      >
                        <Terminal className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {(!containers || containers.length === 0) && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground">
                      No containers found
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={!!selectedContainer} onOpenChange={() => handleCloseLogs()}>
        <DialogContent className="sm:max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Terminal className="h-5 w-5" />
              Logs: {selectedContainerName}
              {isConnected ? (
                <Badge variant="secondary" className="ml-2">
                  <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse mr-1.5" />
                  Connected
                </Badge>
              ) : (
                <Badge variant="outline" className="ml-2">
                  <Loader2 className="h-3 w-3 animate-spin mr-1.5" />
                  Connecting
                </Badge>
              )}
            </DialogTitle>
          </DialogHeader>

          <ScrollArea className="h-[400px] rounded-md border bg-muted/30" ref={scrollContainerRef}>
            <div className="p-4 font-mono text-sm space-y-1">
              {logs.length === 0 ? (
                <div className="text-muted-foreground">Waiting for logs...</div>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className="break-all text-foreground">
                    {log}
                  </div>
                ))
              )}
              {isConnected && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span>Streaming...</span>
                </div>
              )}
            </div>
          </ScrollArea>

          <DialogFooter className="flex-row justify-between sm:justify-between">
            <Button variant="outline" onClick={clearLogs}>
              Clear
            </Button>
            <Button onClick={handleCloseLogs}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
