import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { toast } from 'sonner'
import {
  Settings,
  Network,
  RefreshCw,
  Plug,
  Unplug,
  Activity,
  Check,
  X,
  Loader2,
  Info,
} from 'lucide-react'
import api from '@/lib/api'

interface NAPIConfig {
  auto_start: boolean
  networks: { vlan_id: number; ip_address: string; enabled: boolean }[]
  default_wol_port: number
  ping_timeout: number
  ping_workers: number
  arp_timeout: number
  dns_timeout: number
}

interface NAPIStatus {
  running: boolean
  version: string | null
  connected_networks: string[]
}

interface NetworkInfo {
  name: string
  vlan_id: number
  address: string
  mask: string
  ip_address?: string
}

export function NAPIPage() {
  const queryClient = useQueryClient()

  // Fetch NAPI status
  const { data: status, isLoading: statusLoading } = useQuery<NAPIStatus>({
    queryKey: ['napi-status'],
    queryFn: async () => {
      const response = await api.get('/napi/status')
      return response.data
    },
    refetchInterval: 5000,
  })

  // Fetch NAPI config
  const { data: config, isLoading: configLoading } = useQuery<NAPIConfig>({
    queryKey: ['napi-config'],
    queryFn: async () => {
      const response = await api.get('/napi/config')
      return response.data
    },
  })

  // Fetch available networks
  const { data: networks } = useQuery<NetworkInfo[]>({
    queryKey: ['networks'],
    queryFn: async () => {
      const response = await api.get('/networks')
      return response.data
    },
  })

  // Save config mutation
  const saveConfigMutation = useMutation({
    mutationFn: async (newConfig: NAPIConfig) => {
      const response = await api.post('/napi/config', newConfig)
      return response.data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['napi-config'] })
      toast.success('Configuration saved')
      if (status?.running) {
        toast.info('Restart the container to apply changes', {
          duration: 5000,
        })
      }
    },
    onError: () => {
      toast.error('Failed to save configuration')
    },
  })

  // Restart NAPI mutation
  const restartMutation = useMutation({
    mutationFn: async () => {
      const response = await api.post('/napi/restart')
      return response.data
    },
    onSuccess: (data) => {
      if (data.status) {
        toast.success('NAPI restarted')
        queryClient.invalidateQueries({ queryKey: ['napi-status'] })
      } else {
        toast.error(data.message)
      }
    },
    onError: () => {
      toast.error('Failed to restart NAPI')
    },
  })

  const handleUpdateSetting = (key: keyof NAPIConfig, value: number | boolean) => {
    if (!config) return
    saveConfigMutation.mutate({ ...config, [key]: value })
  }

  const isNetworkConnected = (networkName: string) => {
    return status?.connected_networks.includes(`NETWORKBOX_${networkName}`)
  }

  // Networks with NAPI IP configured
  const napiNetworks = networks?.filter((n) => n.ip_address) || []

  if (configLoading || statusLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">NAPI Configuration</h1>
        <p className="text-muted-foreground">
          Configure the Network API service for WOL and network scanning
        </p>
      </div>

      {/* Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Service Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Badge variant={status?.running ? 'success' : 'destructive'}>
                {status?.running ? (
                  <>
                    <Check className="h-3 w-3 mr-1" />
                    Running
                  </>
                ) : (
                  <>
                    <X className="h-3 w-3 mr-1" />
                    Stopped
                  </>
                )}
              </Badge>
              {status?.version && (
                <span className="text-sm text-muted-foreground">
                  Version: {status.version}
                </span>
              )}
              <span className="text-sm text-muted-foreground">
                Connected Networks: {status?.connected_networks.length || 0}
              </span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => restartMutation.mutate()}
              disabled={restartMutation.isPending}
            >
              {restartMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="h-4 w-4 mr-2" />
              )}
              Restart
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Connected Networks Overview */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Network className="h-5 w-5" />
                Connected Networks
              </CardTitle>
              <CardDescription>
                Networks where NAPI is available for WOL and scanning
              </CardDescription>
            </div>
            <Button variant="outline" asChild>
              <Link to="/admin/networks">Manage Networks</Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {napiNetworks.length === 0 ? (
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                No networks configured with NAPI IP addresses. Go to{' '}
                <Link to="/admin/networks" className="font-medium underline underline-offset-4">
                  Networks
                </Link>{' '}
                and add an IP address for NAPI to enable WOL and scanning in those VLANs.
              </AlertDescription>
            </Alert>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Network</TableHead>
                  <TableHead>VLAN ID</TableHead>
                  <TableHead>NAPI IP Address</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {napiNetworks.map((network) => (
                  <TableRow key={network.vlan_id}>
                    <TableCell className="font-medium">{network.name}</TableCell>
                    <TableCell>{network.vlan_id}</TableCell>
                    <TableCell className="font-mono">{network.ip_address}</TableCell>
                    <TableCell>
                      {isNetworkConnected(network.name) ? (
                        <Badge variant="default">
                          <Plug className="h-3 w-3 mr-1" />
                          Connected
                        </Badge>
                      ) : (
                        <Badge variant="secondary">
                          <Unplug className="h-3 w-3 mr-1" />
                          Disconnected
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Scanner Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Scanner Settings
          </CardTitle>
          <CardDescription>Configure timeouts and performance settings for network scans</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Default WOL Port</Label>
              <Input
                type="number"
                value={config?.default_wol_port || 9}
                onChange={(e) => handleUpdateSetting('default_wol_port', parseInt(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">UDP port for Wake-on-LAN packets</p>
            </div>

            <div className="space-y-2">
              <Label>Ping Workers</Label>
              <Input
                type="number"
                value={config?.ping_workers || 50}
                onChange={(e) => handleUpdateSetting('ping_workers', parseInt(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                Number of parallel workers for ping scans
              </p>
            </div>

            <div className="space-y-2">
              <Label>Ping Timeout (seconds)</Label>
              <Input
                type="number"
                step="0.1"
                value={config?.ping_timeout || 1.0}
                onChange={(e) => handleUpdateSetting('ping_timeout', parseFloat(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">Timeout for individual ping requests</p>
            </div>

            <div className="space-y-2">
              <Label>ARP Timeout (seconds)</Label>
              <Input
                type="number"
                step="0.1"
                value={config?.arp_timeout || 2.0}
                onChange={(e) => handleUpdateSetting('arp_timeout', parseFloat(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">Timeout for ARP scan requests</p>
            </div>

            <div className="space-y-2">
              <Label>DNS Timeout (seconds)</Label>
              <Input
                type="number"
                step="0.1"
                value={config?.dns_timeout || 0.5}
                onChange={(e) => handleUpdateSetting('dns_timeout', parseFloat(e.target.value))}
              />
              <p className="text-xs text-muted-foreground">
                Timeout for hostname resolution during ARP scans
              </p>
            </div>
          </div>

          <Separator />

          <div className="flex items-center justify-between">
            <div>
              <Label>Auto-Start</Label>
              <p className="text-sm text-muted-foreground">
                Automatically connect to configured networks on startup
              </p>
            </div>
            <Switch
              checked={config?.auto_start ?? true}
              onCheckedChange={(checked) => handleUpdateSetting('auto_start', checked)}
            />
          </div>
        </CardContent>
      </Card>

    </div>
  )
}
