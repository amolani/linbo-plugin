import { useState, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Checkbox } from '@/components/ui/checkbox'
import {
  useCertificateSources,
  useCertificates,
  useCreateCertificateSource,
  useDeleteCertificateSource,
  useSyncCertificateSource,
  useTestCertificateSource,
  useSourceCertificates,
  useUploadCertificate,
  useGenerateCertificate,
  useDeleteCertificate,
} from '@/hooks/use-certificates'
import { Alert, AlertDescription } from '@/components/ui/alert'
import {
  Award,
  Plus,
  Trash2,
  RefreshCw,
  Download,
  Eye,
  EyeOff,
  AlertTriangle,
  CheckCircle,
  Upload,
  Sparkles,
  FileKey,
  FileText,
  List,
  Server,
  Plug,
  Info,
} from 'lucide-react'
import { toast } from 'sonner'
import type { CertificateSource } from '@/types'

export function CertificatesPage() {
  const { data: sources, isLoading: sourcesLoading } = useCertificateSources()
  const { data: certificates, isLoading: certsLoading } = useCertificates()
  const createSource = useCreateCertificateSource()
  const deleteSource = useDeleteCertificateSource()
  const syncSource = useSyncCertificateSource()
  const testSource = useTestCertificateSource()
  const uploadCert = useUploadCertificate()
  const generateCert = useGenerateCertificate()
  const deleteCert = useDeleteCertificate()

  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [isUploadOpen, setIsUploadOpen] = useState(false)
  const [isGenerateOpen, setIsGenerateOpen] = useState(false)
  const [isDeleteOpen, setIsDeleteOpen] = useState(false)
  const [isBrowseOpen, setIsBrowseOpen] = useState(false)
  const [browsingSource, setBrowsingSource] = useState<string | null>(null)
  const [deletingCert, setDeletingCert] = useState<string | null>(null)
  const [showPassword, setShowPassword] = useState(false)
  const [syncingSource, setSyncingSource] = useState<string | null>(null)
  const [testingSource, setTestingSource] = useState<string | null>(null)

  // Local state for certificate selection in browse dialog
  const [selectedCertNames, setSelectedCertNames] = useState<string[]>([])
  const [isSavingSelection, setIsSavingSelection] = useState(false)

  // Query for browsing certificates from a source
  const { data: sourceCerts, isLoading: sourceCertsLoading } = useSourceCertificates(browsingSource || '')

  const [newSource, setNewSource] = useState<Partial<CertificateSource>>({
    name: '',
    type: 'sophos',
    sophos_hostname: '',
    sophos_port: 4444,
    sophos_username: '',
    sophos_password: '',
    sophos_cert_names: [], // Multiple certificates can be selected
    sync_interval: 60,
    enabled: true,
  })

  const [uploadData, setUploadData] = useState({
    name: '',
    cert_pem: '',
    key_pem: '',
  })
  const [certFileName, setCertFileName] = useState<string | null>(null)
  const [keyFileName, setKeyFileName] = useState<string | null>(null)
  const certFileRef = useRef<HTMLInputElement>(null)
  const keyFileRef = useRef<HTMLInputElement>(null)

  const [generateData, setGenerateData] = useState({
    name: '',
    common_name: '',
    organization: '',
    organizational_unit: '',
    country: '',
    state: '',
    locality: '',
    san_dns: '',
    san_ip: '',
    validity_days: 365,
    key_size: 2048,
  })

  const handleCreate = async () => {
    try {
      await createSource.mutateAsync(newSource as CertificateSource)
      toast.success('Certificate source created')
      setIsCreateOpen(false)
      resetSourceForm()
    } catch {
      toast.error('Failed to create certificate source')
    }
  }

  const resetSourceForm = () => {
    setNewSource({
      name: '',
      type: 'sophos',
      sophos_hostname: '',
      sophos_port: 4444,
      sophos_username: '',
      sophos_password: '',
      sophos_cert_names: [],
      sync_interval: 60,
      enabled: true,
    })
  }

  const handleCertFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setCertFileName(file.name)
      const reader = new FileReader()
      reader.onload = (event) => {
        const content = event.target?.result as string
        setUploadData({ ...uploadData, cert_pem: content })
      }
      reader.readAsText(file)
    }
  }

  const handleKeyFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setKeyFileName(file.name)
      const reader = new FileReader()
      reader.onload = (event) => {
        const content = event.target?.result as string
        setUploadData({ ...uploadData, key_pem: content })
      }
      reader.readAsText(file)
    }
  }

  const handleUpload = async () => {
    try {
      await uploadCert.mutateAsync(uploadData)
      toast.success('Certificate uploaded successfully')
      setIsUploadOpen(false)
      setUploadData({ name: '', cert_pem: '', key_pem: '' })
      setCertFileName(null)
      setKeyFileName(null)
      if (certFileRef.current) certFileRef.current.value = ''
      if (keyFileRef.current) keyFileRef.current.value = ''
    } catch {
      toast.error('Failed to upload certificate')
    }
  }

  const handleGenerate = async () => {
    try {
      const data = {
        name: generateData.name,
        common_name: generateData.common_name,
        organization: generateData.organization || undefined,
        organizational_unit: generateData.organizational_unit || undefined,
        country: generateData.country || undefined,
        state: generateData.state || undefined,
        locality: generateData.locality || undefined,
        san_dns: generateData.san_dns
          ? generateData.san_dns.split(',').map((s) => s.trim()).filter(Boolean)
          : undefined,
        san_ip: generateData.san_ip
          ? generateData.san_ip.split(',').map((s) => s.trim()).filter(Boolean)
          : undefined,
        validity_days: generateData.validity_days,
        key_size: generateData.key_size,
      }
      await generateCert.mutateAsync(data)
      toast.success('Certificate generated successfully')
      setIsGenerateOpen(false)
      setGenerateData({
        name: '',
        common_name: '',
        organization: '',
        organizational_unit: '',
        country: '',
        state: '',
        locality: '',
        san_dns: '',
        san_ip: '',
        validity_days: 365,
        key_size: 2048,
      })
    } catch {
      toast.error('Failed to generate certificate')
    }
  }

  const handleTestConnection = async (name: string) => {
    setTestingSource(name)
    try {
      const result = await testSource.mutateAsync(name)
      if (result.status) {
        toast.success(result.message)
      } else {
        toast.error(result.message)
      }
    } catch {
      toast.error('Connection test failed')
    } finally {
      setTestingSource(null)
    }
  }

  const handleDeleteSource = async (name: string) => {
    if (!confirm('Are you sure? This will also delete all associated certificates.')) return
    try {
      await deleteSource.mutateAsync(name)
      toast.success('Certificate source deleted')
    } catch {
      toast.error('Failed to delete certificate source')
    }
  }

  const handleDeleteCertClick = (name: string) => {
    setDeletingCert(name)
    setIsDeleteOpen(true)
  }

  const handleDeleteCert = async () => {
    if (!deletingCert) return
    try {
      await deleteCert.mutateAsync(deletingCert)
      toast.success('Certificate deleted')
      setIsDeleteOpen(false)
      setDeletingCert(null)
    } catch {
      toast.error('Failed to delete certificate')
    }
  }

  const handleSync = async (sourceName: string, certName?: string, add?: boolean, remove?: boolean) => {
    setSyncingSource(sourceName)
    try {
      const result = await syncSource.mutateAsync({ sourceName, certName, add, remove })
      if (result.status) {
        toast.success(result.message)
      } else {
        toast.error(result.message)
      }
    } catch {
      toast.error('Sync failed')
    } finally {
      setSyncingSource(null)
    }
  }

  const handleBrowseCerts = (sourceName: string) => {
    const source = sources?.find(s => s.name === sourceName)
    setSelectedCertNames(source?.sophos_cert_names || [])
    setBrowsingSource(sourceName)
    setIsBrowseOpen(true)
  }

  const toggleCertSelection = (certName: string) => {
    setSelectedCertNames(prev =>
      prev.includes(certName)
        ? prev.filter(n => n !== certName)
        : [...prev, certName]
    )
  }

  const handleSaveSelection = async () => {
    if (!browsingSource) return

    const currentSource = sources?.find(s => s.name === browsingSource)
    const currentSelected = currentSource?.sophos_cert_names || []

    // Find certs to add and remove
    const toAdd = selectedCertNames.filter(n => !currentSelected.includes(n))
    const toRemove = currentSelected.filter(n => !selectedCertNames.includes(n))

    if (toAdd.length === 0 && toRemove.length === 0) {
      setIsBrowseOpen(false)
      setBrowsingSource(null)
      return
    }

    setIsSavingSelection(true)
    try {
      // Remove deselected certificates
      for (const certName of toRemove) {
        await syncSource.mutateAsync({ sourceName: browsingSource, certName, remove: true })
      }

      // Add and sync newly selected certificates
      for (const certName of toAdd) {
        await syncSource.mutateAsync({ sourceName: browsingSource, certName, add: true })
      }

      toast.success(`Selection saved: ${toAdd.length} added, ${toRemove.length} removed`)
      setIsBrowseOpen(false)
      setBrowsingSource(null)
    } catch {
      toast.error('Failed to save selection')
    } finally {
      setIsSavingSelection(false)
    }
  }

  const getCertStatus = (validTo: string) => {
    const expiry = new Date(validTo)
    const now = new Date()
    const daysUntilExpiry = Math.floor((expiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))

    if (daysUntilExpiry < 0) return { label: 'Expired', variant: 'destructive' as const }
    if (daysUntilExpiry < 7) return { label: `${daysUntilExpiry}d left`, variant: 'destructive' as const }
    if (daysUntilExpiry < 30) return { label: `${daysUntilExpiry}d left`, variant: 'secondary' as const }
    return { label: 'Valid', variant: 'default' as const }
  }

  const handleDownload = (name: string, format: string) => {
    const token = localStorage.getItem('access_token')
    window.open(`/api/v1/certificates/${name}/download?format=${format}&token=${token}`, '_blank')
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Certificate Manager</h1>
          <p className="text-muted-foreground">Manage SSL/TLS certificates</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="mr-2 h-4 w-4" />
                Upload
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Upload Certificate</DialogTitle>
                <DialogDescription>Upload an existing certificate and private key (PEM format)</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>Certificate Name</Label>
                  <Input
                    value={uploadData.name}
                    onChange={(e) => setUploadData({ ...uploadData, name: e.target.value })}
                    placeholder="my-certificate"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Certificate File (.crt, .pem)</Label>
                  <div
                    className="flex items-center gap-2 p-3 border rounded-md cursor-pointer hover:bg-accent/50 transition-colors"
                    onClick={() => certFileRef.current?.click()}
                  >
                    <FileText className="h-5 w-5 text-muted-foreground" />
                    <span className={certFileName ? 'text-foreground' : 'text-muted-foreground'}>
                      {certFileName || 'Click to select certificate file...'}
                    </span>
                    <input
                      ref={certFileRef}
                      type="file"
                      accept=".crt,.pem,.cer"
                      onChange={handleCertFileChange}
                      className="hidden"
                    />
                  </div>
                  {uploadData.cert_pem && (
                    <p className="text-xs text-green-600">Certificate loaded</p>
                  )}
                </div>
                <div className="space-y-2">
                  <Label>Private Key File (.key, .pem)</Label>
                  <div
                    className="flex items-center gap-2 p-3 border rounded-md cursor-pointer hover:bg-accent/50 transition-colors"
                    onClick={() => keyFileRef.current?.click()}
                  >
                    <FileKey className="h-5 w-5 text-muted-foreground" />
                    <span className={keyFileName ? 'text-foreground' : 'text-muted-foreground'}>
                      {keyFileName || 'Click to select private key file...'}
                    </span>
                    <input
                      ref={keyFileRef}
                      type="file"
                      accept=".key,.pem"
                      onChange={handleKeyFileChange}
                      className="hidden"
                    />
                  </div>
                  {uploadData.key_pem && (
                    <p className="text-xs text-green-600">Private key loaded</p>
                  )}
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsUploadOpen(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={handleUpload}
                  disabled={uploadCert.isPending || !uploadData.name || !uploadData.cert_pem || !uploadData.key_pem}
                >
                  Upload
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isGenerateOpen} onOpenChange={setIsGenerateOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Sparkles className="mr-2 h-4 w-4" />
                Generate
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Generate Self-Signed Certificate</DialogTitle>
                <DialogDescription>Create a new self-signed certificate</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Certificate Name *</Label>
                    <Input
                      value={generateData.name}
                      onChange={(e) => setGenerateData({ ...generateData, name: e.target.value })}
                      placeholder="my-certificate"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Common Name (CN) *</Label>
                    <Input
                      value={generateData.common_name}
                      onChange={(e) => setGenerateData({ ...generateData, common_name: e.target.value })}
                      placeholder="example.com"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Organization (O)</Label>
                    <Input
                      value={generateData.organization}
                      onChange={(e) => setGenerateData({ ...generateData, organization: e.target.value })}
                      placeholder="My Company"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Organizational Unit (OU)</Label>
                    <Input
                      value={generateData.organizational_unit}
                      onChange={(e) => setGenerateData({ ...generateData, organizational_unit: e.target.value })}
                      placeholder="IT Department"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Country (C)</Label>
                    <Input
                      value={generateData.country}
                      onChange={(e) => setGenerateData({ ...generateData, country: e.target.value })}
                      placeholder="DE"
                      maxLength={2}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>State (ST)</Label>
                    <Input
                      value={generateData.state}
                      onChange={(e) => setGenerateData({ ...generateData, state: e.target.value })}
                      placeholder="Bavaria"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Locality (L)</Label>
                    <Input
                      value={generateData.locality}
                      onChange={(e) => setGenerateData({ ...generateData, locality: e.target.value })}
                      placeholder="Munich"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Subject Alternative Names (DNS)</Label>
                  <Input
                    value={generateData.san_dns}
                    onChange={(e) => setGenerateData({ ...generateData, san_dns: e.target.value })}
                    placeholder="www.example.com, api.example.com"
                  />
                  <p className="text-xs text-muted-foreground">Comma-separated list of DNS names</p>
                </div>
                <div className="space-y-2">
                  <Label>Subject Alternative Names (IP)</Label>
                  <Input
                    value={generateData.san_ip}
                    onChange={(e) => setGenerateData({ ...generateData, san_ip: e.target.value })}
                    placeholder="192.168.1.1, 10.0.0.1"
                  />
                  <p className="text-xs text-muted-foreground">Comma-separated list of IP addresses</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Validity (days)</Label>
                    <Input
                      type="number"
                      value={generateData.validity_days}
                      onChange={(e) => setGenerateData({ ...generateData, validity_days: parseInt(e.target.value) })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Key Size (bits)</Label>
                    <Input
                      type="number"
                      value={generateData.key_size}
                      onChange={(e) => setGenerateData({ ...generateData, key_size: parseInt(e.target.value) })}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsGenerateOpen(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={handleGenerate}
                  disabled={generateCert.isPending || !generateData.name || !generateData.common_name}
                >
                  Generate
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Source
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Add Certificate Source</DialogTitle>
                <DialogDescription>Connect to your Sophos XGS to sync certificates</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="space-y-2">
                  <Label>Source Name</Label>
                  <Input
                    value={newSource.name}
                    onChange={(e) => setNewSource({ ...newSource, name: e.target.value })}
                    placeholder="sophos-main"
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-2 space-y-2">
                    <Label>Sophos Hostname</Label>
                    <Input
                      value={newSource.sophos_hostname}
                      onChange={(e) => setNewSource({ ...newSource, sophos_hostname: e.target.value })}
                      placeholder="192.168.1.1"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Port</Label>
                    <Input
                      type="number"
                      value={newSource.sophos_port}
                      onChange={(e) => setNewSource({ ...newSource, sophos_port: parseInt(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Username</Label>
                    <Input
                      value={newSource.sophos_username}
                      onChange={(e) => setNewSource({ ...newSource, sophos_username: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Password</Label>
                    <div className="relative">
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        value={newSource.sophos_password}
                        onChange={(e) => setNewSource({ ...newSource, sophos_password: e.target.value })}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Sync Interval (minutes)</Label>
                  <Input
                    type="number"
                    value={newSource.sync_interval}
                    onChange={(e) => setNewSource({ ...newSource, sync_interval: parseInt(e.target.value) })}
                  />
                  <p className="text-xs text-muted-foreground">
                    After creating the source, browse available certificates to select which one to sync.
                  </p>
                </div>
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Der API-Benutzer darf keine Zwei-Faktor-Authentifizierung aktiviert haben.
                    Erstelle ggf. einen separaten Admin-Account ohne 2FA für den API-Zugriff.
                  </AlertDescription>
                </Alert>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreate} disabled={createSource.isPending}>
                  Create
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Tabs defaultValue="certificates">
        <TabsList>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
          <TabsTrigger value="sources">Sources</TabsTrigger>
        </TabsList>

        <TabsContent value="certificates" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Certificates</CardTitle>
              <CardDescription>All certificates (synced, uploaded, or generated)</CardDescription>
            </CardHeader>
            <CardContent>
              {certsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : certificates && certificates.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Source</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Valid Until</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-32"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {certificates.map((cert) => {
                      const status = getCertStatus(cert.valid_to)
                      return (
                        <TableRow key={cert.name}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Award className="h-4 w-4 text-primary" />
                              <span className="font-medium">{cert.name}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{cert.source}</Badge>
                          </TableCell>
                          <TableCell className="max-w-48 truncate font-mono text-xs">
                            {cert.subject}
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {new Date(cert.valid_to).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant={status.variant}>
                              {status.variant === 'destructive' ? (
                                <AlertTriangle className="mr-1 h-3 w-3" />
                              ) : (
                                <CheckCircle className="mr-1 h-3 w-3" />
                              )}
                              {status.label}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDownload(cert.name, 'pem')}
                                title="Download PEM"
                              >
                                <Download className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteCertClick(cert.name)}
                                className="text-destructive hover:text-destructive"
                                title="Delete"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              ) : (
                <div className="py-8 text-center text-muted-foreground">
                  No certificates yet. Upload, generate, or sync from a source.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sources" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Certificate Sources</CardTitle>
              <CardDescription>Configured Sophos XGS connections for certificate sync</CardDescription>
            </CardHeader>
            <CardContent>
              {sourcesLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : sources && sources.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Sophos Host</TableHead>
                      <TableHead>Selected Certificate</TableHead>
                      <TableHead>Sync Interval</TableHead>
                      <TableHead>Last Sync</TableHead>
                      <TableHead className="w-40"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sources.map((source) => (
                      <TableRow key={source.name}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Server className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium">{source.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {source.sophos_hostname}:{source.sophos_port}
                        </TableCell>
                        <TableCell>
                          {source.sophos_cert_names && source.sophos_cert_names.length > 0 ? (
                            <div className="flex flex-wrap gap-1">
                              {source.sophos_cert_names.map((certName) => (
                                <Badge key={certName} variant="outline">{certName}</Badge>
                              ))}
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-sm">Not selected</span>
                          )}
                        </TableCell>
                        <TableCell>{source.sync_interval} min</TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {source.last_sync ? new Date(source.last_sync).toLocaleString() : 'Never'}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleTestConnection(source.name)}
                              disabled={testingSource === source.name}
                              title="Test connection"
                            >
                              <Plug className={`h-4 w-4 ${testingSource === source.name ? 'animate-pulse' : ''}`} />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleBrowseCerts(source.name)}
                              title="Browse certificates"
                            >
                              <List className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleSync(source.name)}
                              disabled={syncingSource === source.name || !source.sophos_cert_names?.length}
                              title={source.sophos_cert_names?.length ? 'Sync all' : 'Select certificates first'}
                            >
                              <RefreshCw
                                className={`h-4 w-4 ${syncingSource === source.name ? 'animate-spin' : ''}`}
                              />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteSource(source.name)}
                              className="text-destructive hover:text-destructive"
                              title="Delete source"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="py-8 text-center text-muted-foreground">
                  No certificate sources configured yet.
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Delete Certificate Dialog */}
      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Certificate</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete the certificate "{deletingCert}"?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteCert} disabled={deleteCert.isPending}>
              {deleteCert.isPending ? 'Deleting...' : 'Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Browse Certificates Dialog */}
      <Dialog open={isBrowseOpen} onOpenChange={(open) => {
        setIsBrowseOpen(open)
        if (!open) setBrowsingSource(null)
      }}>
        <DialogContent className="!max-w-4xl">
          <DialogHeader>
            <DialogTitle>Certificates on Sophos</DialogTitle>
            <DialogDescription>
              Select certificates from "{browsingSource}" to sync. Click on a row to select/deselect.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {sourceCertsLoading ? (
              <div className="flex items-center justify-center py-8">
                <RefreshCw className="h-6 w-6 animate-spin" />
                <span className="ml-2">Loading certificates...</span>
              </div>
            ) : sourceCerts && sourceCerts.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12"></TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Valid From</TableHead>
                    <TableHead>Valid Until</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sourceCerts.map((cert) => {
                    const isSelected = selectedCertNames.includes(cert.name)
                    return (
                      <TableRow
                        key={cert.name}
                        className={`cursor-pointer transition-colors ${isSelected ? 'bg-accent/50 hover:bg-accent/70' : 'hover:bg-muted/50'}`}
                        onClick={() => toggleCertSelection(cert.name)}
                      >
                        <TableCell>
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() => toggleCertSelection(cert.name)}
                            onClick={(e) => e.stopPropagation()}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Award className="h-4 w-4 text-primary" />
                            <span className="font-medium">{cert.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-sm">
                          {cert.valid_from || 'N/A'}
                        </TableCell>
                        <TableCell className="text-sm">
                          {cert.valid_to || 'N/A'}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            ) : (
              <div className="py-8 text-center text-muted-foreground">
                No certificates found on this Sophos. Check your connection settings.
              </div>
            )}
          </div>
          <DialogFooter className="flex items-center justify-between sm:justify-between">
            <div className="text-sm text-muted-foreground">
              {selectedCertNames.length} certificate{selectedCertNames.length !== 1 ? 's' : ''} selected
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => {
                setIsBrowseOpen(false)
                setBrowsingSource(null)
              }}>
                Cancel
              </Button>
              <Button onClick={handleSaveSelection} disabled={isSavingSelection}>
                {isSavingSelection ? (
                  <>
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save & Sync'
                )}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
