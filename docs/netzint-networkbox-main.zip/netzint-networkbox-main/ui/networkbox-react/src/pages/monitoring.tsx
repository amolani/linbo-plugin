import { useState, useMemo } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { NetworkTopology } from '@/components/network-topology'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  useMonitoringConfig,
  useUpdateMonitoringConfig,
  useMonitoringStatus,
  useMonitoredSwitches,
  useAddSwitch,
  useDeleteSwitch,
  useTestSwitchSNMP,
  useIncidents,
  useUpdateIncident,
  useDeleteIncident,
  useMACFlapping,
  useTestUniFiConnection,
  useDiscoverUniFiSwitches,
  useStartMonitoring,
  useStopMonitoring,
  useSwitchConnections,
} from '@/hooks/use-monitoring'
import {
  Plus,
  Trash2,
  Play,
  Square,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Activity,
  Network,
  Settings,
  Eye,
  EyeOff,
  Loader2,
  Search,
  Clock,
} from 'lucide-react'
import { toast } from 'sonner'
import type {
  MonitoredSwitch,
  MonitoringConfig,
  SNMPConfig,
  UniFiConfig,
  IncidentStatus,
} from '@/types'

const defaultSNMPConfig: SNMPConfig = {
  version: 'v2c',
  community: 'public',
  username: '',
  auth_protocol: 'SHA',
  auth_password: '',
  priv_protocol: 'AES',
  priv_password: '',
}

const defaultUniFiConfig: UniFiConfig = {
  enabled: false,
  controller_url: '',
  username: '',
  password: '',
  site: 'default',
  verify_ssl: false,
}

export function MonitoringPage() {
  const { data: config } = useMonitoringConfig()
  const { data: status, refetch: refetchStatus } = useMonitoringStatus()
  const { data: switches, isLoading: switchesLoading, refetch: refetchSwitches } = useMonitoredSwitches()
  const { data: incidents, isLoading: incidentsLoading } = useIncidents()
  const { data: connections } = useSwitchConnections()
  const { data: flappingData } = useMACFlapping()

  const updateConfig = useUpdateMonitoringConfig()
  const addSwitch = useAddSwitch()
  const deleteSwitch = useDeleteSwitch()
  const testSNMP = useTestSwitchSNMP()
  const updateIncident = useUpdateIncident()
  const deleteIncident = useDeleteIncident()
  const testUniFi = useTestUniFiConnection()
  const discoverSwitches = useDiscoverUniFiSwitches()
  const startMonitoring = useStartMonitoring()
  const stopMonitoring = useStopMonitoring()

  const [activeTab, setActiveTab] = useState('overview')
  const [isAddSwitchOpen, setIsAddSwitchOpen] = useState(false)
  const [isSettingsOpen, setIsSettingsOpen] = useState(false)
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({})
  const [incidentFilter, setIncidentFilter] = useState<string>('all')

  // Build switch status map for topology
  const switchStatusMap = useMemo(() => {
    const map: Record<string, boolean> = {}
    // For now, assume all enabled switches are reachable if monitoring is active
    // This will be updated by the scheduler with real status
    switches?.forEach((sw) => {
      map[sw.name] = sw.enabled && (status?.enabled ?? false)
    })
    return map
  }, [switches, status?.enabled])

  const [newSwitch, setNewSwitch] = useState<Partial<MonitoredSwitch>>({
    name: '',
    ip_address: '',
    snmp_config: { ...defaultSNMPConfig },
    model: '',
    port_count: 24,
    uplink_ports: [],
    enabled: true,
  })

  const [editConfig, setEditConfig] = useState<MonitoringConfig | null>(null)

  const togglePassword = (key: string) => {
    setShowPasswords((prev) => ({ ...prev, [key]: !prev[key] }))
  }

  const handleAddSwitch = async () => {
    if (!newSwitch.name || !newSwitch.ip_address) {
      toast.error('Name and IP address are required')
      return
    }

    try {
      await addSwitch.mutateAsync(newSwitch as MonitoredSwitch)
      toast.success('Switch added successfully')
      setIsAddSwitchOpen(false)
      setNewSwitch({
        name: '',
        ip_address: '',
        snmp_config: { ...defaultSNMPConfig },
        model: '',
        port_count: 24,
        uplink_ports: [],
        enabled: true,
      })
    } catch {
      toast.error('Failed to add switch')
    }
  }

  const handleDeleteSwitch = async (name: string) => {
    if (!confirm(`Are you sure you want to delete switch "${name}"?`)) return
    try {
      await deleteSwitch.mutateAsync(name)
      toast.success('Switch deleted successfully')
    } catch {
      toast.error('Failed to delete switch')
    }
  }

  const handleTestSNMP = async (name: string) => {
    try {
      const result = await testSNMP.mutateAsync(name)
      if (result.status) {
        toast.success(result.message)
      } else {
        toast.error(result.message)
      }
    } catch {
      toast.error('SNMP test failed')
    }
  }

  const handleUpdateIncidentStatus = async (id: string, newStatus: IncidentStatus) => {
    try {
      await updateIncident.mutateAsync({ id, update: { status: newStatus } })
      toast.success('Incident updated')
    } catch {
      toast.error('Failed to update incident')
    }
  }

  const handleDeleteIncident = async (id: string) => {
    if (!confirm('Are you sure you want to delete this incident?')) return
    try {
      await deleteIncident.mutateAsync(id)
      toast.success('Incident deleted')
    } catch {
      toast.error('Failed to delete incident')
    }
  }

  const handleSaveConfig = async () => {
    if (!editConfig) return
    try {
      await updateConfig.mutateAsync(editConfig)
      toast.success('Configuration saved')
      setIsSettingsOpen(false)
    } catch {
      toast.error('Failed to save configuration')
    }
  }

  const handleTestUniFi = async () => {
    if (!editConfig?.unifi) return
    try {
      const result = await testUniFi.mutateAsync(editConfig.unifi)
      if (result.status) {
        toast.success(result.message)
      } else {
        toast.error(result.message)
      }
    } catch {
      toast.error('UniFi connection test failed')
    }
  }

  const handleDiscoverSwitches = async () => {
    try {
      const discovered = await discoverSwitches.mutateAsync()
      toast.success(`Discovered ${discovered.length} switches`)
      refetchSwitches()
    } catch {
      toast.error('Failed to discover switches')
    }
  }

  const handleStartMonitoring = async () => {
    try {
      await startMonitoring.mutateAsync()
      toast.success('Monitoring started')
      refetchStatus()
    } catch {
      toast.error('Failed to start monitoring')
    }
  }

  const handleStopMonitoring = async () => {
    try {
      await stopMonitoring.mutateAsync()
      toast.success('Monitoring stopped')
      refetchStatus()
    } catch {
      toast.error('Failed to stop monitoring')
    }
  }

  const openSettings = () => {
    setEditConfig(config || {
      enabled: false,
      poll_interval_seconds: 30,
      mac_table_interval_seconds: 60,
      alert_email: '',
      alert_webhook_url: '',
      unifi: { ...defaultUniFiConfig },
      mac_flap_threshold: 4,
      mac_flap_window_seconds: 60,
      stp_tc_threshold: 5,
      discard_rate_threshold: 1.0,
      warning_score: 40,
      critical_score: 70,
    })
    setIsSettingsOpen(true)
  }

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <Badge variant="destructive">Critical</Badge>
      case 'warning':
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Warning</Badge>
      case 'info':
      default:
        return <Badge variant="secondary">Info</Badge>
    }
  }

  const getStatusBadge = (incidentStatus: string) => {
    switch (incidentStatus) {
      case 'open':
        return <Badge variant="destructive">Open</Badge>
      case 'investigating':
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Investigating</Badge>
      case 'resolved':
        return <Badge variant="success">Resolved</Badge>
      default:
        return <Badge variant="secondary">{incidentStatus}</Badge>
    }
  }

  const filteredIncidents = incidents?.filter((i) => {
    if (incidentFilter === 'all') return true
    return i.status === incidentFilter
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Network Monitoring</h1>
          <p className="text-muted-foreground">Loop detection and switch monitoring</p>
        </div>
        <div className="flex items-center gap-2">
          {status?.enabled ? (
            <Button variant="outline" onClick={handleStopMonitoring} disabled={stopMonitoring.isPending}>
              <Square className="mr-2 h-4 w-4" />
              Stop Monitoring
            </Button>
          ) : (
            <Button onClick={handleStartMonitoring} disabled={startMonitoring.isPending}>
              <Play className="mr-2 h-4 w-4" />
              Start Monitoring
            </Button>
          )}
          <Button variant="outline" onClick={openSettings}>
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="topology">Topology</TabsTrigger>
          <TabsTrigger value="switches">Switches</TabsTrigger>
          <TabsTrigger value="incidents">Incidents</TabsTrigger>
          <TabsTrigger value="mac-flapping">MAC Flapping</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Monitoring Status</CardTitle>
                <Activity className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {status?.enabled ? (
                    <span className="text-green-600">Active</span>
                  ) : (
                    <span className="text-muted-foreground">Inactive</span>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {status?.last_poll
                    ? `Last poll: ${new Date(status.last_poll).toLocaleTimeString()}`
                    : 'No polls yet'}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Switches</CardTitle>
                <Network className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {status?.switches_reachable || 0} / {status?.switches_enabled || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Reachable / Enabled ({status?.switches_total || 0} total)
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Open Incidents</CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {status?.open_incidents || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  {status?.critical_incidents || 0} critical, {status?.warning_incidents || 0} warning
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Flapping MACs</CardTitle>
                <RefreshCw className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {status?.flapping_macs_count || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  MACs moving between ports
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Recent Incidents */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Incidents</CardTitle>
              <CardDescription>Latest detected loop incidents</CardDescription>
            </CardHeader>
            <CardContent>
              {incidentsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : incidents && incidents.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Switch</TableHead>
                      <TableHead>Severity</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Detected</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {incidents.slice(0, 5).map((incident) => (
                      <TableRow key={incident.id}>
                        <TableCell className="font-medium">{incident.switch_name}</TableCell>
                        <TableCell>{getSeverityBadge(incident.severity)}</TableCell>
                        <TableCell>{incident.score}/100</TableCell>
                        <TableCell>{getStatusBadge(incident.status)}</TableCell>
                        <TableCell>{new Date(incident.detected_at).toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle2 className="mx-auto h-12 w-12 mb-2" />
                  <p>No incidents detected</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Topology Tab */}
        <TabsContent value="topology" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Network Topology</CardTitle>
              <CardDescription>
                Visual representation of your switch network. Red nodes and edges indicate detected incidents.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <NetworkTopology
                switches={switches || []}
                connections={connections || []}
                incidents={incidents || []}
                switchStatus={switchStatusMap}
                onSwitchClick={() => {
                  setActiveTab('switches')
                }}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Switches Tab */}
        <TabsContent value="switches" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Monitored Switches</CardTitle>
                  <CardDescription>Switches being monitored for loop detection</CardDescription>
                </div>
                <div className="flex gap-2">
                  {config?.unifi?.enabled && (
                    <Button
                      variant="outline"
                      onClick={handleDiscoverSwitches}
                      disabled={discoverSwitches.isPending}
                    >
                      {discoverSwitches.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Search className="mr-2 h-4 w-4" />
                      )}
                      Discover from UniFi
                    </Button>
                  )}
                  <Dialog open={isAddSwitchOpen} onOpenChange={setIsAddSwitchOpen}>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="mr-2 h-4 w-4" />
                        Add Switch
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle>Add Switch</DialogTitle>
                        <DialogDescription>Add a switch to monitor for loops</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Name</Label>
                            <Input
                              value={newSwitch.name}
                              onChange={(e) => setNewSwitch({ ...newSwitch, name: e.target.value })}
                              placeholder="switch-1"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>IP Address</Label>
                            <Input
                              value={newSwitch.ip_address}
                              onChange={(e) => setNewSwitch({ ...newSwitch, ip_address: e.target.value })}
                              placeholder="192.168.1.1"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label>Model</Label>
                            <Input
                              value={newSwitch.model}
                              onChange={(e) => setNewSwitch({ ...newSwitch, model: e.target.value })}
                              placeholder="USW-24-POE"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>Port Count</Label>
                            <Input
                              type="number"
                              value={newSwitch.port_count}
                              onChange={(e) => setNewSwitch({ ...newSwitch, port_count: parseInt(e.target.value) })}
                            />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <Label>SNMP Version</Label>
                          <Select
                            value={newSwitch.snmp_config?.version}
                            onValueChange={(value) =>
                              setNewSwitch({
                                ...newSwitch,
                                snmp_config: { ...newSwitch.snmp_config!, version: value as 'v2c' | 'v3' },
                              })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="v2c">SNMPv2c</SelectItem>
                              <SelectItem value="v3">SNMPv3</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        {newSwitch.snmp_config?.version === 'v2c' ? (
                          <div className="space-y-2">
                            <Label>Community</Label>
                            <Input
                              value={newSwitch.snmp_config?.community}
                              onChange={(e) =>
                                setNewSwitch({
                                  ...newSwitch,
                                  snmp_config: { ...newSwitch.snmp_config!, community: e.target.value },
                                })
                              }
                              placeholder="public"
                            />
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label>Username</Label>
                              <Input
                                value={newSwitch.snmp_config?.username}
                                onChange={(e) =>
                                  setNewSwitch({
                                    ...newSwitch,
                                    snmp_config: { ...newSwitch.snmp_config!, username: e.target.value },
                                  })
                                }
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label>Auth Protocol</Label>
                                <Select
                                  value={newSwitch.snmp_config?.auth_protocol}
                                  onValueChange={(value) =>
                                    setNewSwitch({
                                      ...newSwitch,
                                      snmp_config: { ...newSwitch.snmp_config!, auth_protocol: value },
                                    })
                                  }
                                >
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="MD5">MD5</SelectItem>
                                    <SelectItem value="SHA">SHA</SelectItem>
                                    <SelectItem value="SHA256">SHA256</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <Label>Auth Password</Label>
                                <Input
                                  type="password"
                                  value={newSwitch.snmp_config?.auth_password}
                                  onChange={(e) =>
                                    setNewSwitch({
                                      ...newSwitch,
                                      snmp_config: { ...newSwitch.snmp_config!, auth_password: e.target.value },
                                    })
                                  }
                                />
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label>Privacy Protocol</Label>
                                <Select
                                  value={newSwitch.snmp_config?.priv_protocol}
                                  onValueChange={(value) =>
                                    setNewSwitch({
                                      ...newSwitch,
                                      snmp_config: { ...newSwitch.snmp_config!, priv_protocol: value },
                                    })
                                  }
                                >
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="DES">DES</SelectItem>
                                    <SelectItem value="AES">AES</SelectItem>
                                    <SelectItem value="AES256">AES256</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <Label>Privacy Password</Label>
                                <Input
                                  type="password"
                                  value={newSwitch.snmp_config?.priv_password}
                                  onChange={(e) =>
                                    setNewSwitch({
                                      ...newSwitch,
                                      snmp_config: { ...newSwitch.snmp_config!, priv_password: e.target.value },
                                    })
                                  }
                                />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsAddSwitchOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={handleAddSwitch} disabled={addSwitch.isPending}>
                          Add Switch
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {switchesLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>IP Address</TableHead>
                      <TableHead>Model</TableHead>
                      <TableHead>Ports</TableHead>
                      <TableHead>SNMP</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-32"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {switches?.map((sw) => (
                      <TableRow key={sw.name}>
                        <TableCell className="font-medium">{sw.name}</TableCell>
                        <TableCell className="font-mono text-sm">{sw.ip_address}</TableCell>
                        <TableCell>{sw.model || '-'}</TableCell>
                        <TableCell>{sw.port_count}</TableCell>
                        <TableCell>
                          <Badge variant="secondary">
                            {sw.snmp_config.version.toUpperCase()}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={sw.enabled ? 'success' : 'secondary'}>
                            {sw.enabled ? 'Enabled' : 'Disabled'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleTestSNMP(sw.name)}
                              disabled={testSNMP.isPending}
                            >
                              <Search className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteSwitch(sw.name)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {(!switches || switches.length === 0) && (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center text-muted-foreground">
                          No switches configured
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Incidents Tab */}
        <TabsContent value="incidents" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Loop Incidents</CardTitle>
                  <CardDescription>Detected network loop incidents</CardDescription>
                </div>
                <Select value={incidentFilter} onValueChange={setIncidentFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Incidents</SelectItem>
                    <SelectItem value="open">Open</SelectItem>
                    <SelectItem value="investigating">Investigating</SelectItem>
                    <SelectItem value="resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {incidentsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <RefreshCw className="h-6 w-6 animate-spin" />
                </div>
              ) : filteredIncidents && filteredIncidents.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Switch</TableHead>
                      <TableHead>Severity</TableHead>
                      <TableHead>Score</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>MAC Moves</TableHead>
                      <TableHead>Suspected Ports</TableHead>
                      <TableHead>Detected</TableHead>
                      <TableHead className="w-32"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredIncidents.map((incident) => (
                      <TableRow key={incident.id}>
                        <TableCell className="font-mono text-sm">{incident.id}</TableCell>
                        <TableCell className="font-medium">{incident.switch_name}</TableCell>
                        <TableCell>{getSeverityBadge(incident.severity)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full ${
                                  incident.score >= 70
                                    ? 'bg-red-500'
                                    : incident.score >= 40
                                    ? 'bg-yellow-500'
                                    : 'bg-blue-500'
                                }`}
                                style={{ width: `${incident.score}%` }}
                              />
                            </div>
                            <span className="text-sm">{incident.score}</span>
                          </div>
                        </TableCell>
                        <TableCell>{getStatusBadge(incident.status)}</TableCell>
                        <TableCell>{incident.mac_moves_count}</TableCell>
                        <TableCell>
                          {incident.suspected_ports.slice(0, 3).join(', ')}
                          {incident.suspected_ports.length > 3 && '...'}
                        </TableCell>
                        <TableCell>{new Date(incident.detected_at).toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            {incident.status !== 'resolved' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleUpdateIncidentStatus(incident.id, 'resolved')}
                                title="Mark as resolved"
                              >
                                <CheckCircle2 className="h-4 w-4 text-green-600" />
                              </Button>
                            )}
                            {incident.status === 'open' && (
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleUpdateIncidentStatus(incident.id, 'investigating')}
                                title="Mark as investigating"
                              >
                                <Clock className="h-4 w-4 text-yellow-600" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteIncident(incident.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle2 className="mx-auto h-12 w-12 mb-2" />
                  <p>No incidents found</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* MAC Flapping Tab */}
        <TabsContent value="mac-flapping" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>MAC Flapping</CardTitle>
              <CardDescription>
                MAC addresses moving between ports (potential loop indicators)
              </CardDescription>
            </CardHeader>
            <CardContent>
              {flappingData?.flapping_macs && flappingData.flapping_macs.length > 0 ? (
                <>
                  <div className="grid grid-cols-3 gap-4 mb-4">
                    <Card>
                      <CardContent className="pt-4">
                        <div className="text-2xl font-bold">{flappingData.flapping_macs.length}</div>
                        <p className="text-xs text-muted-foreground">Flapping MACs</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-4">
                        <div className="text-2xl font-bold">{flappingData.total_moves}</div>
                        <p className="text-xs text-muted-foreground">Total Moves</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-4">
                        <div className="text-2xl font-bold">{flappingData.affected_ports}</div>
                        <p className="text-xs text-muted-foreground">Affected Ports</p>
                      </CardContent>
                    </Card>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>MAC Address</TableHead>
                        <TableHead>Move Count</TableHead>
                        <TableHead>Affected Ports</TableHead>
                        <TableHead>Last Move</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {flappingData.flapping_macs.map((mac) => (
                        <TableRow key={mac.mac}>
                          <TableCell className="font-mono">{mac.mac}</TableCell>
                          <TableCell>
                            <Badge variant={mac.move_count >= 10 ? 'destructive' : 'secondary'}>
                              {mac.move_count}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {mac.ports.slice(0, 4).map(([sw, port], idx) => (
                                <Badge key={idx} variant="outline" className="text-xs">
                                  {sw}:{port}
                                </Badge>
                              ))}
                              {mac.ports.length > 4 && (
                                <Badge variant="outline" className="text-xs">
                                  +{mac.ports.length - 4}
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{new Date(mac.last_move).toLocaleString()}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle2 className="mx-auto h-12 w-12 mb-2" />
                  <p>No MAC flapping detected</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Settings Dialog */}
      <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Monitoring Settings</DialogTitle>
            <DialogDescription>Configure network monitoring and alerting</DialogDescription>
          </DialogHeader>
          {editConfig && (
            <Tabs defaultValue="general" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="general">General</TabsTrigger>
                <TabsTrigger value="unifi">UniFi</TabsTrigger>
                <TabsTrigger value="alerting">Alerting</TabsTrigger>
              </TabsList>

              <TabsContent value="general" className="space-y-4 mt-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable Monitoring</Label>
                    <p className="text-sm text-muted-foreground">
                      Activate automatic loop detection
                    </p>
                  </div>
                  <Switch
                    checked={editConfig.enabled}
                    onCheckedChange={(checked) => setEditConfig({ ...editConfig, enabled: checked })}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Poll Interval (seconds)</Label>
                    <Input
                      type="number"
                      value={editConfig.poll_interval_seconds}
                      onChange={(e) =>
                        setEditConfig({ ...editConfig, poll_interval_seconds: parseInt(e.target.value) })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>MAC Table Interval (seconds)</Label>
                    <Input
                      type="number"
                      value={editConfig.mac_table_interval_seconds}
                      onChange={(e) =>
                        setEditConfig({ ...editConfig, mac_table_interval_seconds: parseInt(e.target.value) })
                      }
                    />
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-3">Detection Thresholds</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>MAC Flap Threshold</Label>
                      <Input
                        type="number"
                        value={editConfig.mac_flap_threshold}
                        onChange={(e) =>
                          setEditConfig({ ...editConfig, mac_flap_threshold: parseInt(e.target.value) })
                        }
                      />
                      <p className="text-xs text-muted-foreground">
                        Moves in window to trigger
                      </p>
                    </div>
                    <div className="space-y-2">
                      <Label>Flap Window (seconds)</Label>
                      <Input
                        type="number"
                        value={editConfig.mac_flap_window_seconds}
                        onChange={(e) =>
                          setEditConfig({ ...editConfig, mac_flap_window_seconds: parseInt(e.target.value) })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>STP TC Threshold</Label>
                      <Input
                        type="number"
                        value={editConfig.stp_tc_threshold}
                        onChange={(e) =>
                          setEditConfig({ ...editConfig, stp_tc_threshold: parseInt(e.target.value) })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Discard Rate Threshold (%)</Label>
                      <Input
                        type="number"
                        step="0.1"
                        value={editConfig.discard_rate_threshold}
                        onChange={(e) =>
                          setEditConfig({ ...editConfig, discard_rate_threshold: parseFloat(e.target.value) })
                        }
                      />
                    </div>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-3">Incident Scoring</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Warning Score</Label>
                      <Input
                        type="number"
                        value={editConfig.warning_score}
                        onChange={(e) =>
                          setEditConfig({ ...editConfig, warning_score: parseInt(e.target.value) })
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Critical Score</Label>
                      <Input
                        type="number"
                        value={editConfig.critical_score}
                        onChange={(e) =>
                          setEditConfig({ ...editConfig, critical_score: parseInt(e.target.value) })
                        }
                      />
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="unifi" className="space-y-4 mt-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable UniFi Integration</Label>
                    <p className="text-sm text-muted-foreground">
                      Discover switches from UniFi Controller
                    </p>
                  </div>
                  <Switch
                    checked={editConfig.unifi?.enabled}
                    onCheckedChange={(checked) =>
                      setEditConfig({
                        ...editConfig,
                        unifi: { ...editConfig.unifi, enabled: checked },
                      })
                    }
                  />
                </div>

                {editConfig.unifi?.enabled && (
                  <>
                    <div className="space-y-2">
                      <Label>Controller URL</Label>
                      <Input
                        value={editConfig.unifi?.controller_url}
                        onChange={(e) =>
                          setEditConfig({
                            ...editConfig,
                            unifi: { ...editConfig.unifi, controller_url: e.target.value },
                          })
                        }
                        placeholder="https://unifi.example.com:8443"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Username</Label>
                        <Input
                          value={editConfig.unifi?.username}
                          onChange={(e) =>
                            setEditConfig({
                              ...editConfig,
                              unifi: { ...editConfig.unifi, username: e.target.value },
                            })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Password</Label>
                        <div className="relative">
                          <Input
                            type={showPasswords['unifi'] ? 'text' : 'password'}
                            value={editConfig.unifi?.password}
                            onChange={(e) =>
                              setEditConfig({
                                ...editConfig,
                                unifi: { ...editConfig.unifi, password: e.target.value },
                              })
                            }
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="absolute right-0 top-0"
                            onClick={() => togglePassword('unifi')}
                          >
                            {showPasswords['unifi'] ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Site</Label>
                        <Input
                          value={editConfig.unifi?.site}
                          onChange={(e) =>
                            setEditConfig({
                              ...editConfig,
                              unifi: { ...editConfig.unifi, site: e.target.value },
                            })
                          }
                          placeholder="default"
                        />
                      </div>
                      <div className="flex items-center space-x-2 pt-7">
                        <Switch
                          id="verify_ssl"
                          checked={editConfig.unifi?.verify_ssl}
                          onCheckedChange={(checked) =>
                            setEditConfig({
                              ...editConfig,
                              unifi: { ...editConfig.unifi, verify_ssl: checked },
                            })
                          }
                        />
                        <Label htmlFor="verify_ssl">Verify SSL</Label>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      onClick={handleTestUniFi}
                      disabled={testUniFi.isPending}
                    >
                      {testUniFi.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Search className="mr-2 h-4 w-4" />
                      )}
                      Test Connection
                    </Button>
                  </>
                )}
              </TabsContent>

              <TabsContent value="alerting" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Webhook URL</Label>
                  <Input
                    value={editConfig.alert_webhook_url}
                    onChange={(e) => setEditConfig({ ...editConfig, alert_webhook_url: e.target.value })}
                    placeholder="https://discord.com/api/webhooks/..."
                  />
                  <p className="text-xs text-muted-foreground">
                    Receives alerts in Discord/Slack compatible format
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>Alert Email</Label>
                  <Input
                    type="email"
                    value={editConfig.alert_email}
                    onChange={(e) => setEditConfig({ ...editConfig, alert_email: e.target.value })}
                    placeholder="admin@example.com"
                  />
                  <p className="text-xs text-muted-foreground">
                    Email notifications (requires SMTP configuration)
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSettingsOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveConfig} disabled={updateConfig.isPending}>
              Save Settings
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
