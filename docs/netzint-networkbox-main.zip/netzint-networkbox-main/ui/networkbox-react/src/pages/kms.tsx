import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import {
  useKMSConfig,
  useKMSStatus,
  useCreateKMSConfig,
  useUpdateKMSConfig,
} from '@/hooks/use-kms'
import { useNetworks } from '@/hooks/use-networks'
import { useActionStream } from '@/hooks/use-action-stream'
import { ActionLogDialog } from '@/components/action-log-dialog'
import { Key, Play, Square, RefreshCw, Save, Network, Server, Monitor } from 'lucide-react'
import { toast } from 'sonner'
import type { KMSConfig } from '@/types'

export function KMSPage() {
  const { data: config, isLoading: configLoading } = useKMSConfig()
  const { data: status, refetch: refetchStatus } = useKMSStatus()
  const { data: networks } = useNetworks()
  const createConfig = useCreateKMSConfig()
  const updateConfig = useUpdateKMSConfig()
  const actionStream = useActionStream()

  const [formData, setFormData] = useState<Partial<KMSConfig>>({
    listen_address: '0.0.0.0',
    listen_port: 1688,
    allowed_networks: [],
    status: false,
  })

  const [isDirty, setIsDirty] = useState(false)

  useEffect(() => {
    if (config) {
      setFormData(config)
    }
  }, [config])

  const handleNetworkToggle = (vlanId: number, checked: boolean) => {
    const networks = formData.allowed_networks || []
    if (checked) {
      setFormData({ ...formData, allowed_networks: [...networks, vlanId] })
    } else {
      setFormData({ ...formData, allowed_networks: networks.filter((id) => id !== vlanId) })
    }
    setIsDirty(true)
  }

  const handleSave = async () => {
    try {
      if (config) {
        await updateConfig.mutateAsync(formData)
      } else {
        await createConfig.mutateAsync(formData as KMSConfig)
      }
      toast.success('KMS configuration saved')
      if (isRunning) {
        toast.info('Restart the container to apply changes', {
          duration: 5000,
        })
      }
      setIsDirty(false)
    } catch {
      toast.error('Failed to save configuration')
    }
  }

  const handleStart = () => {
    actionStream.startStream('/api/v1/kms/start/stream', 'Starting KMS Server')
  }

  const handleStop = () => {
    actionStream.startStream('/api/v1/kms/stop/stream', 'Stopping KMS Server')
  }

  const handleActionClose = () => {
    actionStream.close()
    refetchStatus()
  }

  const isRunning = status?.status === true

  if (configLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">KMS Server</h1>
          <p className="text-muted-foreground">
            Key Management Service for Windows/Office activation
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={isRunning ? 'success' : 'destructive'} className="text-sm">
            {isRunning ? 'Running' : 'Stopped'}
          </Badge>
          {isRunning ? (
            <Button variant="outline" onClick={handleStop} disabled={actionStream.isRunning}>
              {actionStream.isRunning ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Square className="mr-2 h-4 w-4" />
              )}
              Stop
            </Button>
          ) : (
            <Button onClick={handleStart} disabled={actionStream.isRunning || !config}>
              {actionStream.isRunning ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Play className="mr-2 h-4 w-4" />
              )}
              Start
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="h-5 w-5" />
              Server Configuration
            </CardTitle>
            <CardDescription>Configure the KMS server settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Listen Address</Label>
                <Input
                  value={formData.listen_address}
                  onChange={(e) => {
                    setFormData({ ...formData, listen_address: e.target.value })
                    setIsDirty(true)
                  }}
                  placeholder="0.0.0.0"
                />
              </div>
              <div className="space-y-2">
                <Label>Listen Port</Label>
                <Input
                  type="number"
                  value={formData.listen_port}
                  onChange={(e) => {
                    setFormData({ ...formData, listen_port: parseInt(e.target.value) })
                    setIsDirty(true)
                  }}
                />
              </div>
            </div>

            <div className="rounded-lg border p-4 bg-muted/50">
              <h4 className="font-medium mb-2 flex items-center gap-2">
                <Server className="h-4 w-4" />
                Server Info
              </h4>
              <div className="text-sm text-muted-foreground space-y-1">
                <p>KMS uses py-kms to emulate a Microsoft KMS server.</p>
                <p className="font-mono text-xs mt-2">
                  slmgr /skms {formData.listen_address === '0.0.0.0' ? '<server-ip>' : formData.listen_address}:{formData.listen_port}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Network className="h-5 w-5" />
              Allowed Networks
            </CardTitle>
            <CardDescription>
              Select networks that are allowed to activate (leave empty for all)
            </CardDescription>
          </CardHeader>
          <CardContent>
            {networks && networks.length > 0 ? (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {networks.map((network) => (
                  <div key={network.vlan_id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`network-${network.vlan_id}`}
                      checked={formData.allowed_networks?.includes(network.vlan_id)}
                      onCheckedChange={(checked) => handleNetworkToggle(network.vlan_id, checked as boolean)}
                    />
                    <label
                      htmlFor={`network-${network.vlan_id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center gap-2"
                    >
                      <span>{network.name}</span>
                      <span className="text-xs text-muted-foreground font-mono">
                        VLAN {network.vlan_id} - {network.address}/{network.mask}
                      </span>
                    </label>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No networks configured. Create networks in the Networks page.
              </div>
            )}
            {(formData.allowed_networks?.length === 0 || !formData.allowed_networks) && networks && networks.length > 0 && (
              <p className="text-xs text-muted-foreground mt-3">
                No networks selected - KMS will accept requests from all networks.
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Monitor className="h-5 w-5" />
              Supported Products
            </CardTitle>
            <CardDescription>
              Products that can be activated using this KMS server
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Windows Desktop</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>Windows 11 Enterprise/Education/Pro</li>
                  <li>Windows 10 Enterprise/Education/Pro</li>
                  <li>Windows 8.1 Enterprise/Pro</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Windows Server</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>Windows Server 2022</li>
                  <li>Windows Server 2019</li>
                  <li>Windows Server 2016</li>
                  <li>Windows Server 2012 R2</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium text-sm">Microsoft Office</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>Office LTSC 2021</li>
                  <li>Office 2019</li>
                  <li>Office 2016</li>
                  <li>Office 365 ProPlus</li>
                </ul>
              </div>
            </div>

            <div className="mt-6 rounded-lg border p-4 bg-muted/50">
              <h4 className="font-medium mb-2">Activation Commands</h4>
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Windows (Admin CMD):</p>
                  <code className="text-xs bg-background px-2 py-1 rounded block">
                    slmgr /skms {formData.listen_address === '0.0.0.0' ? '<server-ip>' : formData.listen_address}:{formData.listen_port}<br />
                    slmgr /ato
                  </code>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Office (ospp.vbs):</p>
                  <code className="text-xs bg-background px-2 py-1 rounded block">
                    cscript ospp.vbs /sethst:{formData.listen_address === '0.0.0.0' ? '<server-ip>' : formData.listen_address}<br />
                    cscript ospp.vbs /act
                  </code>
                </div>
              </div>
            </div>

            <div className="flex justify-end mt-4">
              <Button onClick={handleSave} disabled={!isDirty || createConfig.isPending || updateConfig.isPending}>
                {(createConfig.isPending || updateConfig.isPending) ? (
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Save className="mr-2 h-4 w-4" />
                )}
                Save Configuration
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Log Dialog */}
      <ActionLogDialog
        open={actionStream.isOpen}
        onClose={handleActionClose}
        title={actionStream.title}
        logs={actionStream.logs}
        isRunning={actionStream.isRunning}
        success={actionStream.success}
      />
    </div>
  )
}
