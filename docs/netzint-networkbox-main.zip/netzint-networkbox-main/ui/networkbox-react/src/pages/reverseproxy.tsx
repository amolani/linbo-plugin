import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  useReverseProxies,
  useCreateReverseProxy,
  useUpdateReverseProxy,
  useDeleteReverseProxy,
  useStartReverseProxy,
  useStopReverseProxy,
} from '@/hooks/use-reverseproxy'
import { useCertificates } from '@/hooks/use-certificates'
import { ActionLogDialog } from '@/components/action-log-dialog'
import type { LogEntry } from '@/hooks/use-action-stream'
import { Plus, Trash2, Play, Square, RefreshCw, ArrowRightLeft, X, Pencil } from 'lucide-react'
import { toast } from 'sonner'
import type { ReverseProxy, ReverseProxyTarget } from '@/types'

const PROTOCOLS = [
  { value: 'http', label: 'HTTP', port: 80 },
  { value: 'https', label: 'HTTPS', port: 443 },
  { value: 'ldap', label: 'LDAP', port: 389 },
  { value: 'ldaps', label: 'LDAPS', port: 636 },
  { value: 'smtp', label: 'SMTP', port: 25 },
  { value: 'smtps', label: 'SMTPS', port: 465 },
  { value: 'imap', label: 'IMAP', port: 143 },
  { value: 'imaps', label: 'IMAPS', port: 993 },
  { value: 'pop3', label: 'POP3', port: 110 },
  { value: 'pop3s', label: 'POP3S', port: 995 },
]

const LOAD_BALANCING = [
  { value: 'round-robin', label: 'Round Robin' },
  { value: 'least-conn', label: 'Least Connections' },
  { value: 'source', label: 'Source IP Hash' },
]

const emptyProxy: Partial<ReverseProxy> = {
  name: '',
  protocol: 'http',
  listen_address: '0.0.0.0',
  listen_port: 80,
  targets: [{ address: '', port: 80, weight: 1 }],
  certificate: '',
  load_balancing: 'round-robin',
  status: false,
}

export function ReverseProxyPage() {
  const { data: proxies, isLoading } = useReverseProxies()
  const { data: certificates } = useCertificates()
  const createProxy = useCreateReverseProxy()
  const updateProxy = useUpdateReverseProxy()
  const deleteProxy = useDeleteReverseProxy()
  const startProxy = useStartReverseProxy()
  const stopProxy = useStopReverseProxy()

  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [isEditOpen, setIsEditOpen] = useState(false)
  const [editingProxy, setEditingProxy] = useState<string | null>(null)
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  const [formData, setFormData] = useState<Partial<ReverseProxy>>({ ...emptyProxy })

  // Action dialog state for start/stop operations
  const [actionDialogOpen, setActionDialogOpen] = useState(false)
  const [actionDialogTitle, setActionDialogTitle] = useState('')
  const [actionDialogLogs, setActionDialogLogs] = useState<LogEntry[]>([])
  const [actionDialogRunning, setActionDialogRunning] = useState(false)
  const [actionDialogSuccess, setActionDialogSuccess] = useState<boolean | null>(null)

  const addActionLog = (level: LogEntry['level'], message: string) => {
    const timestamp = new Date().toLocaleTimeString('de-DE', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    })
    setActionDialogLogs(prev => [...prev, { timestamp, level, message }])
  }

  // Reset form when dialog closes
  useEffect(() => {
    if (!isCreateOpen && !isEditOpen) {
      setFormData({ ...emptyProxy })
      setEditingProxy(null)
    }
  }, [isCreateOpen, isEditOpen])

  const handleProtocolChange = (protocol: string) => {
    const protocolInfo = PROTOCOLS.find((p) => p.value === protocol)
    setFormData({
      ...formData,
      protocol,
      listen_port: protocolInfo?.port || 80,
    })
  }

  const addTarget = () => {
    setFormData({
      ...formData,
      targets: [...(formData.targets || []), { address: '', port: 80, weight: 1 }],
    })
  }

  const removeTarget = (index: number) => {
    setFormData({
      ...formData,
      targets: (formData.targets || []).filter((_, i) => i !== index),
    })
  }

  const updateTarget = (index: number, field: keyof ReverseProxyTarget, value: string | number) => {
    const targets = [...(formData.targets || [])]
    targets[index] = { ...targets[index], [field]: value }
    setFormData({ ...formData, targets })
  }

  const handleCreate = async () => {
    if (!formData.name || !formData.targets?.length) {
      toast.error('Please fill in all required fields')
      return
    }
    try {
      await createProxy.mutateAsync(formData as ReverseProxy)
      toast.success('Reverse proxy created')
      setIsCreateOpen(false)
    } catch {
      toast.error('Failed to create reverse proxy')
    }
  }

  const handleEdit = (proxy: ReverseProxy) => {
    setFormData({ ...proxy })
    setEditingProxy(proxy.name)
    setIsEditOpen(true)
  }

  const handleUpdate = async () => {
    if (!editingProxy || !formData.targets?.length) {
      toast.error('Please fill in all required fields')
      return
    }
    try {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const { name, status, ...updateData } = formData
      await updateProxy.mutateAsync({ name: editingProxy, data: updateData })
      toast.success('Reverse proxy updated')
      setIsEditOpen(false)
    } catch {
      toast.error('Failed to update reverse proxy')
    }
  }

  const handleDelete = async (name: string) => {
    if (!confirm('Are you sure you want to delete this reverse proxy?')) return
    try {
      await deleteProxy.mutateAsync(name)
      toast.success('Reverse proxy deleted')
    } catch {
      toast.error('Failed to delete reverse proxy')
    }
  }

  const handleStart = async (name: string) => {
    setActionLoading(name)
    setActionDialogTitle(`Starting Reverse Proxy: ${name}`)
    setActionDialogLogs([])
    setActionDialogRunning(true)
    setActionDialogSuccess(null)
    setActionDialogOpen(true)
    addActionLog('info', `Starting reverse proxy ${name}...`)

    try {
      const result = await startProxy.mutateAsync(name)
      if (result.status) {
        addActionLog('success', `Successfully started ${name}`)
        setActionDialogSuccess(true)
        toast.success(result.message)
      } else {
        addActionLog('error', `Failed: ${result.message}`)
        setActionDialogSuccess(false)
        toast.error(result.message)
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error'
      addActionLog('error', `Error: ${message}`)
      setActionDialogSuccess(false)
      toast.error('Failed to start reverse proxy')
    } finally {
      setActionLoading(null)
      setActionDialogRunning(false)
    }
  }

  const handleStop = async (name: string) => {
    setActionLoading(name)
    setActionDialogTitle(`Stopping Reverse Proxy: ${name}`)
    setActionDialogLogs([])
    setActionDialogRunning(true)
    setActionDialogSuccess(null)
    setActionDialogOpen(true)
    addActionLog('info', `Stopping reverse proxy ${name}...`)

    try {
      const result = await stopProxy.mutateAsync(name)
      if (result.status) {
        addActionLog('success', `Successfully stopped ${name}`)
        setActionDialogSuccess(true)
        toast.success(result.message)
      } else {
        addActionLog('error', `Failed: ${result.message}`)
        setActionDialogSuccess(false)
        toast.error(result.message)
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error'
      addActionLog('error', `Error: ${message}`)
      setActionDialogSuccess(false)
      toast.error('Failed to stop reverse proxy')
    } finally {
      setActionLoading(null)
      setActionDialogRunning(false)
    }
  }

  const handleActionClose = () => {
    setActionDialogOpen(false)
  }

  const isTlsProtocol = (protocol: string) => {
    return ['https', 'ldaps', 'smtps', 'imaps', 'pop3s'].includes(protocol)
  }

  // Render function for form fields (not a component, to avoid focus loss)
  const renderFormFields = (isEdit: boolean) => (
    <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto overflow-x-hidden px-1">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Name</Label>
          <Input
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="web-proxy"
            disabled={isEdit}
          />
        </div>
        <div className="space-y-2">
          <Label>Protocol</Label>
          <Select
            value={formData.protocol}
            onValueChange={handleProtocolChange}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {PROTOCOLS.map((p) => (
                <SelectItem key={p.value} value={p.value}>
                  {p.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Listen Address</Label>
          <Input
            value={formData.listen_address}
            onChange={(e) => setFormData({ ...formData, listen_address: e.target.value })}
            placeholder="0.0.0.0"
          />
        </div>
        <div className="space-y-2">
          <Label>Listen Port</Label>
          <Input
            type="number"
            value={formData.listen_port}
            onChange={(e) => setFormData({ ...formData, listen_port: parseInt(e.target.value) })}
          />
        </div>
      </div>

      {isTlsProtocol(formData.protocol || '') && (
        <div className="space-y-2">
          <Label>SSL Certificate</Label>
          <Select
            value={formData.certificate || ''}
            onValueChange={(value) => setFormData({ ...formData, certificate: value })}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select certificate" />
            </SelectTrigger>
            <SelectContent>
              {certificates?.map((cert) => (
                <SelectItem key={cert.name} value={cert.name}>
                  {cert.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="space-y-2">
        <Label>Load Balancing</Label>
        <Select
          value={formData.load_balancing}
          onValueChange={(value) => setFormData({ ...formData, load_balancing: value })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {LOAD_BALANCING.map((lb) => (
              <SelectItem key={lb.value} value={lb.value}>
                {lb.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Backend Targets</Label>
          <Button type="button" variant="outline" size="sm" onClick={addTarget}>
            <Plus className="mr-1 h-3 w-3" />
            Add Target
          </Button>
        </div>
        {formData.targets?.map((target, index) => (
          <div key={index} className="grid grid-cols-7 gap-2 items-end">
            <div className="col-span-3 space-y-1">
              <Label className="text-xs">Address</Label>
              <Input
                value={target.address}
                onChange={(e) => updateTarget(index, 'address', e.target.value)}
                placeholder="192.168.1.10"
              />
            </div>
            <div className="col-span-2 space-y-1">
              <Label className="text-xs">Port</Label>
              <Input
                type="number"
                value={target.port}
                onChange={(e) => updateTarget(index, 'port', parseInt(e.target.value))}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Weight</Label>
              <Input
                type="number"
                value={target.weight}
                onChange={(e) => updateTarget(index, 'weight', parseInt(e.target.value))}
                min={1}
              />
            </div>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => removeTarget(index)}
              disabled={formData.targets?.length === 1}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Reverse Proxy</h1>
          <p className="text-muted-foreground">
            Multi-protocol reverse proxy with load balancing
          </p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Proxy
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Reverse Proxy</DialogTitle>
              <DialogDescription>
                Configure a new reverse proxy endpoint
              </DialogDescription>
            </DialogHeader>
            {renderFormFields(false)}
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreate} disabled={createProxy.isPending}>
                Create
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Configured Proxies</CardTitle>
          <CardDescription>Manage your reverse proxy endpoints</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
            </div>
          ) : proxies && proxies.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Protocol</TableHead>
                  <TableHead>Listen</TableHead>
                  <TableHead>Targets</TableHead>
                  <TableHead>Load Balancing</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-40"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {proxies.map((proxy) => (
                  <TableRow key={proxy.name}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <ArrowRightLeft className="h-4 w-4 text-primary" />
                        <span className="font-medium">{proxy.name}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{proxy.protocol.toUpperCase()}</Badge>
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {proxy.listen_address}:{proxy.listen_port}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {proxy.targets.length} target{proxy.targets.length !== 1 ? 's' : ''}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {proxy.targets.map((t) => `${t.address}:${t.port}`).join(', ')}
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">
                      {LOAD_BALANCING.find((lb) => lb.value === proxy.load_balancing)?.label}
                    </TableCell>
                    <TableCell>
                      <Badge variant={proxy.status ? 'success' : 'destructive'}>
                        {proxy.status ? 'Running' : 'Stopped'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleEdit(proxy)}
                          disabled={proxy.status}
                          title={proxy.status ? 'Stop proxy before editing' : 'Edit'}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        {proxy.status ? (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleStop(proxy.name)}
                            disabled={actionLoading === proxy.name}
                            title="Stop"
                          >
                            {actionLoading === proxy.name ? (
                              <RefreshCw className="h-4 w-4 animate-spin" />
                            ) : (
                              <Square className="h-4 w-4" />
                            )}
                          </Button>
                        ) : (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleStart(proxy.name)}
                            disabled={actionLoading === proxy.name}
                            title="Start"
                          >
                            {actionLoading === proxy.name ? (
                              <RefreshCw className="h-4 w-4 animate-spin" />
                            ) : (
                              <Play className="h-4 w-4" />
                            )}
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(proxy.name)}
                          className="text-destructive hover:text-destructive"
                          disabled={proxy.status}
                          title={proxy.status ? 'Stop proxy before deleting' : 'Delete'}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              No reverse proxies configured yet.
            </div>
          )}
        </CardContent>
      </Card>

      {/* Edit Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Reverse Proxy</DialogTitle>
            <DialogDescription>
              Modify the reverse proxy configuration
            </DialogDescription>
          </DialogHeader>
          {renderFormFields(true)}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdate} disabled={updateProxy.isPending}>
              {updateProxy.isPending ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Action Log Dialog */}
      <ActionLogDialog
        open={actionDialogOpen}
        onClose={handleActionClose}
        title={actionDialogTitle}
        logs={actionDialogLogs}
        isRunning={actionDialogRunning}
        success={actionDialogSuccess}
      />
    </div>
  )
}
