import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { toast } from 'sonner'
import { Zap, Info, Send, Code, Loader2, Download, Terminal, Copy, ExternalLink } from 'lucide-react'
import api from '@/lib/api'

const WAKEONLAN_VERSION = '2.0.0'
const GITHUB_REPO = 'netzint/netzint-networkbox'

interface NetworkInfo {
  name: string
  vlan_id: number
  address: string
  mask: string
}

export function WOLPage() {
  const [mac, setMac] = useState('')
  const [broadcastIP, setBroadcastIP] = useState('255.255.255.255')
  const [port, setPort] = useState('9')
  const [selectedNetwork, setSelectedNetwork] = useState<string>('')
  const [activeTab, setActiveTab] = useState('send')

  // Get current host for configuration examples
  const currentHost = window.location.hostname
  const apiPort = '8000'

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard')
  }

  const downloadUrl = `https://github.com/${GITHUB_REPO}/releases/download/wakeonlan-v${WAKEONLAN_VERSION}/wakeonlan-networkbox_${WAKEONLAN_VERSION}_all.deb`

  // Fetch networks
  const { data: networks } = useQuery<NetworkInfo[]>({
    queryKey: ['networks'],
    queryFn: async () => {
      const response = await api.get('/networks')
      return response.data
    },
  })

  // Wake mutation
  const wakeMutation = useMutation({
    mutationFn: async (data: { mac: string; ip: string; port: number }) => {
      const response = await api.post('/napi/wake', data)
      return response.data
    },
    onSuccess: (data) => {
      if (data.status) {
        toast.success(`Wake-on-LAN packet sent to ${mac}`)
      } else {
        toast.error(data.message || 'Failed to send WOL packet')
      }
    },
    onError: () => {
      toast.error('Failed to send Wake-on-LAN packet')
    },
  })

  const handleSendWOL = () => {
    if (!mac) {
      toast.error('Please enter a MAC address')
      return
    }

    // Validate MAC format
    const macRegex = /^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/
    if (!macRegex.test(mac)) {
      toast.error('Invalid MAC address format. Use XX:XX:XX:XX:XX:XX')
      return
    }

    wakeMutation.mutate({
      mac: mac.toUpperCase(),
      ip: broadcastIP,
      port: parseInt(port),
    })
  }

  const handleNetworkChange = (vlanId: string) => {
    setSelectedNetwork(vlanId)
    const network = networks?.find((n) => n.vlan_id === parseInt(vlanId))
    if (network) {
      // Calculate broadcast address from network
      const parts = network.address.split('.')
      const maskParts = network.mask.split('.')
      const broadcast = parts.map((part, i) => {
        const p = parseInt(part)
        const m = parseInt(maskParts[i])
        return (p | (~m & 255)).toString()
      }).join('.')
      setBroadcastIP(broadcast)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Wake on LAN</h1>
        <p className="text-muted-foreground">Wake up devices on the network</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="send" className="gap-2">
            <Zap className="h-4 w-4" />
            Send WOL
          </TabsTrigger>
          <TabsTrigger value="client" className="gap-2">
            <Download className="h-4 w-4" />
            Client Installation
          </TabsTrigger>
          <TabsTrigger value="api" className="gap-2">
            <Code className="h-4 w-4" />
            API
          </TabsTrigger>
        </TabsList>

        {/* Send WOL Tab */}
        <TabsContent value="send" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5" />
                  Send Wake-on-LAN
                </CardTitle>
                <CardDescription>
                  Send a magic packet to wake up a device
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="mac">MAC Address</Label>
                  <Input
                    id="mac"
                    placeholder="00:11:22:33:44:55"
                    value={mac}
                    onChange={(e) => setMac(e.target.value)}
                    className="font-mono"
                  />
                </div>

                <div className="space-y-2">
                  <Label>Target Network</Label>
                  <Select value={selectedNetwork} onValueChange={handleNetworkChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select network (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="broadcast">Global Broadcast</SelectItem>
                      {networks?.map((network) => (
                        <SelectItem key={network.vlan_id} value={String(network.vlan_id)}>
                          {network.name} (VLAN {network.vlan_id})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="ip">Broadcast IP</Label>
                    <Input
                      id="ip"
                      value={broadcastIP}
                      onChange={(e) => setBroadcastIP(e.target.value)}
                      className="font-mono"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="port">Port</Label>
                    <Input
                      id="port"
                      type="number"
                      value={port}
                      onChange={(e) => setPort(e.target.value)}
                    />
                  </div>
                </div>

                <Button
                  className="w-full"
                  onClick={handleSendWOL}
                  disabled={!mac || wakeMutation.isPending}
                >
                  {wakeMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Send className="h-4 w-4 mr-2" />
                  )}
                  Send Magic Packet
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>How it works</CardTitle>
                <CardDescription>Wake-on-LAN explained</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm text-muted-foreground">
                <p>
                  Wake-on-LAN (WoL) sends a special &quot;magic packet&quot; to a network interface
                  that wakes up the computer, even when it&apos;s powered off or in sleep mode.
                </p>
                <p>
                  The magic packet contains the target MAC address repeated 16 times,
                  which the network card recognizes and uses to power on the system.
                </p>
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    WoL must be enabled in BIOS/UEFI and the network driver settings
                    on the target machine.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Client Installation Tab */}
        <TabsContent value="client" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Download & Install Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="h-5 w-5" />
                  wakeonlan-networkbox
                </CardTitle>
                <CardDescription>
                  Drop-in replacement for the standard wakeonlan command
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    This package replaces the standard <code className="bg-muted px-1 rounded">wakeonlan</code> command
                    and forwards all WoL requests through this NetworkBOX server.
                  </AlertDescription>
                </Alert>

                <div className="space-y-3">
                  <h4 className="font-medium">1. Download &amp; Install</h4>
                  <div className="bg-muted rounded-md p-3 font-mono text-xs space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <code className="break-all">wget {downloadUrl}</code>
                      <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => copyToClipboard(`wget ${downloadUrl}`)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <code>sudo dpkg -i wakeonlan-networkbox_{WAKEONLAN_VERSION}_all.deb</code>
                      <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => copyToClipboard(`sudo dpkg -i wakeonlan-networkbox_${WAKEONLAN_VERSION}_all.deb`)}>
                        <Copy className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">2. Configure NetworkBOX Server</h4>
                  <div className="bg-muted rounded-md p-3 font-mono text-xs">
                    <code>sudo nano /etc/networkbox/wakeonlan.conf</code>
                    <Button variant="ghost" size="icon" className="h-6 w-6 ml-2" onClick={() => copyToClipboard('sudo nano /etc/networkbox/wakeonlan.conf')}>
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                  <div className="bg-muted rounded-md p-3 font-mono text-xs">
                    <pre>{`NETWORKBOX_HOST="${currentHost}"
NETWORKBOX_PORT="${apiPort}"`}</pre>
                    <Button variant="ghost" size="icon" className="h-6 w-6 absolute top-2 right-2" onClick={() => copyToClipboard(`NETWORKBOX_HOST="${currentHost}"\nNETWORKBOX_PORT="${apiPort}"`)}>
                      <Copy className="h-3 w-3" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-medium">3. Use it!</h4>
                  <div className="bg-muted rounded-md p-3 font-mono text-xs">
                    <code>wakeonlan AA:BB:CC:DD:EE:FF</code>
                  </div>
                </div>

                <div className="pt-2">
                  <Button variant="outline" className="w-full" asChild>
                    <a href={`https://github.com/${GITHUB_REPO}/releases`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View all releases on GitHub
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Usage Examples Card */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Terminal className="h-5 w-5" />
                  Usage Examples
                </CardTitle>
                <CardDescription>
                  Command-line usage after installation
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Wake a single machine</Label>
                  <pre className="rounded-md bg-muted p-3 font-mono text-xs">
wakeonlan 00:11:22:33:44:55</pre>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Wake multiple machines</Label>
                  <pre className="rounded-md bg-muted p-3 font-mono text-xs">
wakeonlan AA:BB:CC:DD:EE:FF 11:22:33:44:55:66</pre>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Verbose mode (for debugging)</Label>
                  <pre className="rounded-md bg-muted p-3 font-mono text-xs">
wakeonlan -V 00:11:22:33:44:55</pre>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Wake from file</Label>
                  <pre className="rounded-md bg-muted p-3 font-mono text-xs">
wakeonlan -f /path/to/mac-list.txt</pre>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Override server on command line</Label>
                  <pre className="rounded-md bg-muted p-3 font-mono text-xs">
wakeonlan --host={currentHost} 00:11:22:33:44:55</pre>
                </div>

                <Alert className="mt-4">
                  <Info className="h-4 w-4" />
                  <AlertTitle>Environment Variables</AlertTitle>
                  <AlertDescription className="text-xs mt-2">
                    You can also use <code className="bg-background px-1 rounded">NB_HOST</code> and{' '}
                    <code className="bg-background px-1 rounded">NB_PORT</code> environment variables.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* API Documentation Tab */}
        <TabsContent value="api" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  API Examples
                </CardTitle>
                <CardDescription>
                  Use the WOL API for automation and scripting
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="curl">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="curl">cURL</TabsTrigger>
                    <TabsTrigger value="powershell">PowerShell</TabsTrigger>
                    <TabsTrigger value="python">Python</TabsTrigger>
                  </TabsList>

                  <TabsContent value="curl" className="space-y-4">
                    <pre className="rounded-md bg-muted p-4 font-mono text-xs overflow-x-auto">
{`curl -X POST http://${currentHost}:${apiPort}/api/v1/napi/wake \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -d '{"mac": "00:11:22:33:44:55"}'`}
                    </pre>
                  </TabsContent>

                  <TabsContent value="powershell" className="space-y-4">
                    <pre className="rounded-md bg-muted p-4 font-mono text-xs overflow-x-auto">
{`$headers = @{
  "Content-Type" = "application/json"
  "Authorization" = "Bearer YOUR_TOKEN"
}
$body = @{
  mac = "00:11:22:33:44:55"
} | ConvertTo-Json

Invoke-RestMethod \`
  -Uri "http://${currentHost}:${apiPort}/api/v1/napi/wake" \`
  -Method POST -Headers $headers -Body $body`}
                    </pre>
                  </TabsContent>

                  <TabsContent value="python" className="space-y-4">
                    <pre className="rounded-md bg-muted p-4 font-mono text-xs overflow-x-auto">
{`import requests

response = requests.post(
    "http://${currentHost}:${apiPort}/api/v1/napi/wake",
    headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_TOKEN"
    },
    json={"mac": "00:11:22:33:44:55"}
)
print(response.json())`}
                    </pre>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>API Reference</CardTitle>
                <CardDescription>Endpoint details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Endpoint</Label>
                  <pre className="rounded-md bg-muted p-3 font-mono text-xs">
POST /api/v1/napi/wake</pre>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Request Body</Label>
                  <pre className="rounded-md bg-muted p-3 font-mono text-xs">
{`{
  "mac": "XX:XX:XX:XX:XX:XX",
  "ip": "255.255.255.255",  // optional
  "port": 9                  // optional
}`}</pre>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">Success Response</Label>
                  <pre className="rounded-md bg-muted p-3 font-mono text-xs">
{`{
  "status": true,
  "message": "Magic packet sent"
}`}</pre>
                </div>

                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertTitle>Authentication</AlertTitle>
                  <AlertDescription className="text-xs mt-2">
                    This endpoint requires a valid JWT token in the Authorization header.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
