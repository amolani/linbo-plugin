import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  useProxyConfig,
  useProxyStatus,
  useCreateProxyConfig,
  useUpdateProxyConfig,
} from '@/hooks/use-proxy'
import { useAuthenticationList, useAuthenticationGroups } from '@/hooks/use-authentication'
import { useActionStream } from '@/hooks/use-action-stream'
import { ActionLogDialog } from '@/components/action-log-dialog'
import {
  Shield, Play, Square, RefreshCw, Save, AlertCircle, Check, ChevronsUpDown, X,
  ListCheck, Ban, Palette, Image, Plus, Trash2, Globe, Copy, ExternalLink, Key, Info,
  Server, Network, Users, FileText, Search, Radio, Pause
} from 'lucide-react'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command'
import { cn } from '@/lib/utils'
import { toast } from 'sonner'
import type { ProxyConfig, ProxyBlockPageConfig, KerberosConfig, ParentProxyConfig, IPAllowConfig, AllowedIP } from '@/types'
import { Alert, AlertDescription } from '@/components/ui/alert'
import api from '@/lib/api'

const defaultBlockPage: ProxyBlockPageConfig = {
  title: 'Zugriff nicht erlaubt',
  message: 'Ihr Gerät ist nicht für den Internetzugang freigeschaltet.',
  logo_url: undefined,
  background_color: '#f5f7fa',
  card_background_color: '#ffffff',
  title_color: '#1f2937',
  text_color: '#6b7280',
  accent_color: '#dc2626',
  show_url: true,
  show_ip: true,
  show_time: true,
  animation_enabled: true,
}

const defaultIPAllow: IPAllowConfig = {
  api_key: '',
  allowed_ips: [],
  blocked_ips: [],
}

const defaultKerberos: KerberosConfig = {
  enabled: false,
  realm: '',
  kdc: '',
  domain_admin: '',
  domain_admin_password: '',
  proxy_hostname: '',
  ticket_lifetime: '24h',
  renew_lifetime: '7d',
}

const defaultParentProxy: ParentProxyConfig = {
  enabled: false,
  host: '',
  port: 8080,
  forward_auth: 'none',
  auth_header_name: 'X-Authenticated-User',
  username: '',
  password: '',
}

export function ProxyPage() {
  const { data: config, isLoading: configLoading } = useProxyConfig()
  const { data: status, refetch: refetchStatus } = useProxyStatus()
  const { data: authentications } = useAuthenticationList()
  const createConfig = useCreateProxyConfig()
  const updateConfig = useUpdateProxyConfig()
  const actionStream = useActionStream()

  const [selectedAuth, setSelectedAuth] = useState<string>('')
  const { data: availableGroups } = useAuthenticationGroups(selectedAuth)

  const [formData, setFormData] = useState<Partial<ProxyConfig>>({
    listen_address: '0.0.0.0',
    listen_port: 3128,
    auth_mode: 'ldap',
    authentication: '',
    allowed_groups: [],
    ip_allow: defaultIPAllow,
    whitelist_domains: [],
    blacklist_domains: [],
    bypass_groups: [],
    block_page: defaultBlockPage,
    kerberos: defaultKerberos,
    parent_proxy: defaultParentProxy,
    status: false,
  })

  const [isDirty, setIsDirty] = useState(false)
  const [groupsOpen, setGroupsOpen] = useState(false)
  const [bypassGroupsOpen, setBypassGroupsOpen] = useState(false)
  const [newWhitelistDomain, setNewWhitelistDomain] = useState('')
  const [newBlacklistDomain, setNewBlacklistDomain] = useState('')
  const [newDirectDomain, setNewDirectDomain] = useState('')
  const [newDirectNetwork, setNewDirectNetwork] = useState('')
  const [newAllowedIP, setNewAllowedIP] = useState('')
  const [newAllowedIPDesc, setNewAllowedIPDesc] = useState('')
  const [newBlockedIP, setNewBlockedIP] = useState('')
  const [newBlockedIPDesc, setNewBlockedIPDesc] = useState('')
  const [generatingApiKey, setGeneratingApiKey] = useState(false)

  // Logs state
  const [logs, setLogs] = useState<string[]>([])
  const [logsLoading, setLogsLoading] = useState(false)
  const [logsSearch, setLogsSearch] = useState('')
  const [isLiveMode, setIsLiveMode] = useState(false)
  const [eventSource, setEventSource] = useState<EventSource | null>(null)

  useEffect(() => {
    if (config) {
      // Ensure block_page, kerberos, parent_proxy and ip_allow have all default values
      const blockPage = config.block_page ? { ...defaultBlockPage, ...config.block_page } : defaultBlockPage
      const kerberos = config.kerberos ? { ...defaultKerberos, ...config.kerberos } : defaultKerberos
      const parentProxy = config.parent_proxy ? { ...defaultParentProxy, ...config.parent_proxy } : defaultParentProxy
      const ipAllow = config.ip_allow ? { ...defaultIPAllow, ...config.ip_allow } : defaultIPAllow
      setFormData({
        ...config,
        auth_mode: config.auth_mode || 'ldap',
        block_page: blockPage,
        kerberos,
        parent_proxy: parentProxy,
        ip_allow: ipAllow
      })
      setSelectedAuth(config.authentication || '')
    }
  }, [config])

  const handleAuthChange = (value: string) => {
    setSelectedAuth(value)
    setFormData({ ...formData, authentication: value, allowed_groups: [], bypass_groups: [] })
    setIsDirty(true)
  }

  const handleGroupToggle = (group: string) => {
    const groups = formData.allowed_groups || []
    const isSelected = groups.includes(group)
    if (isSelected) {
      setFormData({ ...formData, allowed_groups: groups.filter((g) => g !== group) })
    } else {
      setFormData({ ...formData, allowed_groups: [...groups, group] })
    }
    setIsDirty(true)
  }

  const handleBypassGroupToggle = (group: string) => {
    const groups = formData.bypass_groups || []
    const isSelected = groups.includes(group)
    if (isSelected) {
      setFormData({ ...formData, bypass_groups: groups.filter((g) => g !== group) })
    } else {
      setFormData({ ...formData, bypass_groups: [...groups, group] })
    }
    setIsDirty(true)
  }

  const removeGroup = (group: string) => {
    setFormData({
      ...formData,
      allowed_groups: (formData.allowed_groups || []).filter((g) => g !== group),
    })
    setIsDirty(true)
  }

  const removeBypassGroup = (group: string) => {
    setFormData({
      ...formData,
      bypass_groups: (formData.bypass_groups || []).filter((g) => g !== group),
    })
    setIsDirty(true)
  }

  const extractGroupName = (dn: string) => {
    const match = dn.match(/^CN=([^,]+)/i)
    return match ? match[1] : dn
  }

  const addWhitelistDomain = () => {
    if (!newWhitelistDomain.trim()) return
    const domain = newWhitelistDomain.trim().toLowerCase()
    if (formData.whitelist_domains?.includes(domain)) {
      toast.error('Domain already in whitelist')
      return
    }
    setFormData({
      ...formData,
      whitelist_domains: [...(formData.whitelist_domains || []), domain],
    })
    setNewWhitelistDomain('')
    setIsDirty(true)
  }

  const removeWhitelistDomain = (domain: string) => {
    setFormData({
      ...formData,
      whitelist_domains: (formData.whitelist_domains || []).filter((d) => d !== domain),
    })
    setIsDirty(true)
  }

  const addBlacklistDomain = () => {
    if (!newBlacklistDomain.trim()) return
    const domain = newBlacklistDomain.trim().toLowerCase()
    if (formData.blacklist_domains?.includes(domain)) {
      toast.error('Domain already in blacklist')
      return
    }
    setFormData({
      ...formData,
      blacklist_domains: [...(formData.blacklist_domains || []), domain],
    })
    setNewBlacklistDomain('')
    setIsDirty(true)
  }

  const removeBlacklistDomain = (domain: string) => {
    setFormData({
      ...formData,
      blacklist_domains: (formData.blacklist_domains || []).filter((d) => d !== domain),
    })
    setIsDirty(true)
  }

  const updateBlockPage = (updates: Partial<ProxyBlockPageConfig>) => {
    setFormData({
      ...formData,
      block_page: { ...formData.block_page!, ...updates },
    })
    setIsDirty(true)
  }

  const updateKerberos = (updates: Partial<KerberosConfig>) => {
    setFormData({
      ...formData,
      kerberos: { ...formData.kerberos!, ...updates },
    })
    setIsDirty(true)
  }

  const updateParentProxy = (updates: Partial<ParentProxyConfig>) => {
    setFormData({
      ...formData,
      parent_proxy: { ...formData.parent_proxy!, ...updates },
    })
    setIsDirty(true)
  }

  // PAC/WPAD functions
  const addDirectDomain = () => {
    if (!newDirectDomain.trim()) return
    const domain = newDirectDomain.trim().toLowerCase()
    if (formData.pac_direct_domains?.includes(domain)) {
      toast.error('Domain already in direct list')
      return
    }
    setFormData({
      ...formData,
      pac_direct_domains: [...(formData.pac_direct_domains || []), domain],
    })
    setNewDirectDomain('')
    setIsDirty(true)
  }

  const removeDirectDomain = (domain: string) => {
    setFormData({
      ...formData,
      pac_direct_domains: (formData.pac_direct_domains || []).filter((d) => d !== domain),
    })
    setIsDirty(true)
  }

  const addDirectNetwork = () => {
    if (!newDirectNetwork.trim()) return
    const network = newDirectNetwork.trim()
    if (formData.pac_direct_networks?.includes(network)) {
      toast.error('Network already in direct list')
      return
    }
    setFormData({
      ...formData,
      pac_direct_networks: [...(formData.pac_direct_networks || []), network],
    })
    setNewDirectNetwork('')
    setIsDirty(true)
  }

  const removeDirectNetwork = (network: string) => {
    setFormData({
      ...formData,
      pac_direct_networks: (formData.pac_direct_networks || []).filter((n) => n !== network),
    })
    setIsDirty(true)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard')
  }

  // IP-Allow functions
  const updateIPAllow = (updates: Partial<IPAllowConfig>) => {
    setFormData({
      ...formData,
      ip_allow: { ...formData.ip_allow!, ...updates },
    })
    setIsDirty(true)
  }

  const generateApiKey = async () => {
    setGeneratingApiKey(true)
    try {
      const response = await api.post('/proxy/generate-api-key')
      // API returns the key in the message field
      if (response.data.status && response.data.message) {
        updateIPAllow({ api_key: response.data.message })
        toast.success('API Key generated')
      }
    } catch {
      toast.error('Failed to generate API key')
    } finally {
      setGeneratingApiKey(false)
    }
  }

  // Validate IP address, CIDR notation, or IP range
  const isValidIPEntry = (entry: string): boolean => {
    // Single IP: 192.168.1.100
    const singleIP = /^(\d{1,3}\.){3}\d{1,3}$/
    // CIDR notation: 192.168.1.0/24
    const cidr = /^(\d{1,3}\.){3}\d{1,3}\/\d{1,2}$/
    // IP range: 192.168.1.100-192.168.1.200
    const ipRange = /^(\d{1,3}\.){3}\d{1,3}-(\d{1,3}\.){3}\d{1,3}$/
    return singleIP.test(entry) || cidr.test(entry) || ipRange.test(entry)
  }

  const addAllowedIP = () => {
    if (!newAllowedIP.trim()) return
    const ip = newAllowedIP.trim()
    // Validate IP, CIDR, or range
    if (!isValidIPEntry(ip)) {
      toast.error('Invalid format. Use IP, CIDR (e.g., 192.168.1.0/24), or range (e.g., 192.168.1.100-192.168.1.200)')
      return
    }
    if (formData.ip_allow?.allowed_ips.some((item) => item.ip === ip)) {
      toast.error('IP already in allowed list')
      return
    }
    const newEntry: AllowedIP = {
      ip,
      description: newAllowedIPDesc.trim(),
      added_at: new Date().toISOString(),
      added_by: 'manual',
    }
    updateIPAllow({
      allowed_ips: [...(formData.ip_allow?.allowed_ips || []), newEntry],
    })
    setNewAllowedIP('')
    setNewAllowedIPDesc('')
  }

  const removeAllowedIP = (ip: string) => {
    updateIPAllow({
      allowed_ips: (formData.ip_allow?.allowed_ips || []).filter((item) => item.ip !== ip),
    })
  }

  const addBlockedIP = () => {
    if (!newBlockedIP.trim()) return
    const ip = newBlockedIP.trim()
    // Validate IP, CIDR, or range
    if (!isValidIPEntry(ip)) {
      toast.error('Invalid format. Use IP, CIDR (e.g., 192.168.1.0/24), or range (e.g., 192.168.1.100-192.168.1.200)')
      return
    }
    if (formData.ip_allow?.blocked_ips.some((item) => item.ip === ip)) {
      toast.error('IP already in blocked list')
      return
    }
    const newEntry: AllowedIP = {
      ip,
      description: newBlockedIPDesc.trim(),
      added_at: new Date().toISOString(),
      added_by: 'manual',
    }
    updateIPAllow({
      blocked_ips: [...(formData.ip_allow?.blocked_ips || []), newEntry],
    })
    setNewBlockedIP('')
    setNewBlockedIPDesc('')
  }

  const removeBlockedIP = (ip: string) => {
    updateIPAllow({
      blocked_ips: (formData.ip_allow?.blocked_ips || []).filter((item) => item.ip !== ip),
    })
  }

  const formatDate = (dateString: string) => {
    if (!dateString) return '-'
    try {
      return new Date(dateString).toLocaleString('de-DE', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    } catch {
      return dateString
    }
  }

  const wpadUrl = `${window.location.origin}/wpad.dat`
  const pacUrl = `${window.location.origin}/proxy.pac`

  // Logs functions
  const fetchLogs = async () => {
    setLogsLoading(true)
    try {
      const response = await api.get('/proxy/logs', { params: { lines: 500 } })
      if (response.data.logs) {
        setLogs(response.data.logs)
      }
    } catch {
      toast.error('Failed to fetch logs')
    } finally {
      setLogsLoading(false)
    }
  }

  const startLiveStream = () => {
    if (eventSource) {
      eventSource.close()
    }

    const token = localStorage.getItem('access_token')
    const url = `/api/v1/proxy/logs/stream?token=${token}&lines=100`
    const es = new EventSource(url)

    es.onmessage = (event) => {
      const line = event.data
      if (line && !line.startsWith('{')) {
        setLogs((prev) => [...prev.slice(-999), line])
      }
    }

    es.onerror = () => {
      es.close()
      setIsLiveMode(false)
      setEventSource(null)
    }

    setEventSource(es)
    setIsLiveMode(true)
  }

  const stopLiveStream = () => {
    if (eventSource) {
      eventSource.close()
      setEventSource(null)
    }
    setIsLiveMode(false)
  }

  const parseLogLine = (line: string) => {
    // Log format: %tl %un %>a %rm %ru %Hs %<st
    // Example: 21/Jan/2026:22:50:33 +0100 user 192.168.1.100 GET https://example.com/ 200 1234
    const parts = line.split(' ')
    if (parts.length >= 7) {
      const timestamp = parts.slice(0, 2).join(' ')
      const username = parts[2] || '-'
      const clientIp = parts[3] || '-'
      const method = parts[4] || '-'
      const url = parts[5] || '-'
      const status = parts[6] || '-'
      const size = parts[7] || '-'
      return { timestamp, username, clientIp, method, url, status, size, raw: line }
    }
    return { timestamp: '-', username: '-', clientIp: '-', method: '-', url: line, status: '-', size: '-', raw: line }
  }

  const filteredLogs = logs
    .map(parseLogLine)
    .filter((log) => {
      if (!logsSearch) return true
      const searchLower = logsSearch.toLowerCase()
      return (
        log.username.toLowerCase().includes(searchLower) ||
        log.clientIp.toLowerCase().includes(searchLower) ||
        log.url.toLowerCase().includes(searchLower) ||
        log.method.toLowerCase().includes(searchLower) ||
        log.status.includes(searchLower)
      )
    })
    .reverse()

  const handleSave = async () => {
    try {
      if (config) {
        await updateConfig.mutateAsync(formData)
      } else {
        await createConfig.mutateAsync(formData as ProxyConfig)
      }
      toast.success('Proxy configuration saved')
      if (isRunning) {
        toast.info('Restart the container to apply changes', {
          duration: 5000,
        })
      }
      setIsDirty(false)
    } catch {
      toast.error('Failed to save configuration')
    }
  }

  const handleStart = () => {
    actionStream.startStream('/api/v1/proxy/start/stream', 'Starting Proxy Server')
  }

  const handleStop = () => {
    actionStream.startStream('/api/v1/proxy/stop/stream', 'Stopping Proxy Server')
  }

  const handleActionClose = () => {
    actionStream.close()
    refetchStatus()
  }

  const isRunning = status?.status === true

  if (configLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Proxy Server</h1>
          <p className="text-muted-foreground">
            Group-based internet access control with whitelist/blacklist
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={isRunning ? 'success' : 'destructive'} className="text-sm">
            {isRunning ? 'Running' : 'Stopped'}
          </Badge>
          {isRunning ? (
            <Button variant="outline" onClick={handleStop} disabled={actionStream.isRunning}>
              {actionStream.isRunning ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Square className="mr-2 h-4 w-4" />
              )}
              Stop
            </Button>
          ) : (
            <Button onClick={handleStart} disabled={actionStream.isRunning || !config}>
              {actionStream.isRunning ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Play className="mr-2 h-4 w-4" />
              )}
              Start
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general" className="gap-2">
            <Shield className="h-4 w-4" />
            General
          </TabsTrigger>
          <TabsTrigger value="lists" className="gap-2">
            <ListCheck className="h-4 w-4" />
            Whitelist / Blacklist
          </TabsTrigger>
          <TabsTrigger value="blockpage" className="gap-2">
            <Palette className="h-4 w-4" />
            Block Page
          </TabsTrigger>
          <TabsTrigger value="wpad" className="gap-2">
            <Globe className="h-4 w-4" />
            WPAD / PAC
          </TabsTrigger>
          <TabsTrigger value="logs" className="gap-2">
            <FileText className="h-4 w-4" />
            Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          {/* Server Configuration */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Server Configuration
              </CardTitle>
              <CardDescription>Configure the Squid proxy server settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Listen Address</Label>
                  <Input
                    value={formData.listen_address}
                    onChange={(e) => {
                      setFormData({ ...formData, listen_address: e.target.value })
                      setIsDirty(true)
                    }}
                    placeholder="0.0.0.0"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Listen Port</Label>
                  <Input
                    type="number"
                    value={formData.listen_port}
                    onChange={(e) => {
                      setFormData({ ...formData, listen_port: parseInt(e.target.value) })
                      setIsDirty(true)
                    }}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Authentication Mode Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Key className="h-5 w-5" />
                Authentication Mode
              </CardTitle>
              <CardDescription>Choose how users are authenticated</CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={formData.auth_mode || 'ldap'}
                onValueChange={(value) => {
                  setFormData({ ...formData, auth_mode: value as 'ldap' | 'kerberos' | 'ip_allow' })
                  setIsDirty(true)
                }}
                className="space-y-4"
              >
                <Label
                  htmlFor="auth-ldap"
                  className="flex items-start space-x-3 p-3 rounded-lg border hover:bg-muted/50 cursor-pointer [&:has([data-state=checked])]:border-primary"
                >
                  <RadioGroupItem value="ldap" id="auth-ldap" className="mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 font-medium">
                      <Users className="h-4 w-4" />
                      LDAP User Groups
                    </div>
                    <p className="text-sm text-muted-foreground mt-1 font-normal">
                      Authentication via Active Directory / LDAP groups with Basic Auth
                    </p>
                  </div>
                </Label>
                <Label
                  htmlFor="auth-kerberos"
                  className="flex items-start space-x-3 p-3 rounded-lg border hover:bg-muted/50 cursor-pointer [&:has([data-state=checked])]:border-primary"
                >
                  <RadioGroupItem value="kerberos" id="auth-kerberos" className="mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 font-medium">
                      <Key className="h-4 w-4" />
                      Kerberos SSO
                    </div>
                    <p className="text-sm text-muted-foreground mt-1 font-normal">
                      Single Sign-On for domain-joined Windows clients (SPNEGO/Negotiate)
                    </p>
                  </div>
                </Label>
                <Label
                  htmlFor="auth-ip"
                  className="flex items-start space-x-3 p-3 rounded-lg border hover:bg-muted/50 cursor-pointer [&:has([data-state=checked])]:border-primary"
                >
                  <RadioGroupItem value="ip_allow" id="auth-ip" className="mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 font-medium">
                      <Network className="h-4 w-4" />
                      IP-based Access Control
                    </div>
                    <p className="text-sm text-muted-foreground mt-1 font-normal">
                      Allow/block IPs via webhook or manually (no user authentication)
                    </p>
                  </div>
                </Label>
              </RadioGroup>
            </CardContent>
          </Card>

          {/* LDAP / Kerberos Mode: Authentication Provider & Groups */}
          {(formData.auth_mode === 'ldap' || formData.auth_mode === 'kerberos') && (
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Authentication Provider</CardTitle>
                  <CardDescription>LDAP server for user authentication</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Select value={selectedAuth} onValueChange={handleAuthChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select authentication provider" />
                    </SelectTrigger>
                    <SelectContent>
                      {authentications?.map((auth) => (
                        <SelectItem key={auth.name} value={auth.name}>
                          {auth.name} ({auth.server})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {!authentications?.length && (
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" />
                      No authentication providers configured.
                    </p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Allowed Groups</CardTitle>
                  <CardDescription>
                    LDAP groups that are allowed to access the internet
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedAuth ? (
                    <>
                      <Popover open={groupsOpen} onOpenChange={setGroupsOpen}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={groupsOpen}
                            className="w-full justify-between font-normal"
                          >
                            {formData.allowed_groups?.length
                              ? `${formData.allowed_groups.length} group(s) selected`
                              : "Select groups..."}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-[350px] p-0">
                          <Command>
                            <CommandInput placeholder="Search groups..." />
                            <CommandList>
                              <CommandEmpty>No groups found.</CommandEmpty>
                              <CommandGroup>
                                {availableGroups?.map((group) => (
                                  <CommandItem
                                    key={group}
                                    value={group}
                                    onSelect={() => handleGroupToggle(group)}
                                  >
                                    <Check
                                      className={cn(
                                        "mr-2 h-4 w-4",
                                        formData.allowed_groups?.includes(group) ? "opacity-100" : "opacity-0"
                                      )}
                                    />
                                    {extractGroupName(group)}
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>

                      {formData.allowed_groups && formData.allowed_groups.length > 0 && (
                        <div className="flex flex-wrap gap-2">
                          {formData.allowed_groups.map((group) => (
                            <Badge key={group} variant="secondary" className="gap-1">
                              {extractGroupName(group)}
                              <button
                                type="button"
                                onClick={() => removeGroup(group)}
                                className="ml-1 hover:text-destructive"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </Badge>
                          ))}
                        </div>
                      )}

                      {(!formData.allowed_groups || formData.allowed_groups.length === 0) && (
                        <p className="text-sm text-muted-foreground">
                          No groups selected. Users won't be able to access the internet.
                        </p>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      Select an authentication provider first
                    </div>
                )}
              </CardContent>
            </Card>
          </div>

          )}

          {/* IP-Allow Mode: Webhook API & IP Management */}
          {formData.auth_mode === 'ip_allow' && (
            <>
              {/* Webhook API Configuration */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Key className="h-5 w-5" />
                    Webhook API
                  </CardTitle>
                  <CardDescription>API key for webhook authentication</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>API Key</Label>
                    <div className="flex gap-2">
                      <Input
                        value={formData.ip_allow?.api_key || ''}
                        readOnly
                        className="font-mono text-sm"
                        placeholder="No API key generated yet"
                      />
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={generateApiKey}
                        disabled={generatingApiKey}
                        title="Generate new API key"
                      >
                        {generatingApiKey ? (
                          <RefreshCw className="h-4 w-4 animate-spin" />
                        ) : (
                          <RefreshCw className="h-4 w-4" />
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => copyToClipboard(formData.ip_allow?.api_key || '')}
                        disabled={!formData.ip_allow?.api_key}
                        title="Copy API key"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <Alert>
                    <Info className="h-4 w-4" />
                    <AlertDescription>
                      <p className="font-medium mb-2">Webhook Endpoints:</p>
                      <div className="space-y-1 font-mono text-xs">
                        <p>POST /api/v1/proxy/webhook/allow - Allow IP</p>
                        <p>POST /api/v1/proxy/webhook/block - Block IP</p>
                        <p>POST /api/v1/proxy/webhook/remove - IP entfernen</p>
                        <p>GET /api/v1/proxy/webhook/status?ip=... - Status abfragen</p>
                      </div>
                      <p className="mt-2 text-muted-foreground">
                        Header: <code className="bg-muted px-1 rounded">X-API-Key: &lt;api_key&gt;</code>
                      </p>
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>

              {/* Allowed IPs */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-green-500" />
                    Allowed IPs ({formData.ip_allow?.allowed_ips.length || 0})
                  </CardTitle>
                  <CardDescription>
                    These IP addresses have internet access
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Supports single IPs, CIDR notation (192.168.1.0/24), and ranges (192.168.1.100-192.168.1.200)
                  </p>
                  <div className="flex gap-2">
                    <Input
                      placeholder="IP, CIDR, or range"
                      value={newAllowedIP}
                      onChange={(e) => setNewAllowedIP(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addAllowedIP()}
                      className="max-w-[200px]"
                    />
                    <Input
                      placeholder="Description (optional)"
                      value={newAllowedIPDesc}
                      onChange={(e) => setNewAllowedIPDesc(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addAllowedIP()}
                    />
                    <Button onClick={addAllowedIP} size="icon">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  {formData.ip_allow?.allowed_ips && formData.ip_allow.allowed_ips.length > 0 ? (
                    <div className="border rounded-lg">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>IP Address</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead>Added</TableHead>
                            <TableHead>Source</TableHead>
                            <TableHead className="w-[50px]"></TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {formData.ip_allow.allowed_ips.map((item) => (
                            <TableRow key={item.ip}>
                              <TableCell className="font-mono">{item.ip}</TableCell>
                              <TableCell>{item.description || '-'}</TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                {formatDate(item.added_at)}
                              </TableCell>
                              <TableCell>
                                <Badge variant={item.added_by === 'webhook' ? 'secondary' : 'outline'}>
                                  {item.added_by}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => removeAllowedIP(item.ip)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No IPs allowed
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Blocked IPs */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Ban className="h-5 w-5 text-red-500" />
                    Blocked IPs ({formData.ip_allow?.blocked_ips.length || 0})
                  </CardTitle>
                  <CardDescription>
                    These IP addresses are explicitly blocked
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Supports single IPs, CIDR notation (192.168.1.0/24), and ranges (192.168.1.100-192.168.1.200)
                  </p>
                  <div className="flex gap-2">
                    <Input
                      placeholder="IP, CIDR, or range"
                      value={newBlockedIP}
                      onChange={(e) => setNewBlockedIP(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addBlockedIP()}
                      className="max-w-[200px]"
                    />
                    <Input
                      placeholder="Description (optional)"
                      value={newBlockedIPDesc}
                      onChange={(e) => setNewBlockedIPDesc(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && addBlockedIP()}
                    />
                    <Button onClick={addBlockedIP} size="icon" variant="destructive">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  {formData.ip_allow?.blocked_ips && formData.ip_allow.blocked_ips.length > 0 ? (
                    <div className="border rounded-lg">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>IP Address</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead>Added</TableHead>
                            <TableHead>Source</TableHead>
                            <TableHead className="w-[50px]"></TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {formData.ip_allow.blocked_ips.map((item) => (
                            <TableRow key={item.ip}>
                              <TableCell className="font-mono">{item.ip}</TableCell>
                              <TableCell>{item.description || '-'}</TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                {formatDate(item.added_at)}
                              </TableCell>
                              <TableCell>
                                <Badge variant={item.added_by === 'webhook' ? 'secondary' : 'outline'}>
                                  {item.added_by}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => removeBlockedIP(item.ip)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground text-center py-8">
                      No IPs blocked
                    </p>
                  )}
                </CardContent>
              </Card>
            </>
          )}

          {/* Kerberos SSO Configuration - only shown in kerberos mode */}
          {formData.auth_mode === 'kerberos' && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5" />
                  Kerberos Configuration
                </CardTitle>
                <CardDescription>
                  Configure Kerberos SSO settings for domain authentication
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    Kerberos SSO requires: DNS resolution for proxy hostname, time sync (max 5 min offset to DC),
                    and the proxy container will join the domain at startup. Basic LDAP auth is used as fallback.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Realm (Domain)</Label>
                    <Input
                      value={formData.kerberos?.realm || ''}
                      onChange={(e) => updateKerberos({ realm: e.target.value.toUpperCase() })}
                      placeholder="AD.EXAMPLE.COM"
                      className="uppercase"
                    />
                    <p className="text-xs text-muted-foreground">
                      Active Directory domain in uppercase
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>KDC (Domain Controller IP)</Label>
                    <Input
                      value={formData.kerberos?.kdc || ''}
                      onChange={(e) => updateKerberos({ kdc: e.target.value })}
                      placeholder="10.0.0.1"
                    />
                    <p className="text-xs text-muted-foreground">
                      IP address of the Domain Controller (used for DNS and Kerberos)
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Proxy Hostname (FQDN)</Label>
                    <Input
                      value={formData.kerberos?.proxy_hostname || ''}
                      onChange={(e) => updateKerberos({ proxy_hostname: e.target.value })}
                      placeholder="proxy.ad.example.com"
                    />
                    <p className="text-xs text-muted-foreground">
                      FQDN for the SPN (HTTP/proxy.fqdn)
                    </p>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="text-sm font-medium mb-3">Domain Join Credentials</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Domain Admin Username</Label>
                      <Input
                        value={formData.kerberos?.domain_admin || ''}
                        onChange={(e) => updateKerberos({ domain_admin: e.target.value })}
                        placeholder="Administrator"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Domain Admin Password</Label>
                      <Input
                        type="password"
                        value={formData.kerberos?.domain_admin_password || ''}
                        onChange={(e) => updateKerberos({ domain_admin_password: e.target.value })}
                        placeholder="••••••••"
                      />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Credentials are used to join the domain and create the HTTP keytab at container startup
                  </p>
                </div>

                <div className="border-t pt-4">
                  <h4 className="text-sm font-medium mb-3">Ticket Lifetime Settings</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Ticket Lifetime</Label>
                      <Input
                        value={formData.kerberos?.ticket_lifetime || '24h'}
                        onChange={(e) => updateKerberos({ ticket_lifetime: e.target.value })}
                        placeholder="24h"
                      />
                      <p className="text-xs text-muted-foreground">
                        How long a ticket is valid (e.g., 8h, 24h, 1d)
                      </p>
                    </div>
                    <div className="space-y-2">
                      <Label>Renew Lifetime</Label>
                      <Input
                        value={formData.kerberos?.renew_lifetime || '7d'}
                        onChange={(e) => updateKerberos({ renew_lifetime: e.target.value })}
                        placeholder="7d"
                      />
                      <p className="text-xs text-muted-foreground">
                        How long a ticket can be renewed (e.g., 7d, 30d)
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Parent Proxy Configuration */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Server className="h-5 w-5" />
                    Parent Proxy (Upstream)
                  </CardTitle>
                  <CardDescription>
                    Forward all traffic through an upstream proxy (e.g., Sophos XGS for web filtering)
                  </CardDescription>
                </div>
                <Switch
                  checked={formData.parent_proxy?.enabled}
                  onCheckedChange={(checked) => updateParentProxy({ enabled: checked })}
                />
              </div>
            </CardHeader>
            {formData.parent_proxy?.enabled && (
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Parent Proxy Host</Label>
                    <Input
                      value={formData.parent_proxy?.host || ''}
                      onChange={(e) => updateParentProxy({ host: e.target.value })}
                      placeholder="192.168.1.1 or proxy.example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Parent Proxy Port</Label>
                    <Input
                      type="number"
                      value={formData.parent_proxy?.port || 8080}
                      onChange={(e) => updateParentProxy({ port: parseInt(e.target.value) })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Authentication Forwarding</Label>
                  <Select
                    value={formData.parent_proxy?.forward_auth || 'none'}
                    onValueChange={(value) => updateParentProxy({ forward_auth: value as 'none' | 'basic' | 'header' })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">No forwarding (parent sees only proxy IP)</SelectItem>
                      <SelectItem value="header">HTTP Header (X-Authenticated-User)</SelectItem>
                      <SelectItem value="basic">Basic Auth (forward credentials to parent)</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Choose how to pass user identity to the parent proxy for logging/filtering
                  </p>
                </div>

                {formData.parent_proxy?.forward_auth === 'header' && (
                  <div className="space-y-2">
                    <Label>Header Name</Label>
                    <Input
                      value={formData.parent_proxy?.auth_header_name || 'X-Authenticated-User'}
                      onChange={(e) => updateParentProxy({ auth_header_name: e.target.value })}
                      placeholder="X-Authenticated-User"
                    />
                    <p className="text-xs text-muted-foreground">
                      The authenticated username will be sent in this HTTP header
                    </p>
                  </div>
                )}

                {formData.parent_proxy?.forward_auth === 'basic' && (
                  <div className="border-t pt-4">
                    <h4 className="text-sm font-medium mb-3">Parent Proxy Credentials (optional)</h4>
                    <p className="text-xs text-muted-foreground mb-3">
                      If the parent proxy requires authentication, enter fixed credentials here.
                      Leave empty to forward client credentials.
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Username</Label>
                        <Input
                          value={formData.parent_proxy?.username || ''}
                          onChange={(e) => updateParentProxy({ username: e.target.value })}
                          placeholder="Leave empty to forward client auth"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Password</Label>
                        <Input
                          type="password"
                          value={formData.parent_proxy?.password || ''}
                          onChange={(e) => updateParentProxy({ password: e.target.value })}
                          placeholder="••••••••"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        </TabsContent>

        <TabsContent value="lists" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Whitelist */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ListCheck className="h-5 w-5 text-green-500" />
                  Whitelist
                </CardTitle>
                <CardDescription>
                  Domains that are always allowed (no authentication required)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="example.com, .example.com, or 192.168.1.0/24"
                    value={newWhitelistDomain}
                    onChange={(e) => setNewWhitelistDomain(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && addWhitelistDomain()}
                  />
                  <Button onClick={addWhitelistDomain} size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Domains (.domain.com for subdomains), IPs, CIDR (10.0.0.0/8), or ranges (192.168.1.1-192.168.1.100)
                </p>
                {formData.whitelist_domains && formData.whitelist_domains.length > 0 ? (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {formData.whitelist_domains.map((domain) => (
                      <div
                        key={domain}
                        className="flex items-center justify-between p-2 bg-muted/50 rounded"
                      >
                        <span className="font-mono text-sm">{domain}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => removeWhitelistDomain(domain)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No domains whitelisted
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Blacklist */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Ban className="h-5 w-5 text-red-500" />
                  Blacklist
                </CardTitle>
                <CardDescription>
                  Domains that are always blocked (even for authenticated users)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="example.com, .example.com, or 192.168.1.0/24"
                    value={newBlacklistDomain}
                    onChange={(e) => setNewBlacklistDomain(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && addBlacklistDomain()}
                  />
                  <Button onClick={addBlacklistDomain} size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Domains (.domain.com for subdomains), IPs, CIDR (10.0.0.0/8), or ranges (192.168.1.1-192.168.1.100)
                </p>
                {formData.blacklist_domains && formData.blacklist_domains.length > 0 ? (
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {formData.blacklist_domains.map((domain) => (
                      <div
                        key={domain}
                        className="flex items-center justify-between p-2 bg-muted/50 rounded"
                      >
                        <span className="font-mono text-sm">{domain}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => removeBlacklistDomain(domain)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No domains blacklisted
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Bypass Groups */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Blacklist Bypass Groups</CardTitle>
                <CardDescription>
                  Groups that can access blacklisted domains (e.g., administrators)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedAuth ? (
                  <>
                    <Popover open={bypassGroupsOpen} onOpenChange={setBypassGroupsOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          role="combobox"
                          aria-expanded={bypassGroupsOpen}
                          className="w-full justify-between font-normal max-w-md"
                        >
                          {formData.bypass_groups?.length
                            ? `${formData.bypass_groups.length} group(s) can bypass blacklist`
                            : "Select bypass groups..."}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-[350px] p-0">
                        <Command>
                          <CommandInput placeholder="Search groups..." />
                          <CommandList>
                            <CommandEmpty>No groups found.</CommandEmpty>
                            <CommandGroup>
                              {availableGroups?.map((group) => (
                                <CommandItem
                                  key={group}
                                  value={group}
                                  onSelect={() => handleBypassGroupToggle(group)}
                                >
                                  <Check
                                    className={cn(
                                      "mr-2 h-4 w-4",
                                      formData.bypass_groups?.includes(group) ? "opacity-100" : "opacity-0"
                                    )}
                                  />
                                  {extractGroupName(group)}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>

                    {formData.bypass_groups && formData.bypass_groups.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {formData.bypass_groups.map((group) => (
                          <Badge key={group} variant="outline" className="gap-1 border-orange-500/50">
                            {extractGroupName(group)}
                            <button
                              type="button"
                              onClick={() => removeBypassGroup(group)}
                              className="ml-1 hover:text-destructive"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-4 text-muted-foreground">
                    Select an authentication provider first
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="blockpage" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Content */}
            <Card>
              <CardHeader>
                <CardTitle>Content</CardTitle>
                <CardDescription>Text shown on the block page</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Title</Label>
                  <Input
                    value={formData.block_page?.title}
                    onChange={(e) => updateBlockPage({ title: e.target.value })}
                    placeholder="Access Denied"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Message</Label>
                  <Textarea
                    value={formData.block_page?.message}
                    onChange={(e) => updateBlockPage({ message: e.target.value })}
                    placeholder="You are not authorized to access the internet."
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Image className="h-4 w-4" />
                    Logo URL (optional)
                  </Label>
                  <Input
                    value={formData.block_page?.logo_url || ''}
                    onChange={(e) => updateBlockPage({ logo_url: e.target.value || undefined })}
                    placeholder="https://example.com/logo.png"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Styling */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Colors
                </CardTitle>
                <CardDescription>Customize the block page appearance</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Background</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={formData.block_page?.background_color}
                        onChange={(e) => updateBlockPage({ background_color: e.target.value })}
                        className="w-12 h-10 p-1 cursor-pointer"
                      />
                      <Input
                        value={formData.block_page?.background_color}
                        onChange={(e) => updateBlockPage({ background_color: e.target.value })}
                        className="font-mono"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Card Background</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={formData.block_page?.card_background_color}
                        onChange={(e) => updateBlockPage({ card_background_color: e.target.value })}
                        className="w-12 h-10 p-1 cursor-pointer"
                      />
                      <Input
                        value={formData.block_page?.card_background_color}
                        onChange={(e) => updateBlockPage({ card_background_color: e.target.value })}
                        className="font-mono"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Title Color</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={formData.block_page?.title_color}
                        onChange={(e) => updateBlockPage({ title_color: e.target.value })}
                        className="w-12 h-10 p-1 cursor-pointer"
                      />
                      <Input
                        value={formData.block_page?.title_color}
                        onChange={(e) => updateBlockPage({ title_color: e.target.value })}
                        className="font-mono"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Text Color</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={formData.block_page?.text_color}
                        onChange={(e) => updateBlockPage({ text_color: e.target.value })}
                        className="w-12 h-10 p-1 cursor-pointer"
                      />
                      <Input
                        value={formData.block_page?.text_color}
                        onChange={(e) => updateBlockPage({ text_color: e.target.value })}
                        className="font-mono"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Accent Color (Icon)</Label>
                    <div className="flex gap-2">
                      <Input
                        type="color"
                        value={formData.block_page?.accent_color}
                        onChange={(e) => updateBlockPage({ accent_color: e.target.value })}
                        className="w-12 h-10 p-1 cursor-pointer"
                      />
                      <Input
                        value={formData.block_page?.accent_color}
                        onChange={(e) => updateBlockPage({ accent_color: e.target.value })}
                        className="font-mono"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Display Options */}
            <Card>
              <CardHeader>
                <CardTitle>Display Options</CardTitle>
                <CardDescription>Choose what information to show</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-url">Show blocked URL</Label>
                  <Switch
                    id="show-url"
                    checked={formData.block_page?.show_url}
                    onCheckedChange={(checked) => updateBlockPage({ show_url: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-ip">Show IP address</Label>
                  <Switch
                    id="show-ip"
                    checked={formData.block_page?.show_ip}
                    onCheckedChange={(checked) => updateBlockPage({ show_ip: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="show-time">Show timestamp</Label>
                  <Switch
                    id="show-time"
                    checked={formData.block_page?.show_time}
                    onCheckedChange={(checked) => updateBlockPage({ show_time: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="animation-enabled">Enable pulse animation</Label>
                  <Switch
                    id="animation-enabled"
                    checked={formData.block_page?.animation_enabled}
                    onCheckedChange={(checked) => updateBlockPage({ animation_enabled: checked })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Preview */}
            <Card>
              <CardHeader>
                <CardTitle>Preview</CardTitle>
                <CardDescription>How the block page will look</CardDescription>
              </CardHeader>
              <CardContent>
                <style>
                  {`
                    @keyframes preview-pulse {
                      0%, 100% { transform: scale(1); opacity: 1; }
                      50% { transform: scale(1.15); opacity: 0.5; }
                    }
                  `}
                </style>
                <div
                  className="rounded-lg p-6 min-h-[280px] flex items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, ${formData.block_page?.background_color || '#f5f7fa'} 0%, ${formData.block_page?.background_color || '#f5f7fa'}dd 100%)`
                  }}
                >
                  <div
                    className="text-center p-6 rounded-2xl max-w-xs w-full shadow-lg"
                    style={{
                      backgroundColor: formData.block_page?.card_background_color,
                      boxShadow: '0 4px 24px rgba(0,0,0,0.08), 0 1px 2px rgba(0,0,0,0.04)'
                    }}
                  >
                    {formData.block_page?.logo_url && (
                      <img
                        src={formData.block_page.logo_url}
                        alt="Logo"
                        className="max-w-[120px] max-h-[50px] mx-auto mb-4 object-contain"
                        onError={(e) => (e.currentTarget.style.display = 'none')}
                      />
                    )}
                    <div className="relative w-16 h-16 mx-auto mb-4">
                      {formData.block_page?.animation_enabled && (
                        <div
                          className="absolute inset-0 rounded-full"
                          style={{
                            backgroundColor: `${formData.block_page?.accent_color}30`,
                            animation: 'preview-pulse 2s ease-in-out infinite'
                          }}
                        />
                      )}
                      <div
                        className="relative w-16 h-16 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: `${formData.block_page?.accent_color}20` }}
                      >
                        <Shield
                          className="w-8 h-8"
                          style={{ color: formData.block_page?.accent_color }}
                        />
                      </div>
                    </div>
                    <h3
                      className="text-xl font-semibold mb-2"
                      style={{ color: formData.block_page?.title_color }}
                    >
                      {formData.block_page?.title || 'Zugriff nicht erlaubt'}
                    </h3>
                    <p
                      className="text-sm mb-4 leading-relaxed"
                      style={{ color: formData.block_page?.text_color }}
                    >
                      {formData.block_page?.message || 'Ihr Gerät ist nicht für den Internetzugang freigeschaltet.'}
                    </p>
                    {formData.block_page?.show_url && (
                      <div
                        className="p-3 rounded-lg mb-4"
                        style={{ backgroundColor: `${formData.block_page?.background_color}` }}
                      >
                        <p className="text-xs font-medium mb-1" style={{ color: formData.block_page?.text_color, opacity: 0.6 }}>
                          URL
                        </p>
                        <p
                          className="text-xs font-mono break-all"
                          style={{ color: formData.block_page?.title_color }}
                        >
                          https://example.com/page
                        </p>
                      </div>
                    )}
                    <div
                      className="pt-3 mt-3 flex justify-center gap-4 text-xs"
                      style={{ borderTop: `1px solid ${formData.block_page?.text_color}20` }}
                    >
                      {formData.block_page?.show_ip && (
                        <span style={{ color: formData.block_page?.text_color, opacity: 0.5 }}>
                          IP: 192.168.1.100
                        </span>
                      )}
                      {formData.block_page?.show_time && (
                        <span style={{ color: formData.block_page?.text_color, opacity: 0.5 }}>
                          {new Date().toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="wpad" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* PAC URLs */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Auto-Configuration URLs
                </CardTitle>
                <CardDescription>
                  URLs for automatic proxy configuration in browsers and via DHCP/DNS
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>WPAD URL (for DHCP Option 252 / DNS wpad.domain)</Label>
                  <div className="flex gap-2">
                    <Input value={wpadUrl} readOnly className="font-mono text-sm" />
                    <Button variant="outline" size="icon" onClick={() => copyToClipboard(wpadUrl)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" asChild>
                      <a href={wpadUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>PAC URL (for manual browser configuration)</Label>
                  <div className="flex gap-2">
                    <Input value={pacUrl} readOnly className="font-mono text-sm" />
                    <Button variant="outline" size="icon" onClick={() => copyToClipboard(pacUrl)}>
                      <Copy className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="icon" asChild>
                      <a href={pacUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Proxy Hostname (used in PAC file)</Label>
                  <Input
                    value={formData.proxy_hostname || ''}
                    onChange={(e) => {
                      setFormData({ ...formData, proxy_hostname: e.target.value })
                      setIsDirty(true)
                    }}
                    placeholder="proxy.domain.local (leave empty to auto-detect)"
                  />
                  <p className="text-xs text-muted-foreground">
                    Hostname or IP address clients use to reach the proxy. Leave empty to use the request host.
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Setup Instructions */}
            <Card>
              <CardHeader>
                <CardTitle>Deployment Options</CardTitle>
                <CardDescription>How to deploy the proxy to clients</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4 text-sm">
                <div>
                  <h4 className="font-semibold mb-1">1. DHCP (Recommended)</h4>
                  <p className="text-muted-foreground">
                    Set DHCP Option 252 to: <code className="bg-muted px-1 rounded">{wpadUrl}</code>
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-1">2. DNS (WPAD)</h4>
                  <p className="text-muted-foreground">
                    Create DNS record: <code className="bg-muted px-1 rounded">wpad.yourdomain.local</code> pointing to this server
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-1">3. Group Policy (Windows)</h4>
                  <p className="text-muted-foreground">
                    User Configuration → Preferences → Windows Settings → Registry<br />
                    Set <code className="bg-muted px-1 rounded">AutoConfigURL</code> to the PAC URL
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-1">4. Manual</h4>
                  <p className="text-muted-foreground">
                    Browser Settings → Network → Proxy → Use PAC file URL
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Direct Domains */}
            <Card>
              <CardHeader>
                <CardTitle>Direct Domains</CardTitle>
                <CardDescription>
                  Domains that bypass the proxy (accessed directly)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="example.local or .internal.lan"
                    value={newDirectDomain}
                    onChange={(e) => setNewDirectDomain(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && addDirectDomain()}
                  />
                  <Button onClick={addDirectDomain} size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Use .domain.local to include all subdomains
                </p>
                {formData.pac_direct_domains && formData.pac_direct_domains.length > 0 ? (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {formData.pac_direct_domains.map((domain) => (
                      <div
                        key={domain}
                        className="flex items-center justify-between p-2 bg-muted/50 rounded"
                      >
                        <span className="font-mono text-sm">{domain}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => removeDirectDomain(domain)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No direct domains configured
                  </p>
                )}
              </CardContent>
            </Card>

            {/* Direct Networks */}
            <Card>
              <CardHeader>
                <CardTitle>Direct Networks</CardTitle>
                <CardDescription>
                  IP networks that bypass the proxy (CIDR notation)
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    placeholder="10.0.0.0/8 or 192.168.1.0/24"
                    value={newDirectNetwork}
                    onChange={(e) => setNewDirectNetwork(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && addDirectNetwork()}
                  />
                  <Button onClick={addDirectNetwork} size="icon">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Internal networks that should be accessed directly
                </p>
                {formData.pac_direct_networks && formData.pac_direct_networks.length > 0 ? (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {formData.pac_direct_networks.map((network) => (
                      <div
                        key={network}
                        className="flex items-center justify-between p-2 bg-muted/50 rounded"
                      >
                        <span className="font-mono text-sm">{network}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6"
                          onClick={() => removeDirectNetwork(network)}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No direct networks configured
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="logs" className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Access Logs
                  </CardTitle>
                  <CardDescription>
                    View proxy access logs with user, URL, and status information
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  {isLiveMode ? (
                    <Button variant="outline" onClick={stopLiveStream}>
                      <Pause className="mr-2 h-4 w-4" />
                      Stop Live
                    </Button>
                  ) : (
                    <Button variant="outline" onClick={startLiveStream} disabled={!isRunning}>
                      <Radio className="mr-2 h-4 w-4" />
                      Live View
                    </Button>
                  )}
                  <Button variant="outline" onClick={fetchLogs} disabled={logsLoading || !isRunning}>
                    {logsLoading ? (
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <RefreshCw className="mr-2 h-4 w-4" />
                    )}
                    Refresh
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isRunning ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Proxy server is not running</p>
                  <p className="text-sm">Start the proxy to view logs</p>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search by user, IP, URL, or status..."
                        value={logsSearch}
                        onChange={(e) => setLogsSearch(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    {isLiveMode && (
                      <Badge variant="default" className="animate-pulse">
                        <Radio className="mr-1 h-3 w-3" />
                        Live
                      </Badge>
                    )}
                  </div>

                  {logs.length === 0 ? (
                    <div className="text-center py-12 text-muted-foreground">
                      <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      <p>No logs available</p>
                      <p className="text-sm">Click "Refresh" or "Live View" to load logs</p>
                    </div>
                  ) : (
                    <div className="border rounded-lg overflow-hidden">
                      <div className="max-h-[500px] overflow-auto">
                        <Table>
                          <TableHeader className="sticky top-0 bg-background">
                            <TableRow>
                              <TableHead className="w-[180px]">Timestamp</TableHead>
                              <TableHead className="w-[120px]">User</TableHead>
                              <TableHead className="w-[130px]">Client IP</TableHead>
                              <TableHead className="w-[60px]">Method</TableHead>
                              <TableHead>URL</TableHead>
                              <TableHead className="w-[70px]">Status</TableHead>
                              <TableHead className="w-[80px]">Size</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {filteredLogs.slice(0, 200).map((log, index) => (
                              <TableRow key={index} className="font-mono text-xs">
                                <TableCell className="text-muted-foreground">
                                  {log.timestamp}
                                </TableCell>
                                <TableCell>
                                  {log.username !== '-' ? (
                                    <Badge variant="secondary" className="font-mono">
                                      {log.username}
                                    </Badge>
                                  ) : (
                                    <span className="text-muted-foreground">-</span>
                                  )}
                                </TableCell>
                                <TableCell>{log.clientIp}</TableCell>
                                <TableCell>
                                  <Badge variant="outline">{log.method}</Badge>
                                </TableCell>
                                <TableCell className="max-w-[300px] truncate" title={log.url}>
                                  {log.url}
                                </TableCell>
                                <TableCell>
                                  <Badge
                                    variant={
                                      log.status.startsWith('2') ? 'default' :
                                      log.status.startsWith('3') ? 'secondary' :
                                      log.status.startsWith('4') ? 'outline' :
                                      'destructive'
                                    }
                                  >
                                    {log.status}
                                  </Badge>
                                </TableCell>
                                <TableCell className="text-muted-foreground">
                                  {log.size !== '-' ? `${parseInt(log.size).toLocaleString()} B` : '-'}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                      {filteredLogs.length > 200 && (
                        <div className="p-2 text-center text-sm text-muted-foreground border-t">
                          Showing 200 of {filteredLogs.length} entries
                        </div>
                      )}
                    </div>
                  )}

                  {logs.length > 0 && (
                    <p className="text-xs text-muted-foreground text-right">
                      {filteredLogs.length} {filteredLogs.length === 1 ? 'entry' : 'entries'}
                      {logsSearch && ` matching "${logsSearch}"`}
                    </p>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={!isDirty || createConfig.isPending || updateConfig.isPending}
          size="lg"
        >
          {(createConfig.isPending || updateConfig.isPending) ? (
            <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Save className="mr-2 h-4 w-4" />
          )}
          Save Configuration
        </Button>
      </div>

      {/* Action Log Dialog */}
      <ActionLogDialog
        open={actionStream.isOpen}
        onClose={handleActionClose}
        title={actionStream.title}
        logs={actionStream.logs}
        isRunning={actionStream.isRunning}
        success={actionStream.success}
      />
    </div>
  )
}
