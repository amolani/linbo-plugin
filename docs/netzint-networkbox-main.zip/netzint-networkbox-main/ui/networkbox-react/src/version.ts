export const APP_VERSION = {
  name: 'Netzint Network-Box',
  version: 'dev',
  commit: 'local',
  buildTime: new Date().toISOString()
} as const;
