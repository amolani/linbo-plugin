#!/usr/bin/env sh
set -eu

SSL_DIR="/data/ui/ssl"

# CN konsistent setzen: CN hat Vorrang, sonst fallback auf CERT_CN, sonst Default
CN="${CN:-${CERT_CN:-netzint-networkbox}}"

# Standard-Regex für zu ignorierende Interfaces (korrekt geschlossen)
IGNORE_IFACES_REGEX="${IGNORE_IFACES_REGEX:-^(lo|docker.*|veth.*|br-.*|tun.*|tap.*|cni.*|flannel.*|kube.*)$}"

mkdir -p "$SSL_DIR"

collect_ips() {
  # IPv4, global scope, Interfaces nach Regex filtern, nur IP (ohne /CIDR)
  # Falls 'ip' fehlt, kannst du als Fallback 'hostname -I' nutzen.
  ip -o -4 addr show scope global \
    | awk -v re="$IGNORE_IFACES_REGEX" '$2 !~ re {print $4}' \
    | cut -d'/' -f1
}

# IP-Liste (einfacher String mit Newlines)
IP_LIST="$(collect_ips | sort -u || true)"

if [ -z "$IP_LIST" ]; then
  echo "WARN: Keine globalen IPs gefunden. Erzeuge Zertifikat nur mit CN=${CN}."
fi

# SAN zusammenbauen
SAN="DNS:${CN}"
for ip in $IP_LIST; do
  [ -n "$ip" ] && SAN="${SAN},IP:${ip}"
done

NEED_GEN=0
[ ! -f "$SSL_DIR/privkey.pem" ] || [ ! -f "$SSL_DIR/fullchain.pem" ] && NEED_GEN=1

if [ -f "$SSL_DIR/.san_spec" ]; then
  OLD_SAN="$(cat "$SSL_DIR/.san_spec" 2>/dev/null || true)"
  [ "$OLD_SAN" != "$SAN" ] && NEED_GEN=1
else
  NEED_GEN=1
fi

if [ "$NEED_GEN" -eq 1 ]; then
  echo "Generating self-signed certificate for CN=${CN}"
  echo "SANs: ${SAN}"

  OPENSSL_CNF="${SSL_DIR}/openssl.cnf"
  cat > "$OPENSSL_CNF" <<EOF
[req]
prompt = no
default_md = sha256
distinguished_name = dn
x509_extensions = x509_ext

[dn]
CN = ${CN}

[x509_ext]
subjectAltName = ${SAN}
basicConstraints = CA:FALSE
keyUsage = digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
EOF

  openssl req -x509 -newkey rsa:4096 -nodes -days 825 \
    -keyout "$SSL_DIR/privkey.pem" \
    -out "$SSL_DIR/fullchain.pem" \
    -config "$OPENSSL_CNF"

  chmod 600 "$SSL_DIR/privkey.pem"
  printf '%s' "$SAN" > "$SSL_DIR/.san_spec"
else
  echo "Existing certificate matches current SANs. Reuse."
fi

if [ "${SKIP_DHPARAM:-0}" != "1" ] && [ ! -f "$SSL_DIR/dhparam.pem" ]; then
  echo "Generating dhparam (once)..."
  openssl dhparam -out "$SSL_DIR/dhparam.pem" 2048
fi

exec nginx -g 'daemon off;'
