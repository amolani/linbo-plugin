export const APP_VERSION = {
    name: "Netzint Network-Box",
    version: "0.0.0",
    commit: "unknown",
    buildTime: "unknown"
} as const;