import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../services/authservice';
import { Router } from '@angular/router';
import { APP_VERSION } from '../version';

@Component({
  selector: 'app-login',
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  errorMessage = '';

  footer_text = `${APP_VERSION.name} | v${APP_VERSION.version}`;

  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  ngOnInit() {
    if (this.authService.isTokenValid()) {
      this.router.navigate(['/admin']);
    }
  }

  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) return;
    this.loading = true;
    const { username, password } = this.loginForm.value;
    
    this.authService.login(username, password).subscribe({
      next: (response) => {
        if (response) {
          this.loading = false;
          this.router.navigate(['/admin']);
        } else {
          this.errorMessage = "Benutzername oder Passwort falsch!";
          this.loading = false;
        }
      },
      error: (error) => {
        console.log(error);
        this.errorMessage = "Etwas ist schief gelaufen!";
        this.loading = false;
      }
    });
  }
}
