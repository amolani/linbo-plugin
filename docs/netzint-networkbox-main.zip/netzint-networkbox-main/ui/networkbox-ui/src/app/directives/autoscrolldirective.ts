import { AfterViewInit, Directive, ElementRef, OnDestroy } from '@angular/core';

@Directive({
  selector: '[autoScroll]'
})
export class AutoScrollDirective implements AfterViewInit, OnDestroy {
  private mo?: MutationObserver;

  constructor(private el: ElementRef<HTMLElement>) {}

  ngAfterViewInit() {
    const node = this.el.nativeElement;
    this.mo = new MutationObserver(() => {
      const nearBottom = (node.scrollHeight - node.scrollTop - node.clientHeight) < 80;
      if (nearBottom) node.scrollTop = node.scrollHeight;
    });
    this.mo.observe(node, { childList: true, subtree: true, characterData: true });
  }

  ngOnDestroy() { this.mo?.disconnect(); }
}