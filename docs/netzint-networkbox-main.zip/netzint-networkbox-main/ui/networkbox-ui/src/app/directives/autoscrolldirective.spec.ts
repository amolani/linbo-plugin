import { Autoscrolldirective } from './autoscrolldirective';

describe('Autoscrolldirective', () => {
  it('should create an instance', () => {
    const directive = new Autoscrolldirective();
    expect(directive).toBeTruthy();
  });
});
