import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin.component/admin.component';
import { NetworksComponent } from './admin/networks.component/networks.component';
import { MdnsComponent } from './admin/mdns.component/mdns.component';
import { HomeComponent } from './admin/home.component/home.component';
import { AuthGuard } from './guards/auth.guard-guard';
import { RadiusComponent } from './admin/radius.component/radius.component';
import { AuthenticationComponent } from './admin/authentication.component/authentication.component';
import { CertificateComponent } from './admin/certificate.component/certificate.component';
import { ContainersComponent } from './admin/containers.component/containers.component';
import { WOLComponent } from './admin/wol.component/wol.component';
import { KMSComponent } from './admin/kms.component/kms.component';
import { ReverseproxyComponent } from './admin/reverseproxy.component/reverseproxy.component';
import { ProxyComponent } from './admin/proxy.component/proxy.component';

export const routes: Routes = [
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'admin',
        component: AdminComponent,
        canActivate: [AuthGuard],
        children: [
            {
                path: 'home',
                component: HomeComponent
            },
            {
                path: 'networks',
                component: NetworksComponent
            },
            {
                path: 'mdns',
                component: MdnsComponent
            },
            {
                path: 'radius',
                component: RadiusComponent
            },
            {
                path: 'authentication',
                component: AuthenticationComponent
            },
            {
                path: 'certificates',
                component: CertificateComponent
            },
            {
                path: 'containers',
                component: ContainersComponent
            },
            {
                path: 'wol',
                component: WOLComponent
            },
            {
                path: 'kms',
                component: KMSComponent
            },
            {
                path: 'reverseproxy',
                component: ReverseproxyComponent
            },
            {
                path: 'proxy',
                component: ProxyComponent
            },
            {
                path: '',
                redirectTo: 'home',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
    },
    {
        path: '**',
        redirectTo: 'login'
    }
];
