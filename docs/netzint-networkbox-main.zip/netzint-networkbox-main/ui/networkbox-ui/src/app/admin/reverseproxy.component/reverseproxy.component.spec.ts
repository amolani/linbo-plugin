import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReverseproxyComponent } from './reverseproxy.component';

describe('ReverseproxyComponent', () => {
  let component: ReverseproxyComponent;
  let fixture: ComponentFixture<ReverseproxyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReverseproxyComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReverseproxyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
