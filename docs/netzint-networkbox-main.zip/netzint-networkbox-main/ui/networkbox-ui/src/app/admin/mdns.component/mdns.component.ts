import { Component } from '@angular/core';
import { MDNSService } from '../../services/mdnsservice';
import { MDNS, MDNSCluster } from '../../interfaces/mdns.model';
import { maskToCidr, NetworksService } from '../../services/networksservice';
import { Network } from '../../interfaces/network.model';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ModalService } from '../../services/modal.service';

@Component({
  selector: 'app-mdns.component',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './mdns.component.html',
  styleUrl: './mdns.component.scss'
})
export class MdnsComponent {

  mdnss: MDNS[] = [];
  networks: Network[] = [];

  adding = false;
  addForm: FormGroup;
  addError: string = "";

  editName: string | null = null;
  editForm!: FormGroup;
  editError: string = "";

  constructor(private mdnsService: MDNSService, private networkService: NetworksService, private fb: FormBuilder, private modalService: ModalService) {
    this.addForm = this.fb.group({
      name:     [{value: '', disabled: true}, [Validators.required]],
      network1_vlan_id:   [null, [Validators.required]],
      network1_address:  ['', [Validators.required]],
      network2_vlan_id:  [null, [Validators.required]],
      network2_address:     ['', [Validators.required]]
    });
  }

  ngOnInit() {
    this.mdnsService.getMDNSs().subscribe(mdns => {
      this.mdnss = mdns
    });
    this.networkService.getNetworks().subscribe(networks => {
      this.networks = networks
    });

    this.addForm.get('network1_vlan_id')!.valueChanges.subscribe(() => this.updateName());
    this.addForm.get('network2_vlan_id')!.valueChanges.subscribe(() => this.updateName());
  }

  getNetworkByVLAN(vlan_id: number): Network | undefined {
    return this.networks.find(network => network.vlan_id === vlan_id);
  }

  maskToCidr(mask: string): number {
    return maskToCidr(mask);
  }

  toggleAdd() {
    this.adding = !this.adding;
    if (!this.adding) {
      this.addForm.reset();
    }
  }

  startMDNS(name: string) {
    this.mdnsService.startMDNS(name).subscribe({
      next: () => {
        this.ngOnInit();
      },
      error: err => {
        console.error(err);
      }
    });
  }

  stopMDNS(name: string) {
    this.mdnsService.stopMDNS(name).subscribe({
      next: () => {
        this.ngOnInit();
      },
      error: err => {
        console.error(err);
      }
    });
  }

  submitAdd() {
    if (this.addForm.invalid) {
      this.addForm.markAllAsTouched();
      return;
    }

    const network1 = this.getNetworkByVLAN(this.addForm.get('network1_vlan_id')!.value);
    const network2 = this.getNetworkByVLAN(this.addForm.get('network2_vlan_id')!.value);
    if (!network1 || !network2) {
      console.log("Networks not found");
      return;
    }

    const payload: MDNS = {
      name: this.addForm.get('name')!.value,
      network1: {
        vlan_id: this.addForm.get('network1_vlan_id')!.value,
        address: this.addForm.get('network1_address')!.value,
        mask: network1.mask
      },
      network2: {
        vlan_id: this.addForm.get('network2_vlan_id')!.value,
        address: this.addForm.get('network2_address')!.value,
        mask: network2.mask
      },
      status: false
    }
    this.mdnsService.addMDNS(payload).subscribe({
      next: () => {
        this.toggleAdd();
        this.ngOnInit();
      },
      error: err => {
        this.addError = err.error.detail;
        console.error(err);
      }
    });
  }

  deleteMDNS(name: string) {
    this.modalService.confirm("Wirklich löschen?", "Willst du diesen MDNS-Repeater wirklich löschen?").then(res => {
      if (res) {
        this.mdnsService.deleteMDNS(name).subscribe({
          next: () => {
            this.ngOnInit();
          },
          error: err => {
            console.error(err);
          }
        });
      }
    });
  }

  startEditMDNS(mdns: MDNS) {
    this.editName = mdns.name;
    this.editForm = this.fb.group({
      network1_address:  [mdns.network1.address ?? '', [Validators.required]],
      network2_address:     [mdns.network2.address ?? '', [Validators.required]]
    });
  }

  stopEditMDNS() {
    this.editName = null;
  }

  submitEdit() {
    if (this.editForm.invalid) {
      this.editForm.markAllAsTouched();
      return;
    }

    if (!this.editName) { return; }

    this.mdnsService.updateMDNS(this.editName, this.editForm.get('network1_address')!.value, this.editForm.get('network2_address')!.value).subscribe({
      next: () => {
        this.stopEditMDNS();
        this.ngOnInit();
      },
      error: err => {
        this.editError = err.error.detail;
        console.error(err);
      }
    });
  }

  private updateName() {
    const id1 = this.addForm.get('network1_vlan_id')!.value;
    const id2 = this.addForm.get('network2_vlan_id')!.value;
    const n1 = this.getNetworkByVLAN(id1)?.name;
    const n2 = this.getNetworkByVLAN(id2)?.name;

    if (n1 && n2) {
      // setzt den disabled-Name-Field-Wert
      this.addForm.get('name')!.setValue(`${n1}_${n2}`);
    } else {
      // leeren, falls eins fehlt
      this.addForm.get('name')!.setValue('');
    }
  }

}
