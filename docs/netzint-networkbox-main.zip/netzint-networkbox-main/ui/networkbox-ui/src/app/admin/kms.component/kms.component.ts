import { Component } from '@angular/core';

@Component({
  selector: 'app-kms.component',
  imports: [],
  templateUrl: './kms.component.html',
  styleUrl: './kms.component.scss'
})
export class KMSComponent {

}
