import { Component } from '@angular/core';
import { Container } from '../../interfaces/container.model';
import { ContainerService } from '../../services/containerservice';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { AutoScrollDirective } from '../../directives/autoscrolldirective';

interface ContainerLog {
  logLines: string[];
  logSub?: Subscription;
} 

@Component({
  selector: 'app-containers.component',
  imports: [CommonModule, AutoScrollDirective],
  templateUrl: './containers.component.html',
  styleUrl: './containers.component.scss'
})
export class ContainersComponent {

  containers: Container[] = [];
  container_logs: Record<string, ContainerLog> = {};

  constructor(private containerService: ContainerService) {}

  ngOnInit() {
    this.containerService.getContainers().subscribe(containers => {
      this.containers = containers;
    });
  }

  ngOnDestroy() {
    this.stopAllLogs();
  }

  showLogs(id: string) {
    this.stopAllLogs();

    if (!this.container_logs[id]) {
      this.container_logs[id] = { logLines: [] };
    } else {
      this.container_logs[id].logLines = [];
    }

    this.container_logs[id].logSub = this.containerService.getContainerLogs(id).subscribe({
      next: line => this.container_logs[id].logLines.push(line),
      error: err => this.container_logs[id].logLines.push('[Stream beendet]'),
    });
  }

  stopLog(id: string) { 
    if (!this.container_logs[id]) return;
    this.container_logs[id].logSub?.unsubscribe(); 
    delete this.container_logs[id];
  }

  private stopAllLogs() {
    for (let id in this.container_logs) {
      this.stopLog(id);
    }
  }

}
