import { Component } from '@angular/core';
import { Radius, RadiusCredentials, RadiusGroups, RadiusUpdate } from '../../interfaces/radius.model';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, FormGroup, ReactiveFormsModule, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { RadiusService } from '../../services/radiusservice';
import { maskToCidr, NetworksService, isIpInNetwork } from '../../services/networksservice';
import { Network } from '../../interfaces/network.model';
import { Authentication } from '../../interfaces/authentications.model';
import { AuthenticationService } from '../../services/authenticationservice';

@Component({
  selector: 'app-radius.component',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './radius.component.html',
  styleUrl: './radius.component.scss'
})
export class RadiusComponent {

  radiuss: Radius[] = [];
  networks: Network[] = [];
  authentications: Authentication[] = [];

  adding = false;
  addForm: FormGroup;
  addError: string = "";
  addAuthenticationGroups: string[] = [];

  editName: string | null = null;
  editForm!: FormGroup;
  editError: string = "";

  filteredGroupsAdd: Map<number, string[]> = new Map();
  filteredGroupsEdit: Map<number, string[]> = new Map();
  showDropdownAdd: Map<number, boolean> = new Map();
  showDropdownEdit: Map<number, boolean> = new Map();


  constructor(
    private radiusService: RadiusService, 
    private fb: FormBuilder,
    private networkService: NetworksService,
    private authenticationService: AuthenticationService
  ) {
    this.addForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(13), Validators.pattern('^[a-zA-Z0-9_-]*[a-zA-Z0-9_-]$')]],
      network_vlan_id: [0, Validators.required],
      network_address: ['', Validators.required],
      authentication: ['', Validators.required],
      samba_domain: ['', [Validators.required]],
      samba_domain_admin: ['', [Validators.required]],
      samba_domain_admin_password: ['', [Validators.required]],
      credentials: this.fb.array([]),
      groups: this.fb.array([])
    });
  }

  ngOnInit() {
    this.radiusService.getRadiuss().subscribe(radiuss => this.radiuss = radiuss);
    this.networkService.getNetworks().subscribe(networks => this.networks = networks);
    this.authenticationService.getAuthentications().subscribe(authentications => this.authentications = authentications);

    this.addCredential();

    // Add validator for IP in network
    this.addForm.get('network_vlan_id')!.valueChanges.subscribe(vlan_id => {
      const network = this.getNetworkByVLAN(vlan_id);
      const addressControl = this.addForm.get('network_address');
      
      if (network && addressControl) {
        addressControl.setValidators([
          Validators.required,
          (control: AbstractControl): ValidationErrors | null => {
            const ip = control.value;
            if (!ip) return null;
            
            if (!isIpInNetwork(ip, network.address, network.mask)) {
              return { ipNotInNetwork: { 
                message: `IP must be within network ${network.address}/${maskToCidr(network.mask)}`,
                network: network.address,
                mask: network.mask
              }};
            }
            return null;
          }
        ]);
        addressControl.updateValueAndValidity();
      }
    });

    this.addForm.get('authentication')!.valueChanges.subscribe(() => {
      if (this.addForm.get('authentication')?.value != "") {
        this.addForm.get('groups')!.reset();
        const groupsArr = this.addForm.get('groups') as FormArray;
        while (groupsArr.length) {
          groupsArr.removeAt(0);
        }
        this.addGroup();
        this.authenticationService.getAuthenticationGroups(this.addForm.get('authentication')?.value).subscribe(authentication_groups => {
          this.addAuthenticationGroups = authentication_groups;
          // Update filtered groups for all existing indices
          for (let i = 0; i < this.groupsArr.length; i++) {
            this.filteredGroupsAdd.set(i, authentication_groups);
          }
        });
      }
    });
  }

  filterGroups(value: string, context: 'add' | 'edit', index: number): void {
    const filterValue = value.toLowerCase();
    const groups = this.addAuthenticationGroups;
    const filtered = groups.filter(group => {
      const cn = this.getCN(group);
      const displayName = cn || group;
      return displayName.toLowerCase().includes(filterValue);
    });
    
    if (context === 'add') {
      this.filteredGroupsAdd.set(index, filtered);
      // Keep dropdown visible while typing
      if (this.showDropdownAdd.get(index)) {
        this.showDropdownAdd.set(index, true);
      }
    } else {
      this.filteredGroupsEdit.set(index, filtered);
      // Keep dropdown visible while typing
      if (this.showDropdownEdit.get(index)) {
        this.showDropdownEdit.set(index, true);
      }
    }
  }

  getFilteredGroups(context: 'add' | 'edit', index: number): string[] {
    const map = context === 'add' ? this.filteredGroupsAdd : this.filteredGroupsEdit;
    return map.get(index) || this.addAuthenticationGroups;
  }

  selectGroup(group: string, context: 'add' | 'edit', index: number): void {
    const formArray = context === 'add' ? this.groupsArr : this.groupsArrEdit;
    formArray.at(index).get('name')?.setValue(group);
    
    if (context === 'add') {
      this.showDropdownAdd.set(index, false);
    } else {
      this.showDropdownEdit.set(index, false);
    }
  }

  isDropdownVisible(context: 'add' | 'edit', index: number): boolean {
    const map = context === 'add' ? this.showDropdownAdd : this.showDropdownEdit;
    return map.get(index) || false;
  }

  onClickGroup(context: 'add' | 'edit', index: number): void {
    // Toggle dropdown on click
    const isCurrentlyVisible = this.isDropdownVisible(context, index);
    
    if (context === 'add') {
      this.filteredGroupsAdd.set(index, this.addAuthenticationGroups);
      this.showDropdownAdd.set(index, !isCurrentlyVisible);
    } else {
      this.filteredGroupsEdit.set(index, this.addAuthenticationGroups);
      this.showDropdownEdit.set(index, !isCurrentlyVisible);
    }
  }

  onBlurGroup(context: 'add' | 'edit', index: number): void {
    // Hide dropdown after a short delay to allow click on dropdown items
    setTimeout(() => {
      if (context === 'add') {
        this.showDropdownAdd.set(index, false);
      } else {
        this.showDropdownEdit.set(index, false);
      }
    }, 200);
  }

  toggleAdd() {
    this.adding = !this.adding;
    if (!this.adding) {
      this.addForm.reset();
      this.filteredGroupsAdd.clear();
    }
  }

  startRadius(name: string) {
    this.radiusService.startRadius(name).subscribe({
      next: () => {
        this.ngOnInit();
      },
      error: err => {
        console.error(err);
      }
    });
  }

  stopRadius(name: string) {
    this.radiusService.stopRadius(name).subscribe({
      next: () => {
        this.ngOnInit();
      },
      error: err => {
        console.error(err);
      }
    });
  }

  maskToCidr(mask: string): number {
    return maskToCidr(mask);
  }

  getCN(dn: string): string | null {
    const m = dn.match(/cn\s*=\s*([^,]+)\s*(?:,|$)/i);
    return m ? m[1].trim() : null;
  }

  getNetworkByVLAN(vlan_id: number): Network | undefined {
    return this.networks.find(network => network.vlan_id === vlan_id);
  }

  submitAdd() {
    if (this.addForm.invalid) {
      this.addForm.markAllAsTouched();
      return;
    }

    const network = this.getNetworkByVLAN(this.addForm.get('network_vlan_id')!.value);
    if (!network) {
      console.log("Network not found");
      return;
    }

    const payload: Radius = {
      name: this.addForm.get('name')!.value,
      network: {
        vlan_id: this.addForm.get('network_vlan_id')!.value,
        address: this.addForm.get('network_address')!.value,
        mask: network.mask
      },
      authentication: this.addForm.get('authentication')!.value,
      samba_domain: this.addForm.get('samba_domain')!.value,
      samba_domain_admin: this.addForm.get('samba_domain_admin')!.value,
      samba_domain_admin_password: this.addForm.get('samba_domain_admin_password')!.value,
      credentials: this.addForm.get('credentials')!.value,
      groups: this.addForm.get('groups')!.value,
      status: false
    }

    this.radiusService.addRadius(payload).subscribe({
      next: () => {
        this.toggleAdd();
        this.ngOnInit();
      },
      error: err => {
        this.addError = err.error.detail;
        console.error(err);
      }
    });
  }

  get credentialsArr(): FormArray<FormGroup> {
    return this.addForm.get('credentials') as FormArray<FormGroup>;
  }
  get groupsArr(): FormArray<FormGroup> {
    return this.addForm.get('groups') as FormArray<FormGroup>;
  }

  get credentialsArrEdit(): FormArray<FormGroup> {
    return this.editForm.get('credentials') as FormArray<FormGroup>;
  }
  get groupsArrEdit(): FormArray<FormGroup> {
    return this.editForm.get('groups') as FormArray<FormGroup>;
  }

  addCredential() {
    const fg = this.fb.group({
      network: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(4)]]
    });
    this.credentialsArr.push(fg);
  }
  removeCredential(i: number) { this.credentialsArr.removeAt(i); }

  addCredentialEdit() {
    const fg = this.fb.group({
      network: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(4)]]
    });
    this.credentialsArrEdit.push(fg);
  }
  removeCredentialEdit(i: number) { this.credentialsArrEdit.removeAt(i); }

  addGroup() {
    const fg = this.fb.group({
      name: ['', Validators.required],
      simultaneous_use: [1, [Validators.required, Validators.min(0)]],
      vlan_id: [0, [Validators.min(0), Validators.max(4094)]]
    });
    this.groupsArr.push(fg);
    const index = this.groupsArr.length - 1;
    this.filteredGroupsAdd.set(index, this.addAuthenticationGroups);
    this.showDropdownAdd.set(index, false); // Initially closed
  }
  removeGroup(i: number) { 
    this.groupsArr.removeAt(i);
    this.filteredGroupsAdd.delete(i);
  }

  addGroupEdit() {
    const fg = this.fb.group({
      name: ['', Validators.required],
      simultaneous_use: [1, [Validators.required, Validators.min(0)]],
      vlan_id: [0, [Validators.min(0), Validators.max(4094)]]
    });
    this.groupsArrEdit.push(fg);
    const index = this.groupsArrEdit.length - 1;
    this.filteredGroupsEdit.set(index, this.addAuthenticationGroups);
    this.showDropdownEdit.set(index, false); // Initially closed
  }
  removeGroupEdit(i: number) { 
    this.groupsArrEdit.removeAt(i);
    this.filteredGroupsEdit.delete(i);
  }

  deleteRadius(name: string) {
    this.radiusService.deleteRadius(name).subscribe({
      next: () => {
        this.ngOnInit();
      },
      error: err => {
        console.error(err);
      }
    });
  }

  startEditRadius(radius: Radius) {
    this.editName = radius.name;
    this.editForm = this.fb.group({
      network_vlan_id: [radius.network.vlan_id ?? 0, Validators.required],
      network_address: [radius.network.address ?? '', Validators.required],
      authentication: [radius.authentication ?? '', Validators.required],
      samba_domain: [radius.samba_domain ?? '', [Validators.required]],
      samba_domain_admin: [radius.samba_domain_admin ?? '', [Validators.required]],
      samba_domain_admin_password: [radius.samba_domain_admin_password ?? '', [Validators.required]],
      credentials: this.fb.array([]),
      groups: this.fb.array([])
    });
    const creds = radius.credentials && radius.credentials.length ? radius.credentials : [{} as RadiusCredentials];
    creds.forEach(c => this.credentialsArrEdit.push(this.createCredential(c)));

    const grps = radius.groups && radius.groups.length ? radius.groups : [{} as RadiusGroups];
    grps.forEach((g, index) => {
      this.groupsArrEdit.push(this.createGroupRow(g));
      this.filteredGroupsEdit.set(index, this.addAuthenticationGroups);
      this.showDropdownEdit.set(index, false); // Initially closed
    });

    // Add validator for IP in network for edit form
    this.editForm.get('network_vlan_id')!.valueChanges.subscribe(vlan_id => {
      const network = this.getNetworkByVLAN(vlan_id);
      const addressControl = this.editForm.get('network_address');
      
      if (network && addressControl) {
        addressControl.setValidators([
          Validators.required,
          (control: AbstractControl): ValidationErrors | null => {
            const ip = control.value;
            if (!ip) return null;
            
            if (!isIpInNetwork(ip, network.address, network.mask)) {
              return { ipNotInNetwork: { 
                message: `IP must be within network ${network.address}/${maskToCidr(network.mask)}`,
                network: network.address,
                mask: network.mask
              }};
            }
            return null;
          }
        ]);
        addressControl.updateValueAndValidity();
      }
    });

    // Trigger initial validation
    const initialNetwork = this.getNetworkByVLAN(radius.network.vlan_id ?? 0);
    if (initialNetwork) {
      const addressControl = this.editForm.get('network_address');
      if (addressControl) {
        addressControl.setValidators([
          Validators.required,
          (control: AbstractControl): ValidationErrors | null => {
            const ip = control.value;
            if (!ip) return null;
            
            if (!isIpInNetwork(ip, initialNetwork.address, initialNetwork.mask)) {
              return { ipNotInNetwork: { 
                message: `IP must be within network ${initialNetwork.address}/${maskToCidr(initialNetwork.mask)}`,
                network: initialNetwork.address,
                mask: initialNetwork.mask
              }};
            }
            return null;
          }
        ]);
      }
    }

    this.authenticationService.getAuthenticationGroups(this.editForm.get('authentication')?.value).subscribe(authentication_groups => {
      this.addAuthenticationGroups = authentication_groups;
      // Update all filtered groups with new data
      for (let i = 0; i < this.groupsArrEdit.length; i++) {
        this.filteredGroupsEdit.set(i, authentication_groups);
      }
    });
  }

  stopEditRadius() {
    this.editName = null;
    this.editForm.reset();
    this.filteredGroupsEdit.clear();
  }

  submitEdit() {
    if (this.editForm.invalid) {
      this.editForm.markAllAsTouched();
      return;
    }

    const network = this.getNetworkByVLAN(this.editForm.get('network_vlan_id')!.value);
    if (!network) {
      console.log("Network not found");
      return;
    }

    if (!this.editName) { return; }

    const payload: RadiusUpdate = {
      network: {
        vlan_id: this.editForm.get('network_vlan_id')!.value,
        address: this.editForm.get('network_address')!.value,
        mask: network.mask
      },
      authentication: this.editForm.get('authentication')!.value,
      samba_domain: this.editForm.get('samba_domain')!.value,
      samba_domain_admin: this.editForm.get('samba_domain_admin')!.value,
      samba_domain_admin_password: this.editForm.get('samba_domain_admin_password')!.value,
      credentials: this.editForm.get('credentials')!.value,
      groups: this.editForm.get('groups')!.value,
    }

    this.radiusService.updateRadius(this.editName, payload).subscribe({
      next: () => {
        this.stopEditRadius();
        this.ngOnInit();
      },
      error: err => {
        this.editError = err.error.detail;
        console.error(err);
      }
    });
  }

  private createCredential(c: Partial<RadiusCredentials> = {}): FormGroup {
    return this.fb.group({
      network: [c.network ?? '', Validators.required],
      password: [c.password ?? '', Validators.required],
    });
  }
  private createGroupRow(g: Partial<RadiusGroups> = {}): FormGroup {
    return this.fb.group({
      name: [g.name ?? '', Validators.required],
      simultaneous_use: [g.simultaneous_use ?? 1, [Validators.required, Validators.min(1)]],
      vlan_id: [g.vlan_id ?? 0, [Validators.min(0), Validators.max(4094)]]
    });
  }

}
