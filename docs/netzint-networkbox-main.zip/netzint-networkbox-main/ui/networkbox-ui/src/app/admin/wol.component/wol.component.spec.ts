import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WolComponent } from './wol.component';

describe('WolComponent', () => {
  let component: WolComponent;
  let fixture: ComponentFixture<WolComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [WolComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
