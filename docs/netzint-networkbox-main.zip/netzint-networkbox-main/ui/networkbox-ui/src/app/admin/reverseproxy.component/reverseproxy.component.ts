import { Component } from '@angular/core';

@Component({
  selector: 'app-reverseproxy.component',
  imports: [],
  templateUrl: './reverseproxy.component.html',
  styleUrl: './reverseproxy.component.scss'
})
export class ReverseproxyComponent {

}
