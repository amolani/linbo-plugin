import { Component, TemplateRef } from '@angular/core';
import { NetworksService, getSecondToLastIP } from '../../services/networksservice';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Network } from '../../interfaces/network.model';
import { InterfacesService } from '../../services/interfacesservice';
import { networkAddressValidator, ipInNetworkValidator } from '../../helper/validators';
import { ModalService } from '../../services/modal.service';
import { SophosService, SophosConnection } from '../../services/sophosservice';
import { SophosXGSNetworkVLAN } from '../../interfaces/sophos.model';

interface MaskOption {
  cidr: number;
  mask: string;
}

@Component({
  selector: 'app-networks.component',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './networks.component.html',
  styleUrl: './networks.component.scss'
})
export class NetworksComponent {

  networks: Network[] = [];
  interfaces: string[] = [];

  maskOptions: MaskOption[] = [];

  adding = false;
  addForm: FormGroup;
  addError: string = "";

  importing = false;
  importProgress = 0;
  importForm!: FormGroup;
  importedNetworks: SophosXGSNetworkVLAN[] = [];
  selectedNetworks: Set<number> = new Set();
  importError: string = "";
  loadingNetworks = false;
  networkInterfaces: Map<number, string> = new Map();  // Map vlan_id -> interface
  networkIpAddresses: Map<number, string> = new Map(); // Map vlan_id -> IP address

  constructor(private fb: FormBuilder, private networkService: NetworksService, private interfacesService: InterfacesService, private modalService: ModalService, private sophosService: SophosService) {
    this.addForm = this.fb.group({
      name:     ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9_-]*[a-zA-Z0-9_-]$')]],
      parent:   ['', [Validators.required]],
      vlan_id:  [null, [Validators.required, Validators.min(0)]],
      address:  ['', [Validators.required, networkAddressValidator('mask')]],
      mask:     ['', [Validators.required]],
      ip_address: ['', [Validators.required]]
    });

    // Update address validation when mask changes
    this.addForm.get('mask')!.valueChanges.subscribe(() => {
      this.addForm.get('address')!.updateValueAndValidity({ onlySelf: true });
      this.updateDefaultIP();
    });

    // Update default IP when address changes
    this.addForm.get('address')!.valueChanges.subscribe(() => {
      this.updateDefaultIP();
    });

    this.importForm = this.fb.group({
      source: ['sophos', Validators.required],
      hostname: ['', Validators.required],
      port: [4444, [Validators.required, Validators.min(1), Validators.max(65535)]],
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.networkService.getNetworks().subscribe(networks => {
      this.networks = networks
    });
    this.interfacesService.getInterfaces().subscribe(interfaces => {
      this.interfaces = interfaces
    });
    this.generateMaskOptions();
  }

  toggleAdd() {
    this.adding = !this.adding;
    if (!this.adding) {
      this.addForm.reset();
    }
  }

  submit() {
    if (this.addForm.invalid) {
      this.addForm.markAllAsTouched();
      return;
    }
    const payload = this.addForm.value as Network;
    this.networkService.addNetwork(payload).subscribe({
      next: () => {
        this.toggleAdd();
        this.ngOnInit();
      },
      error: err => {
        this.addError = err.error.detail;
        console.error(err);
      }
    });
  }

  deleteNetwork(vlan_id: number) {
    this.modalService.danger("Netzwerk löschen", "Sind Sie sicher, dass Sie das Netzwerk löschen wollen?", { confirmText: "Löschen" }).then(result => {
      if (result) {
        this.networkService.deleteNetwork(vlan_id).subscribe({
          next: () => {
            this.ngOnInit();
          },
          error: err => {
            console.error(err);
          }
        });
      }
    });
    
  }

  importNetworks(template: TemplateRef<any>) {
    this.importing = true;
    this.importedNetworks = [];
    this.selectedNetworks.clear();
    this.networkInterfaces.clear();
    this.networkIpAddresses.clear();
    this.importError = "";
    this.importForm.reset({
      source: 'sophos',
      port: 4444
    });
    this.modalService.show(template, { 
      size: 'xl', 
      showFooter: false,
      title: 'Netzwerke importieren',
      backdrop: 'static'
    });
  }

  loadNetworksFromSource() {
    if (this.importForm.invalid) {
      this.importForm.markAllAsTouched();
      return;
    }

    this.loadingNetworks = true;
    this.importError = "";
    
    const connection: SophosConnection = {
      hostname: this.importForm.get('hostname')?.value,
      port: this.importForm.get('port')?.value,
      username: this.importForm.get('username')?.value,
      password: this.importForm.get('password')?.value
    };

    this.sophosService.listNetworkVLANs(connection).subscribe({
      next: (networks) => {
        this.importedNetworks = networks;
        this.loadingNetworks = false;
        
        // Automatisch alle Netzwerke auswählen, die noch nicht existieren und Defaults setzen
        this.importedNetworks.forEach(net => {
          const netVlanId = Number(net.vlan_id);
          const exists = this.networks.find(n => Number(n.vlan_id) === netVlanId);
          
          // Set default interface for ALL networks
          this.networkInterfaces.set(netVlanId, this.interfaces[0] || 'eth0');
          // Calculate and set default IP (second-to-last in network)
          try {
            const defaultIP = getSecondToLastIP(net.address, net.mask);
            this.networkIpAddresses.set(netVlanId, defaultIP);
          } catch (e) {
            // If calculation fails, use network address + 1
            this.networkIpAddresses.set(netVlanId, net.address);
          }
          
          // Only select if it doesn't exist
          if (!exists) {
            this.selectedNetworks.add(netVlanId);
          }
        });
      },
      error: (err) => {
        this.importError = err.error?.detail || 'Fehler beim Laden der Netzwerke';
        this.loadingNetworks = false;
      }
    });
  }

  toggleNetworkSelection(vlanId: number) {
    const vlanIdNum = Number(vlanId);
    if (this.selectedNetworks.has(vlanIdNum)) {
      this.selectedNetworks.delete(vlanIdNum);
    } else {
      this.selectedNetworks.add(vlanIdNum);
    }
  }

  isNetworkSelected(vlanId: number): boolean {
    const vlanIdNum = Number(vlanId);
    return this.selectedNetworks.has(vlanIdNum);
  }

  networkExists(vlanId: number): boolean {
    // Convert to number to ensure proper comparison
    const vlanIdNum = Number(vlanId);
    return !!this.networks.find(n => Number(n.vlan_id) === vlanIdNum);
  }

  updateDefaultIP() {
    const address = this.addForm.get('address')?.value;
    const mask = this.addForm.get('mask')?.value;
    
    if (address && mask) {
      try {
        const defaultIP = getSecondToLastIP(address, mask);
        this.addForm.get('ip_address')?.setValue(defaultIP);
        
        // Add IP validation
        const ipControl = this.addForm.get('ip_address');
        if (ipControl) {
          ipControl.setValidators([
            Validators.required,
            (control) => {
              const ip = control.value;
              if (!ip) return null;
              
              // Create a temporary network object for validation
              const tempNetwork = {
                address: address,
                mask: mask,
                name: '',
                parent: '',
                vlan_id: 0
              };
              
              const validator = ipInNetworkValidator(tempNetwork, 'ip_address');
              return validator(this.addForm);
            }
          ]);
          ipControl.updateValueAndValidity();
        }
      } catch (e) {
        // Invalid network/mask combination
      }
    }
  }

  selectAllNetworks() {
    this.importedNetworks.forEach(net => {
      const vlanIdNum = Number(net.vlan_id);
      if (!this.networkExists(vlanIdNum)) {
        this.selectedNetworks.add(vlanIdNum);
      }
    });
  }

  deselectAllNetworks() {
    this.selectedNetworks.clear();
  }

  async performImport() {
    const networksToImport = this.importedNetworks.filter(net => 
      this.selectedNetworks.has(Number(net.vlan_id))
    );

    if (networksToImport.length === 0) {
      this.modalService.warning('Keine Auswahl', 'Bitte wählen Sie mindestens ein Netzwerk aus.');
      return;
    }

    const confirmed = await this.modalService.confirm(
      'Import bestätigen',
      `Möchten Sie ${networksToImport.length} Netzwerk(e) importieren?`
    );

    if (!confirmed) return;

    let successCount = 0;
    let errorCount = 0;
    const errors: string[] = [];

    for (const sophos_net of networksToImport) {
      const vlanIdNum = Number(sophos_net.vlan_id);
      const network: Network = {
        name: sophos_net.name,
        parent: this.networkInterfaces.get(vlanIdNum) || this.interfaces[0] || 'eth0',
        vlan_id: vlanIdNum,
        address: sophos_net.address,
        mask: sophos_net.mask,
        ip_address: this.networkIpAddresses.get(vlanIdNum)
      };

      try {
        await this.networkService.addNetwork(network).toPromise();
        successCount++;
      } catch (err: any) {
        errorCount++;
        console.log("Error: " + err)
        errors.push(`${sophos_net.name}: ${err.error?.detail || 'Unbekannter Fehler'}`);
      }

    }

    // this.modalService.close(true);
    console.log(errorCount)
    
    if (errorCount > 0) {
      await this.modalService.warning(
        'Import teilweise erfolgreich',
        `${successCount} Netzwerk(e) importiert, ${errorCount} fehlgeschlagen:\n${errors.join('\n')}`
      );
    } else {
      await this.modalService.success(
        'Import erfolgreich',
        `${successCount} Netzwerk(e) wurden erfolgreich importiert.`
      );
    }

    this.ngOnInit(); // Netzwerkliste neu laden
    this.importing = false;
  }

  cancelImport() {
    this.modalService.close(false);
    this.importing = false;
  }

  private generateMaskOptions() {
    this.maskOptions = Array.from({ length: 33 }, (_, cidr) => {
      const maskInt = cidr === 0
        ? 0
        : 0xffffffff << (32 - cidr);
      const octets = [
        (maskInt >>> 24) & 0xff,
        (maskInt >>> 16) & 0xff,
        (maskInt >>> 8) & 0xff,
        maskInt & 0xff
      ];
      return {
        cidr,
        mask: octets.join('.')
      };
    });
  }

}
