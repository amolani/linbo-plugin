import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-wol.component',
  imports: [],
  templateUrl: './wol.component.html',
  styleUrl: './wol.component.scss'
})
export class WOLComponent {

  wol_script: string = "";

  constructor(private http: HttpClient) {}

  ngOnInit() {
    let currentUrl = window.location.protocol + '//' + window.location.hostname + ':' + window.location.port;

    this.http.get('wol_script.readme', { responseType: 'text' }).subscribe(data => {
      this.wol_script = data.replaceAll('<CURRENT_URL>', currentUrl);
    })
  }

  copy() {
    navigator.clipboard.writeText(this.wol_script);
  }

}
