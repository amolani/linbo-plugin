import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MdnsComponent } from './mdns.component';

describe('MdnsComponent', () => {
  let component: MdnsComponent;
  let fixture: ComponentFixture<MdnsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MdnsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MdnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
