import { Component } from '@angular/core';
import { NetworksService } from '../../services/networksservice';
import { Network } from '../../interfaces/network.model';
import { ARPScanResult } from '../../interfaces/result.model';
import { ContainerService } from '../../services/containerservice';
import { Container } from '../../interfaces/container.model';
import { CommonModule } from '@angular/common';
import { NAPIService } from '../../services/napiservice';

@Component({
  selector: 'app-home.component',
  imports: [CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {
  networks: Network[] = [];
  containers: Container[] = [];
  arpscanresult: [number, {ip: string, mac: string, hostname: string, vendor: string}[]][] = [];

  network_scanner: any;

  constructor(
    private networkService: NetworksService,
    private containerService: ContainerService,
    private napiService: NAPIService
  ) {}

  ngOnInit() {
    this.networkService.getNetworks().subscribe(networks => {
      this.networks = networks;
      this.scanNetworks();
    });
    this.containerService.getContainers().subscribe(containers => {
      this.containers = containers
    });

    this.network_scanner = setInterval(() => this.scanNetworks(), 0.5 * 60 * 1000); // every 30 seconds
  }

  ngOnDestroy() {
    clearInterval(this.network_scanner);
  }

  containersByNetwork(net: { name: string }) {
    const key = 'NETWORKBOX_' + net.name;
    return this.containers.filter(c =>
      Array.isArray(c.networks) &&
      c.networks.some((n: any) =>
        typeof n === 'string' ? n === key : n?.network === key
      )
    );
  }

  ipInNetwork(container: any, net: { name: string }): string | null {
    const key = 'NETWORKBOX_' + net.name;
    const entry = container?.networks?.find((n: any) =>
      typeof n === 'string' ? n === key : n?.network === key
    );
    return typeof entry === 'string' ? null : (entry?.ip ?? null);
  }


  arpscanByNetwork(net: { vlan_id: number }): {ip: string, mac: string, hostname: string, vendor: string}[] {
    const hit = this.arpscanresult.find(([vlan]) => vlan === net.vlan_id);
    if (!hit) return [];
    
    return hit[1].filter(a => 
      !this.containers.some(c => 
        c.networks.some((n: any) => 
          typeof n === 'string' ? false : n.ip === a.ip
        )
      )
    );
  }

  scanNetworks() {
    this.networks.forEach(net => {
      this.napiService.arpScan(net.vlan_id).subscribe(result => {
        this.arpscanresult.push([net.vlan_id, result.hosts]);
      })
    })
  }

}
