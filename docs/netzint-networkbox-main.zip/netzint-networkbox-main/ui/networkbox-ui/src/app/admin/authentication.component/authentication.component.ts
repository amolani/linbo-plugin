import { Component } from '@angular/core';
import { Authentication } from '../../interfaces/authentications.model';
import { AuthenticationService } from '../../services/authenticationservice';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { APIResponse } from '../../interfaces/response.model';

@Component({
  selector: 'app-authentication.component',
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './authentication.component.html',
  styleUrl: './authentication.component.scss'
})
export class AuthenticationComponent {

  authentications: Authentication[] = [];
  authentications_status: Record<string, boolean> = {};

  adding = false;
  addForm: FormGroup;
  addError: string = "";

  editName: string | null = null;
  editForm!: FormGroup;
  editError: string = "";

  constructor(private authenticationService: AuthenticationService, private fb: FormBuilder) {
    this.addForm = this.fb.group({
      name:     ['', [Validators.required]],
      server:  ['', [Validators.required]],
      port:     [null, [Validators.required, Validators.min(1), Validators.max(65535)]],
      use_ssl:  [false, [Validators.required]],
      validate_cert:  [false, [Validators.required]],
      binduser: ['', [Validators.required]],
      password: ['', [Validators.required]],
      basedn: ['', [Validators.required]],
      userfilter: ['', []]
    });
  }

  ngOnInit() {
    this.authenticationService.getAuthentications().subscribe(authentications => {
      this.authentications = authentications;
      this.authentications.forEach(authentication => {
        this.testAuthentication(authentication.name);
      })
    });
  }

  toggleAdd() {
    this.adding = !this.adding;
    if (!this.adding) {
      this.addForm.reset();
    }
  }

  testAuthentication(name: string) {
    this.authenticationService.testAuthentication(name).subscribe({
      next: (result: APIResponse) => {
        const auth = this.authentications.find(auth => auth.name === name);
        if (auth) {
          auth.status = result.status;
          auth.status_message = result.message;
        }
      },
      error: err => {
        const auth = this.authentications.find(auth => auth.name === name);
        if (auth) {
          auth.status = false;
        }
        console.error(err);
      }
    });
  }

  submitAdd() {
    if (this.addForm.invalid) {
      this.addForm.markAllAsTouched();
      return;
    }
    const payload = this.addForm.value as Authentication;
    this.authenticationService.addAuthentication(payload).subscribe({
      next: () => {
        this.toggleAdd();
        this.ngOnInit();
      },
      error: err => {
        this.addError = err.error.detail;
        console.error(err);
      }
    });
  }

  deleteAuthentication(name: string) {
    this.authenticationService.deleteAuthentication(name).subscribe({
      next: () => {
        this.ngOnInit();
      },
      error: err => {
        console.error(err);
      }
    });
  }

  startEditAuthentication(authentication: Authentication) {
      this.editName = authentication.name;
      this.editForm = this.fb.group({
        server:  [authentication.server ?? '', [Validators.required]],
        port:     [authentication.port ?? null, [Validators.required, Validators.min(1), Validators.max(65535)]],
        use_ssl:  [authentication.use_ssl ?? false, [Validators.required]],
        validate_cert:  [authentication.validate_cert ?? false, [Validators.required]],
        binduser: [authentication.binduser ?? '', [Validators.required]],
        password: [authentication.password ?? '', [Validators.required]],
        basedn: [authentication.basedn ?? '', [Validators.required]],
        userfilter: [authentication.userfilter ?? '', []]
      });
    }
  
    stopEditAuthentication() {
      this.editName = null;
    }
  
    submitEdit() {
      if (this.editForm.invalid) {
        this.editForm.markAllAsTouched();
        return;
      }

      if (!this.editName) { return; }

      const payload = this.editForm.value as Authentication;
      this.authenticationService.updateAuthentication(this.editName, payload).subscribe({
        next: () => {
          this.stopEditAuthentication();
          this.ngOnInit();
        },
        error: err => {
          this.editError = err.error.detail;
          console.error(err);
        }
      });
    }

}
