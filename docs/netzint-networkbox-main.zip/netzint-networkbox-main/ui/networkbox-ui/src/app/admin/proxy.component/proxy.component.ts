import { Component } from '@angular/core';

@Component({
  selector: 'app-proxy.component',
  imports: [],
  templateUrl: './proxy.component.html',
  styleUrl: './proxy.component.scss'
})
export class ProxyComponent {

}
