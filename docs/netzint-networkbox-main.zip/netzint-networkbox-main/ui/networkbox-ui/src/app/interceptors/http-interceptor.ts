import { HttpInterceptorFn } from '@angular/common/http';
import { JWT_TOKEN_KEY } from '../services/authservice';

export const httpInterceptor: HttpInterceptorFn = (req, next) => {
  const authToken = localStorage.getItem(JWT_TOKEN_KEY);

  let authReq = req;

  if (authToken) {
    authReq = req.clone({
        setHeaders: { Authorization: `Bearer ${authToken}` },
        withCredentials: true
      });
  } else {
    authReq = req.clone({ withCredentials: true });
  }

  return next(authReq);
};
