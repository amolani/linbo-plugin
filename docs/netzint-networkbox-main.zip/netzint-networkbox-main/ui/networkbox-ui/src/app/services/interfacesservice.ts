import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InterfacesService {
  private apiUrl = '/api/v1/interfaces';

  constructor(private http: HttpClient) {}

  getInterfaces(): Observable<string[]> {
      return this.http.get<string[]>(this.apiUrl);
  }
}
