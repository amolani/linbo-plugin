import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { APIResponse } from '../interfaces/response.model';
import { ARPScanResult, PINGScanResult } from '../interfaces/result.model';

@Injectable({
  providedIn: 'root'
})
export class NAPIService {

  private apiUrl = '/api/v1/napi';

  constructor(private http: HttpClient) {}

  getNAPIStatus(): Observable<APIResponse> {
    return this.http.get<APIResponse>(`${this.apiUrl}/status`);
  }

  startNAPI(): Observable<APIResponse> {
    return this.http.post<APIResponse>(`${this.apiUrl}/start`, {});
  }

  stopNAPI(): Observable<APIResponse> {
    return this.http.post<APIResponse>(`${this.apiUrl}/stop`, {});
  }

  wake(macaddress: string): Observable<APIResponse> {
    return this.http.post<APIResponse>(`${this.apiUrl}/wake`, {"mac": macaddress});
  }

  arpScan(vlan_id: number): Observable<ARPScanResult> {
    return this.http.post<ARPScanResult>(`${this.apiUrl}/arp-scan`, {"vlan_id": vlan_id});
  }

  pingScan(vlan_id: number): Observable<PINGScanResult> {
    return this.http.post<PINGScanResult>(`${this.apiUrl}/ping-scan`, {"vlan_id": vlan_id});
  }
}
