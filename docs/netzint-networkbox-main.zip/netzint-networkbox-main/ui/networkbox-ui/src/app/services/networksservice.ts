import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Network } from '../interfaces/network.model';
import { APIResponse } from '../interfaces/response.model';

@Injectable({
  providedIn: 'root'
})
export class NetworksService {
  private apiUrl = '/api/v1/networks';

  constructor(private http: HttpClient) {}

  getNetworks(): Observable<Network[]> {
      return this.http.get<Network[]>(this.apiUrl);
  }

  getNetwork(vlan_id: number): Observable<Network> {
      return this.http.get<Network>(`${this.apiUrl}/${vlan_id}`);
  }

  addNetwork(n: Partial<Network>): Observable<APIResponse> {
      return this.http.post<APIResponse>(this.apiUrl, n);
  }

  updateNetwork(vlan_id: number, n: Partial<Network>): Observable<APIResponse> {
      return this.http.patch<APIResponse>(`${this.apiUrl}/${vlan_id}`, n);
  }

  deleteNetwork(vlan_id: number): Observable<APIResponse> {
      return this.http.delete<APIResponse>(`${this.apiUrl}/${vlan_id}`);
  }
}

/**
 * Wandelt eine IPv4-Subnetzmaske in die entsprechende CIDR-Präfixlänge um.
 * @param mask IPv4-Maske als String, z.B. "255.255.255.0"
 * @returns Präfixlänge (0–32) oder wirft einen Error bei ungültiger Maske
 */
export function maskToCidr(mask: string): number {
  const octets = mask.split('.').map(o => parseInt(o, 10));

  if (octets.length !== 4 || octets.some(o => isNaN(o) || o < 0 || o > 255)) {
    throw new Error(`Ungültige Maske: ${mask}`);
  }

  let bitCount = 0;
  let passedZero = false;

  for (const octet of octets) {
    // Zähle Einsen in jedem Oktett
    for (let i = 7; i >= 0; i--) {
      const bit = (octet >> i) & 1;
      if (bit === 1) {
        if (passedZero) {
          throw new Error(`Maske ist nicht zusammenhängend: ${mask}`);
        }
        bitCount++;
      } else {
        passedZero = true;
      }
    }
  }

  return bitCount;
}

export function ipv4ToInt(ip: string): number {
  return ip.split('.')
    .map(o => {
      const n = Number(o);
      if (n < 0 || n > 255 || Number.isNaN(n)) {
        throw new Error(`Ungültiges Oktett in IP: ${o}`);
      }
      return n;
    })
    .reduce((acc, oct) => (acc << 8) | oct, 0) >>> 0;
}

/**
 * Wandelt eine Punkt-Notation-Maske (z.B. "255.255.255.0") in einen 32-Bit-Masken-Integer um.
 */
export function maskToInt(mask: string): number {
  return ipv4ToInt(mask);
}

export function intToIpv4(n: number): string {
  return [
    (n >>> 24) & 255,
    (n >>> 16) & 255,
    (n >>> 8) & 255,
    n & 255,
  ].join('.');
}

/**
 * Prüft, ob die IP `ip` im Netzwerk `network` mit der Maske `mask` liegt.
 * @param ip       IP-Adresse als String (z.B. "10.1.0.5")
 * @param network  Netzwerk-Adresse als String (z.B. "10.1.0.0")
 * @param mask     Subnetz-Maske als String (z.B. "255.255.255.0")
 * @returns        true, wenn ip im Netz liegt, sonst false
 */
export function isIpInNetwork(ip: string, network: string, mask: string): boolean {
  const ipInt = ipv4ToInt(ip);
  const netInt = ipv4ToInt(network);
  const maskInt = maskToInt(mask);

  return (ipInt & maskInt) === (netInt & maskInt);
}

/**
 * Berechnet die vorletzte IP-Adresse eines Netzwerks (typisch für Router/Gateway)
 * @param network  Netzwerk-Adresse als String (z.B. "10.1.0.0")
 * @param mask     Subnetz-Maske als String (z.B. "255.255.255.0")
 * @returns        Die vorletzte IP des Netzwerks (z.B. "10.1.0.254")
 */
export function getSecondToLastIP(network: string, mask: string): string {
  const netInt = ipv4ToInt(network);
  const maskInt = maskToInt(mask);
  
  // Berechne Broadcast-Adresse
  const broadcastInt = netInt | (~maskInt >>> 0);
  
  // Vorletzte IP = Broadcast - 1
  const secondToLastInt = broadcastInt - 2;
  
  return intToIpv4(secondToLastInt);
}