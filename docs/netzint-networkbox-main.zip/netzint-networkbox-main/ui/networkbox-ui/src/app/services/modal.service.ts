import { Injectable, TemplateRef } from '@angular/core';
import { Subject } from 'rxjs';

export interface ModalConfig {
  title?: string;
  message?: string;
  template?: TemplateRef<any>;
  templateContext?: any;
  confirmText?: string;
  cancelText?: string;
  confirmClass?: string;
  size?: 'sm' | 'lg' | 'xl' | '';
  centered?: boolean;
  backdrop?: boolean | 'static';
  keyboard?: boolean;
  scrollable?: boolean;
  fullscreen?: boolean | 'sm-down' | 'md-down' | 'lg-down' | 'xl-down' | 'xxl-down';
  showFooter?: boolean;
}

export interface ModalResult {
  confirmed: boolean;
  data?: any;
}

@Injectable({
  providedIn: 'root'
})
export class ModalService {
  private modalSubject = new Subject<ModalConfig | null>();
  private resultSubject = new Subject<ModalResult>();
  
  modal$ = this.modalSubject.asObservable();
  result$ = this.resultSubject.asObservable();

  /**
   * Show a confirmation modal with OK/Cancel buttons
   */
  confirm(title: string, message: string, options?: Partial<ModalConfig>): Promise<boolean> {
    return new Promise((resolve) => {
      this.modalSubject.next({
        title,
        message,
        confirmText: 'OK',
        cancelText: 'Abbrechen',
        confirmClass: 'btn-primary',
        showFooter: true,
        backdrop: 'static',
        ...options
      });

      const subscription = this.result$.subscribe(result => {
        resolve(result.confirmed);
        subscription.unsubscribe();
      });
    });
  }

  /**
   * Show an alert modal with only OK button
   */
  alert(title: string, message: string, options?: Partial<ModalConfig>): Promise<void> {
    return new Promise((resolve) => {
      this.modalSubject.next({
        title,
        message,
        confirmText: 'OK',
        confirmClass: 'btn-primary',
        showFooter: true,
        ...options
      });

      const subscription = this.result$.subscribe(() => {
        resolve();
        subscription.unsubscribe();
      });
    });
  }

  /**
   * Show a danger confirmation modal
   */
  danger(title: string, message: string, options?: Partial<ModalConfig>): Promise<boolean> {
    return this.confirm(title, message, {
      confirmClass: 'btn-danger',
      confirmText: 'Löschen',
      ...options
    });
  }

  /**
   * Show a custom template in a modal
   */
  show(template: TemplateRef<any>, options?: Partial<ModalConfig>): Promise<ModalResult> {
    return new Promise((resolve) => {
      this.modalSubject.next({
        template,
        confirmText: 'OK',
        cancelText: 'Abbrechen',
        confirmClass: 'btn-primary',
        showFooter: true,
        backdrop: 'static',
        ...options
      });

      const subscription = this.result$.subscribe(result => {
        resolve(result);
        subscription.unsubscribe();
      });
    });
  }

  /**
   * Close the current modal
   */
  close(confirmed: boolean = false, data?: any) {
    this.resultSubject.next({ confirmed, data });
    this.modalSubject.next(null);
  }

  /**
   * Simple info modal
   */
  info(title: string, message: string): Promise<void> {
    return this.alert(title, message, {
      confirmClass: 'btn-info'
    });
  }

  /**
   * Simple success modal
   */
  success(title: string, message: string): Promise<void> {
    return this.alert(title, message, {
      confirmClass: 'btn-success'
    });
  }

  /**
   * Simple warning modal
   */
  warning(title: string, message: string): Promise<void> {
    return this.alert(title, message, {
      confirmClass: 'btn-warning'
    });
  }

  /**
   * Simple error modal
   */
  error(title: string, message: string): Promise<void> {
    return this.alert(title, message, {
      confirmClass: 'btn-danger'
    });
  }
}