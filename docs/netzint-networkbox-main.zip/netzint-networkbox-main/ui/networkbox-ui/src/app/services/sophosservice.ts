import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { SophosXGSNetworkVLAN } from '../interfaces/sophos.model';

export interface SophosConnection {
  hostname: string;
  port: number;
  username: string;
  password: string;
}

@Injectable({
  providedIn: 'root'
})
export class SophosService {
  private apiUrl = '/api/v1/sophos';

  constructor(private http: HttpClient) {}

  listNetworkVLANs(connection: SophosConnection): Observable<SophosXGSNetworkVLAN[]> {
      return this.http.post<SophosXGSNetworkVLAN[]>(`${this.apiUrl}/network/vlans/list`, connection);
  }
}
