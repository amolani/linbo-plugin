import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Authentication } from '../interfaces/authentications.model';
import { APIResponse } from '../interfaces/response.model';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private apiUrl = '/api/v1/authentications';

  constructor(private http: HttpClient) {}

  getAuthentications(): Observable<Authentication[]> {
    return this.http.get<Authentication[]>(this.apiUrl);
  }

  getAuthentication(name: string): Observable<Authentication> {
    return this.http.get<Authentication>(`${this.apiUrl}/${name}`);
  }

  addAuthentication(n: Partial<Authentication>): Observable<APIResponse> {
    return this.http.post<APIResponse>(this.apiUrl, n);
  }

  updateAuthentication(name: string, n: Partial<Authentication>): Observable<APIResponse> {
    return this.http.patch<APIResponse>(`${this.apiUrl}/${name}`, n);
  }

  deleteAuthentication(name: string): Observable<APIResponse> {
    return this.http.delete<APIResponse>(`${this.apiUrl}/${name}`);
  }

  testAuthentication(name: string): Observable<APIResponse> {
    return this.http.post<APIResponse>(`${this.apiUrl}/${name}/test`, {});
  }

  getAuthenticationGroups(name: string): Observable<string[]> {
    return this.http.get<string[]>(`${this.apiUrl}/${name}/get/groups`);
  }
}
