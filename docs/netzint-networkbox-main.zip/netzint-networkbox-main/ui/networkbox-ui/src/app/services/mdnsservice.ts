import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MDNS, MDNSCluster } from '../interfaces/mdns.model';
import { APIResponse } from '../interfaces/response.model';

@Injectable({
  providedIn: 'root'
})
export class MDNSService {
  private apiUrl = '/api/v1/mdns';

  constructor(private http: HttpClient) {}

  getMDNSs(): Observable<MDNS[]> {
      return this.http.get<MDNS[]>(this.apiUrl);
  }

  getMDNSsCluster(): Observable<MDNSCluster> {
      return this.http.get<MDNSCluster>(`${this.apiUrl}/cluster`);
  }

  getMDNS(name: string): Observable<MDNS> {
      return this.http.get<MDNS>(`${this.apiUrl}/${name}`);
  }

  addMDNS(n: Partial<MDNS>): Observable<APIResponse> {
      return this.http.post<APIResponse>(this.apiUrl, n);
  }

  updateMDNS(name: string, network1_address: string, network2_address: string): Observable<APIResponse> {
      return this.http.patch<APIResponse>(`${this.apiUrl}/${name}`, {network1_address, network2_address});
  }

  deleteMDNS(name: string): Observable<APIResponse> {
      return this.http.delete<APIResponse>(`${this.apiUrl}/${name}`);
  }

  startMDNS(name: string): Observable<APIResponse> {
      return this.http.post<APIResponse>(`${this.apiUrl}/${name}/start`, {});
  }

  stopMDNS(name: string): Observable<APIResponse> {
      return this.http.post<APIResponse>(`${this.apiUrl}/${name}/stop`, {});
  }
}
