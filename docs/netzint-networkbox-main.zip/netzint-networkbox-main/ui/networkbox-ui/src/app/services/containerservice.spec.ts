import { TestBed } from '@angular/core/testing';

import { Containerservice } from './containerservice';

describe('Containerservice', () => {
  let service: Containerservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Containerservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
