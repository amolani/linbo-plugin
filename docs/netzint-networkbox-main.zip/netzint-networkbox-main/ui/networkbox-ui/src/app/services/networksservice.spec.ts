import { TestBed } from '@angular/core/testing';

import { Networksservice } from './networksservice';

describe('Networksservice', () => {
  let service: Networksservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Networksservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
