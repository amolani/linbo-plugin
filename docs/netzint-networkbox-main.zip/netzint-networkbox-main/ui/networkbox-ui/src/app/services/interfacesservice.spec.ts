import { TestBed } from '@angular/core/testing';

import { Interfacesservice } from './interfacesservice';

describe('Interfacesservice', () => {
  let service: Interfacesservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Interfacesservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
