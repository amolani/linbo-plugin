import { TestBed } from '@angular/core/testing';

import { Radiusservice } from './radiusservice';

describe('Radiusservice', () => {
  let service: Radiusservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Radiusservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
