# Modal Service Usage Examples

## In einer Komponente verwenden

```typescript
import { Component } from '@angular/core';
import { ModalService } from '../services/modal.service';

@Component({
  // ...
})
export class ExampleComponent {
  
  constructor(private modalService: ModalService) {}

  // Einfache Bestätigung
  async deleteItem() {
    const confirmed = await this.modalService.confirm(
      'Löschen bestätigen',
      'Möchten Sie diesen Eintrag wirklich löschen?'
    );
    
    if (confirmed) {
      // Löschvorgang durchführen
    }
  }

  // Gefahr-Modal (rot)
  async deleteDatabase() {
    const confirmed = await this.modalService.danger(
      'Datenbank löschen',
      'Diese Aktion kann nicht rückgängig gemacht werden!'
    );
    
    if (confirmed) {
      // Datenbank löschen
    }
  }

  // Info-Modal (nur OK-Button)
  async showInfo() {
    await this.modalService.info(
      'Information',
      'Der Vorgang wurde erfolgreich abgeschlossen.'
    );
  }

  // Erfolgs-Modal
  async showSuccess() {
    await this.modalService.success(
      'Erfolg!',
      'Die Daten wurden gespeichert.'
    );
  }

  // Warnung-Modal
  async showWarning() {
    await this.modalService.warning(
      'Warnung',
      'Die Verbindung ist instabil.'
    );
  }

  // Fehler-Modal
  async showError() {
    await this.modalService.error(
      'Fehler',
      'Ein unerwarteter Fehler ist aufgetreten.'
    );
  }

  // Modal mit Optionen
  async showCustomModal() {
    const confirmed = await this.modalService.confirm(
      'Große Modal',
      'Dies ist eine große, zentrierte Modal.',
      {
        size: 'lg',
        centered: true,
        confirmText: 'Speichern',
        cancelText: 'Verwerfen'
      }
    );
  }

  // Template-basierte Modal (für komplexe Inhalte)
  async showTemplateModal(template: TemplateRef<any>) {
    const result = await this.modalService.show(template, {
      title: 'Benutzer bearbeiten',
      confirmText: 'Speichern',
      size: 'lg'
    });
    
    if (result.confirmed) {
      // Mit result.data arbeiten
    }
  }
}
```

## Template-Beispiel in HTML

```html
<!-- Template für komplexe Modal-Inhalte -->
<ng-template #userEditTemplate>
  <form>
    <div class="mb-3">
      <label class="form-label">Name</label>
      <input type="text" class="form-control form-control-dark">
    </div>
    <div class="mb-3">
      <label class="form-label">E-Mail</label>
      <input type="email" class="form-control form-control-dark">
    </div>
  </form>
</ng-template>

<!-- Button zum Öffnen -->
<button (click)="showTemplateModal(userEditTemplate)" class="btn btn-primary">
  Benutzer bearbeiten
</button>
```

## Modal-Optionen

- `title`: Modal-Titel
- `message`: Einfache Textnachricht
- `template`: Template für komplexe Inhalte
- `templateContext`: Kontext für das Template
- `confirmText`: Text für Bestätigen-Button (default: "OK")
- `cancelText`: Text für Abbrechen-Button (default: "Abbrechen")
- `confirmClass`: CSS-Klasse für Bestätigen-Button (default: "btn-primary")
- `size`: Modal-Größe ('sm', 'lg', 'xl', '')
- `centered`: Modal vertikal zentrieren
- `backdrop`: Hintergrund ('static' = nicht schließbar durch Klick)
- `keyboard`: ESC-Taste zum Schließen
- `scrollable`: Scrollbarer Inhalt
- `fullscreen`: Vollbild-Modal
- `showFooter`: Footer mit Buttons anzeigen

## Integration in bestehende Komponenten

Beispiel für RADIUS-Komponente:

```typescript
async deleteRadius(name: string) {
  const confirmed = await this.modalService.danger(
    'RADIUS-Server löschen',
    `Möchten Sie den RADIUS-Server "${name}" wirklich löschen?`,
    {
      confirmText: 'Endgültig löschen'
    }
  );
  
  if (confirmed) {
    this.radiusService.deleteRadius(name).subscribe({
      next: () => {
        this.ngOnInit();
        this.modalService.success('Gelöscht', 'Der RADIUS-Server wurde erfolgreich gelöscht.');
      },
      error: err => {
        this.modalService.error('Fehler', err.error.detail || 'Löschen fehlgeschlagen');
      }
    });
  }
}
```