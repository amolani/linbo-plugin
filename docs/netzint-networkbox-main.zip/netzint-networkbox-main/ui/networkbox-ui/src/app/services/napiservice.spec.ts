import { TestBed } from '@angular/core/testing';

import { Napiservice } from './napiservice';

describe('Napiservice', () => {
  let service: Napiservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Napiservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
