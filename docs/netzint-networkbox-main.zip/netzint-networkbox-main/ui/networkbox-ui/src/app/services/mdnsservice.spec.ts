import { TestBed } from '@angular/core/testing';

import { Mdnsservice } from './mdnsservice';

describe('Mdnsservice', () => {
  let service: Mdnsservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Mdnsservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
