import { TestBed } from '@angular/core/testing';

import { Sophosservice } from './sophosservice';

describe('Sophosservice', () => {
  let service: Sophosservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Sophosservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
