import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MDNS } from '../interfaces/mdns.model';
import { APIResponse } from '../interfaces/response.model';
import { Radius, RadiusUpdate } from '../interfaces/radius.model';

@Injectable({
  providedIn: 'root'
})
export class RadiusService {
  private apiUrl = '/api/v1/radius';

  constructor(private http: HttpClient) {}

  getRadiuss(): Observable<Radius[]> {
      return this.http.get<Radius[]>(this.apiUrl);
  }

  getRadius(name: string): Observable<Radius> {
      return this.http.get<Radius>(`${this.apiUrl}/${name}`);
  }

  addRadius(n: Partial<Radius>): Observable<APIResponse> {
      return this.http.post<APIResponse>(this.apiUrl, n);
  }

  updateRadius(name: string, n: RadiusUpdate): Observable<APIResponse> {
      return this.http.patch<APIResponse>(`${this.apiUrl}/${name}`, n);
  }

  deleteRadius(name: string): Observable<APIResponse> {
      return this.http.delete<APIResponse>(`${this.apiUrl}/${name}`);
  }

  startRadius(name: string): Observable<APIResponse> {
      return this.http.post<APIResponse>(`${this.apiUrl}/${name}/start`, {});
  }

  stopRadius(name: string): Observable<APIResponse> {
      return this.http.post<APIResponse>(`${this.apiUrl}/${name}/stop`, {});
  }
}
