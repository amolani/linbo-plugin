import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, map, Observable, of, tap } from 'rxjs';

import * as jwt_decode from "jwt-decode";

export const JWT_TOKEN_KEY = 'networkbox_jwt_token'

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private refreshTimer: any;
  
  constructor(private http: HttpClient, private router: Router) {
    this.startTokenMonitor();
  }

  login(username: string, password: string) : Observable<boolean> {
    return this.http.post<{ access_token: string }>('/api/v1/login', { username, password }, { withCredentials: true }).pipe(
      map(response => {
        this.setToken(response.access_token)
        return true;
      }),
      catchError(error => {
        return of(false);
      })
    )
  }

  refresh() : Observable<string> {
    return this.http.post<{ access_token: string }>('/api/v1/refresh', {}, { withCredentials: true }).pipe(
      map(response => response.access_token)
    );
  }

  changePassword(currentPassword: string, newPassword: string): Observable<boolean> {
    return this.http.post('/api/v1/change-password', { current_password: currentPassword, new_password: newPassword }).pipe(
      map(() => true),
      catchError(() => of(false))
    );
  }

  logout() : void {
    clearInterval(this.refreshTimer);
    localStorage.removeItem(JWT_TOKEN_KEY);
    this.router.navigate(['/login']);
  }

  isTokenValid() : boolean {
    const currentTime = Math.floor(Date.now() / 1000);
    const expiration = this.getExpiration();

    if (expiration) {
      return expiration > currentTime;
    }
    return false;
  }

  getToken() : string | null {
    if (typeof localStorage === 'undefined') {
      return null;
    }
    return localStorage.getItem(JWT_TOKEN_KEY);
  }

  private setToken(token: string) {
    localStorage.setItem(JWT_TOKEN_KEY, token);
  }

  private getExpiration() : number | null | undefined {
    let token = this.getToken();
    if (token) {
      return jwt_decode.jwtDecode(token)["exp"];
    }
    return null;
  }

  private startTokenMonitor() {
    this.refreshTimer = setInterval(() => {
      const exp = this.getExpiration();
      const now = Date.now();

      if(exp && exp - now < 5 * 60 * 1000) {
        this.refresh().subscribe({
          next: token => this.setToken(token),
          error: () => this.logout()
        });
      }
    }, 2 * 60 * 1000);
  }

}
