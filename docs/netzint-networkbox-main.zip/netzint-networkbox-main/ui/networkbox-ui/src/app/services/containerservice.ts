import { HttpClient } from '@angular/common/http';
import { Injectable, NgZone } from '@angular/core';
import { Observable } from 'rxjs';
import { Container } from '../interfaces/container.model';
import { AuthService } from './authservice';

@Injectable({
  providedIn: 'root'
})
export class ContainerService {
  private apiUrl = '/api/v1/containers';

  constructor(private http: HttpClient, private authService: AuthService, private zone: NgZone) {}

  getContainers(): Observable<Container[]> {
    return this.http.get<Container[]>(`${this.apiUrl}`);
  }

  getContainerLogs(name: string): Observable<string> {
    return new Observable<string>(observer => {
      const es = new EventSource(`${this.apiUrl}/${name}/logs?token=${this.authService.getToken()}`, { withCredentials: false });

      es.onmessage = (ev) => {
        this.zone.run(() => observer.next(ev.data as string));
      };
      es.onerror = (err) => {
        this.zone.run(() => observer.error(err));
        es.close();
      };

      return () => es.close();
    });
  }

}
