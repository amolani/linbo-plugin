export interface APIResponse {
    status: boolean,
    message: string,
    error?: string
}