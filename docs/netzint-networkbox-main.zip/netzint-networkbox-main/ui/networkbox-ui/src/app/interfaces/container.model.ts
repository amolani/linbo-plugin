export interface Container {
    id: string
    image: string
    name: string
    status: string
    labels: string
    networks: ContainerNetwork[]
}

export interface ContainerNetwork {
    network: string
    ip: string
}