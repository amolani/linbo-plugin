export interface Network {
    name: string
    parent: string
    vlan_id: number
    address: string
    mask: string
    ip_address?: string  // Optional IP address for the interface
}