export interface RadiusGroups {
    name: string;
    simultaneous_use: number;
    vlan_id?: number
}

export interface RadiusCredentials {
    network: string;
    password: string;
    show_pw?: boolean
}

export interface RadiusNetwork {
    vlan_id: number
    address: string
    mask: string
}

export interface Radius {
    name: string;
    network: RadiusNetwork;
    authentication: string;
    samba_domain: string;
    samba_domain_admin: string;
    samba_domain_admin_password: string;
    credentials: RadiusCredentials[];
    groups: RadiusGroups[];
    status: boolean;
    show_pw?: boolean
}

export interface RadiusUpdate {
    network: RadiusNetwork;
    authentication: string;
    samba_domain: string;
    samba_domain_admin: string;
    samba_domain_admin_password: string;
    credentials: RadiusCredentials[];
    groups: RadiusGroups[];
}