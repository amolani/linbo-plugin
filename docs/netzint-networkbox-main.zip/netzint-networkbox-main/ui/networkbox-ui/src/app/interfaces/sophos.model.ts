export interface SophosXGSNetworkVLAN {
    name: string
    vlan_id: number
    address: string
    mask: string
}