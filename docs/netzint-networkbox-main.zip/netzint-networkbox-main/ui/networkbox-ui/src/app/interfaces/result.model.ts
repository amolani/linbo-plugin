export interface ARPScanResult {
    hosts: {ip: string, mac: string, hostname: string, vendor: string}[]
}

export interface PINGScanResult {
    hosts: string[]
    reachable: string[]
}