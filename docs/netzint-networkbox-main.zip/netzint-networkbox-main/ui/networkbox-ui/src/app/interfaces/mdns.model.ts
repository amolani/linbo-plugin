import { Edge, Node } from "@swimlane/ngx-graph"

export interface MDNS {
    name: string
    network1: MDNSNetwork
    network2: MDNSNetwork
    status: boolean
}

export interface MDNSNetwork {
    vlan_id: number
    address: string
    mask: string
}

export interface MDNSCluster {
    nodes: Node[]
    links: Edge[]
}
    
// export interface MDNSClusterNode {
//     id: string
//     label: string
// }

// export interface MDNSClusterLink {
//     source: string
//     target: string
//     id: string
//     label: string
// }