export interface Authentication {
    name: string
    server: string
    port: number
    use_ssl: boolean
    validate_cert: boolean
    binduser: string
    password: string
    basedn: string
    userfilter: string
    status?: boolean
    status_message?: string
    show_pw?: boolean
}