import { Component, OnInit, OnDestroy, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalService, ModalConfig } from '../../services/modal.service';
import { Subscription } from 'rxjs';

declare var bootstrap: any;

@Component({
  selector: 'app-modal',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="modal fade" #modal tabindex="-1" [attr.data-bs-backdrop]="config?.backdrop ?? 'static'" [attr.data-bs-keyboard]="config?.keyboard ?? false">
      <div class="modal-dialog" 
           [class.modal-sm]="config?.size === 'sm'"
           [class.modal-lg]="config?.size === 'lg'"
           [class.modal-xl]="config?.size === 'xl'"
           [class.modal-dialog-centered]="config?.centered"
           [class.modal-dialog-scrollable]="config?.scrollable"
           [class.modal-fullscreen]="config?.fullscreen === true"
           [class.modal-fullscreen-sm-down]="config?.fullscreen === 'sm-down'"
           [class.modal-fullscreen-md-down]="config?.fullscreen === 'md-down'"
           [class.modal-fullscreen-lg-down]="config?.fullscreen === 'lg-down'"
           [class.modal-fullscreen-xl-down]="config?.fullscreen === 'xl-down'"
           [class.modal-fullscreen-xxl-down]="config?.fullscreen === 'xxl-down'">
        <div class="modal-content bg-dark text-light">
          <div class="modal-header" *ngIf="config?.title">
            <h5 class="modal-title">{{ config?.title }}</h5>
            <button type="button" class="btn-close btn-close-white" (click)="cancel()" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p *ngIf="config?.message">{{ config?.message }}</p>
            <ng-container *ngIf="config?.template">
              <ng-container *ngTemplateOutlet="config?.template; context: config?.templateContext || {}"></ng-container>
            </ng-container>
          </div>
          <div class="modal-footer" *ngIf="config?.showFooter !== false">
            <button type="button" class="btn btn-secondary" (click)="cancel()" *ngIf="config?.cancelText">
              {{ config?.cancelText }}
            </button>
            <button type="button" class="btn" [ngClass]="config?.confirmClass || 'btn-primary'" (click)="confirm()">
              {{ config?.confirmText || 'OK' }}
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ModalComponent implements OnInit, OnDestroy {
  @ViewChild('modal', { static: true }) modalElement!: ElementRef;
  
  config: ModalConfig | null = null;
  modal: any;
  subscription!: Subscription;

  constructor(private modalService: ModalService) {}

  ngOnInit() {
    this.modal = new bootstrap.Modal(this.modalElement.nativeElement);
    
    this.subscription = this.modalService.modal$.subscribe(config => {
      this.config = config;
      if (config) {
        this.modal.show();
      } else {
        this.modal.hide();
      }
    });

    // Handle modal hidden event
    this.modalElement.nativeElement.addEventListener('hidden.bs.modal', () => {
      if (this.config) {
        this.modalService.close(false);
      }
    });
  }

  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
    if (this.modal) {
      this.modal.dispose();
    }
  }

  confirm() {
    this.modalService.close(true);
  }

  cancel() {
    this.modalService.close(false);
  }
}