import { AbstractControl, FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';
import { Network } from '../interfaces/network.model';
import { isIpInNetwork, ipv4ToInt, maskToInt, intToIpv4 } from '../services/networksservice';

export function ipInNetworkValidator(
  network: Network,
  ipField: string
): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const ip = group.get(ipField)?.value;

    if (!isIpInNetwork(ip, network.address, network.mask)) {
      group.get(ipField)?.setErrors({ ipNotInNetwork: { value: ip } });
      return { ipNotInNetwork: true };
    }
    const errs = group.get(ipField)?.errors;
    if (errs && errs['ipNotInNetwork']) {
      delete errs['ipNotInNetwork'];
      if (Object.keys(errs).length === 0) {
        group.get(ipField)?.setErrors(null);
      }
    }
    return null;
  };
}

export function networkAddressValidator(maskControlName: string): ValidatorFn {
  return (control: AbstractControl) => {
    const ipStr = control.value;
    if (!ipStr) return null; // andere Validatoren (required) übernehmen das
    const parent = control.parent as FormGroup | null;
    const maskCtrl = parent?.get(maskControlName);
    const maskVal = maskCtrl?.value;

    const ipInt = ipv4ToInt(ipStr);
    const maskInt = maskToInt(maskVal as any);

    if (ipInt == null || maskInt == null) return null; // erst prüfen, wenn beides gültig

    const networkInt = ipInt & maskInt;
    return (networkInt === ipInt)
      ? null
      : { notNetworkAddress: { requiredNetwork: intToIpv4(networkInt) } };
  };
}
