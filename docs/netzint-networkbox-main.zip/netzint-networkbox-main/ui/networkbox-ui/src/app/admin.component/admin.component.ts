import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AuthService } from '../services/authservice';
import { NAPIService } from '../services/napiservice';
import { APP_VERSION } from '../version';

@Component({
  selector: 'app-admin.component',
  imports: [CommonModule, RouterModule, FormsModule],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.scss'
})
export class AdminComponent {

  napiStatus: boolean | null = null;
  napiStatusString: string | null = null;
  napiLoading: boolean = true;

  showPasswordForm = false;
  passwordCurrent = '';
  passwordNew = '';
  passwordMessage = '';
  passwordError = false;

  footer_text = `${APP_VERSION.name} | v${APP_VERSION.version}`;

  constructor(private authService: AuthService, private napiService: NAPIService) {}

  ngOnInit() {
    this.napiService.getNAPIStatus().subscribe(response => {
      this.napiStatus = response.status;
      this.napiStatusString = response.message;
      this.napiLoading = false;
    });
  }

  logout() {
    this.authService.logout();
  }

  togglePasswordForm() {
    this.showPasswordForm = !this.showPasswordForm;
    this.passwordCurrent = '';
    this.passwordNew = '';
    this.passwordMessage = '';
  }

  submitPasswordChange() {
    if (!this.passwordCurrent || !this.passwordNew) return;
    this.authService.changePassword(this.passwordCurrent, this.passwordNew).subscribe(success => {
      if (success) {
        this.passwordError = false;
        this.passwordMessage = 'Passwort erfolgreich geändert';
        this.passwordCurrent = '';
        this.passwordNew = '';
      } else {
        this.passwordError = true;
        this.passwordMessage = 'Fehler: Aktuelles Passwort falsch';
      }
    });
  }

  startNAPI() {
    this.napiLoading = true;
    this.napiService.startNAPI().subscribe(response => {
      console.log(response);
      this.ngOnInit();
    });
  }

  stopNAPI() {
    this.napiLoading = true;
    this.napiService.stopNAPI().subscribe(response => {
      console.log(response);
      this.ngOnInit();
    });
  }


  toggleNAPI() {
    if (this.napiStatus) {
      this.stopNAPI();
    } else {
      this.startNAPI();
    }
  }
}
