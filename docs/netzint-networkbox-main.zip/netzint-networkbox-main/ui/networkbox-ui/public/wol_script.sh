#!/usr/bin/env bash
set -euo pipefail

# Ziel-API (per ENV überschreibbar)
source /etc/netzint-networkbox/networkbox.conf
API_URL="${API_URL:-https://netzint-networkbox}"
API_URL="${API_URL}/api/v1/napi/wake"

# Defaults wie beim üblichen WOL
IP="255.255.255.255"
PORT=9

usage() {
  cat >&2 <<EOF
Usage: $(basename "$0") [-i ip] [-p port] MAC
z.B.:  $(basename "$0") -i 255.255.255.255 -p 9 aa:bb:cc:aa:bb:cc
Optionen:
  -i   Broadcast/Ziel-IP (Default: 255.255.255.255)
  -p   UDP-Port (Default: 9)
  -h   Hilfe
EOF
  exit 1
}

while getopts ":i:p:h" opt; do
  case "$opt" in
    i) IP="$OPTARG" ;;
    p) PORT="$OPTARG" ;;
    h) usage ;;
    \?) echo "Unbekannte Option: -$OPTARG" >&2; usage ;;
    :)  echo "Option -$OPTARG benötigt ein Argument." >&2; usage ;;
  esac
done
shift $((OPTIND-1))

# MAC ist Pflicht
if [ $# -lt 1 ]; then
  echo "Fehlende MAC-Adresse." >&2
  usage
fi
MAC="$1"

# --- einfache Validierungen ---
# Port
if ! [[ "$PORT" =~ ^[0-9]{1,5}$ ]] || [ "$PORT" -lt 1 ] || [ "$PORT" -gt 65535 ]; then
  echo "Ungültiger Port: $PORT" >&2; exit 2
fi

# IPv4 grob prüfen
if ! [[ "$IP" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
  echo "Ungültige IPv4: $IP" >&2; exit 2
fi
IFS='.' read -r o1 o2 o3 o4 <<< "$IP"
for o in "$o1" "$o2" "$o3" "$o4"; do
  if ! [[ "$o" =~ ^[0-9]+$ ]] || [ "$o" -gt 255 ]; then
    echo "Ungültige IPv4: $IP" >&2; exit 2
  fi
done

# MAC-Formate akzeptieren: aa:bb:..., aa-bb-..., aabbccddeeff
if ! [[ "$MAC" =~ ^([[:xdigit:]]{2}[:-]){5}[[:xdigit:]]{2}$|^[[:xdigit:]]{12}$ ]]; then
  echo "Ungültiges MAC-Format: $MAC" >&2; exit 2
fi
# 12-stellige Hex in aa:bb:cc:dd:ee:ff umwandeln (nur kosmetisch)
if [[ "$MAC" =~ ^[[:xdigit:]]{12}$ ]]; then
  MAC="$(echo "$MAC" | sed -E 's/../&:/g; s/:$//')"
fi

# JSON bauen
JSON=$(printf '{"ip":"%s","mac":"%s","port":%d}' "$IP" "$MAC" "$PORT")

# Request senden
TMP_RESP="$(mktemp)"
HTTP_STATUS=$(curl -sS -o "$TMP_RESP" -w "%{http_code}" \
  -X POST "$API_URL" \
  -H "Content-Type: application/json" \
  --data "$JSON" \
  --connect-timeout 2)

if [ "$HTTP_STATUS" -ge 200 ] && [ "$HTTP_STATUS" -lt 300 ]; then
  cat "$TMP_RESP"; echo
  rm -f "$TMP_RESP"
  exit 0
else
  cat "$TMP_RESP" >&2 || true
  rm -f "$TMP_RESP"
  exit 1
fi
