# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Netzint-NetworkBOX is a multi-service network management platform with features including:
- WakeOnLAN Server
- mDNS Repeater
- RADIUS Server (with Linuxmuster/LDAP backend)
- Container management interface
- Network scanning and monitoring

## Architecture

### Backend (FastAPI)
- **Location**: `/api/app/`
- **Main API**: `api.py` - FastAPI application with JWT authentication
- **Database**: MongoDB via `database.py` using pymongo
- **Service modules**:
  - `mdns.py` - mDNS repeater container management
  - `radius.py` - RADIUS server container management
  - `sophos.py` - Sophos XGS certificate management
  - `cron.py` - Scheduled tasks
- **Models**: `models.py` - Pydantic models for API requests/responses
- **Dependencies**: FastAPI, uvicorn, docker, pymongo, python-jose, ldap3, xmltodict, cryptography

### Frontend (Angular)
- **Location**: `/ui/networkbox-ui/`
- **Framework**: Angular 20.1 with TypeScript
- **Key directories**:
  - `src/app/admin/` - Admin feature components (authentication, containers, networks, radius, etc.)
  - `src/app/services/` - Angular services for API communication
  - `src/app/interfaces/` - TypeScript interfaces/models
  - `src/app/guards/` - Route guards for authentication

### Docker Setup
- Three main containers: API, UI, and MongoDB database
- Development mode uses volume mounts for hot reloading
- Production images available at `ghcr.io/netzint/networkbox-*`

## Development Commands

### Backend (API)
```bash
# Start API in development mode (from project root)
docker compose up networkbox-api

# API runs on port 8000 with auto-reload
# Access at: http://localhost:8000
```

### Frontend (Angular UI)
```bash
# Navigate to UI directory
cd ui/networkbox-ui

# Install dependencies
npm install

# Start development server with proxy to API
npm start

# Build for production
npm run build

# Run unit tests
npm test
```

### Docker Compose
```bash
# Start all services
docker compose up -d

# View logs
docker compose logs -f

# Stop services
docker compose down
```

## Environment Configuration

Create a `.env` file in the project root with:
- `NETWORKBOX_JWT_SECRET` - JWT signing secret
- `NETWORKBOX_DB_USERNAME` - MongoDB username
- `NETWORKBOX_DB_PASSWORD` - MongoDB password
- `NETWORKBOX_DB_DATABASE` - MongoDB database name (default: networkbox)
- `NETWORKBOX_USERNAME` - Admin login username
- `NETWORKBOX_PASSWORD` - Admin login password

## API Authentication

The API uses JWT tokens with:
- Access token lifetime: 60 minutes
- Refresh token lifetime: 7 days
- OAuth2 password bearer scheme
- Tokens stored in cookies for UI, bearer tokens for API calls

## Key API Endpoints

- `/api/v1/login` - User authentication
- `/api/v1/mdns/*` - mDNS repeater management
- `/api/v1/radius/*` - RADIUS server management
- `/api/v1/containers/*` - Docker container management
- `/api/v1/networks/*` - Network interface management
- `/api/v1/authentications/*` - Authentication provider management

## Database Schema

MongoDB collections:
- `mdns` - mDNS repeater configurations
- `radius` - RADIUS server configurations
- `authentications` - Authentication provider settings

## Container Management

The application manages Docker containers for services like mDNS repeaters and RADIUS servers. It uses the Docker SDK to create, start, stop, and monitor containers dynamically based on user configuration.